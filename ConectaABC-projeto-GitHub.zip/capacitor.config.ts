import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "br.com.sad.conectaabc",
  appName: "Conecta ABC",
  webDir: "out",
  backgroundColor: "#101110",
  ios: { contentInset: "automatic" },
};

export default config;
