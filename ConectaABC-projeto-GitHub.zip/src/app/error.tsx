"use client";
import Link from "next/link";

export default function ErrorPage({ retry }: { error: unknown; retry: () => void }) {
  return <main className="beta-error panel" role="alert">
    <h1>Não foi possível abrir esta tela</h1>
    <p>Tente novamente. Se o problema continuar, use “Ajuda e relatar problema” para avisar a equipe.</p>
    <p>Se um envio foi interrompido, confira Meus envios antes de repetir.</p>
    <div className="button-row"><button className="primary-btn" onClick={retry}>Tentar novamente</button><Link className="secondary-btn" href="/">Voltar ao início</Link></div>
  </main>;
}
