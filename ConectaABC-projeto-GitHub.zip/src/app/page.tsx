"use client";

import { Fragment, useCallback, useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import Image from "next/image";
import Link from "next/link";
import type { SupabaseClient, User } from "@supabase/supabase-js";
import {
  AlertTriangle,
  Ellipsis,
  LockKeyhole,
  ArrowLeft,
  ArrowUpRight,
  BadgePercent,
  Bell,
  Briefcase,
  BookOpen,
  Building2,
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  Copy,
  IdCard,
  FileText,
  Flag,
  Handshake,
  Heart,
  House,
  ImagePlus,
  Inbox,
  Lock,
  MapPin,
  MessageSquare,
  PawPrint,
  Search,
  Share2,
  Settings,
  ShieldCheck,
  Sparkles,
  Star,
  Store,
  Trophy,
  UserRound,
  UsersRound,
  Video,
  X,
  type LucideIcon,
} from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { animalReportSchema, cityReportSchema, communityPostSchema, marketplaceListingSchema, officialPostSchema, socialServiceRequestSchema } from "@/lib/validation";
import { AuthPanel } from "@/components/AuthPanel";
import { useSupabaseAuth } from "@/lib/supabase/use-auth";
import { CommunityProfileEditor, PublicMemberProfile, PresenceHeartbeat } from "@/components/CommunityProfile";
import { OfficialMediaPublisher } from "@/components/OfficialMediaPublisher";
import { SeasonRanking, LevelSettings, type MemberLevel, type MemberProgress } from "@/components/LevelFeatures";
import { useCommunityResource } from "@/lib/use-community-resource";
import { usePersonalPostVisibility } from "@/lib/use-personal-post-visibility";
import { ReactionPicker } from "@/components/ReactionPicker";
import { ActivitySummary, MemberBadges } from "@/components/ActivitySummary";
import { ContentReportModeration } from "@/components/ContentReports";
import { Coupons, ValidateCoupon } from "@/components/Coupons";
import { AccountPrivacy, AccountDeletionQueue } from "@/components/AccountPrivacy";
import { CampaignDrafts, InactiveCampaigns } from "@/components/CampaignDrafts";
import { GlobalSearch, TopWeek } from "@/components/GlobalSearch";
import { Recommendations, RecommendationModeration } from "@/components/Recommendations";
import { Utilities } from "@/components/Utilities";
import { InstallApp } from "@/components/InstallApp";
import { ExtendedClassifieds } from "@/components/ExtendedClassifieds";
import { Stories } from "@/components/Stories";
import { PlaceReviewModeration } from "@/components/PlaceParticipation";
import { MyMarketListings, ListingBadges, type ListingExtras } from "@/components/MarketplaceFeatures";
import { BusinessDirectory } from "@/components/BusinessDirectory";
import { useVisualExamples, VisualExamplesBanner, ExampleHighlights } from "@/components/VisualExamples";
import { HomeOverview } from "@/components/HomeOverview";
import {ReferenceRightRail} from "@/components/ReferenceRightRail";
import { HomeFeedSection, homeFeedGroups } from "@/components/HomeFeedSections";
import { EventAgenda } from "@/components/EventAgenda";
import { CommunityHub } from "@/components/CommunityHub";
import { SocialFeaturesProvider, SocialWorkspace, PostSocialActions } from "@/components/SocialFeatures";
import { SocialShell, CreateSheet } from "@/components/SocialShell";
import { selectPublicPosts, type SocialCollection } from "@/lib/social-feed";
import { ExploreMap } from "@/components/ExploreMap";

const sectionNames = ["stories","denuncias-equipe","cupons-equipe","cupons-portal","validar-cupom","dados","exclusoes-equipe","campanhas","campanhas-equipe","indica","indica-equipe","utilidades","utilidades-equipe","top","imoveis","vagas","achados","classificados-equipe","stories-equipe","avaliacoes-equipe","empresas","empresas-equipe","membro","midia-equipe","niveis-equipe","cupons","agenda-equipe","enquetes","comunidades","comunidade-equipe","amigos","salvos","notificacoes","comentarios-equipe","explorar","busca","agora","agenda","noticias","mais","mapa","inicio","feed","clube","parceiros","mercadao","animais","pontua","cidade","servicos","envios","portal","admin","perfil"] as const;
type Section = typeof sectionNames[number];
type FeedTab = "comunidade" | "oficial";
type Access = { is_admin: boolean; is_city_moderator: boolean; is_service_provider: boolean; is_referral_verifier: boolean };
type FeedPost = { id: string; author: string; authorId?: string; authorAvatarUrl?: string; city: string; category: string; title?: string; body: string; source?: string; official: boolean; sensitive: boolean; anonymous?: boolean; mediaPath?: string; mediaUrl?: string; mediaKind?: "image" | "video"; createdAt: string; likes: number; liked: boolean; demo: boolean; status?: "pending" | "approved" | "rejected" | "hidden" };
type PublicCommunityPostRow = { id: string; author_id: string | null; category: string; city: string; body: string; status: FeedPost["status"]; created_at: string; title: string | null; source: string | null; sensitive: boolean; is_official: boolean; is_anonymous: boolean; media_path: string | null; media_kind: "image" | "video" | null };
type FeedPostDraft = Pick<FeedPost, "author" | "city" | "category" | "body" | "official" | "sensitive"> & Partial<Pick<FeedPost, "title" | "source">>;
type CommunityPostSubmission = { draft: FeedPostDraft; anonymous: boolean; mediaFile: File | null };
type CityReportRecord = { id: string; category: string; city: string; neighborhood: string | null; description: string; status: "pending" | "review" | "in_progress" | "resolved" | "rejected"; createdAt: string; media_path?: string | null; media_url?: string };
type CityReportDbRow = Omit<CityReportRecord, "createdAt" | "media_url"> & { created_at: string };

const submissionMediaBucket = "submission-media";
const maxSubmissionImageSize = 20 * 1024 * 1024;

async function uploadSubmissionImage(client: SupabaseClient, userId: string, file: File) {
  if (!new Set(["image/jpeg", "image/png", "image/webp"]).has(file.type)) return { path: null, error: "Envie uma imagem JPG, PNG ou WebP." };
  if (file.size > maxSubmissionImageSize) return { path: null, error: "A imagem deve ter no máximo 20 MB." };
  const extension = file.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
  const path = `${userId}/${crypto.randomUUID()}.${extension}`;
  const { error } = await client.storage.from(submissionMediaBucket).upload(path, file, { contentType: file.type, cacheControl: "3600", upsert: false });
  if (error) return { path: null, error: error.message.includes("Bucket not found") ? "O envio de fotos ainda não está configurado no servidor. A equipe precisa executar a migração 202611040002_submission_images.sql no Supabase." : "Não foi possível enviar a imagem. Confira a conexão e tente novamente." };
  return { path, error: null };
}

async function hydrateSubmissionImages<T extends { media_path?: string | null }>(client: SupabaseClient, rows: T[]) {
  const paths = [...new Set(rows.flatMap((row) => row.media_path ? [row.media_path] : []))];
  if (!paths.length) return rows as (T & { media_url?: string })[];
  const { data, error } = await client.storage.from(submissionMediaBucket).createSignedUrls(paths, 60 * 60);
  if (error || !data) return rows as (T & { media_url?: string })[];
  const urls = new Map(data.map((item) => [item.path, item.signedUrl]));
  return rows.map((row) => ({ ...row, media_url: row.media_path ? urls.get(row.media_path) ?? undefined : undefined }));
}

const navItems: { id: Section; label: string; icon: LucideIcon; count?: string }[] = [
  { id: "inicio", label: "Início", icon: House },
  { id: "feed", label: "Feed", icon: MessageSquare },
  { id: "clube", label: "Clube de benefícios", icon: Star },
  { id: "parceiros", label: "Parceiros e ofertas", icon: Handshake },
  { id: "mercadao", label: "Mercadão", icon: Store },
  { id: "animais", label: "Animais Perdidos", icon: PawPrint },
  { id: "pontua", label: "Meu progresso", icon: Sparkles },
  { id: "perfil", label: "Carteirinha", icon: IdCard },
  { id: "cidade", label: "Problemas da cidade", icon: MapPin },
  { id: "servicos", label: "Serviços", icon: ClipboardList },
  { id: "envios", label: "Meus envios", icon: Inbox },
  { id: "portal", label: "Portal do parceiro", icon: ArrowUpRight },
  { id: "admin", label: "Administração", icon: Settings },
];

const cities = ["Todas as cidades", "Santo André", "São Bernardo do Campo", "São Caetano do Sul", "Diadema", "Mauá", "Ribeirão Pires", "Rio Grande da Serra"];
const dailyMissionIdeas = [
  { title: "Curta uma publicação do Feed", detail: "Apoie uma publicação aprovada de outra pessoa. Cada publicação pontua uma única vez.", icon: Heart, section: "feed" as Section },
  { title: "Publique algo útil para o bairro", detail: "Compartilhe uma dica ou iniciativa. A publicação, por si só, não concede pontos.", icon: MessageSquare, section: "feed" as Section },
  { title: "Confira o Notícias do ABC", detail: "Veja um comunicado oficial novo ou atualizado.", icon: Bell, section: "feed" as Section },
  { title: "Acompanhe um problema da cidade", detail: "Confira se houve atualização em um relato que você acompanha.", icon: MapPin, section: "cidade" as Section },
  { title: "Ajude um animal a voltar para casa", detail: "Compartilhe um anúncio ativo de animal perdido ou encontrado.", icon: PawPrint, section: "animais" as Section },
  { title: "Conheça um serviço disponível", detail: "Consulte uma orientação ou iniciativa de apoio à comunidade.", icon: ClipboardList, section: "servicos" as Section },
];

async function hydrateFeedAuthors(client: SupabaseClient, posts: FeedPost[]) {
  const postIds = posts.filter((post) => !post.official && !post.anonymous).map((post) => post.id);
  if (!postIds.length) return posts;

  const { data, error } = await client.rpc("social_feed_authors", { post_ids: postIds });
  if (error || !data?.length) return posts;

  const authors = new Map((data as { post_id: string; first_name: string | null; avatar_path: string | null }[])
    .map((row) => [row.post_id, row]));
  const paths = [...new Set([...authors.values()].flatMap((row) => row.avatar_path ? [row.avatar_path] : []))];
  const urls = new Map<string, string>();
  if (paths.length) {
    const { data: signedUrls } = await client.storage.from("member-avatars").createSignedUrls(paths, 600);
    for (const item of signedUrls ?? []) {
      if (item.path && item.signedUrl) urls.set(item.path, item.signedUrl);
    }
  }

  return posts.map((post) => {
    if (post.official || post.anonymous) return post;
    const author = authors.get(post.id);
    return {
      ...post,
      author: author?.first_name || post.author,
      authorAvatarUrl: author?.avatar_path ? urls.get(author.avatar_path) : undefined,
    };
  });
}

async function hydrateFeedMedia(client: SupabaseClient, posts: FeedPost[]) {
  posts = posts.map(post => post.anonymous && post.status === "approved" && post.mediaKind ? { ...post, mediaPath: undefined, mediaUrl: `${process.env.NEXT_PUBLIC_SUPABASE_URL?.trim()}/functions/v1/public-media?post=${encodeURIComponent(post.id)}` } : post);
  const paths = [...new Set(posts.flatMap((post) => post.mediaPath ? [post.mediaPath] : []))];
  if (!paths.length) return posts;
  const { data, error } = await client.storage.from("feed-media").createSignedUrls(paths, 60 * 60);
  if (error || !data) return posts;
  const urls = new Map(data.map((item) => [item.path, item.signedUrl]));
  return posts.map((post) => ({ ...post, mediaUrl: post.mediaPath ? urls.get(post.mediaPath) ?? undefined : post.mediaUrl }));
}

async function loadFeedPosts(client: SupabaseClient, sharedId: string | null) {
  const { data, error } = await client.rpc("list_public_community_posts");
  if (error) throw error;
  const rows: PublicCommunityPostRow[] = [...(data ?? [])];
  if (sharedId && /^[0-9a-f-]{36}$/i.test(sharedId) && !rows.some((row) => row.id === sharedId)) {
    const shared = await client.rpc("social_public_post", { target_post: sharedId });
    if (!shared.error && shared.data) rows.unshift(shared.data);
  }

  const dateFormat = new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" });
  const posts: FeedPost[] = rows.map((row) => ({
    id: row.id,
    authorId: row.is_anonymous ? undefined : row.author_id ?? undefined,
    author: row.is_official ? "Administração SAD" : row.is_anonymous ? "Morador(a) anônimo(a)" : "Membro da comunidade",
    city: row.city,
    category: row.category,
    body: row.body,
    official: row.is_official,
    sensitive: row.sensitive,
    anonymous: row.is_anonymous,
    mediaPath: row.media_path ?? undefined,
    mediaKind: row.media_kind ?? undefined,
    title: row.title ?? undefined,
    source: row.source ?? undefined,
    createdAt: dateFormat.format(new Date(row.created_at)),
    likes: 0,
    liked: false,
    demo: false,
    status: row.status,
  }));
  if (!posts.length) return posts;

  const [withAuthors, { data: reactions }] = await Promise.all([
    hydrateFeedAuthors(client, posts).then((items) => hydrateFeedMedia(client, items)),
    client.rpc("get_community_post_reaction_summary", { post_ids: posts.map((post) => post.id) }),
  ]);
  const reactionRows = (reactions ?? []) as { post_id: string; liked: boolean; reaction_count: number }[];
  const summaries = new Map(reactionRows.map((item) => [item.post_id, item]));
  return withAuthors.map((post) => ({
    ...post,
    liked: summaries.get(post.id)?.liked ?? false,
    likes: Number(summaries.get(post.id)?.reaction_count ?? 0),
  }));
}

function money(value: number) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 }).format(value);
}

function submissionLimitMessage(error: { message?: string } | null | undefined) {
  return error?.message?.includes("submission_rate_limited")
    ? "Você atingiu o limite temporário de envios desta área. Aguarde antes de tentar novamente."
    : null;
}

function useInitialRefresh(refresh: () => Promise<void>) {
  useEffect(() => {
    const timer = window.setTimeout(() => { void refresh(); }, 0);
    return () => window.clearTimeout(timer);
  }, [refresh]);
}

function ImageAttachmentField({ id, file, onChange, disabled = false }: { id: string; file: File | null; onChange: (file: File | null) => void; disabled?: boolean }) {
  const [preview, setPreview] = useState("");
  useEffect(() => {
    if (!file) { setPreview(""); return; }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);
  return <div className="field full">
    <label className="feed-media-label" htmlFor={id}><ImagePlus size={14} /> Foto (opcional)</label>
    <input id={id} name="media" type="file" accept="image/jpeg,image/png,image/webp" disabled={disabled} onChange={(event) => onChange(event.currentTarget.files?.[0] ?? null)} />
    <small>JPG, PNG ou WebP · até 20 MB. A foto fica privada enquanto o envio estiver em análise.</small>
    {preview && file && <div className="feed-media-preview"><Image src={preview} alt="Prévia da foto anexada" width={480} height={360} unoptimized /><button type="button" className="secondary-btn" onClick={() => onChange(null)} disabled={disabled}><X size={14} /> Remover foto</button></div>}
  </div>;
}

export default function Home() {
  const auth = useSupabaseAuth();
  const [active, setActive] = useState<Section>("inicio");
  const [publicHandle,setPublicHandle] = useState("");
  const sectionHistoryRef = useRef<Section[]>([]);
  const [city, setCity] = useState(cities[1]);
  const [feedInitialTab, setFeedInitialTab] = useState<FeedTab>("comunidade");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Todos");
  const [feedPosts, setFeedPosts] = useState<FeedPost[]>([]);
  const [feedRevision, setFeedRevision] = useState(0);
  const [feedLoading, setFeedLoading] = useState(Boolean(auth.client));
  const [toast, setToast] = useState("");
  const [reportError, setReportError] = useState("");
  const [reportSuccess, setReportSuccess] = useState("");
  const [reportSubmitting, setReportSubmitting] = useState(false);
  const [cityReports, setCityReports] = useState<CityReportRecord[]>([]);
  const [reportsLoading, setReportsLoading] = useState(Boolean(auth.client));
  const [createOpen, setCreateOpen] = useState(false);
  const [composerOpen, setComposerOpen] = useState(false);
  const [composerVersion, setComposerVersion] = useState(0);
  const [authOpen, setAuthOpen] = useState(false);
  const [authInitialMode, setAuthInitialMode] = useState<"signin" | "signup">("signin");
  const [access, setAccess] = useState<Access>({ is_admin: false, is_city_moderator: false, is_service_provider: false, is_referral_verifier: false });
  const [accessLoading, setAccessLoading] = useState(Boolean(auth.user));

  useEffect(() => {
    let current = true;
    if (!auth.client || !auth.user) {
      setAccess({ is_admin: false, is_city_moderator: false, is_service_provider: false, is_referral_verifier: false });
      setAccessLoading(false);
      return;
    }
    setAccessLoading(true);
    void Promise.all([auth.client.rpc("get_current_access"), auth.client.rpc("can_verify_referrals")]).then(([rolesResult, verifierResult]) => {
      if (!current) return;
      const row = Array.isArray(rolesResult.data) ? rolesResult.data[0] : null;
      const admin = !rolesResult.error && row?.is_admin === true;
      setAccess({ is_admin: admin, is_city_moderator: admin || (!rolesResult.error && row?.is_city_moderator === true), is_service_provider: admin || (!rolesResult.error && row?.is_service_provider === true), is_referral_verifier: !verifierResult.error && verifierResult.data === true });
      setAccessLoading(false);
    }, () => {
      if (!current) return;
      setAccess({ is_admin: false, is_city_moderator: false, is_service_provider: false, is_referral_verifier: false });
      setAccessLoading(false);
    });
    return () => { current = false; };
  }, [auth.client, auth.user]);

  useEffect(() => {
    const referral = new URLSearchParams(window.location.search).get("ref")?.trim().toUpperCase();
    if (referral && /^[A-F0-9]{10}$/.test(referral)) {
      try { window.localStorage.setItem("conecta-abc-referral-code", referral); } catch { /* Navegação sem armazenamento local. */ }
    }
  }, []);

  useEffect(() => {
    if (auth.authNotice) notify(auth.authNotice);
  }, [auth.authNotice]);

  useEffect(() => {
    const area = new URLSearchParams(window.location.search).get("area");
    if (!area || !sectionNames.some(name => name === area)) return;
    const timer = window.setTimeout(() => {setPublicHandle(new URLSearchParams(window.location.search).get("usuario")||"");if(new URLSearchParams(window.location.search).has("anuncio"))setCity("Todas as cidades");setActive(area as Section);}, 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const sharedPostId = new URLSearchParams(window.location.search).get("post");
    if (sharedPostId || window.location.hash.startsWith("#feed")) {
      queueMicrotask(() => {
        if (sharedPostId) setCity("Todas as cidades");
        setActive("feed");
      });
    }
  }, []);

  useEffect(() => {
    const sharedPostId = new URLSearchParams(window.location.search).get("post");
    if (!sharedPostId || active !== "feed" || feedLoading) return;
    const sharedPost = feedPosts.find(post => post.id === sharedPostId);
    if (sharedPost) setFeedInitialTab(sharedPost.official ? "oficial" : "comunidade");
    const timer = window.setTimeout(() => document.getElementById(`feed-post-${sharedPostId}`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 120);
    return () => window.clearTimeout(timer);
  }, [active, feedLoading, feedPosts]);

  useEffect(() => {
    if (!auth.client) return;
    const client = auth.client;
    let active = true;
    void client
      .from("city_reports")
      .select("id, category, city, neighborhood, description, status, created_at, media_path")
      .order("created_at", { ascending: false })
      .limit(50)
    .then(async ({ data, error }) => {
        if (!active) return;
        if (error) {
          setReportError("Não foi possível carregar os relatos do servidor.");
        } else {
          const hydrated = await hydrateSubmissionImages(auth.client!, (data ?? []) as CityReportDbRow[]);
          setCityReports(hydrated.map((row) => ({
            id: row.id,
            category: row.category,
            city: row.city,
            neighborhood: row.neighborhood,
            description: row.description,
            status: row.status,
            createdAt: new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(row.created_at)),
            media_path: row.media_path,
            media_url: row.media_url,
          })));
        }
        setReportsLoading(false);
      })
      .then(undefined, () => {
        if (!active) return;
        setReportError("Falha de conexão ao carregar os relatos. Tente atualizar a página.");
        setReportsLoading(false);
      });
    return () => { active = false; };
  }, [auth.client]);

  useEffect(() => {
    if (!auth.client) return;
    let active = true;
    const sharedId = new URLSearchParams(window.location.search).get("post");
    void loadFeedPosts(auth.client, sharedId).then((posts) => {
      if (!active) return;
      setFeedPosts(posts);
      setFeedLoading(false);
    }, () => {
      if (!active) return;
      setFeedPosts([]);
      setFeedLoading(false);
      notify("Não foi possível atualizar o Feed. Tente novamente mais tarde.");
    });
    return () => { active = false; };
  }, [auth.client, auth.user, auth.profile?.avatar_public, auth.profile?.avatar_path, auth.profile?.display_name, feedRevision]);

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  }

  function navigate(section: Section, feedTab?: FeedTab) {
    if (section === "clube") {
      notify("Clube de benefícios fechado por enquanto.");
      return;
    }
    if (section === "feed") setFeedInitialTab(feedTab ?? "comunidade");
    if (section !== active) sectionHistoryRef.current.push(active);
    setActive(section);
    setQuery("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function goBack() {
    const previous = sectionHistoryRef.current.pop() ?? "inicio";
    setActive(previous);
    setQuery("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }


  async function submitOfficialPost(post: FeedPostDraft) {
    if (!auth.client || !auth.user) { setAuthOpen(true); notify("Entre com uma conta administradora para publicar no Notícias do ABC."); return false; }
    try {
      const { error } = await auth.client.rpc("create_official_post", { post_title: post.title, post_category: post.category, post_city: post.city, post_body: post.body, post_source: post.source, post_sensitive: post.sensitive });
      if (error) {
        notify(error.code === "PGRST202" || error.code === "42883" ? "A função de publicação oficial não foi encontrada. Aplique a migração 202611020008 no Supabase." : error.code === "42501" ? "Sua conta ainda não está autorizada como moderadora no Supabase." : "O Supabase recusou a publicação. Confira os campos e tente novamente.");
        return false;
      }
      setFeedRevision((revision) => revision + 1);
      return true;
    } catch {
      notify("Falha de conexão. O comunicado não foi confirmado; atualize a página e confira o Feed antes de reenviar.");
      return false;
    }
  }

  async function submitCommunityPost({ draft: post, anonymous, mediaFile }: CommunityPostSubmission) {
    if (!auth.client || !auth.user) {
      setAuthOpen(true);
      notify("Entre na sua conta para enviar uma publicação.");
      return false;
    }
    let mediaPath: string | null = null;
    try {
      if (mediaFile) {
        const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm", "video/quicktime"]);
        if (!allowedTypes.has(mediaFile.type) || mediaFile.size > 20 * 1024 * 1024) {
          notify("Escolha uma imagem ou vídeo compatível de até 20 MB.");
          return false;
        }
        const extension = mediaFile.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || (mediaFile.type.startsWith("video/") ? "mp4" : "jpg");
        mediaPath = `${auth.user.id}/${crypto.randomUUID()}.${extension}`;
        const { error: uploadError } = await auth.client.storage.from("feed-media").upload(mediaPath, mediaFile, { contentType: mediaFile.type, cacheControl: "3600", upsert: false });
        if (uploadError) {
          notify(uploadError.message.includes("Bucket not found") ? "O armazenamento de mídia ainda não foi ativado. Aplique a migração 202611030013 no Supabase." : "Não foi possível enviar a mídia. Confira o tipo, tamanho e armazenamento do Supabase.");
          return false;
        }
      }
      const { error } = await auth.client.from("community_posts").insert({
        author_id: auth.user.id,
        category: post.category,
        city: post.city,
        body: post.body,
        is_anonymous: anonymous,
        media_path: mediaPath,
        media_kind: mediaFile ? mediaFile.type.startsWith("video/") ? "video" : "image" : null,
      });
      if (error) {
        if (mediaPath) await auth.client.storage.from("feed-media").remove([mediaPath]);
        const message = submissionLimitMessage(error)
          ?? (error.code === "42P01" || error.code === "PGRST205"
          ? "O Feed ainda não está atualizado no Supabase. Aplique a migração 202611030013."
          : error.code === "PGRST204"
            ? "O banco ainda não reconhece os campos novos do Feed. Aplique a migração 202611030013 no Supabase."
          : error.code === "42501"
            ? "O banco recusou a publicação. Confirme as políticas RLS do Feed no Supabase."
            : "Não foi possível enviar. Confira sua conexão e tente novamente.");
        notify(message);
        return false;
      }
      setFeedRevision((revision) => revision + 1);
      return true;
    } catch {
      notify("Falha de conexão. A publicação não foi confirmada; tente novamente.");
      return false;
    }
  }

  async function toggleFeedLike(id: string,reactionKind?:string) {
    const post = feedPosts.find((item) => item.id === id);
    if (!post) return;
    if (post.demo) {
      setFeedPosts((current) => current.map((item) => item.id === id ? { ...item, liked: !item.liked, likes: item.likes + (item.liked ? -1 : 1) } : item));
      return;
    }
    if (!auth.client || !auth.user) { setAuthOpen(true); notify("Entre para apoiar uma publicação."); return; }
    if (post.authorId === auth.user.id) { notify("Apoiar sua própria publicação não gera pontos."); return; }
    try {
      const { data, error } = reactionKind?await auth.client.rpc("social_set_reaction",{target_post:id,target_kind:reactionKind}):await auth.client.rpc("toggle_community_post_reaction", { post_id: id });
      if (error) {
        notify(error.code === "P0002" ? "Só é possível apoiar publicações aprovadas pela equipe." : error.code === "P0001" ? "Não é possível pontuar apoiando sua própria publicação." : error.code === "PGRST202" || error.code === "42883" ? "O apoio ainda não foi ativado no servidor." : "Não foi possível registrar seu apoio. Entre novamente e tente outra vez.");
        return;
      }
      const summary = Array.isArray(data) ? data[0] : data;
      if (!summary) { notify("A publicação não está disponível para receber apoio."); return; }
      setFeedPosts((current) => current.map((item) => item.id === id ? { ...item, liked: Boolean(summary.liked), likes: Number(summary.reaction_count) } : item));
      if (!summary.liked) notify("Apoio removido. Descurtir não tira pontos já registrados.");
      else if (Number(summary.points_awarded) > 0) notify("Apoio registrado: +3 pontos para você.");
      else notify("Apoio registrado. Você já recebeu pontos por esta publicação.");
    } catch {
      notify("Falha de conexão ao registrar apoio. Tente novamente.");
    }
  }

  async function submitFeedReport(postId: string, reason: string, details: string) {
    if (!auth.client || !auth.user) {
      setAuthOpen(true);
      notify("Entre na sua conta para enviar uma denúncia.");
      return false;
    }
    try {
      const { error } = await auth.client.rpc("create_community_post_report", { reported_post_id: postId, report_reason: reason, report_details: details });
      if (error) {
        notify(error.code === "23505" ? "Você já enviou uma denúncia pendente para esta publicação." : error.code === "PGRST202" || error.code === "42883" ? "O envio de denúncias ainda não foi ativado no servidor." : "Não foi possível enviar a denúncia. Confira os campos e tente novamente.");
        return false;
      }
      notify("Denúncia enviada para análise da equipe.");
      return true;
    } catch {
      notify("Falha de conexão. A denúncia não foi confirmada; tente novamente.");
      return false;
    }
  }

  function applyModeration() {
    setFeedRevision((revision) => revision + 1);
  }

  async function submitCityReport(event: FormEvent<HTMLFormElement>, imageFile: File | null): Promise<boolean> {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const result = cityReportSchema.safeParse({ category: form.get("category"), city: form.get("city"), neighborhood: form.get("neighborhood") ?? "", details: form.get("details") });
    if (!result.success) {
      setReportError(result.error.issues[0]?.message ?? "Confira os campos do formulário.");
      setReportSuccess("");
      return false;
    }
    if (!auth.client || !auth.user) {
      setAuthOpen(true);
      setReportError("Entre na sua conta para enviar um relato.");
      setReportSuccess("");
      return false;
    }
    setReportSubmitting(true);
    setReportError("");
    setReportSuccess("");
    let submitted = false;
    let mediaPath: string | null = null;
    try {
      if (imageFile) {
        const uploaded = await uploadSubmissionImage(auth.client, auth.user.id, imageFile);
        if (uploaded.error) { setReportError(uploaded.error); return false; }
        mediaPath = uploaded.path;
      }
      const { error } = await auth.client.from("city_reports").insert({
        author_id: auth.user.id,
        category: result.data.category,
        city: result.data.city,
        neighborhood: result.data.neighborhood || null,
        description: result.data.details,
        media_path: mediaPath,
      });
      if (error) {
        if (mediaPath) await auth.client.storage.from(submissionMediaBucket).remove([mediaPath]);
        setReportError(submissionLimitMessage(error) ?? "Não foi possível enviar o relato. Confira sua conexão e tente novamente.");
        return false;
      }
      submitted = true;
      formElement.reset();
      setReportSuccess("Relato enviado. Ele ficará pendente até a equipe iniciar a análise.");
      notify("Relato enviado para análise. Nenhum ponto é concedido pelo envio.");
      try {
        const { data } = await auth.client.from("city_reports").select("id, category, city, neighborhood, description, status, created_at, media_path").order("created_at", { ascending: false }).limit(50);
        if (data) {
          const hydrated = await hydrateSubmissionImages(auth.client, data);
          setCityReports(hydrated.map((row) => ({ id: row.id, category: row.category, city: row.city, neighborhood: row.neighborhood, description: row.description, status: row.status, createdAt: new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(row.created_at)), media_path: row.media_path, media_url: row.media_url })));
        }
      } catch {
        // O relato já foi salvo; preservar a confirmação, mesmo se a lista não atualizar agora.
      }
      return true;
    } catch {
      if (submitted) {
        setReportSuccess("Relato enviado. Ele ficará pendente até a equipe iniciar a análise.");
        return true;
      } else {
        if (mediaPath) await auth.client?.storage.from(submissionMediaBucket).remove([mediaPath]);
        setReportError("Não foi possível enviar o relato. Confira sua conexão e tente novamente.");
        return false;
      }
    } finally {
      setReportSubmitting(false);
    }
  }

  async function applyCityReportStatus(reportId: string, status: CityReportRecord["status"]) {
    setCityReports((current) => current.map((report) => report.id === reportId ? { ...report, status } : report));
    if (!auth.client) return;
    try {
      const { data } = await auth.client.from("city_reports").select("id, category, city, neighborhood, description, status, created_at, media_path").order("created_at", { ascending: false }).limit(50);
      if (data) {
        const hydrated = await hydrateSubmissionImages(auth.client, data);
        setCityReports(hydrated.map((row) => ({ id: row.id, category: row.category, city: row.city, neighborhood: row.neighborhood, description: row.description, status: row.status, createdAt: new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(row.created_at)), media_path: row.media_path, media_url: row.media_url })));
      }
    } catch {
      notify("Status atualizado. A lista pode demorar a refletir a mudança; atualize a página.");
    }
  }

  const canManage = access.is_admin || access.is_city_moderator || access.is_service_provider || access.is_referral_verifier;
  if (auth.loading) return <LoginLoadingScreen />;
  return (
    <SocialFeaturesProvider key={auth.user?.id ?? "visitor"} client={auth.client} userId={auth.user?.id} openAuth={() => setAuthOpen(true)}><PresenceHeartbeat><SocialShell active={active} navigate={(section) => navigate(section as Section)} back={goBack} create={() => setCreateOpen(true)} signedIn={Boolean(auth.user)} login={() => setAuthOpen(true)} canManage={canManage}>
          {active.endsWith("-equipe") && !access.is_admin && <section className="social-empty" role={accessLoading?"status":undefined}><h1>{accessLoading?"Verificando permissões…":"Área restrita à equipe"}</h1>{!accessLoading&&<p>Sua conta não possui acesso a esta ferramenta.</p>}</section>}
          {(["inicio", "explorar", "noticias", "agora"] as Section[]).includes(active) && <SocialTimeline collection={active as SocialCollection} posts={feedPosts} city={city} setCity={setCity} loading={feedLoading} navigate={navigate} create={() => setCreateOpen(true)} displayName={auth.profile?.display_name} onLike={toggleFeedLike} onReport={submitFeedReport} notify={notify} client={auth.client} />}
          {(["amigos", "salvos", "notificacoes"] as Section[]).includes(active) && <SocialWorkspace key={active} area={active as "amigos" | "salvos" | "notificacoes"} />}
          {active === "comentarios-equipe" && access.is_admin && <SocialWorkspace area="comentarios-equipe" />}
          {(active === "enquetes" || active === "comunidades" || (active === "comunidade-equipe" && access.is_admin)) && <CommunityHub key={active} area={active as "enquetes" | "comunidades" | "comunidade-equipe"}/>}
          {active === "agenda" && <EventAgenda>{selectPublicPosts(feedPosts,"agenda","Todas as cidades").map(post => <FeedPostCard key={post.id} post={post} onLike={toggleFeedLike} onReport={submitFeedReport} notify={notify}/>)}</EventAgenda>}
          {active === "agenda-equipe" && access.is_admin && <EventAgenda moderation/>}
          {active === "admin" && access.is_admin && <button className="secondary-btn" onClick={()=>navigate("agenda-equipe")}>Moderar agenda</button>}
          {active === "membro" && <PublicMemberProfile handle={publicHandle}/>}
          {active === "midia-equipe" && (access.is_admin ? <OfficialMediaPublisher/> : <section className="social-empty">Entre com uma conta da equipe para publicar conteúdo oficial.</section>)}
          {active === "niveis-equipe" && access.is_admin && <LevelSettings/>}
          {active === "admin" && access.is_admin && <div className="button-row"><button className="secondary-btn" onClick={()=>navigate("midia-equipe")}>Publicar foto ou vídeo oficial</button><button className="secondary-btn" onClick={()=>navigate("niveis-equipe")}>Configurar níveis</button></div>}
          {active === "stories" && <Stories startComposing/>}
          {active === "stories-equipe" && access.is_admin && <Stories moderation/>}
          {active === "avaliacoes-equipe" && access.is_admin && <PlaceReviewModeration/>}
          {active === "admin" && access.is_admin && <div className="button-row"><button className="secondary-btn" onClick={()=>navigate("stories-equipe")}>Moderar stories</button><button className="secondary-btn" onClick={()=>navigate("avaliacoes-equipe")}>Moderar avaliações</button></div>}
          {(active === "mercadao" || active === "imoveis") && <nav className="social-filter-tabs" aria-label="Seções do Mercadão">
            <button className={active === "mercadao" ? "selected" : ""} aria-current={active === "mercadao" ? "page" : undefined} onClick={() => navigate("mercadao")}>Produtos e vagas</button>
            <button className={active === "imoveis" ? "selected" : ""} aria-current={active === "imoveis" ? "page" : undefined} onClick={() => navigate("imoveis")}>Imóveis</button>
          </nav>}
          {(active === "imoveis" || active === "vagas" || active === "achados") && <ExtendedClassifieds key={active} kind={active}/>}
          {active === "classificados-equipe" && access.is_admin && <ExtendedClassifieds kind="imoveis" moderation/>}
          {active === "admin" && access.is_admin && <button className="secondary-btn" onClick={()=>navigate("classificados-equipe")}>Moderar imóveis, vagas e achados</button>}
          {active === "busca" && <GlobalSearch/>}
          {active === "top" && <TopWeek/>}
          {active === "indica" && <Recommendations/>}
          {active === "indica-equipe" && access.is_admin && <RecommendationModeration/>}
          {active === "utilidades" && <Utilities/>}
          {active === "utilidades-equipe" && access.is_admin && <Utilities manage/>}
          {active === "admin" && access.is_admin && <div className="button-row"><button className="secondary-btn" onClick={()=>navigate("indica-equipe")}>Moderar recomendações</button><button className="secondary-btn" onClick={()=>navigate("utilidades-equipe")}>Gerenciar utilidades</button></div>}
          {active === "cupons-portal" && <Coupons owner/>}
          {active === "validar-cupom" && <ValidateCoupon/>}
          {active === "cupons-equipe" && access.is_admin && <Coupons moderation/>}
          {active === "dados" && <AccountPrivacy/>}
          {active === "exclusoes-equipe" && access.is_admin && <AccountDeletionQueue/>}
          {active === "campanhas" && <InactiveCampaigns/>}
          {active === "campanhas-equipe" && access.is_admin && <CampaignDrafts/>}
          {active === "portal" && auth.user && <a className="secondary-btn" href="/?area=cupons-portal">Preparar cupons do meu negócio</a>}
          {active === "admin" && access.is_admin && <div className="button-row"><button className="secondary-btn" onClick={()=>navigate("cupons-equipe")}>Analisar cupons</button><button className="secondary-btn" onClick={()=>navigate("exclusoes-equipe")}>Solicitações de exclusão</button><button className="secondary-btn" onClick={()=>navigate("campanhas-equipe")}>Preparar campanhas desativadas</button></div>}
          {active === "denuncias-equipe" && access.is_admin && <ContentReportModeration/>}
          {active === "admin" && access.is_admin && <button className="secondary-btn" onClick={()=>navigate("denuncias-equipe")}>Denúncias de perfis, stories e conteúdo</button>}
          {active === "mais" && <AllAreas navigate={navigate} canManage={canManage} />}
          {active === "mapa" && <ExploreMap client={auth.client} user={auth.user} onLogin={() => setAuthOpen(true)} />}
          {active === "feed" && <CommunityFeed key={`feed-${feedInitialTab}-${composerVersion}`} initialTab={feedInitialTab} startComposing={composerOpen} city={city} posts={feedPosts} onCreatePost={submitCommunityPost} onLike={toggleFeedLike} onReport={submitFeedReport} notify={notify} loading={feedLoading} connected={auth.isConfigured} />}
          {active === "mercadao" && <Marketplace city={city} query={query} setQuery={setQuery} category={category} setCategory={setCategory} auth={auth} notify={notify} openAuth={() => setAuthOpen(true)} />}
          {active === "animais" && <AnimalReports city={city} auth={auth} notify={notify} openAuth={() => setAuthOpen(true)} />}
          {active === "cidade" && <CityReport onSubmit={submitCityReport} error={reportError} success={reportSuccess} connected={auth.isConfigured} authenticated={Boolean(auth.user)} submitting={reportSubmitting} reports={cityReports} loading={reportsLoading} selectedCity={city} />}
          {active === "pontua" && <ProgressView notify={notify} navigate={navigate} auth={auth} openAuth={() => setAuthOpen(true)} />}
          {active === "perfil" && <ProfileView navigate={navigate} notify={notify} auth={auth} openAuth={() => setAuthOpen(true)} />}
          {active === "servicos" && <SocialServiceRequest auth={auth} openAuth={() => setAuthOpen(true)} />}
          {active === "envios" && <MySubmissionsView client={auth.client} user={auth.user} loadingAuth={auth.loading} openAuth={() => setAuthOpen(true)} navigate={navigate} />}
          {(active === "parceiros" || active === "empresas") && <BusinessDirectory/>}
          {active === "portal" && <BusinessDirectory mode="owner"/>}
          {(active === "parceiros" || active === "portal") && <details className="hub-create"><summary>Solicitações anteriores e contato com a equipe</summary><PartnerArea mode={active} auth={auth} openAuth={() => setAuthOpen(true)}/></details>}
          {active === "empresas-equipe" && access.is_admin && <BusinessDirectory mode="moderation"/>}
          {active === "cupons" && <Coupons/>}
          {active === "admin" && access.is_admin && <button className="secondary-btn" onClick={()=>navigate("empresas-equipe")}>Analisar empresas</button>}
          {active === "admin" && access.is_admin && <button className="secondary-btn" onClick={()=>navigate("comunidade-equipe")}>Moderar enquetes e comunidades</button>}
          {active === "admin" && access.is_admin && <button className="primary-btn" onClick={() => navigate("comentarios-equipe")}>Moderar comentários</button>}
          {active === "admin" && <AdminPanel access={access} accessLoading={accessLoading} posts={feedPosts} onCreatePost={submitOfficialPost} onLike={toggleFeedLike} onReport={submitFeedReport} notify={notify} client={auth.client} user={auth.user} onModerated={applyModeration} onCityReportStatusChanged={applyCityReportStatus} />}
          {createOpen && <CreateSheet close={() => setCreateOpen(false)} select={(section) => { setComposerOpen(true); setComposerVersion(value => value + 1); navigate(section as Section); }} />}
      <AuthPanel key={authInitialMode} initialMode={authInitialMode} open={authOpen} client={auth.client} user={auth.user} profile={auth.profile} onClose={() => setAuthOpen(false)} onSignedOut={() => notify("Você saiu da sua conta.")} />
      {toast && <div role="status" className="toast">{toast}</div>}
    </SocialShell></PresenceHeartbeat></SocialFeaturesProvider>
  );
}

function LoginLoadingScreen() {
  return <main className="login-loading-screen" aria-busy="true"><Image src="/conecta-abc-mark.svg" alt="" width={52} height={52} priority /><p>Preparando seu espaço no Conecta ABC…</p></main>;
}

function LoginPortal({ auth, onBrowseAsGuest }: { auth: ReturnType<typeof useSupabaseAuth>; onBrowseAsGuest: () => void }) {
  return <div className="login-portal">
    <div className="login-portal-glow" aria-hidden="true" />
    <div className="login-portal-shell">
      <section className="login-portal-story" aria-label="Sobre o Conecta ABC">
        <div className="login-portal-brand" aria-label="Conecta ABC">
          <Image src="/conecta-abc-mark.svg" alt="" width={54} height={54} priority />
          <span><strong>CONECTA <b>ABC</b></strong><small>UMA PLATAFORMA DA SAD</small></span>
        </div>
        <div className="login-portal-copy">
          <span className="login-portal-kicker"><span /> O GRANDE ABC CONECTADO</span>
          <h1>Sua cidade fica mais perto quando a gente se conecta.</h1>
          <p>Entre para participar da comunidade, acompanhar sua região e acessar os serviços do Conecta ABC.</p>
        </div>
        <div className="login-portal-features">
          <div><span className="login-feature-index">01</span><span><strong>Uma comunidade só</strong><small>Informação local nos sete municípios.</small></span></div>
          <div><span className="login-feature-index">02</span><span><strong>Participação que importa</strong><small>Compartilhe, acompanhe e ajude o ABC.</small></span></div>
          <div><span className="login-feature-index">03</span><span><strong>Seu acesso, protegido</strong><small>Entre com sua conta ou crie um cadastro gratuito.</small></span></div>
        </div>
        <div className="login-city-list" aria-label="Municípios atendidos">
          {cities.slice(1).map((name) => <span key={name}>{name}</span>)}
        </div>
      </section>
      <div className="login-portal-form">
        <AuthPanel open client={auth.client} user={null} profile={null} onClose={onBrowseAsGuest} onSignedOut={() => {}} presentation="page" callbackNotice={auth.authNotice} onBrowseAsGuest={onBrowseAsGuest} />
      </div>
    </div>
    <footer className="login-portal-footer"><span>Conecta ABC · Uma plataforma da SAD</span><span><Link href="/privacidade">Privacidade</Link><Link href="/termos">Termos</Link></span></footer>
  </div>;
}

function Stat({ icon: Icon, label, value, foot }: { icon: LucideIcon; label: string; value: string; foot: string }) {
  return <div className="stat-card"><div className="stat-top"><span>{label}</span><span className="stat-icon"><Icon size={15} strokeWidth={1.8} /></span></div><div className="stat-value">{value}</div><div className="stat-foot">{foot}</div></div>;
}

function SideNavItem({ item, active, navigate }: { item: (typeof navItems)[number]; active: boolean; navigate: (section: Section) => void }) {
  const Icon = item.id === "clube" ? Lock : item.icon;
  return <button className={`nav-item ${active ? "active" : ""} ${item.id === "clube" ? "nav-locked" : ""}`} onClick={() => navigate(item.id)}><span className="nav-symbol"><Icon size={15} strokeWidth={1.8} /></span>{item.label}{item.id === "clube" && <span className="lock-label">Fechado</span>}{item.count && <span className="nav-count">{item.count}</span>}</button>;
}

function ActivityRow({ icon: Icon, title, detail, time }: { icon: LucideIcon; title: string; detail: string; time: string }) {
  return <div className="activity"><div className="activity-icon"><Icon size={15} strokeWidth={1.8} /></div><div><strong>{title}</strong><span>{detail}</span></div><time>{time}</time></div>;
}

function ProfileView({ navigate, notify, auth, openAuth }: { navigate: (section: Section) => void; notify: (message: string) => void; auth: ReturnType<typeof useSupabaseAuth>; openAuth: () => void }) {
  const memberName = auth.profile?.display_name ?? "Seu perfil";
  const memberCity = auth.profile?.city ?? "Cidade não informada";

  return <>
    <div className="module-title-row"><div><div className="eyebrow">SEU PERFIL NA COMUNIDADE</div><h1>Meu perfil</h1><p className="muted">Suas contribuições reconhecidas pelo Grande ABC.</p></div><span className="badge">{auth.user && auth.profile ? "CONTA CONECTADA" : "ENTRE PARA PARTICIPAR"}</span></div>
    <section className="panel account-status-card"><div className="account-status-copy"><span className={`account-status-dot ${auth.user ? "connected" : ""}`} /><div><strong>{auth.loading ? "Verificando sua conta…" : auth.user ? "Conta conectada ao Conecta ABC" : auth.isConfigured ? "Entre para criar seu perfil" : "Conexão aguardando configuração"}</strong><p>{auth.profileError || (auth.user ? "Seu cadastro e seu link de indicação estão registrados na plataforma." : "Entre para acessar seu perfil e acompanhar suas contribuições.")}</p></div></div><button className="secondary-btn" type="button" onClick={openAuth}>{auth.user ? "Gerenciar conta" : "Entrar ou criar conta"}</button></section>
    {auth.profile && <section className="panel public-profile-card"><div className="profile-avatar">{memberName.slice(0,1).toUpperCase()}</div><div><h2>{memberName}</h2><p>{memberCity}</p></div></section>}
    {auth.user && <CommunityProfileEditor navigate={area=>navigate(area as Section)} name={auth.profile?.display_name||""} city={auth.profile?.city||""} onSaved={auth.refreshProfile}/> }
    {auth.profile ? <MemberCard auth={auth} notify={notify}/> : <section className="panel"><h3>Sua carteirinha está aqui</h3><p>Entre para acessar seu perfil, foto e QR Code.</p><button className="primary-btn" onClick={openAuth}>Entrar ou criar conta</button></section>}
    {auth.user && <section className="panel"><div className="panel-title"><h3>Ranking da comunidade</h3><span className="badge">PARTICIPAÇÃO AUTOMÁTICA</span></div><p className="muted">Todos os membros aparecem no ranking público com primeiro nome, cidade e pontos. Sobrenome, CPF, e-mail e telefone não são exibidos.</p></section>}
    <button className="secondary-btn" onClick={()=>navigate("dados")}>Meus dados e privacidade</button><InstallApp/><div className="profile-privacy-note"><ShieldCheck size={16} /><p>Seu perfil apresenta o nome e a cidade do cadastro. As contribuições passam por análise da equipe.</p></div>
    <div className="profile-actions">{auth.user && <button className="secondary-btn" onClick={() => navigate("envios")}>Meus envios　→</button>}<button className="secondary-btn" onClick={() => navigate("pontua")}>Ver meu progresso　→</button><button className="secondary-btn" onClick={() => navigate("inicio")}>Voltar ao início</button></div>
    <p className="data-note">{auth.profile ? "Sua carteirinha identifica seu cadastro na comunidade. Pontos refletem contribuições confirmadas." : "Entre para ver informações e documentos associados à sua conta."}</p>
  </>;
}

function MemberCard({ auth, notify }: { auth: ReturnType<typeof useSupabaseAuth>; notify: (message: string) => void }) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [avatarPath, setAvatarPath] = useState(auth.profile?.avatar_path ?? null);
  const [avatarPublic, setAvatarPublic] = useState(auth.profile?.avatar_public ?? false);
  const [avatarUrl, setAvatarUrl] = useState("");
  const progression=useCommunityResource<MemberProgress>("social_my_progress",{},Boolean(auth.user));
  const levelConfig=useCommunityResource<MemberLevel[]>("social_get_levels");
  const memberPoints=progression.data?.points??null;
  const [cardBack,setCardBack]=useState(false);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [photoError, setPhotoError] = useState("");
  const [photoSuccess, setPhotoSuccess] = useState("");
  const profile = auth.profile;
  const memberCode = profile ? `ABC-${profile.id.slice(0, 8).toUpperCase()}` : "";
  const verificationUrl = profile ? `https://conectaabc.com/verificar?membro=${encodeURIComponent(profile.id)}` : "";
  const metadata = auth.user?.user_metadata ?? {};
  const providerAvatar = [metadata.avatar_url, metadata.picture].find((value): value is string => {
    if (typeof value !== "string") return false;
    try { return new URL(value).protocol === "https:"; } catch { return false; }
  }) ?? "";


  const memberTiers = (levelConfig.data||[]).map(tier=>({min:tier.minimum_points,level:tier.level,name:tier.name,color:tier.color}));
  const currentTierIndex = memberPoints === null ? -1 : memberTiers.findLastIndex((tier) => memberPoints >= tier.min);
  const currentTier = currentTierIndex >= 0 ? memberTiers[currentTierIndex] : null;
  const nextTier = currentTierIndex >= 0 ? memberTiers[currentTierIndex + 1] : memberTiers[0];
  const tierProgress = memberPoints === null || !currentTier || !nextTier ? 100 : Math.min(100, Math.round(((memberPoints - currentTier.min) / (nextTier.min - currentTier.min)) * 100));

  useEffect(() => setAvatarPath(profile?.avatar_path ?? null), [profile?.avatar_path]);
  useEffect(() => setAvatarPublic(Boolean(profile?.avatar_public)), [profile?.avatar_public]);
  useEffect(() => {
    let active = true;
    if (!auth.client || !avatarPath) { setAvatarUrl(""); return; }
    void auth.client.storage.from("member-avatars").createSignedUrl(avatarPath, 60 * 60)
      .then(({ data, error }) => {
        if (!active) return;
        setAvatarUrl(error ? "" : data.signedUrl);
      });
    return () => { active = false; };
  }, [auth.client, avatarPath]);

  async function uploadPhoto(event: ChangeEvent<HTMLInputElement>) {
    const input = event.currentTarget;
    const file = input.files?.[0];
    input.value = "";
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      setPhotoError("Escolha uma foto JPG, PNG ou WebP."); setPhotoSuccess(""); return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setPhotoError("A foto precisa ter até 5 MB."); setPhotoSuccess(""); return;
    }
    if (!auth.client || !auth.user || !profile) {
      setPhotoError("Entre na sua conta para adicionar a foto."); setPhotoSuccess(""); return;
    }
    const extension = file.type === "image/jpeg" ? "jpg" : file.type === "image/png" ? "png" : "webp";
    const path = `${auth.user.id}/carteirinha.${extension}`;
    const previousPath = avatarPath;
    const storage = auth.client.storage.from("member-avatars");
    setPhotoBusy(true); setPhotoError(""); setPhotoSuccess("");
    const { error: uploadError } = await storage.upload(path, file, { upsert: true, contentType: file.type, cacheControl: "3600" });
    if (uploadError) {
      setPhotoBusy(false); setPhotoError("Não foi possível enviar a foto. Tente novamente."); return;
    }
    const { error: saveError } = await auth.client.from("profiles").update({ avatar_path: path }).eq("id", auth.user.id);
    if (saveError) {
      if (path !== previousPath) void storage.remove([path]);
      setPhotoBusy(false); setPhotoError("A foto foi enviada, mas não conseguimos vinculá-la ao perfil. Confira se a migração foi aplicada."); return;
    }
    setAvatarPath(path);
    if (previousPath && previousPath !== path) void storage.remove([previousPath]);
    await auth.refreshProfile();
    setPhotoBusy(false); setPhotoSuccess("Foto da carteirinha atualizada.");
    notify("Foto adicionada à sua carteirinha.");
  }

  async function removePhoto() {
    if (!auth.client || !auth.user || !avatarPath) return;
    setPhotoBusy(true); setPhotoError(""); setPhotoSuccess("");
    const previousPath = avatarPath;
    const { error } = await auth.client.from("profiles").update({ avatar_path: null, avatar_public: false }).eq("id", auth.user.id);
    if (error) {
      setPhotoBusy(false); setPhotoError("Não foi possível remover a foto agora."); return;
    }
    setAvatarPath(null); setAvatarPublic(false);
    void auth.client.storage.from("member-avatars").remove([previousPath]);
    await auth.refreshProfile();
    setPhotoBusy(false); setPhotoSuccess("Foto removida. Você pode adicionar outra quando quiser.");
  }

  async function updatePhotoVisibility(enabled: boolean) {
    if (!auth.client || !auth.user || !avatarPath) return;
    setPhotoBusy(true); setPhotoError(""); setPhotoSuccess("");
    const { error } = await auth.client.from("profiles").update({ avatar_public: enabled }).eq("id", auth.user.id);
    setPhotoBusy(false);
    if (error) { setPhotoError("Não foi possível atualizar a privacidade da foto. Tente novamente."); return; }
    setAvatarPublic(enabled);
    await auth.refreshProfile();
    setPhotoSuccess(enabled ? "Foto pública: ela aparecerá nos seus posts do Feed." : "Foto privada: ela deixará de aparecer nas próximas leituras do Feed.");
  }

  async function copyMemberNumber() {
    try { await navigator.clipboard.writeText(memberCode); notify("Código da carteirinha copiado."); }
    catch { notify("Não foi possível copiar o código neste navegador."); }
  }

  if (!profile) return null;
  const photo = avatarUrl || providerAvatar;
  return <section className="digital-card-wrap"><div className="section-head"><h2>Carteirinha digital</h2><span className="badge">MEMBRO CONECTADO</span></div><button className="secondary-btn" onClick={()=>setCardBack(!cardBack)}>{cardBack?"Ver frente":"Ver verso e QR"}</button>{cardBack && <article className="digital-member-card premium-member-card member-card-back"><h3>CONECTA ABC</h3><QRCodeSVG value={verificationUrl} size={180} includeMargin/><strong>{memberCode}</strong><a className="secondary-btn" href={verificationUrl} target="_blank" rel="noreferrer">Abrir validação do perfil</a><p>Use o QR para consultar a validade deste perfil na plataforma.</p><small>A carteirinha não representa assinatura ativa do clube de benefícios.</small></article>}<article hidden={cardBack} className={`digital-member-card premium-member-card card-tone-${currentTier?.color||"gold"}`}>
    <span className="member-card-watermark" aria-hidden="true">ABC</span>
    <div className="premium-card-top"><div className="premium-card-brand"><Image src="/conecta-abc-mark.svg" alt="" width={42} height={42} /><div><strong>CONECTA <span>ABC</span></strong><small>O GRANDE ABC CONECTADO</small></div></div><div className="member-rank-chip"><Trophy size={13}/><span>{memberPoints === null ? "NÍVEL —" : `NÍVEL ${currentTier?.level ?? 1}`}</span></div></div>
    <div className="premium-card-main"><div className="digital-card-person"><div className="member-card-photo">{photo ? <Image src={photo} alt={`Foto de ${profile.display_name}`} width={74} height={74} unoptimized /> : <span>{profile.display_name.slice(0, 1).toUpperCase()}</span>}</div><div className="digital-card-name"><small>CARTEIRINHA DE MEMBRO</small><strong>{profile.display_name}</strong><span>{profile.city ?? "Grande ABC"} · desde {new Intl.DateTimeFormat("pt-BR", { month: "short", year: "numeric" }).format(new Date(profile.created_at))}</span></div></div><div className="premium-card-qr"><QRCodeSVG value={verificationUrl} size={90} level="M" includeMargin bgColor="#fff" fgColor="#111" /><small>PERFIL OFICIAL</small></div></div>
    <div className="member-tier-panel"><div className="member-tier-heading"><div><small>NÍVEL DE PARTICIPAÇÃO</small><strong>{memberPoints === null ? "Em atualização" : currentTier?.name ?? "Morador do ABC"}</strong></div><span>{memberPoints === null ? "—" : `${memberPoints.toLocaleString("pt-BR")} PTS`}</span></div><div className="member-tier-track" role="progressbar" aria-label="Progresso para o próximo nível" aria-valuenow={memberPoints === null ? 0 : tierProgress} aria-valuemin={0} aria-valuemax={100}><span style={{ width: `${memberPoints === null ? 0 : tierProgress}%` }}/></div><small className="member-tier-next">{memberPoints === null ? "Consultando pontos validados…" : nextTier ? `Próximo nível: ${nextTier.name} · ${nextTier.min.toLocaleString("pt-BR")} pts` : "Nível máximo alcançado"}</small></div>
    <MemberBadges memberId={profile.id}/><div className="premium-card-bottom"><span><small>NÚMERO DO MEMBRO</small><strong>{memberCode}</strong></span><button type="button" className="secondary-btn" onClick={() => void copyMemberNumber()}><Copy size={13} /> Copiar número</button></div>
    </article><div className="member-photo-actions"><input ref={fileInputRef} className="visually-hidden" type="file" accept="image/jpeg,image/png,image/webp" onChange={(event) => void uploadPhoto(event)} aria-label="Escolher foto da carteirinha" /><button className="secondary-btn" type="button" disabled={photoBusy} onClick={() => fileInputRef.current?.click()}>{photoBusy ? "Salvando foto…" : "Adicionar ou trocar foto"}</button>{avatarPath && <button className="member-photo-remove" type="button" disabled={photoBusy} onClick={() => void removePhoto()}>Remover foto</button>}</div>
    <div className="member-photo-privacy"><label className="consent-field"><input type="checkbox" checked={avatarPublic} disabled={photoBusy || !avatarPath} onChange={(event) => void updatePhotoVisibility(event.target.checked)} /><span>{photoBusy ? "Salvando preferência…" : "Deixar minha foto pública nos meus posts do Feed"}</span></label><p>{!avatarPath ? "Adicione uma foto à carteirinha para ativar esta opção." : avatarPublic ? "Sua foto pode ser vista por qualquer visitante junto às suas publicações. Ao desativar, novos links deixam de ser emitidos; links já carregados podem durar até 10 minutos." : "Desativada por padrão. Só a sua conta vê a foto até você ativar esta opção."}</p></div>
    {photoError && <p className="auth-error" role="alert">{photoError}</p>}{photoSuccess && <p className="auth-success" role="status">{photoSuccess}</p>}
    <p className="data-note">O QR Code abre uma consulta pública que mostra apenas primeiro nome, cidade e situação do e-mail.</p></section>;
}

type LeaderboardPerson = { position: number; display_name: string; city: string | null; points: number };

function PublicLeaderboard({ leaderboard, error, currentName }: { leaderboard: LeaderboardPerson[]; error: string; currentName?: string }) {
  return <section className="panel ranking-panel"><div className="panel-title"><div className="ranking-heading"><Trophy size={16} /><h3>Ranking geral</h3></div><span className="badge">PÚBLICO</span></div><p className="muted">Todos os membros aparecem automaticamente, com primeiro nome, cidade e pontos.</p>{leaderboard.length ? <div className="ranking-list">{leaderboard.map((person) => <div className="ranking-row" key={person.position}><span className="ranking-position">{String(person.position).padStart(2, "0")}</span><div className="ranking-person"><strong>{person.display_name}{person.display_name === currentName?.trim().split(/\s+/)[0] && <span className="you-badge">Você</span>}</strong><span className="ranking-city">{person.city ?? "Grande ABC"}</span></div><strong className="ranking-score">{person.points.toLocaleString("pt-BR")} <span>pts</span></strong></div>)}</div> : <p className={error ? "auth-error" : "muted"} role={error ? "alert" : undefined}>{error || "Ainda não há membros cadastrados para exibir."}</p>}</section>;
}

function ProgressView({ notify, navigate, auth, openAuth }: { notify: (message: string) => void; navigate: (section: Section) => void; auth: ReturnType<typeof useSupabaseAuth>; openAuth: () => void }) {
  const [pointsPage,setPointsPage]=useState(0);
  const [points, setPoints] = useState<{ event_type: string; points: number; created_at: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [referralError, setReferralError] = useState("");
  const [rankingError, setRankingError] = useState("");
  const [referralSummary, setReferralSummary] = useState<{ registered: number; email_confirmed: number; awaiting_cpf: number; validated: number }>({ registered: 0, email_confirmed: 0, awaiting_cpf: 0, validated: 0 });
  const [leaderboard, setLeaderboard] = useState<{ position: number; display_name: string; city: string | null; points: number }[]>([]);
  const [checkedIn, setCheckedIn] = useState(false);
  const [showPointsGuide, setShowPointsGuide] = useState(false);
  const [todayIndex, setTodayIndex] = useState(0);
  const referralInputRef = useRef<HTMLInputElement>(null);
  const aggregate=useCommunityResource<MemberProgress>("social_my_progress",{},Boolean(auth.user));
  const total = aggregate.data?.points ?? 0;
  const currentLevel=aggregate.data?.level;
  const nextLevel=aggregate.data?.next_level;
  const progress = currentLevel ? nextLevel ? Math.max(0,Math.min(100, Math.round((total-currentLevel.minimum_points)/(nextLevel.minimum_points-currentLevel.minimum_points)*100))) : 100 : 0;

  const refresh = useCallback(async () => {
    if (!auth.client || !auth.user) return;
    setLoading(true);
    setError("");
    const { data, error: queryError } = await auth.client.from("points_ledger").select("event_type, points, created_at").eq("user_id", auth.user.id).order("created_at", { ascending: false }).range(pointsPage*50,pointsPage*50+49);
    setLoading(false);
    if (queryError) {
      setError(queryError.code === "42P01" || queryError.code === "PGRST205" ? "O histórico de pontos ainda não foi criado no Supabase. Aplique as migrações do projeto." : "Não foi possível carregar seus pontos. Confira a conexão e tente novamente.");
      return;
    }
    setPoints(data ?? []);
    const referralsResult = await auth.client.rpc("get_my_referral_summary");
    if (referralsResult.error) {
      setReferralError("As funções de indicação ainda não estão disponíveis no Supabase.");
    } else {
      const row = referralsResult.data?.[0];
      if (row) setReferralSummary({ registered: Number(row.registered), email_confirmed: Number(row.email_confirmed), awaiting_cpf: Number(row.awaiting_cpf), validated: Number(row.validated) });
    }
  }, [auth.client, auth.user,pointsPage]);

  useEffect(() => {
    let active = true;
    const timer = window.setTimeout(() => {
      if (!auth.client) {
        setLeaderboard([]);
        setRankingError("O ranking estará disponível quando a conexão com a comunidade estiver configurada.");
        return;
      }
      void auth.client.rpc("get_public_leaderboard").then(({ data, error: boardError }) => {
        if (!active) return;
        if (boardError) {
          setLeaderboard([]);
          setRankingError("Não foi possível carregar o ranking público agora.");
          return;
        }
        const boardRows = (data ?? []) as { rank_position: number; first_name: string; city: string | null; points: number }[];
        setLeaderboard(boardRows.map((entry) => ({ position: Number(entry.rank_position), display_name: entry.first_name, city: entry.city, points: Number(entry.points) })));
        setRankingError("");
      });
    }, 0);
    return () => { active = false; window.clearTimeout(timer); };
  }, [auth.client]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const day = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
      setTodayIndex(Math.floor(Date.now() / 86_400_000));
      if (!auth.user) { setPoints([]); setCheckedIn(false); return; }
      void refresh();
      void auth.client?.from("daily_mission_claims").select("mission_key").eq("user_id", auth.user.id).eq("claimed_on", day).eq("mission_key", "checkin").maybeSingle().then(({ data }) => setCheckedIn(Boolean(data)));
    }, 0);
    return () => window.clearTimeout(timer);
  }, [auth.client, auth.user, refresh]);

  async function checkIn() {
    if (!auth.client || !auth.user) { openAuth(); return; }
    setBusy(true); setError("");
    const { data, error: rpcError } = await auth.client.rpc("claim_daily_checkin");
    setBusy(false);
    if (rpcError) {
      setError(rpcError.code === "PGRST202" || rpcError.code === "42883" ? "O check-in ainda não foi ativado no Supabase. Aplique a migração de missões diárias." : "Não foi possível registrar o check-in. Tente novamente.");
      return;
    }
    setCheckedIn(true);
    notify(Number(data) > 0 ? "Check-in confirmado: +5 pontos." : "Seu check-in de hoje já foi registrado.");
    await refresh();
  }

  async function copyReferral() {
    const code = auth.profile?.referral_code;
    if (!code) { notify("Seu link será liberado quando seu perfil terminar de carregar."); return; }
    const url = `${window.location.origin}/?ref=${encodeURIComponent(code)}`;
    try { await navigator.clipboard.writeText(url); notify("Link de indicação copiado."); }
    catch { if (referralInputRef.current) { referralInputRef.current.value = url; referralInputRef.current.select(); } notify("Selecione e copie seu link de indicação."); }
  }

  const mission = dailyMissionIdeas[todayIndex % dailyMissionIdeas.length];
  return <>
    <div className="module-title-row"><div><div className="eyebrow">PONTOS E MISSÕES</div><h1>Meu progresso</h1><p className="muted">Pontos exibidos somente após registro validado no servidor.</p></div><div className="progress-title-actions"><span className="badge">{auth.user ? "CONTA CONECTADA" : "ENTRADA NECESSÁRIA"}</span><button className="secondary-btn points-guide-toggle" type="button" aria-expanded={showPointsGuide} aria-controls="points-guide" onClick={() => setShowPointsGuide((visible) => !visible)}><BookOpen size={14} /> {showPointsGuide ? "Fechar regras" : "Como pontuar"}</button></div></div>
    {showPointsGuide && <section className="panel points-guide-panel" id="points-guide"><div className="panel-title"><div className="ranking-heading"><BookOpen size={16} /><h3>Como funciona a pontuação</h3></div><span className="badge">REGRAS ATUAIS</span></div><p className="muted">Os pontos entram no seu histórico somente quando o servidor confirma a ação. Estas são as formas que estão configuradas hoje:</p><div className="points-guide-list"><div><span><strong>Check-in diário</strong><small>Toque em “Fazer check-in”. Vale uma vez por dia, no horário de Brasília.</small></span><b>+5 pts</b></div><div><span><strong>Apoio no Feed</strong><small>Ao apoiar uma publicação aprovada de outra pessoa, você ganha +3 pontos. Em posts identificados, o autor ganha +1. Posts anônimos não creditam ao autor para proteger sua identidade. Vale uma vez por pessoa em cada publicação.</small></span><b>+3 para você · +1 para o autor</b></div><div><span><strong>Indicação validada</strong><small>A pessoa precisa se cadastrar pelo seu link, confirmar o e-mail e ter o CPF conferido pela equipe autorizada.</small></span><b>+10 pts</b></div></div><div className="points-guide-note"><ShieldCheck size={15} /><p><strong>Publicações, relatos da cidade, anúncios e pedidos de serviço não dão pontos automaticamente.</strong> Curtir a própria publicação também não pontua. As sugestões que variam no app são ideias de participação, não missões pontuadas.</p></div><p className="data-note">A indicação é creditada uma única vez ao indicador após as três etapas. O CPF não fica salvo em texto aberto. A campanha de prêmio e a meta exibida no resumo ainda dependem de regras oficiais e validação da equipe.</p></section>}
    {!auth.user && <section className="panel"><h3>Acesse sua conta para ver seus pontos</h3><p className="muted">Seu histórico e link pessoal são privados e aparecem após entrar.</p><button className="primary-btn" type="button" onClick={openAuth}>Entrar ou criar conta　→</button></section>}
    {!auth.user && <PublicLeaderboard leaderboard={leaderboard} error={rankingError} />}
    {auth.user && <>
      {auth.profileError && <p className="auth-error" role="alert">{auth.profileError}</p>}
      <section className="panel daily-missions-panel"><div className="panel-title"><div className="ranking-heading"><Sparkles size={15} /><h3>Pontos e sugestão de hoje</h3></div><span className="badge">CHECK-IN +5</span></div><div className="daily-mission-list"><article className="daily-mission-card"><span className="daily-mission-icon"><CheckCircle2 size={15} /></span><div><strong>Check-in diário</strong><small>Confirme sua entrada. O servidor libera uma vez por dia.</small></div><button type="button" className="secondary-btn" disabled={busy || checkedIn} onClick={checkIn}>{busy ? "Registrando…" : checkedIn ? "Feito hoje" : "Fazer check-in · +5"}</button></article><article className="daily-mission-card"><span className="daily-mission-icon"><mission.icon size={15} /></span><div><strong>Sugestão: {mission.title}</strong><small>{mission.detail} {mission.title === "Curta uma publicação do Feed" ? "Ganha +3 pts se for uma publicação aprovada de outra pessoa, uma vez por publicação." : "É uma sugestão de participação e não concede pontos por si só."}</small></div><button type="button" className="secondary-btn" onClick={() => navigate(mission.section)}>Abrir　→</button></article></div></section>
      <div className="progress-top-grid"><section className="panel referral-panel"><div className="panel-title"><h3>Indique e convide</h3><span className="badge">LINK PESSOAL</span></div><p className="muted">A indicação só poderá pontuar após cadastro, confirmação de e-mail e validação de CPF pelo sistema seguro.</p><div className="referral-code"><div><span>SEU IDENTIFICADOR</span><strong>{auth.profile?.referral_code ?? (auth.profileLoading ? "CARREGANDO…" : "PERFIL INDISPONÍVEL")}</strong></div><div className="referral-link-row"><input ref={referralInputRef} aria-label="Link pessoal de indicação" readOnly value={auth.profile?.referral_code ? `/?ref=${auth.profile.referral_code}` : ""} placeholder="Aguarde o carregamento do perfil" /><button type="button" className="secondary-btn" onClick={copyReferral} disabled={!auth.profile}><Copy size={13} /> Copiar link</button></div></div></section>
      <section className="panel progress-summary"><div className="panel-title"><h3>Meu resumo</h3><span className="badge">{loading ? "CARREGANDO" : "DADOS DA CONTA"}</span></div><div className="summary-points"><strong>{total.toLocaleString("pt-BR")}</strong><span>pontos</span></div><div className="progress-next-level"><span>{currentLevel ? `Nível ${currentLevel.level} · ${currentLevel.name}` : "Consultando nível…"}</span><strong>{nextLevel ? `${total.toLocaleString("pt-BR")} / ${nextLevel.minimum_points.toLocaleString("pt-BR")} pts · ${progress}%` : currentLevel ? "Nível máximo alcançado" : "—"}</strong></div><div className="progress-track" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}><span style={{ width: `${progress}%` }} /></div><p className="data-note">Prêmio e elegibilidade não são ativados nesta tela; dependem de regras publicadas e validação oficial.</p></section></div>
      <ActivitySummary/><section className="panel history-panel"><div className="panel-title"><h3>Histórico de pontos</h3><span className="badge">{points.length} REGISTROS</span></div>{error && <p className="auth-error" role="alert">{error}</p>}{loading ? <p className="muted" role="status">Carregando…</p> : points.length ? <div className="point-history-list">{points.map((item, index) => <div className="point-history-row" key={`${item.created_at}-${index}`}><span className="point-history-icon"><CheckCircle2 size={14} /></span><div><strong>{({ daily_checkin: "Check-in diário", verified_referral: "Indicação validada", feed_like: "Apoio no Feed", feed_like_received: "Curtida recebida" } as Record<string, string>)[item.event_type] ?? item.event_type.replaceAll("_", " ")}</strong><span>{new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(item.created_at))}</span></div><b>+{item.points} pts</b></div>)}</div> : <p className="muted">Ainda não há pontos registrados para esta conta.</p>}</section>
      <div className="button-row"><button className="secondary-btn" disabled={loading||pointsPage===0} onClick={()=>setPointsPage(pointsPage-1)}>Pontos anteriores</button><span>Página {pointsPage+1}</span><button className="secondary-btn" disabled={loading||points.length<50} onClick={()=>setPointsPage(pointsPage+1)}>Mais histórico</button></div><section className="panel referral-panel"><div className="panel-title"><h3>Suas indicações</h3><span className="badge">{referralSummary.validated} VALIDADAS</span></div><div className="stats-grid"><Stat icon={UsersRound} label="Cadastros feitos pelo link" value={String(referralSummary.registered)} foot="Vinculados à sua conta" /><Stat icon={CheckCircle2} label="E-mail confirmado" value={String(referralSummary.email_confirmed)} foot="Aguardando validação final" /><Stat icon={ShieldCheck} label="CPF validado pela equipe" value={String(referralSummary.validated)} foot="Indicações que pontuaram" /></div>{referralError && <p role="alert" className="auth-error">{referralError}</p>}<p className="data-note">A equipe autorizada confere o CPF pelo canal seguro. O número não fica salvo: o sistema mantém apenas uma impressão protegida para impedir que ele valide mais de uma indicação.</p></section>
      <PublicLeaderboard leaderboard={leaderboard} error={rankingError} currentName={auth.profile?.display_name} />
    </>}
  <SeasonRanking/></>;
}

type AnimalRecord = { id: string; report_type: "perdido" | "encontrado"; animal_name: string | null; species: string; city: string; neighborhood: string | null; description: string; status: string; created_at: string; media_path?: string | null; media_url?: string };

function AnimalReports({ city, auth, notify, openAuth }: { city: string; auth: ReturnType<typeof useSupabaseAuth>; notify: (message: string) => void; openAuth: () => void }) {
  const [reports, setReports] = useState<AnimalRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [contacts, setContacts] = useState<Record<string, string>>({});
  const [imageFile, setImageFile] = useState<File | null>(null);

  const refresh = useCallback(async () => {
    if (!auth.client) return;
    setLoading(true);
    const targetAnimal = new URLSearchParams(window.location.search).get("animal");
    let animalQuery=auth.client.from("animal_reports").select("id,report_type,animal_name,species,city,neighborhood,description,status,created_at,media_path").eq("status","active");
    if(targetAnimal&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(targetAnimal))animalQuery=animalQuery.eq("id",targetAnimal);
    const {data,error:queryError}=await animalQuery.order("created_at",{ascending:false}).limit(100);
    setLoading(false);
    if (queryError) setError(queryError.code === "42P01" || queryError.code === "PGRST205" ? "A área de Animais Perdidos ainda não foi ativada no Supabase." : "Não foi possível carregar os avisos de animais.");
    else { setReports(await hydrateSubmissionImages(auth.client, data ?? [])); setError(""); }
  }, [auth.client]);
  useInitialRefresh(refresh);

  async function submitReport(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!auth.client || !auth.user) { openAuth(); setError("Entre para publicar um aviso de animal."); return; }
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const result = animalReportSchema.safeParse({ reportType: form.get("report_type"), name: form.get("name") ?? "", species: form.get("species"), city: form.get("city"), neighborhood: form.get("neighborhood") ?? "", description: form.get("description"), contact: form.get("contact") });
    if (!result.success) { setError(result.error.issues[0]?.message ?? "Confira os dados do aviso."); setSuccess(""); return; }
    if (form.get("contact_consent") !== "on") { setError("Autorize que o contato seja compartilhado com pessoas conectadas interessadas em ajudar."); return; }
    setBusy(true); setError(""); setSuccess("");
    let mediaPath: string | null = null;
    try {
      if (imageFile) {
        const uploaded = await uploadSubmissionImage(auth.client, auth.user.id, imageFile);
        if (uploaded.error) { setError(uploaded.error); return; }
        mediaPath = uploaded.path;
      }
      const { error: insertError } = await auth.client.from("animal_reports").insert({ owner_id: auth.user.id, report_type: result.data.reportType, animal_name: result.data.name || null, species: result.data.species, city: result.data.city, neighborhood: result.data.neighborhood || null, description: result.data.description, contact: result.data.contact, contact_consent_at: new Date().toISOString(), media_path: mediaPath });
      if (insertError) { if (mediaPath) await auth.client.storage.from(submissionMediaBucket).remove([mediaPath]); setError(submissionLimitMessage(insertError) ?? (insertError.code === "42P01" || insertError.code === "PGRST205" ? "Aplique as migrações de Animais Perdidos no Supabase antes de publicar." : insertError.code === "PGRST204" ? "Aplique a nova migração de imagens no Supabase." : insertError.code === "42501" ? "O banco recusou o aviso por permissão. Confira as migrações de Animais Perdidos e imagens." : "Não foi possível enviar o aviso. Confira os dados e tente novamente.")); return; }
      formElement.reset(); setImageFile(null); setSuccess("Aviso enviado para análise. Ele aparecerá para a comunidade após aprovação."); setCreating(false); notify("Aviso enviado para moderação.");
    } catch {
      if (mediaPath) await auth.client.storage.from(submissionMediaBucket).remove([mediaPath]);
      setError("Falha de conexão. Não foi possível confirmar o aviso; atualize a lista antes de tentar novamente.");
    } finally {
      setBusy(false);
    }
  }

  async function revealContact(id: string) {
    if (!auth.client || !auth.user) { openAuth(); return; }
    const { data, error: contactError } = await auth.client.rpc("get_animal_contact", { report_id: id });
    if (contactError || !data) { notify("O contato do responsável está indisponível."); return; }
    setContacts((current) => ({ ...current, [id]: String(data) }));
  }

  const linkedAnimal=typeof window!=="undefined"&&new URLSearchParams(window.location.search).has("animal");
  const visible = reports.filter((item) => linkedAnimal || city === "Todas as cidades" || item.city === city);
  return <>
    <div className="module-title-row"><div><div className="eyebrow">AJUDA QUE SE ESPALHA · GRANDE ABC</div><h1>Animais Perdidos</h1><p className="muted">Avisos revisados para ajudar animais perdidos ou encontrados a voltar para casa.</p></div><button className="primary-btn" type="button" onClick={() => auth.user ? setCreating(!creating) : openAuth()}>＋　Publicar aviso</button></div>
    {creating && <section className="panel"><div className="panel-title"><h3>Novo aviso de animal</h3><span className="badge">REVISADO ANTES DE PUBLICAR</span></div><form className="form-grid" onSubmit={submitReport} noValidate><div className="field"><label htmlFor="animal-report-type">Tipo de aviso</label><select id="animal-report-type" name="report_type" defaultValue="" required><option value="" disabled>Selecione</option><option value="perdido">Animal perdido</option><option value="encontrado">Animal encontrado</option></select></div><div className="field"><label htmlFor="animal-name">Nome (se souber)</label><input id="animal-name" name="name" maxLength={80} /></div><div className="field"><label htmlFor="animal-species">Espécie</label><select id="animal-species" name="species" required defaultValue=""><option value="" disabled>Selecione</option><option>Cachorro</option><option>Gato</option><option>Ave</option><option>Outro</option></select></div><div className="field"><label htmlFor="animal-city">Cidade</label><select id="animal-city" name="city" defaultValue={auth.profile?.city ?? ""} required><option value="" disabled>Selecione</option>{cities.slice(1).map((name) => <option key={name}>{name}</option>)}</select></div><div className="field"><label htmlFor="animal-neighborhood">Bairro aproximado</label><input id="animal-neighborhood" name="neighborhood" maxLength={80} /></div><div className="field"><label htmlFor="animal-contact">Contato do responsável</label><input id="animal-contact" name="contact" required maxLength={120} placeholder="Telefone ou e-mail" /></div><div className="field full"><label htmlFor="animal-description">Descrição</label><textarea id="animal-description" name="description" minLength={20} maxLength={1200} required placeholder="Cor, porte, características e ponto de referência aproximado. Não publique endereço residencial." /></div><ImageAttachmentField id="animal-media" file={imageFile} onChange={setImageFile} disabled={busy} /><div className="field full"><label className="consent-field"><input type="checkbox" name="contact_consent" /><span>Autorizo compartilhar meu contato com membros conectados para ajudar neste caso.</span></label></div><div className="field full"><button type="submit" className="primary-btn" disabled={busy}>{busy ? "Enviando…" : "Enviar para análise →"}</button>{error && <small role="alert" className="auth-error">{error}</small>}{success && <small role="status" className="feed-success">{success}</small>}</div></form><p className="data-note">A foto só aparece ao público depois da aprovação; o contato exato continua protegido.</p></section>}
    {success && !creating && <p role="status" className="feed-success">{success}</p>}{error && !creating && <p role="alert" className="auth-error">{error}</p>}
    <div className="section-head"><h2>Ajude um animal a voltar para casa</h2><span className="badge">{loading ? "CARREGANDO" : `${visible.length} AVISOS`}</span></div>
    {loading ? <div className="empty" role="status">Carregando avisos…</div> : <div className="listing-grid">{visible.length ? visible.map((report) => <article className="panel listing-card" key={report.id}><div className="listing-art">{report.media_url ? <Image src={report.media_url} alt={`Foto de ${report.animal_name || report.species}`} width={640} height={480} unoptimized /> : <PawPrint size={48} strokeWidth={1.3} />}<span className="listing-label">{report.report_type === "perdido" ? "ANIMAL PERDIDO" : "ANIMAL ENCONTRADO"}</span></div><div className="listing-copy"><strong>{report.animal_name || report.species}</strong><p>{report.neighborhood ? `${report.neighborhood} · ` : ""}{report.city}</p><p>{report.description}</p>{contacts[report.id] ? <a className="secondary-btn" style={{ width: "100%", marginTop: 11 }} href={contacts[report.id].includes("@") ? `mailto:${contacts[report.id]}` : `https://wa.me/${contacts[report.id].replace(/\D/g, "")}`} target="_blank" rel="noreferrer">Conversar com responsável</a> : <button className="secondary-btn" style={{ width: "100%", marginTop: 11 }} onClick={() => void revealContact(report.id)}>Quero ajudar · ver contato</button>}</div></article>) : <div className="empty">Ainda não há avisos aprovados para esta cidade.</div>}</div>}
    <p className="data-note">Contatos ficam protegidos e só podem ser solicitados por pessoas conectadas. Avisos passam por análise da equipe.</p>
    
  </>;
}

type MarketplaceRecord = ListingExtras & { id: string; title: string; category: string; city: string; neighborhood: string | null; description: string; price: number | null; created_at: string; media_path?: string | null; media_url?: string };

function Marketplace({ city, query, setQuery, category, setCategory, auth, notify, openAuth }: { city: string; query: string; setQuery: (value: string) => void; category: string; setCategory: (value: string) => void; auth: ReturnType<typeof useSupabaseAuth>; notify: (message: string) => void; openAuth: () => void }) {
  const [items, setItems] = useState<MarketplaceRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [contacts, setContacts] = useState<Record<string, string>>({});
  const [imageFile, setImageFile] = useState<File | null>(null);
  const categories = ["Todos", "Casa", "Bicicletas", "Eletrônicos", "Instrumentos", "Eletrodomésticos", "Empregos", "Outros"];
  const isJobs = category === "Empregos";

  const refresh = useCallback(async () => {
    if (!auth.client) return;
    setLoading(true);
    let request=auth.client.from("marketplace_listings").select("id,title,category,city,neighborhood,description,price,status,created_at,media_path,condition_name,accepts_trade,deal_type,previous_price").eq("status", "active");
    const target=new URLSearchParams(window.location.search).get("anuncio");if(target&&/^[0-9a-f-]{36}$/i.test(target))request=request.eq("id",target);
    const {data,error:queryError}=await request.order("created_at",{ascending:false}).limit(100);
    setLoading(false);
    if (queryError) setError(queryError.code === "42P01" || queryError.code === "PGRST205" ? "O Mercadão ainda não foi ativado no banco Supabase." : "Não foi possível carregar os anúncios.");
    else { setItems(await hydrateSubmissionImages(auth.client, data ?? [])); setError(""); }
  }, [auth.client]);
  useInitialRefresh(refresh);

  async function submitListing(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!auth.client || !auth.user) { openAuth(); setError("Entre para publicar um anúncio."); return; }
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const dealType=String(form.get("deal_type")||"venda");
    const priceText = dealType==="doacao"?"0":String(form.get("price") ?? "").trim().replace(",", ".");
    const result = marketplaceListingSchema.safeParse({ title: form.get("title"), category: form.get("category"), city: form.get("city"), neighborhood: form.get("neighborhood") ?? "", description: form.get("description"), price: priceText ? Number(priceText) : null, contact: form.get("contact") });
    if (!result.success) { setError(result.error.issues[0]?.message ?? "Confira os dados do anúncio."); setSuccess(""); return; }
    if (form.get("contact_consent") !== "on") { setError("Autorize que seu contato seja compartilhado com pessoas conectadas interessadas no anúncio."); return; }
    setBusy(true); setError(""); setSuccess("");
    let mediaPath: string | null = null;
    try {
      if (imageFile) {
        const uploaded = await uploadSubmissionImage(auth.client, auth.user.id, imageFile);
        if (uploaded.error) { setError(uploaded.error); return; }
        mediaPath = uploaded.path;
      }
      const { error: insertError } = await auth.client.from("marketplace_listings").insert({ owner_id: auth.user.id, ...result.data, condition_name: form.get("condition_name")||"Usado", accepts_trade:form.get("accepts_trade")==="on",deal_type:dealType, neighborhood: result.data.neighborhood || null, contact_consent_at: new Date().toISOString(), media_path: mediaPath });
      if (insertError) { if (mediaPath) await auth.client.storage.from(submissionMediaBucket).remove([mediaPath]); setError(submissionLimitMessage(insertError) ?? (insertError.code === "42P01" || insertError.code === "PGRST205" ? "Aplique as migrações do Mercadão no Supabase antes de publicar." : insertError.code === "PGRST204" ? "Aplique a nova migração de imagens no Supabase." : insertError.code === "42501" ? "O banco recusou o anúncio por permissão. Confira as migrações do Mercadão e imagens." : "Não foi possível enviar o anúncio. Confira os dados e tente novamente.")); return; }
      formElement.reset(); setImageFile(null); setSuccess("Anúncio enviado para análise. Ele aparecerá depois da aprovação da equipe."); setCreating(false); notify("Anúncio enviado para moderação.");
    } catch {
      if (mediaPath) await auth.client.storage.from(submissionMediaBucket).remove([mediaPath]);
      setError("Falha de conexão. Não foi possível confirmar o anúncio; atualize a lista antes de tentar novamente.");
    } finally {
      setBusy(false);
    }
  }

  async function revealContact(id: string) {
    if (!auth.client || !auth.user) { openAuth(); return; }
    const { data, error: contactError } = await auth.client.rpc("get_listing_contact", { listing_id: id });
    if (contactError || !data) { notify("O contato deste vendedor está indisponível."); return; }
    setContacts((current) => ({ ...current, [id]: String(data) }));
  }

  const visible = items.filter((item) => (city === "Todas as cidades" || item.city === city) && (category === "Todos" || item.category === category) && `${item.title} ${item.category} ${item.city} ${item.neighborhood ?? ""} ${item.description}`.toLocaleLowerCase("pt-BR").includes(query.toLocaleLowerCase("pt-BR")));
  return <>
    <div className="module-title-row"><div><div className="eyebrow">COMPRA E VENDA NO SEU BAIRRO</div><h1>Mercadão</h1><p className="muted">Anúncios e oportunidades enviados por moradores e revisados pela equipe.</p></div><div className="button-row market-actions"><button className="secondary-btn" onClick={() => setCategory("Empregos")}><Briefcase size={13} /> Ver vagas</button><button className="primary-btn" type="button" onClick={() => auth.user ? setCreating(!creating) : openAuth()}>＋　Criar anúncio</button></div></div>
    <div className="button-row market-module-links"><a className="secondary-btn" href="/?area=vagas">Vagas detalhadas</a><a className="secondary-btn" href="/?area=achados">Achados e perdidos</a></div><MyMarketListings/>
    {creating && <section className="panel"><div className="panel-title"><h3>Novo anúncio</h3><span className="badge">REVISÃO ANTES DA PUBLICAÇÃO</span></div><form className="form-grid" onSubmit={submitListing} noValidate><div className="field"><label htmlFor="listing-title">Título</label><input id="listing-title" name="title" required minLength={5} maxLength={100} /></div><div className="field"><label htmlFor="listing-category">Categoria</label><select id="listing-category" name="category" defaultValue="" required><option value="" disabled>Selecione</option>{categories.slice(1).map((item) => <option key={item}>{item}</option>)}</select></div><div className="field"><label htmlFor="listing-city">Cidade</label><select id="listing-city" name="city" defaultValue={auth.profile?.city ?? ""} required><option value="" disabled>Selecione</option>{cities.slice(1).map((name) => <option key={name}>{name}</option>)}</select></div><div className="field"><label htmlFor="listing-neighborhood">Bairro</label><input id="listing-neighborhood" name="neighborhood" maxLength={80} /></div><div className="field"><label htmlFor="listing-price">Preço (R$; opcional para vagas)</label><input id="listing-price" name="price" inputMode="decimal" placeholder="Ex.: 250,00" /></div><div className="field"><label htmlFor="listing-condition">Estado</label><select id="listing-condition" name="condition_name"><option>Usado</option><option>Seminovo</option><option>Novo</option></select></div><div className="field"><label htmlFor="listing-deal">Tipo de negócio</label><select id="listing-deal" name="deal_type"><option value="venda">Venda</option><option value="troca">Troca</option><option value="doacao">Doação gratuita</option></select></div><div className="field full"><label><input type="checkbox" name="accepts_trade"/> Também aceito troca</label></div><div className="field"><label htmlFor="listing-contact">Contato</label><input id="listing-contact" name="contact" required maxLength={120} placeholder="Telefone ou e-mail" /></div><div className="field full"><label htmlFor="listing-description">Descrição</label><textarea id="listing-description" name="description" required minLength={20} maxLength={1200} /></div><ImageAttachmentField id="listing-media" file={imageFile} onChange={setImageFile} disabled={busy} /><div className="field full"><label className="consent-field"><input type="checkbox" name="contact_consent" /><span>Autorizo compartilhar este contato com membros conectados interessados no anúncio, após aprovação.</span></label></div><div className="field full"><button className="primary-btn" type="submit" disabled={busy}>{busy ? "Enviando…" : "Enviar para análise →"}</button>{error && <small role="alert" className="auth-error">{error}</small>}{success && <small role="status" className="feed-success">{success}</small>}</div></form></section>}
    <label className="searchbar"><Search size={15} /><input value={query} maxLength={100} onChange={(e) => setQuery(e.target.value.slice(0, 100))} placeholder={isJobs ? "Buscar vaga, cargo ou bairro…" : "Buscar produto, categoria ou bairro…"} aria-label="Buscar anúncios e vagas" /></label>
    <div className="filter-row" style={{ marginTop: 12 }}>{categories.map((item) => <button key={item} className={`filter-chip ${category === item ? "selected" : ""}`} onClick={() => setCategory(item)}>{item}</button>)}</div>
    {success && !creating && <p role="status" className="feed-success">{success}</p>}{error && !creating && <p role="alert" className="auth-error">{error}</p>}
    <div className="section-head"><h2>{isJobs ? "Vagas no Grande ABC" : "Anúncios na comunidade"}</h2><span className="badge">{loading ? "CARREGANDO" : `${visible.length} ATIVOS`}</span></div>
    {loading ? <div className="empty" role="status">Carregando anúncios…</div> : <div className="listing-grid">{visible.length ? visible.map((item) => <article key={item.id} className="panel listing-card"><div className="listing-art">{item.media_url ? <Image src={item.media_url} alt={`Foto do anúncio ${item.title}`} width={640} height={480} unoptimized /> : isJobs ? <Briefcase size={48} strokeWidth={1.3} /> : <Store size={48} strokeWidth={1.3} />}<span className="listing-label">{item.category}</span></div><div className="listing-copy"><strong>{item.title}</strong><p>{item.neighborhood ? `${item.neighborhood} · ` : ""}{item.city}</p><p>{item.description}</p><ListingBadges item={item}/><div className="price">{item.deal_type==="doacao"?"Grátis":item.price == null ? "A combinar" : money(Number(item.price))}</div>{contacts[item.id] ? <a className="secondary-btn" style={{ width: "100%", marginTop: 11 }} href={contacts[item.id].includes("@") ? `mailto:${contacts[item.id]}` : `https://wa.me/${contacts[item.id].replace(/\D/g, "")}`} target="_blank" rel="noreferrer">Conversar com anunciante</a> : <button className="secondary-btn" style={{ width: "100%", marginTop: 11 }} onClick={() => void revealContact(item.id)}>Ver contato</button>}</div></article>) : <div className="empty">Ainda não há anúncios aprovados para este filtro.</div>}</div>}
    <p className="data-note">O contato fica privado até a pessoa conectada solicitar vê-lo. Anúncios só aparecem depois da análise da equipe.</p>
    
  </>;
}

function CityReport({ onSubmit, error, success, connected, authenticated, submitting, reports, loading, selectedCity }: { onSubmit: (event: FormEvent<HTMLFormElement>, imageFile: File | null) => Promise<boolean>; error: string; success: string; connected: boolean; authenticated: boolean; submitting: boolean; reports: CityReportRecord[]; loading: boolean; selectedCity: string }) {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const visibleReports = reports.filter((report) => selectedCity === "Todas as cidades" || report.city === selectedCity);
  const statusLabels: Record<CityReportRecord["status"], string> = { pending: "Recebido · aguardando análise", review: "Em análise", in_progress: "Em andamento", resolved: "Resolvido", rejected: "Não publicado" };
  return <><div className="module-title-row"><div><div className="eyebrow">PARTICIPAÇÃO CIDADÃ</div><h1>Problemas da cidade</h1><p className="muted">Relate situações urbanas e acompanhe as atualizações da comunidade.</p></div><span className="badge">{connected ? "CONECTADO" : "PRÉVIA"}</span></div><div className="two-col"><section className="panel"><div className="panel-title"><h3>Registrar um relato</h3><span className="badge">{authenticated ? "CONTA CONECTADA" : "ENTRADA NECESSÁRIA"}</span></div><form onSubmit={(event) => { void onSubmit(event, imageFile).then((sent) => { if (sent) setImageFile(null); }); }} className="form-grid" noValidate><div className="field full"><label htmlFor="report-category">Tipo de problema</label><select id="report-category" name="category" required defaultValue=""><option value="" disabled>Selecione</option><option>Buraco ou pavimento</option><option>Iluminação pública</option><option>Descarte irregular de lixo</option><option>Sinalização ou semáforo</option><option>Calçada ou acessibilidade</option><option>Árvore ou área verde</option><option>Outro</option></select></div><div className="field"><label htmlFor="report-city">Cidade</label><select id="report-city" name="city" required defaultValue={selectedCity === "Todas as cidades" ? "" : selectedCity}><option value="" disabled>Selecione</option>{cities.slice(1).map((name) => <option key={name}>{name}</option>)}</select></div><div className="field"><label htmlFor="neighborhood">Bairro</label><input id="neighborhood" name="neighborhood" maxLength={80} placeholder="Nome do bairro (opcional)" /></div><div className="field full"><label htmlFor="details">Descrição</label><textarea id="details" name="details" placeholder="Conte o que aconteceu e um ponto de referência aproximado…" required minLength={15} maxLength={2000} /><small>Não inclua endereço residencial, telefone, nomes ou outros dados pessoais.</small></div><ImageAttachmentField id="report-media" file={imageFile} onChange={setImageFile} disabled={submitting} /><div className="field full"><button className="primary-btn" type="submit" disabled={submitting}>{submitting ? "Enviando…" : authenticated ? "Enviar relato para análise" : "Entrar para enviar relato"}　→</button>{error && <small role="alert" style={{ color: "#ff9f91" }}>{error}</small>}{success && <small className="feed-success" role="status">{success}</small>}</div></form></section><aside className="panel"><div className="panel-title"><h3>Como funciona</h3></div><div className="notice"><span className="badge">01 · RECEBIDO</span><strong>A equipe da SAD recebe seu relato.</strong><p>O recebimento pela SAD não significa recebimento pela prefeitura.</p></div><div className="notice"><span className="badge">02 · EM ANÁLISE</span><strong>O relato é revisado.</strong><p>Relatos começam privados e pendentes; a equipe atualiza o andamento.</p></div><div className="notice"><span className="badge">03 · ATUALIZAÇÃO</span><strong>Acompanhe o andamento.</strong><p>Relatos em análise, em andamento ou resolvidos podem aparecer à comunidade. Um problema só aparece como resolvido após confirmação adequada.</p></div></aside></div><div className="section-head"><h2>Relatos da comunidade</h2><span className="badge">{loading ? "CARREGANDO" : `${visibleReports.length} RELATOS`}</span></div><div className="feed-list">{loading ? <div className="empty" role="status">Carregando relatos…</div> : visibleReports.length ? visibleReports.map((report) => <article className="panel" key={report.id}><div className="panel-title"><h3>{report.category}</h3><span className="badge">{statusLabels[report.status]}</span></div><p className="muted">{report.neighborhood ? `${report.neighborhood} · ` : ""}{report.city} · {report.createdAt}</p><p>{report.description}</p>{report.media_url && <Image className="feed-post-media" src={report.media_url} alt={`Foto do relato: ${report.category}`} width={960} height={720} unoptimized />}<small className="data-note">Localização aproximada. Identidade do autor não é exibida.</small></article>) : <div className="empty">Ainda não há relatos públicos para essa cidade.</div>}</div><p className="data-note">{connected ? "Os relatos são gravados com acesso protegido por RLS. Só relatos em análise, em andamento ou resolvidos ficam públicos; os pendentes são visíveis apenas ao autor." : "Demonstração: conexão ao servidor ainda não está configurada."}</p></>;
}
function PartnerArea({ mode, auth, openAuth }: { mode: "parceiros" | "portal"; auth: ReturnType<typeof useSupabaseAuth>; openAuth: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [requests, setRequests] = useState<{ id: string; service_type: string; status: string; created_at: string }[]>([]);
  const [requestsError, setRequestsError] = useState("");
  const serviceType = mode === "parceiros" ? "Cadastro de parceiro" : "Acesso ao portal do parceiro";
  const refresh = useCallback(async () => {
    if (!auth.client || !auth.user) { setRequests([]); return; }
    try {
      const { data, error: queryError } = await auth.client.from("service_requests").select("id,service_type,status,created_at").eq("author_id", auth.user.id).eq("service_type", serviceType).order("created_at", { ascending: false });
      if (queryError) throw queryError;
      setRequests(data ?? []);
      setRequestsError("");
    } catch {
      setRequestsError("Não foi possível carregar seus pedidos. Confirme se as migrações de serviços foram aplicadas no Supabase.");
    }
  }, [auth.client, auth.user, serviceType]);
  useInitialRefresh(refresh);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!auth.client || !auth.user) { openAuth(); return; }
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const business = String(form.get("business") ?? "").trim();
    if (business.length < 2) { setError("Informe o nome do negócio."); return; }
    const details = `Negócio: ${business}. ${String(form.get("details") ?? "").trim()}`;
    const result = socialServiceRequestSchema.safeParse({ contact: form.get("contact"), city: form.get("city"), neighborhood: "", service: serviceType, details, consent: form.get("consent") });
    if (!result.success) { setError(result.error.issues[0]?.message ?? "Confira o cadastro."); return; }
    setBusy(true); setError(""); setSuccess("");
    try {
      const { error: submitError } = await auth.client.from("service_requests").insert({ author_id: auth.user.id, service_type: serviceType, city: result.data.city, contact: result.data.contact, description: result.data.details });
      if (submitError) {
        setError(submissionLimitMessage(submitError) ?? (submitError.code === "42P01" || submitError.code === "PGRST205" ? "A tabela de pedidos não existe ainda. Aplique as migrações do Supabase." : submitError.code === "42501" ? "O banco recusou o pedido por permissão. Atualize as migrações de serviços no Supabase." : "Não foi possível enviar o pedido. Confira os campos e tente novamente."));
        return;
      }
      formElement.reset(); setSuccess("Pedido enviado à equipe Conecta ABC. A aprovação e o acesso serão informados pelo contato cadastrado."); await refresh();
    } catch {
      setError("Falha de conexão. O pedido não foi confirmado; verifique a lista antes de tentar novamente.");
    } finally {
      setBusy(false);
    }
  }
  const isPartner = mode === "parceiros";
  return <>
    <div className="module-title-row"><div><div className="eyebrow">{isPartner ? "COMÉRCIO QUE CONECTA" : "ÁREA PROFISSIONAL"}</div><h1>{isPartner ? "Parceiros e ofertas" : "Portal do parceiro"}</h1><p className="muted">{isPartner ? "Peça a análise do seu negócio para participar da rede local." : "Solicite acesso às ferramentas para negócios parceiros aprovados."}</p></div><span className="badge">ANÁLISE DA EQUIPE</span></div>
    <div className="two-col"><section className="panel"><div className="panel-title"><h3>{isPartner ? "Quero ser parceiro" : "Solicitar acesso ao portal"}</h3><span className="badge">PRIVADO</span></div><p className="muted">Ofertas e ferramentas só são liberadas após conferência da equipe.</p>{!auth.user ? <button className="primary-btn" type="button" onClick={openAuth}>Entre para continuar　→</button> : <form className="form-grid" onSubmit={submit} noValidate><div className="field"><label htmlFor="partner-business">Nome do negócio</label><input id="partner-business" name="business" required minLength={2} maxLength={120} /></div><div className="field"><label htmlFor="partner-city">Cidade</label><select id="partner-city" name="city" defaultValue={auth.profile?.city ?? ""} required><option value="" disabled>Selecione</option>{cities.slice(1).map((name) => <option key={name}>{name}</option>)}</select></div><div className="field"><label htmlFor="partner-contact">Contato para retorno</label><input id="partner-contact" name="contact" required minLength={8} maxLength={120} placeholder="Telefone ou e-mail" /></div><div className="field full"><label htmlFor="partner-details">{isPartner ? "Conte sobre os produtos ou serviços" : "Informe o vínculo com o negócio"}</label><textarea id="partner-details" name="details" required minLength={20} maxLength={1400} /></div><div className="field full"><label className="consent-field"><input type="checkbox" name="consent" required /><span>Autorizo a equipe a usar esses dados para analisar e retornar sobre este pedido.</span></label></div><div className="field full"><button className="primary-btn" type="submit" disabled={busy}>{busy ? "Enviando…" : "Enviar para análise →"}</button>{error && <small role="alert" className="auth-error">{error}</small>}{success && <small role="status" className="feed-success">{success}</small>}</div></form>}</section><aside className="panel"><div className="panel-title"><h3>Meus pedidos</h3><span className="badge">{requests.length}</span></div>{requestsError ? <p role="alert" className="auth-error">{requestsError}</p> : requests.length ? requests.map((request) => <div className="notice" key={request.id}><strong>{request.service_type}</strong><span className="badge">{request.status === "received" ? "Recebido" : request.status === "review" ? "Em análise" : request.status}</span><p>{new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium" }).format(new Date(request.created_at))}</p></div>) : <p className="muted">Nenhum pedido feito nesta conta.</p>}<p className="data-note">Esta solicitação não cria automaticamente uma oferta nem concede acesso de parceiro.</p></aside></div>
    
  </>;
}

type MySubmission = { submission_id: string; submission_type: string; title: string; city: string; status: string; description: string; created_at: string };

function MySubmissionsView({ client, user, loadingAuth, openAuth, navigate }: { client: SupabaseClient | null; user: User | null; loadingAuth: boolean; openAuth: () => void; navigate: (section: Section) => void }) {
  const [page,setPage]=useState(0);
  const [items, setItems] = useState<MySubmission[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("todos");
  const refresh = useCallback(async () => {
    if (!client || !user) { setItems([]); return; }
    setLoading(true); setError("");
    const { data, error: loadError } = await client.rpc("social_my_submissions",{page_number:page});
    setLoading(false);
    if (loadError) setError("Não foi possível carregar seus envios. Atualize a página ou tente novamente.");
    else setItems((data ?? []) as MySubmission[]);
  }, [client, user,page]);
  useInitialRefresh(refresh);
  const statusText: Record<string, string> = { expired:"Expirado",cancelled:"Cancelado",pending: "Aguardando análise", received: "Recebido", review: "Em análise", in_progress: "Em andamento", resolved: "Resolvido", completed: "Atendido", closed: "Encerrado", approved: "Aprovado", active: "Publicado", rejected: "Não aprovado", hidden: "Oculto", sold: "Vendido", reunido: "Animal reunido", encerrado: "Encerrado" };
  const filtered = items.filter((item) => filter === "todos" || (filter === "andamento" ? ["pending", "received", "review", "in_progress"].includes(item.status) : ["expired","cancelled","resolved", "completed", "closed", "approved", "active", "rejected", "hidden", "sold", "reunido", "encerrado"].includes(item.status)));
  const sectionByType: Record<string, Section> = { feed: "feed", cidade: "cidade", animal: "animais", mercadao: "mercadao", servico: "servicos",agenda:"agenda",imoveis:"imoveis",vagas:"vagas",achados:"achados",empresa:"portal",story:"stories",enquete:"enquetes",grupo:"comunidades",post_grupo:"comunidades",comentario:"feed",avaliacao:"mapa",indica:"indica",cupom:"cupons-portal",mapa:"mapa" };
  if (loadingAuth) return <section className="panel"><div className="empty" role="status">Carregando sua conta…</div></section>;
  if (!user) return <><div className="module-title-row"><div><div className="eyebrow">ACOMPANHAMENTO</div><h1>Meus envios</h1><p className="muted">Entre para acompanhar publicações, relatos e pedidos enviados por você.</p></div></div><section className="panel"><button className="primary-btn" type="button" onClick={openAuth}>Entrar ou criar conta　→</button></section></>;
  return <><div className="module-title-row"><div><div className="eyebrow">ACOMPANHAMENTO</div><h1>Meus envios</h1><p className="muted">Veja o andamento dos seus relatos, publicações e pedidos de serviço.</p></div><button type="button" className="secondary-btn" disabled={loading} onClick={() => void refresh()}>{loading ? "Atualizando…" : "Atualizar"}</button></div>
    <section className="panel submissions-panel"><div className="submission-filters" aria-label="Filtrar envios">{[["todos", "Todos"], ["andamento", "Em andamento"], ["finalizados", "Finalizados"]].map(([value, label]) => <button key={value} type="button" className={filter === value ? "active" : ""} aria-pressed={filter === value} onClick={() => setFilter(value)}>{label}</button>)}</div>
      {error ? <p className="auth-error" role="alert">{error}<button type="button" className="text-action" onClick={() => void refresh()}>Tentar novamente</button></p> : loading && !items.length ? <div className="empty" role="status">Carregando seus envios…</div> : filtered.length ? <div className="submission-list">{filtered.map((item) => <article className="submission-item" key={`${item.submission_type}-${item.submission_id}`}><div className="submission-item-main"><div className="panel-title"><strong>{item.title}</strong><span className={`submission-status status-${item.status}`}>{statusText[item.status] ?? item.status}</span></div><p>{item.city} · {new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(item.created_at))}</p><small>{item.description}</small></div><button type="button" className="secondary-btn" onClick={() => navigate(sectionByType[item.submission_type] ?? "inicio")}>Abrir área　→</button></article>)}</div> : <div className="empty">{items.length ? "Não há envios nesta categoria." : "Você ainda não enviou nada. Quando fizer um envio, poderá acompanhar o andamento aqui."}</div>}
    <div className="button-row"><button className="secondary-btn" disabled={loading||page===0} onClick={()=>setPage(page-1)}>Anterior</button><span>Página {page+1}</span><button className="secondary-btn" disabled={loading||items.length<50} onClick={()=>setPage(page+1)}>Próxima</button></div></section><p className="data-note">Os status são atualizados pela equipe responsável. Você acompanha cada etapa por esta tela; seus dados e contatos permanecem protegidos.</p>
  </>;
}

function SocialServiceRequest({ auth, openAuth }: { auth: ReturnType<typeof useSupabaseAuth>; openAuth: () => void }) {
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [busy, setBusy] = useState(false);
  const [requests, setRequests] = useState<{ id: string; service_type: string; city: string; status: string; created_at: string }[]>([]);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    if (!auth.client || !auth.user) { setRequests([]); return; }
    setLoading(true);
    const { data, error: queryError } = await auth.client.from("service_requests").select("id, service_type, city, status, created_at").eq("author_id", auth.user.id).order("created_at", { ascending: false }).limit(20);
    setLoading(false);
    if (queryError) setError(queryError.code === "42P01" || queryError.code === "PGRST205" ? "A tabela de solicitações ainda não existe no Supabase. Aplique as migrações do projeto." : "Não foi possível carregar suas solicitações.");
    else setRequests(data ?? []);
  }, [auth.client, auth.user]);

  useInitialRefresh(refresh);

  async function submitRequest(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!auth.client || !auth.user) { openAuth(); setError("Entre ou crie uma conta para enviar seu pedido com segurança."); return; }
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const result = socialServiceRequestSchema.safeParse({ contact: form.get("contact"), city: form.get("city"), neighborhood: form.get("neighborhood") ?? "", service: form.get("service"), details: form.get("details"), consent: form.get("consent") });
    if (!result.success) { setError(result.error.issues[0]?.message ?? "Confira os campos do formulário."); setSuccess(""); return; }
    setBusy(true); setError(""); setSuccess("");
    try {
      const { error: insertError } = await auth.client.from("service_requests").insert({ author_id: auth.user.id, service_type: result.data.service, city: result.data.city, neighborhood: result.data.neighborhood || null, contact: result.data.contact, description: result.data.details });
      if (insertError) {
        setError(submissionLimitMessage(insertError) ?? (insertError.code === "42P01" || insertError.code === "PGRST205" ? "O banco ainda não tem a tabela de atendimentos. Aplique as migrações do projeto." : insertError.code === "42501" ? "Sua conta não tem permissão para enviar pedidos. Atualize as políticas RLS do Supabase." : "Não foi possível enviar agora. Confira os campos e tente novamente."));
        return;
      }
      formElement.reset(); setSuccess("Solicitação enviada com segurança. A equipe poderá analisar e retornar pelo contato informado.");
      await refresh();
    } catch {
      setError("Falha de conexão. Não conseguimos confirmar o envio; atualize a lista antes de reenviar.");
    } finally {
      setBusy(false);
    }
  }

  const labels: Record<string, string> = { received: "Recebida", review: "Em análise", in_progress: "Em andamento", completed: "Concluída", closed: "Encerrada" };
  return <>
    <div className="module-title-row"><div><div className="eyebrow">PROJETO SOCIAL · CONECTA ABC</div><h1>Como podemos ajudar?</h1><p className="muted">Conte do que você precisa. A equipe do projeto social poderá analisar seu pedido e orientar os próximos passos.</p></div><span className="badge">{auth.user ? "CONTA CONECTADA" : "ENTRADA NECESSÁRIA"}</span></div>
    {!auth.user && <section className="panel"><h3>Entre para cadastrar um pedido</h3><p className="muted">As solicitações e seus contatos ficam privados e vinculados à sua conta.</p><button className="primary-btn" type="button" onClick={openAuth}>Entrar ou criar conta　→</button></section>}
    {auth.user && <div className="two-col"><section className="panel"><div className="panel-title"><h3>Conte sua necessidade</h3><span className="badge">PRIVADO</span></div><p className="muted">O formulário exige apenas o necessário para a equipe retornar.</p><form onSubmit={submitRequest} className="form-grid" noValidate>
      <div className="field"><label htmlFor="service-contact">Telefone ou e-mail para retorno</label><input id="service-contact" name="contact" autoComplete="tel" required maxLength={120} placeholder="Seu contato" /></div>
      <div className="field"><label htmlFor="service-city">Cidade</label><select id="service-city" name="city" required defaultValue={auth.profile?.city ?? ""}><option value="" disabled>Selecione sua cidade</option>{cities.slice(1).map((name) => <option key={name}>{name}</option>)}</select></div>
      <div className="field"><label htmlFor="service-neighborhood">Bairro (opcional)</label><input id="service-neighborhood" name="neighborhood" autoComplete="address-level3" maxLength={80} placeholder="Seu bairro" /></div>
      <div className="field"><label htmlFor="service-type">Tipo de apoio</label><select id="service-type" name="service" required defaultValue=""><option value="" disabled>Escolha uma opção</option><option>Apoio social e benefícios</option><option>Orientação jurídica</option><option>Atendimento veterinário</option><option>Doações e itens essenciais</option><option>Cursos e oportunidades</option><option>Outro tipo de apoio</option><option>Ainda não sei — quero conversar</option></select></div>
      <div className="field full"><label htmlFor="service-details">Do que você precisa?</label><textarea id="service-details" name="details" required minLength={20} maxLength={1500} placeholder="Explique brevemente como a equipe pode ajudar. Evite incluir documentos, senhas ou dados sensíveis." /><small>Até 1.500 caracteres. Não envie documentos nem informações médicas detalhadas.</small></div>
      <div className="field full"><label className="consent-field"><input type="checkbox" name="consent" required /><span>Autorizo a equipe do projeto social a usar o contato informado para retornar sobre esta solicitação.</span></label></div>
      <div className="field full"><button className="primary-btn" type="submit" disabled={busy}>{busy ? "Enviando…" : "Enviar pedido de atendimento　→"}</button>{error && <small role="alert" style={{ color: "#ff9f91" }}>{error}</small>}{success && <small className="feed-success" role="status">{success}</small>}</div>
    </form></section><aside className="panel"><div className="panel-title"><h3>Seus pedidos</h3><span className="badge">PRIVADOS</span></div>{loading ? <p role="status">Carregando…</p> : requests.length ? requests.map((request) => <div className="notice" key={request.id}><span className="badge">{labels[request.status] ?? request.status}</span><strong>{request.service_type}</strong><p>{request.city} · {new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium" }).format(new Date(request.created_at))}</p></div>) : <p className="muted">Você ainda não enviou pedidos.</p>}<p className="data-note">A lista e as informações de contato só podem ser vistas pela sua conta e pela equipe autorizada.</p></aside></div>}
    
  </>;
}

function CommunityFeed({ city, posts, onCreatePost, onLike, onReport, notify, loading, connected, initialTab = "comunidade", startComposing = false }: { startComposing?: boolean; city: string; posts: FeedPost[]; onCreatePost: (submission: CommunityPostSubmission) => Promise<boolean>; onLike: (id: string,kind?:string) => void; onReport: (postId: string, reason: string, details: string) => Promise<boolean>; notify: (message: string) => void; loading: boolean; connected: boolean; initialTab?: FeedTab }) {
  const [tab, setTab] = useState<FeedTab>(initialTab);
  const [composing, setComposing] = useState(startComposing);
  const [error, setError] = useState("");
  const [posted, setPosted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState("");
  const [anonymous, setAnonymous] = useState(false);
  const visiblePosts = posts.filter((post) => (tab === "oficial") === post.official && (city === "Todas as cidades" || post.city === "Grande ABC" || post.city === city));

  useEffect(() => () => { if (mediaPreview) URL.revokeObjectURL(mediaPreview); }, [mediaPreview]);

  useEffect(() => {
    const match = window.location.hash.match(/^#feed\/([^/]+)/);
    if (!match) return;
    const postId = decodeURIComponent(match[1]);
    const timer = window.setTimeout(() => document.getElementById(`feed-post-${postId}`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 0);
    return () => window.clearTimeout(timer);
  }, [posts]);

  function selectMedia(event: ChangeEvent<HTMLInputElement>) {
    const file = event.currentTarget.files?.[0] ?? null;
    if (!file) return;
    const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm", "video/quicktime"]);
    if (!allowedTypes.has(file.type)) {
      setError("Escolha uma foto JPG, PNG ou WebP, ou um vídeo MP4, WebM ou MOV.");
      event.currentTarget.value = "";
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      setError("O arquivo deve ter até 20 MB.");
      event.currentTarget.value = "";
      return;
    }
    setError("");
    setMediaFile(file);
    setMediaPreview(URL.createObjectURL(file));
  }

  function removeMedia() {
    setMediaFile(null);
    setMediaPreview("");
    const input = document.getElementById("feed-media") as HTMLInputElement | null;
    if (input) input.value = "";
  }

  function submitPost(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const result = communityPostSchema.safeParse({ category: form.get("category"), city: form.get("city"), body: form.get("body") });
    if (!result.success) {
      setError(result.error.issues[0]?.message ?? "Confira os campos da publicação.");
      setPosted(false);
      return;
    }
    setSubmitting(true);
    setError("");
    void onCreatePost({ draft: { author: "Membro da comunidade", city: result.data.city, category: result.data.category, body: result.data.body, official: false, sensitive: false }, anonymous, mediaFile })
      .then((success) => {
        if (!success) return;
        formElement.reset();
        setAnonymous(false);
        setMediaFile(null);
        setMediaPreview("");
        setPosted(true);
        notify("Enviado para análise da equipe. A publicação aparecerá no feed após aprovação.");
      })
      .finally(() => setSubmitting(false));
  }

  return <>
    <div className="module-title-row"><div><div className="eyebrow">COMUNIDADE · GRANDE ABC</div><h1>Feed da comunidade</h1><p className="muted">Ideias, conversas e informações úteis para quem vive no ABC.</p></div><span className="badge">{connected ? "CONECTADO" : "PRÉVIA"}</span></div>
    <div className="feed-tabs" role="tablist" aria-label="Tipo de publicação"><button type="button" role="tab" aria-selected={tab === "comunidade"} className={tab === "comunidade" ? "selected" : ""} onClick={() => setTab("comunidade")}>Comunidade</button><button type="button" role="tab" aria-selected={tab === "oficial"} className={tab === "oficial" ? "selected" : ""} onClick={() => setTab("oficial")}>Notícias do ABC <span>SAD · oficial</span></button></div>
    {tab === "comunidade" && <button type="button" className="social-compose-prompt" aria-expanded={composing} onClick={() => setComposing(!composing)}><ImagePlus size={20}/>{composing ? "Fechar editor" : "No que você está pensando?"}</button>}
    {tab === "comunidade" ? composing && <section className="panel feed-composer"><div className="panel-title"><h3>O que você quer compartilhar?</h3><span className="badge">MORADORES</span></div><form onSubmit={submitPost} className="form-grid" noValidate><div className="field"><label htmlFor="feed-category">Assunto</label><select id="feed-category" name="category" defaultValue="" required><option value="" disabled>Selecione</option><option>Conversa do bairro</option><option>Pedido de ajuda</option><option>Evento comunitário</option><option>Dica ou informação</option><option>Conquista da comunidade</option></select></div><div className="field"><label htmlFor="feed-city">Cidade</label><select id="feed-city" name="city" defaultValue={city === "Todas as cidades" ? "Santo André" : city} required>{cities.slice(1).map((name) => <option key={name}>{name}</option>)}</select></div><div className="field full"><label htmlFor="feed-body">Sua publicação</label><textarea id="feed-body" name="body" required minLength={10} maxLength={1200} placeholder="Escreva uma mensagem para a comunidade…" /><small>Até 1.200 caracteres. Não publique telefones, documentos, endereços ou dados pessoais de outras pessoas.</small></div><div className="field full"><label className="feed-media-label" htmlFor="feed-media"><ImagePlus size={14} /> Foto ou vídeo (opcional)</label><input id="feed-media" name="media" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" onChange={selectMedia} /><small>JPG, PNG, WebP, MP4, WebM ou MOV · até 20 MB. A mídia fica privada até a publicação ser aprovada.</small>{mediaPreview && mediaFile && <div className="feed-media-preview">{mediaFile.type.startsWith("video/") ? <><video src={mediaPreview} controls muted playsInline /><span><Video size={14} /> Prévia do vídeo</span></> : <Image src={mediaPreview} alt="Prévia da foto escolhida" width={480} height={320} unoptimized />}<button type="button" className="secondary-btn" onClick={removeMedia}><X size={14} /> Remover mídia</button></div>}</div><div className="field full"><label className="consent-field"><input type="checkbox" checked={anonymous} onChange={(event) => setAnonymous(event.currentTarget.checked)} /><span>Publicar anonimamente. Seu nome e sua foto não aparecerão para a comunidade; a equipe de moderação poderá identificar o autor se necessário.</span></label></div><div className="field full"><div className="feed-submit-row"><button className="primary-btn" type="submit" disabled={submitting}>{submitting ? "Enviando…" : connected ? "Enviar para análise　→" : "Entrar para publicar　→"}</button><span>{connected ? "É preciso entrar. A equipe revisa antes da publicação." : "Publicações reais exigem conta e moderação."}</span></div>{error && <small role="alert" style={{ color: "#ff9f91" }}>{error}</small>}{posted && <small className="feed-success" role="status">Enviado para análise. A publicação aparecerá após aprovação.</small>}</div></form></section> : <section className="official-intro"><div className="official-icon"><ShieldCheck size={18} /></div><div><strong>Notícias do ABC · Administração SAD</strong><p>Espaço para acidentes, ocorrências, alertas e informações de interesse público. Publicações precisam de contexto, data e fonte ou referência. Conteúdo sensível recebe aviso antes da exibição.</p></div></section>}
    
    <div className="section-head"><h2>{tab === "oficial" ? "Notícias do ABC · SAD" : "Publicações da comunidade"}</h2><span className="badge">{tab === "oficial" ? `${visiblePosts.length} notícias` : `${visiblePosts.length} ${visiblePosts.length === 1 ? "publicação" : "publicações"}`}</span></div>
    <div className="feed-list">{loading && tab === "comunidade" ? <div className="empty" role="status">Carregando publicações…</div> : visiblePosts.length ? visiblePosts.map((post) => <FeedPostCard key={post.id} post={post} onLike={onLike} onReport={onReport} notify={notify} />) : <div className="empty">Ainda não há publicações aprovadas nesta área para a cidade selecionada.</div>}</div>
    <p className="data-note">{connected ? "Publicações de moradores são enviadas para análise e aparecem após aprovação. O Notícias do ABC é reservado à equipe autorizada; denúncias são encaminhadas à moderação." : "Entre para compartilhar com a comunidade."}</p>
  </>;
}

function FeedPostCard({ post, onLike, onReport, notify }: { post: FeedPost; onLike: (id: string,kind?:string) => void; onReport: (postId: string, reason: string, details: string) => Promise<boolean>; notify: (message: string) => void }) {
  const visibility=usePersonalPostVisibility(post.id);
  const [failedAvatarUrl, setFailedAvatarUrl] = useState<string>();
  const avatarUrl = !post.anonymous && post.authorAvatarUrl !== failedAvatarUrl ? post.authorAvatarUrl : undefined;
  const [showSensitive, setShowSensitive] = useState(false);
  const [postMenuOpen,setPostMenuOpen]=useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportBusy, setReportBusy] = useState(false);
  const [reportError, setReportError] = useState("");
  async function sharePost() {
    const url = new URL("/", window.location.origin);
    url.searchParams.set("post", post.id);
    try {
      if (navigator.share) {
        await navigator.share({ title: post.title ?? "Conecta ABC · Feed", text: post.body.slice(0, 180), url: url.toString() });
      } else {
        await navigator.clipboard.writeText(url.toString());
        notify("Link externo da publicação copiado. Você já pode compartilhar com qualquer pessoa.");
      }
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") return;
      try {
        await navigator.clipboard.writeText(url.toString());
        notify("Link externo da publicação copiado.");
      } catch {
        window.prompt("Copie e envie este link externo:", url.toString());
      }
    }
  }
  async function reportPost(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const reason = String(form.get("reason") ?? "");
    const details = String(form.get("details") ?? "").trim();
    if (!reason) { setReportError("Selecione o motivo da denúncia."); return; }
    if (details.length > 1000) { setReportError("Use até 1.000 caracteres na descrição."); return; }
    setReportBusy(true);
    setReportError("");
    try {
      const submitted = await onReport(post.id, reason, details);
      if (submitted) setReportOpen(false);
    } finally {
      setReportBusy(false);
    }
  }
  if(visibility.hidden)return <div className="hidden-post-note"><span>Publicação ocultada nesta visualização.</span><button className="secondary-btn" onClick={visibility.show}>Desfazer</button></div>;
  return <article data-post-status={post.status} id={`feed-post-${post.id}`} className={`panel feed-post ${post.official ? "feed-post-official" : ""}`}>
    <div className="feed-post-header"><div className={`feed-avatar ${post.official ? "official" : ""}`}>{post.official ? <ShieldCheck size={16} /> : avatarUrl ? <Image src={avatarUrl} alt="Foto pública do autor" width={34} height={34} unoptimized onError={() => setFailedAvatarUrl(avatarUrl)} /> : post.anonymous ? <UserRound size={16} /> : post.author.slice(0, 1)}</div><div className="feed-author"><strong>{post.author}</strong><span>{post.city} · {post.createdAt}</span></div><span className={`feed-post-label ${post.official ? "official" : ""}`}>{post.official ? "NOTÍCIAS DO ABC · SAD" : post.status === "pending" ? "EM ANÁLISE" : "COMUNIDADE"}</span><div className="ref-post-menu"><button type="button" aria-label="Mais opções da publicação" aria-expanded={postMenuOpen} onClick={()=>setPostMenuOpen(!postMenuOpen)}><Ellipsis size={22}/></button>{postMenuOpen&&<div><button type="button" onClick={()=>{setReportOpen(true);setPostMenuOpen(false);}}>Denunciar publicação</button><button type="button" onClick={visibility.hide}>Ocultar na minha tela</button></div>}</div></div>
    <div className="feed-post-category">{post.category}</div>{post.title && <h3 className="feed-post-title">{post.title}</h3>}{post.sensitive && !showSensitive ? <button type="button" className="sensitive-reveal" onClick={() => setShowSensitive(true)}><AlertTriangle size={15} /><span><strong>Conteúdo sensível</strong><small>Ocorrência ou acidente · toque para ler</small></span></button> : <><p className="feed-post-body">{post.body}</p>{post.mediaUrl && post.mediaKind === "image" && <Image className="feed-post-media" src={post.mediaUrl} alt="Mídia anexada à publicação" width={960} height={720} unoptimized />}{post.mediaUrl && post.mediaKind === "video" && <video className="feed-post-media" src={post.mediaUrl} controls preload="metadata" playsInline />}</>}{post.source && <p className="feed-post-source">Fonte / referência: {post.source}</p>}
    {reportOpen && <form className="feed-report-form" onSubmit={reportPost} noValidate><div className="field"><label htmlFor={`report-reason-${post.id}`}>Motivo da denúncia</label><select id={`report-reason-${post.id}`} name="reason" required defaultValue=""><option value="" disabled>Selecione</option><option value="spam">Spam ou conteúdo repetido</option><option value="abusive">Ofensa ou assédio</option><option value="misinformation">Informação possivelmente falsa</option><option value="privacy">Exposição de dados ou privacidade</option><option value="other">Outro motivo</option></select></div><div className="field"><label htmlFor={`report-details-${post.id}`}>Detalhes (opcional)</label><textarea id={`report-details-${post.id}`} name="details" maxLength={1000} placeholder="Conte à equipe por que esta publicação deve ser analisada." /></div><small>O relato será enviado em sigilo para a equipe de moderação.</small>{reportError && <small role="alert" className="auth-error">{reportError}</small>}<div className="button-row"><button className="primary-btn" type="submit" disabled={reportBusy}>{reportBusy ? "Enviando…" : "Enviar denúncia"}</button><button className="secondary-btn" type="button" onClick={() => setReportOpen(false)} disabled={reportBusy}>Cancelar</button></div></form>}
    <PostSocialActions postId={post.id} approved={post.status === "approved" && !post.demo} compact summary={<p className="ref-reaction-total">{post.likes} {post.likes===1?"reação":"reações"}</p>} leadingActions={<><button type="button" aria-label={`Apoiar · ${post.likes}`} title="Apoiar" aria-pressed={post.liked} onClick={()=>onLike(post.id)}><Heart size={25} fill={post.liked?"currentColor":"none"}/></button><ReactionPicker postId={post.id} react={onLike} disabled={post.status!=="approved"}/></>} trailingActions={<button type="button" aria-label="Compartilhar" title="Compartilhar" onClick={()=>void sharePost()}><Share2 size={23}/></button>}/>
    {post.demo && <div className="feed-demo-note">Demonstração · conteúdo fictício, não publicado para outros usuários.</div>}
  </article>;
}

function AdminPanel({ access, accessLoading, posts, onCreatePost, onLike, onReport, notify, client, user, onModerated, onCityReportStatusChanged }: { access: Access; accessLoading: boolean; posts: FeedPost[]; onCreatePost: (post: FeedPostDraft) => Promise<boolean>; onLike: (id: string,kind?:string) => void; onReport: (postId: string, reason: string, details: string) => Promise<boolean>; notify: (message: string) => void; client: SupabaseClient | null; user: User | null; onModerated: (post: PendingPost, decision: "approved" | "rejected") => void; onCityReportStatusChanged: (reportId: string, status: CityReportRecord["status"]) => void }) {
  const [error, setError] = useState("");
  const [created, setCreated] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const officialPosts = posts.filter((post) => post.official);
  const canManage = access.is_admin || access.is_city_moderator || access.is_service_provider || access.is_referral_verifier;

  if (accessLoading) return <section className="panel"><div className="empty" role="status">Verificando as permissões da sua conta…</div></section>;
  if (!canManage) return <section className="panel"><div className="panel-title"><h2>Área restrita</h2><ShieldCheck size={18} /></div><p className="muted">Sua conta não tem acesso a ferramentas de gestão.</p></section>;

  async function submitOfficialPost(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const result = officialPostSchema.safeParse({ title: form.get("title"), category: form.get("category"), city: form.get("city"), body: form.get("body"), source: form.get("source"), sensitive: form.get("sensitive") === "on" });
    if (!result.success) {
      setError(result.error.issues[0]?.message ?? "Confira os campos do comunicado.");
      setCreated(false);
      return;
    }
    setPublishing(true);
    try {
      const success = await onCreatePost({ author: "Administração SAD", city: result.data.city, category: result.data.category, title: result.data.title, body: result.data.body, source: result.data.source, official: true, sensitive: result.data.sensitive });
      if (!success) { setError("A publicação não foi salva. Confira o login, as permissões de moderação e as migrações do Supabase."); setCreated(false); return; }
      formElement.reset();
      setError("");
      setCreated(true);
      notify("Comunicado publicado no Notícias do ABC.");
    } catch {
      setError("Falha de conexão. Atualize o Feed antes de tentar publicar novamente.");
      setCreated(false);
    } finally {
      setPublishing(false);
    }
  }

  return <>
    <div className="module-title-row"><div><div className="eyebrow">ÁREA PROFISSIONAL · ACESSO POR FUNÇÃO</div><h1>{access.is_admin ? "Administração" : access.is_service_provider && access.is_city_moderator ? "Painel da equipe" : access.is_service_provider ? "Painel do prestador" : access.is_city_moderator ? "Gestão de relatos" : "Validação de indicações"}</h1><p className="muted">As ferramentas abaixo correspondem às permissões vinculadas à sua conta.</p></div><span className="badge">ACESSO VERIFICADO</span></div>
    {canManage && <section className="panel" style={{ marginBottom: 14 }}><div className="panel-title"><div><h3>Painel externo da equipe</h3><p className="muted" style={{ margin: "5px 0 0" }}>Área separada do app para trabalhar nas filas de moderação e atendimento.</p></div><Link className="primary-btn" href="/equipe/painel">Abrir painel da equipe　→</Link></div></section>}
    {access.is_referral_verifier && <section className="panel"><div className="panel-title"><h3>Validação de indicações</h3><span className="badge">ÁREA RESTRITA</span></div><p className="muted">Confira o documento original pelo canal seguro da equipe. O painel só registra um identificador criptográfico, nunca o CPF em texto aberto.</p><Link className="primary-btn" href="/equipe/validar-indicacoes">Abrir fila de validação　→</Link></section>}
    {access.is_admin && <CommunityPostReportQueue key={`feed-reports-${user?.id ?? "signed-out"}`} client={client} user={user} notify={notify} />}
    {access.is_admin && <ModerationQueue key={user?.id ?? "signed-out"} client={client} user={user} notify={notify} onModerated={onModerated} />}
    {access.is_city_moderator && <CityReportModerationQueue key={`reports-${user?.id ?? "signed-out"}`} client={client} user={user} notify={notify} onStatusChanged={onCityReportStatusChanged} />}
    {access.is_service_provider && <ServiceRequestModerationQueue key={`service-requests-${user?.id ?? "signed-out"}`} client={client} user={user} notify={notify} />}
    {access.is_admin && <>
    <SubmissionModerationQueue key={`community-submissions-${user?.id ?? "signed-out"}`} client={client} user={user} notify={notify} type="marketplace" />
    <SubmissionModerationQueue key={`animal-submissions-${user?.id ?? "signed-out"}`} client={client} user={user} notify={notify} type="animals" />
      <div className="admin-feed-layout"><section className="panel"><div className="panel-title"><h3>Nova publicação para o Notícias do ABC</h3><span className="badge">INFORMAÇÃO VERIFICADA</span></div><p className="muted admin-feed-guidance">Use para acidentes, ocorrências, alertas, utilidade pública e prestação de contas. Inclua contexto, data e fonte. Não publique imagens gráficas, rostos, placas ou dados que identifiquem vítimas.</p><form onSubmit={submitOfficialPost} className="form-grid" noValidate><div className="field full"><label htmlFor="official-title">Título</label><input id="official-title" name="title" required minLength={5} maxLength={120} placeholder="Título claro e informativo" /></div><div className="field"><label htmlFor="official-category">Categoria</label><select id="official-category" name="category" defaultValue="" required><option value="" disabled>Selecione</option><option>Acidente ou ocorrência</option><option>Alerta à comunidade</option><option>Trânsito e serviço</option><option>Informação pública</option><option>Dados e prestação de contas</option><option>Posicionamento institucional</option><option>Atualização de projeto</option></select></div><div className="field"><label htmlFor="official-city">Cidade das notícias</label><select id="official-city" name="city" defaultValue="Grande ABC" required><option value="Grande ABC">Todas as cidades · Grande ABC</option>{cities.slice(1).map((name) => <option key={name}>{name}</option>)}</select><small>Escolha onde a notícia será exibida.</small></div><div className="field full"><label htmlFor="official-source">Fonte ou referência</label><input id="official-source" name="source" required minLength={3} maxLength={300} placeholder="Órgão, documento ou link de referência" /></div><div className="field full"><label htmlFor="official-body">Conteúdo</label><textarea id="official-body" name="body" required minLength={30} maxLength={3000} placeholder="Apresente os fatos, o contexto e o que muda para a população…" /><small>De 30 a 3.000 caracteres. Evite afirmações sem fonte e identifique datas e locais.</small></div><div className="field full"><label className="consent-field"><input type="checkbox" name="sensitive" /><span>Marcar como conteúdo sensível. A publicação mostrará um aviso antes de exibir o texto.</span></label></div><div className="field full"><button className="primary-btn" type="submit" disabled={publishing}>{publishing ? "Publicando…" : "Adicionar ao Notícias do ABC　→"}</button>{error && <small role="alert" style={{ color: "#ff9f91" }}>{error}</small>}{created && <small className="feed-success" role="status">Publicação adicionada à prévia e disponível na aba “Notícias do ABC” do Feed.</small>}</div></form></section>
        <section className="panel"><div className="panel-title"><h3>Publicações do Notícias do ABC</h3><span className="badge">{officialPosts.length} PUBLICAÇÕES</span></div><div className="admin-official-list">{officialPosts.map((post) => <FeedPostCard key={post.id} post={post} onLike={onLike} onReport={onReport} notify={notify} />)}</div><p className="data-note">Comunicados oficiais são publicados no Feed com fonte, categoria e aviso de conteúdo sensível.</p></section></div></>}
  </>;
}

type PendingPost = { id: string; author_name: string; city: string; category: string; body: string; created_at: string; media_path?: string | null; media_kind?: "image" | "video" | null; media_url?: string };

type PendingFeedReport = { report_id: string; post_id: string; reason: string; details: string; category: string; city: string; post_body: string; created_at: string };

function CommunityPostReportQueue({ client, user, notify }: { client: SupabaseClient | null; user: User | null; notify: (message: string) => void }) {
  const [reports, setReports] = useState<PendingFeedReport[]>([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState("");
  const reasonLabels: Record<string, string> = { spam: "Spam ou conteúdo repetido", abusive: "Ofensa ou assédio", misinformation: "Informação possivelmente falsa", privacy: "Exposição de dados ou privacidade", other: "Outro motivo" };

  const refresh = useCallback(async () => {
    if (!client || !user) { setReports([]); setLoaded(true); return; }
    setLoading(true); setError("");
    const { data, error: loadError } = await client.rpc("list_pending_community_post_reports");
    setLoading(false); setLoaded(true);
    if (loadError) {
      setReports([]);
      setError(loadError.code === "42501" ? "Sua conta não tem permissão para consultar denúncias." : "Não foi possível carregar as denúncias. Confira se a migração do Feed foi aplicada.");
    } else setReports((data ?? []) as PendingFeedReport[]);
  }, [client, user]);
  useInitialRefresh(refresh);

  async function review(report: PendingFeedReport) {
    if (!client) return;
    setBusyId(report.report_id);
    const { error: reviewError } = await client.rpc("review_community_post_report", { report_id: report.report_id });
    setBusyId("");
    if (reviewError) { setError(reviewError.code === "42501" ? "Sua conta não tem permissão para revisar denúncias." : "A denúncia não pôde ser atualizada. Atualize a fila e tente novamente."); return; }
    setReports((current) => current.filter((item) => item.report_id !== report.report_id));
    notify("Denúncia marcada como analisada.");
  }

  return <section className="panel" style={{ marginBottom: 14 }}>
    <div className="panel-title"><div><h3>Denúncias do Feed</h3><p className="muted" style={{ margin: "5px 0 0" }}>Relatos enviados pelos membros, visíveis apenas para a equipe.</p></div><button className="secondary-btn" type="button" onClick={() => void refresh()} disabled={loading || !user}>{loading ? "Atualizando…" : "Atualizar fila"}</button></div>
    {!user ? <div className="empty">Entre com uma conta autorizada para revisar denúncias.</div> : loading || !loaded ? <div className="empty" role="status">Carregando denúncias…</div> : error ? <div className="empty" role="alert">{error}</div> : reports.length === 0 ? <div className="empty">Nenhuma denúncia pendente.</div> : <div className="feed-list">{reports.map((report) => <article className="notice" key={report.report_id}><div className="panel-title"><strong>{reasonLabels[report.reason] ?? "Outro motivo"} · {report.category} · {report.city}</strong><span className="muted">{new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(report.created_at))}</span></div><p>{report.post_body}</p>{report.details && <p className="muted">Detalhes: {report.details}</p>}<div className="button-row"><a className="secondary-btn" href={`/?post=${encodeURIComponent(report.post_id)}`} target="_blank" rel="noreferrer">Abrir publicação</a><button className="primary-btn" type="button" onClick={() => void review(report)} disabled={Boolean(busyId)}>{busyId === report.report_id ? "Salvando…" : "Marcar como analisada"}</button></div></article>)}</div>}
  </section>;
}

async function hydratePendingPostMedia(client: SupabaseClient, posts: PendingPost[]) {
  const paths = [...new Set(posts.flatMap((post) => post.media_path ? [post.media_path] : []))];
  if (!paths.length) return posts;
  const { data, error } = await client.storage.from("feed-media").createSignedUrls(paths, 60 * 60);
  if (error || !data) return posts;
  const urls = new Map(data.map((item) => [item.path, item.signedUrl]));
  return posts.map((post) => ({ ...post, media_url: post.media_path ? urls.get(post.media_path) ?? undefined : undefined }));
}

type PendingCityReport = Pick<CityReportRecord, "id" | "category" | "city" | "neighborhood" | "description" | "status" | "media_path" | "media_url"> & { created_at: string };

function CityReportModerationQueue({ client, user, notify, onStatusChanged }: { client: SupabaseClient | null; user: User | null; notify: (message: string) => void; onStatusChanged: (reportId: string, status: CityReportRecord["status"]) => void }) {
  const [reports, setReports] = useState<PendingCityReport[]>([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState("");

  const refresh = useCallback(async () => {
    if (!client || !user) {
      setReports([]);
      setLoaded(true);
      return;
    }
    setLoading(true);
    setError("");
    try {
      const { data, error: loadError } = await client.rpc("list_city_reports_for_moderation");
      if (loadError) throw loadError;
      setReports(await hydrateSubmissionImages(client, (data ?? []) as PendingCityReport[]));
      setLoaded(true);
    } catch (loadError) {
      setReports([]);
      setLoaded(true);
      setError(loadError && typeof loadError === "object" && "code" in loadError && loadError.code === "42501"
        ? "Esta conta não tem permissão para revisar relatos."
        : "Não foi possível carregar a fila. A migração de análise de relatos precisa ser aplicada no Supabase.");
    } finally {
      setLoading(false);
    }
  }, [client, user]);

  useEffect(() => {
    let active = true;
    if (!client || !user) {
      return;
    }
    void Promise.resolve(client.rpc("list_city_reports_for_moderation")).then(({ data, error: loadError }) => {
      if (!active) return;
      setLoaded(true);
      if (loadError) {
        setReports([]);
        setError(loadError.code === "42501" ? "Esta conta não tem permissão para revisar relatos." : "Não foi possível carregar a fila. A migração de análise de relatos precisa ser aplicada no Supabase.");
      } else {
        void hydrateSubmissionImages(client, (data ?? []) as PendingCityReport[]).then((rows) => { if (active) setReports(rows); });
        setError("");
      }
    }).catch(() => {
      if (!active) return;
      setLoaded(true);
      setReports([]);
      setError("Falha de conexão ao carregar a fila. Tente atualizar.");
    }).finally(() => {
      if (active) setLoading(false);
    });
    return () => { active = false; };
  }, [client, user]);

  async function decide(report: PendingCityReport, status: Exclude<CityReportRecord["status"], "pending">) {
    if (!client) return;
    setBusyId(report.id);
    setError("");
    try {
      const { error: actionError } = await client.rpc("moderate_city_report", { report_id: report.id, decision: status });
      if (actionError) throw actionError;
      setReports((current) => status === "resolved" || status === "rejected"
        ? current.filter((item) => item.id !== report.id)
        : current.map((item) => item.id === report.id ? { ...item, status } : item));
      onStatusChanged(report.id, status);
      const messages: Record<typeof status, string> = {
        review: "Relato publicado para a comunidade como em análise.",
        in_progress: "Relato atualizado para em andamento.",
        resolved: "Relato marcado como resolvido e publicado.",
        rejected: "Relato recusado; ele permanece visível apenas ao autor.",
      };
      notify(messages[status]);
    } catch (actionError) {
      setError(actionError && typeof actionError === "object" && "code" in actionError && actionError.code === "42501"
        ? "Sua conta não tem permissão para revisar relatos."
        : "O relato não foi atualizado. Atualize a fila e tente novamente.");
    } finally {
      setBusyId("");
    }
  }

  return <section className="panel" style={{ marginBottom: 14 }}>
    <div className="panel-title"><div><h3>Fila de problemas da cidade</h3><p className="muted" style={{ margin: "5px 0 0" }}>Só moderadores cadastrados no Supabase podem publicar ou atualizar relatos.</p></div><button className="secondary-btn" type="button" onClick={() => void refresh()} disabled={loading || !user}>{loading ? "Atualizando…" : "Atualizar fila"}</button></div>
    {!user ? <div className="empty">Entre com uma conta autorizada para revisar relatos.</div> : loading || !loaded ? <div className="empty" role="status">Carregando fila…</div> : error ? <div className="empty" role="alert">{error}</div> : reports.length === 0 ? <div className="empty">Nenhum relato em análise.</div> : <div className="feed-list">{reports.map((report) => <article className="notice" key={report.id}><div className="panel-title"><strong>{report.category} · {report.city}</strong><span className="badge">{report.status === "pending" ? "PENDENTE" : report.status === "review" ? "EM ANÁLISE" : "EM ANDAMENTO"}</span></div><p className="muted">{new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(report.created_at))} · {report.neighborhood ? `${report.neighborhood} · ` : ""}{report.city}</p><p>{report.description}</p>{report.media_url && <Image className="feed-post-media" src={report.media_url} alt="Foto anexada ao relato da cidade" width={960} height={720} unoptimized />}<div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{report.status === "pending" && <button className="primary-btn" type="button" onClick={() => void decide(report, "review")} disabled={Boolean(busyId)}>{busyId === report.id ? "Salvando…" : "Publicar em análise"}</button>}{report.status === "review" && <button className="primary-btn" type="button" onClick={() => void decide(report, "in_progress")} disabled={Boolean(busyId)}>{busyId === report.id ? "Salvando…" : "Marcar em andamento"}</button>}{report.status === "in_progress" && <button className="primary-btn" type="button" onClick={() => void decide(report, "resolved")} disabled={Boolean(busyId)}>{busyId === report.id ? "Salvando…" : "Confirmar resolvido"}</button>}<button className="secondary-btn" type="button" onClick={() => void decide(report, "rejected")} disabled={Boolean(busyId)}>Recusar</button></div></article>)}</div>}
    <p className="data-note">O estado avança de pendente para em análise, em andamento e resolvido. Relatos recusados permanecem visíveis apenas ao autor; cada alteração registra o moderador e o horário.</p>
  </section>;
}

function ModerationQueue({ client, user, notify, onModerated }: { client: SupabaseClient | null; user: User | null; notify: (message: string) => void; onModerated: (post: PendingPost, decision: "approved" | "rejected") => void }) {
  const [posts, setPosts] = useState<PendingPost[]>([]);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState("");

  const refresh = useCallback(async () => {
    if (!client || !user) {
      setPosts([]);
      setLoaded(true);
      return;
    }
    setLoading(true);
    setError("");
    const { data, error: loadError } = await client.rpc("list_pending_community_posts");
    setLoading(false);
    setLoaded(true);
    if (loadError) {
      setPosts([]);
      setError(loadError.code === "42501" ? "Esta conta não tem permissão de moderação." : "Não foi possível carregar a fila. Confira se a migração de moderação foi aplicada.");
      return;
    }
    setPosts(await hydratePendingPostMedia(client, (data ?? []) as PendingPost[]));
  }, [client, user]);

  useEffect(() => {
    if (!client || !user) return;
    let active = true;
    void client.rpc("list_pending_community_posts").then(async ({ data, error: loadError }) => {
      if (!active) return;
      setLoaded(true);
      if (loadError) {
        setPosts([]);
        setError(loadError.code === "42501" ? "Esta conta não tem permissão de moderação." : "Não foi possível carregar a fila. Confira se a migração de moderação foi aplicada.");
      } else {
        const hydrated = await hydratePendingPostMedia(client, (data ?? []) as PendingPost[]);
        if (active) setPosts(hydrated);
      }
    });
    return () => { active = false; };
  }, [client, user]);

  async function decide(post: PendingPost, decision: "approved" | "rejected") {
    if (!client) return;
    setBusyId(post.id);
    const { error: actionError } = await client.rpc("moderate_community_post", { post_id: post.id, decision });
    setBusyId("");
    if (actionError) {
      setError(actionError.code === "42501" ? "Sua conta não tem permissão para moderar publicações." : "A publicação mudou ou não pôde ser atualizada. Atualize a fila e tente novamente.");
      return;
    }
    setPosts((current) => current.filter((item) => item.id !== post.id));
    onModerated(post, decision);
    notify(decision === "approved" ? "Publicação aprovada e adicionada ao Feed." : "Publicação rejeitada e removida da fila.");
  }

  return <section className="panel" style={{ marginBottom: 14 }}>
    <div className="panel-title"><div><h3>Fila de moderação do Feed</h3><p className="muted" style={{ margin: "5px 0 0" }}>Aprovações e rejeições são registradas no Supabase.</p></div><button className="secondary-btn" type="button" onClick={() => void refresh()} disabled={loading || !user}>{loading ? "Atualizando…" : "Atualizar fila"}</button></div>
    {!user ? <div className="empty">Entre com uma conta autorizada como moderadora para revisar publicações.</div> : loading || !loaded ? <div className="empty" role="status">Carregando fila…</div> : error ? <div className="empty" role="alert">{error}</div> : posts.length === 0 ? <div className="empty">Nenhuma publicação pendente.</div> : <div className="feed-list">{posts.map((post) => <article className="notice" key={post.id}><div className="panel-title"><strong>{post.category} · {post.city}</strong><span className="muted">{new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(post.created_at))}</span></div><p className="muted">Enviado por {post.author_name}</p><p>{post.body}</p>{post.media_url && post.media_kind === "image" && <Image className="feed-post-media" src={post.media_url} alt="Mídia anexada à publicação pendente" width={960} height={720} unoptimized />}{post.media_url && post.media_kind === "video" && <video className="feed-post-media" src={post.media_url} controls preload="metadata" playsInline />}<div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10 }}><button className="primary-btn" type="button" onClick={() => void decide(post, "approved")} disabled={Boolean(busyId)}>{busyId === post.id ? "Salvando…" : "Aprovar"}</button><button className="secondary-btn" type="button" onClick={() => void decide(post, "rejected")} disabled={Boolean(busyId)}>Rejeitar</button></div></article>)}</div>}
    <p className="data-note">A permissão é concedida no banco por um administrador do projeto. A interface sozinha não concede acesso.</p>
  </section>;
}

type PendingCommunitySubmission = { id: string; title?: string; category?: string; report_type?: string; animal_name?: string | null; species?: string; city: string; neighborhood?: string | null; description: string; created_at: string; media_path?: string | null; media_url?: string };

type PendingServiceRequest = { request_id: string; member_name: string; service_type: string; city: string; neighborhood: string | null; contact: string; description: string; status: string; created_at: string };

function ServiceRequestModerationQueue({ client, user, notify }: { client: SupabaseClient | null; user: User | null; notify: (message: string) => void }) {
  const [requests, setRequests] = useState<PendingServiceRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const refresh = useCallback(async () => {
    if (!client || !user) { setRequests([]); return; }
    setLoading(true); setError("");
    const { data, error: loadError } = await client.rpc("list_service_requests_for_moderation");
    setLoading(false);
    if (loadError) setError("Não foi possível acessar a fila. Confirme a permissão de moderação e a migração.");
    else setRequests((data ?? []) as PendingServiceRequest[]);
  }, [client, user]);
  useInitialRefresh(refresh);
  async function updateStatus(id: string, status: string) {
    if (!client) return;
    setBusy(true);
    const { error: updateError } = await client.rpc("moderate_service_request", { request_id: id, decision: status });
    setBusy(false);
    if (updateError) { setError("Não foi possível atualizar o pedido."); return; }
    await refresh(); notify("Status do pedido atualizado.");
  }
  return <section className="panel" style={{ marginBottom: 14 }}><div className="panel-title"><div><h3>Solicitações do projeto social</h3><p className="muted" style={{ margin: "5px 0 0" }}>Dados de contato visíveis somente à equipe autorizada.</p></div><button className="secondary-btn" type="button" disabled={loading || !user} onClick={() => void refresh()}>{loading ? "Atualizando…" : "Atualizar fila"}</button></div>{!user ? <div className="empty">Entre com conta autorizada.</div> : loading ? <div className="empty" role="status">Carregando…</div> : error ? <p role="alert" className="auth-error">{error}</p> : requests.length ? <div className="feed-list">{requests.map((request) => <article className="notice" key={request.request_id}><span className="badge">{request.service_type} · {request.city}{request.neighborhood ? ` · ${request.neighborhood}` : ""}</span><strong>{request.member_name}</strong><p>{request.description}</p><p><b>Contato:</b> {request.contact}</p><label className="field"><span>Status do pedido</span><select value={request.status} disabled={busy} onChange={(event) => void updateStatus(request.request_id, event.target.value)}><option value="received">Recebido</option><option value="review">Em análise</option><option value="in_progress">Em andamento</option><option value="completed">Concluído</option><option value="closed">Encerrado</option></select></label></article>)}</div> : <div className="empty">Nenhum pedido em aberto.</div>}</section>;
}

function SubmissionModerationQueue({ client, user, notify, type }: { client: SupabaseClient | null; user: User | null; notify: (message: string) => void; type: "marketplace" | "animals" }) {
  const [items, setItems] = useState<PendingCommunitySubmission[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const label = type === "animals" ? "Avisos de animais" : "Anúncios do Mercadão";

  const refresh = useCallback(async () => {
    if (!client || !user) { setItems([]); return; }
    setLoading(true); setError("");
    const { data, error: loadError } = await client.rpc(type === "animals" ? "list_pending_animal_reports" : "list_pending_marketplace_listings");
    setLoading(false);
    if (loadError) setError("Não foi possível carregar a fila. Confirme sua permissão de moderação e as migrações do banco.");
    else setItems(await hydrateSubmissionImages(client, (data ?? []) as PendingCommunitySubmission[]));
  }, [client, user, type]);
  useInitialRefresh(refresh);

  async function moderate(id: string, approve: boolean) {
    if (!client) return;
    setBusy(true);
    const { error: updateError } = await client.rpc(type === "animals" ? "moderate_animal_report" : "moderate_marketplace_listing", { [type === "animals" ? "report_id" : "listing_id"]: id, decision: approve ? "active" : "rejected" });
    setBusy(false);
    if (updateError) { setError("Não foi possível atualizar o anúncio. Tente novamente."); return; }
    setItems((current) => current.filter((item) => item.id !== id));
    notify(approve ? "Conteúdo aprovado e publicado." : "Conteúdo rejeitado.");
  }

  return <section className="panel" style={{ marginBottom: 14 }}><div className="panel-title"><div><h3>Moderação · {label}</h3><p className="muted" style={{ margin: "5px 0 0" }}>Publicações só ficam visíveis após aprovação.</p></div><button type="button" className="secondary-btn" onClick={() => void refresh()} disabled={loading || !user}>{loading ? "Atualizando…" : "Atualizar fila"}</button></div>{!user ? <div className="empty">Entre com uma conta moderadora para revisar este conteúdo.</div> : loading ? <div className="empty" role="status">Carregando…</div> : error ? <p className="auth-error" role="alert">{error}</p> : items.length === 0 ? <div className="empty">Nenhum item pendente.</div> : <div className="feed-list">{items.map((item) => <article className="notice" key={item.id}><span className="badge">{item.city}{item.neighborhood ? ` · ${item.neighborhood}` : ""}</span><strong>{type === "animals" ? `${item.report_type === "perdido" ? "Perdido" : "Encontrado"} · ${item.animal_name || item.species}` : `${item.category} · ${item.title}`}</strong><p>{item.description}</p>{item.media_url && <Image className="feed-post-media" src={item.media_url} alt="Foto anexada ao envio pendente" width={960} height={720} unoptimized />}<div className="button-row"><button className="primary-btn" type="button" disabled={busy} onClick={() => void moderate(item.id, true)}>Aprovar</button><button className="secondary-btn" type="button" disabled={busy} onClick={() => void moderate(item.id, false)}>Rejeitar</button></div></article>)}</div>}</section>;
}


function AllAreas({ navigate, canManage }: { navigate: (section: Section) => void; canManage: boolean }) {
  const areas = [{id:"dados" as Section,label:"Meus dados e privacidade",icon:ShieldCheck},{id:"campanhas" as Section,label:"Campanhas",icon:Trophy},{id:"cupons" as Section,label:"Cupons e benefícios",icon:BadgePercent},{id:"indica" as Section,label:"Indica ABC",icon:UsersRound},{id:"utilidades" as Section,label:"Utilidades",icon:FileText},{id:"top" as Section,label:"Top da semana",icon:Trophy},{id:"imoveis" as Section,label:"Imóveis",icon:Building2},{id:"vagas" as Section,label:"Vagas de emprego",icon:Briefcase},{id:"achados" as Section,label:"Achados e perdidos",icon:Search}, { id: "enquetes" as Section, label: "Enquetes", icon: ClipboardList }, { id: "comunidades" as Section, label: "Comunidades", icon: UsersRound }, { id: "amigos" as Section, label: "Amigos", icon: UsersRound }, { id: "salvos" as Section, label: "Publicações salvas", icon: BookOpen }, { id: "notificacoes" as Section, label: "Notificações", icon: Bell }, ...navItems.filter(item => item.id !== "admin" && item.id !== "clube"), { id: "mapa" as Section, label: "Mapa da comunidade", icon: MapPin }, { id: "noticias" as Section, label: "Notícias por cidade", icon: FileText }, { id: "agenda" as Section, label: "Agenda da comunidade", icon: CalendarDays }];
  return <section><div className="social-page-heading"><span>SEU ABC, EM UM SÓ LUGAR</span><h1>Explore a comunidade</h1><p>Encontre cada área e acompanhe sua participação.</p></div><div className="social-area-grid">{areas.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => navigate(id)}><Icon size={24}/><strong>{label}</strong><ArrowUpRight size={16}/></button>)}{canManage && <button onClick={() => navigate("admin")}><ShieldCheck/><strong>Painel da equipe</strong><ArrowUpRight size={16}/></button>}</div><section className="social-closed"><Lock size={20}/><div><strong>Clube de benefícios</strong><p>Fechado por enquanto. A abertura será anunciada aqui.</p></div></section><div className="social-legal"><Link href="/privacidade">Privacidade</Link><Link href="/termos">Termos e regras</Link></div></section>;
}

function SocialTimeline({ collection, posts, city, setCity, loading, navigate, create, displayName, onLike, onReport, notify, client }: { collection: SocialCollection; posts: FeedPost[]; city: string; setCity: (city: string) => void; loading: boolean; navigate: (section: Section, tab?: FeedTab) => void; create: () => void; displayName?: string; onLike: (id: string,kind?:string) => void; onReport: (id: string, reason: string, details: string) => Promise<boolean>; notify: (message: string) => void; client: SupabaseClient | null }) {
  const {enabled:visualExamples,close:closeVisualExamples} = useVisualExamples();
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState("todos");
  const [ranking, setRanking] = useState<LeaderboardPerson[]>([]);
  const [rankingError, setRankingError] = useState("");
  const [rankingLoading, setRankingLoading] = useState(true);
  useEffect(() => {
    let alive = true;
    if (!client) { setRankingLoading(false); setRankingError("Ranking indisponível no momento."); return; }
    setRankingLoading(true);
    void client.rpc("get_public_leaderboard").then(({ data, error }) => {
      if (!alive) return;
      setRankingLoading(false);
      if (error) { setRankingError("Não foi possível carregar o ranking."); return; }
      setRanking((data ?? []).slice(0, 5).map((row: { rank_position: number; first_name: string; city: string; points: number }) => ({ position: Number(row.rank_position), display_name: row.first_name, city: row.city, points: Number(row.points) })));
    }, () => { if (alive) { setRankingLoading(false); setRankingError("Falha de conexão com o ranking."); } });
    return () => { alive = false; };
  }, [client]);
  const scope=useCommunityResource<string[]>("social_feed_scope",{post_scope:tab},tab==="amigos"||tab==="bairro");
  const visible = selectPublicPosts(posts, collection, city, search).filter(post => collection !== "inicio" || tab === "todos" || (tab==="amigos"||tab==="bairro" ? Boolean(scope.data?.includes(post.id)) : tab === "oficial" ? post.official : !post.official));
  const names: Record<SocialCollection, string> = { inicio: "Sua comunidade acontece aqui", explorar: "Explore o Grande ABC", busca: "Pesquisa", noticias: "Notícias do ABC", agenda: "Agenda da comunidade", agora: "Em alta" };
  return <div className="social-timeline-layout"><div className="social-stream">
    {collection === "inicio" && <>{visualExamples&&<VisualExamplesBanner onClose={closeVisualExamples}/>}<Stories demonstration={visualExamples}/></>}
    {collection === "inicio" ? <HomeOverview demonstration={visualExamples} name={displayName} city={city} create={create} navigate={area=>navigate(area as Section)} count={visible.length}/> : <section className="social-day-panel"><span className="social-kicker">O GRANDE ABC CONECTADO</span><h1>{names[collection]}</h1><p>{collection === "agenda" ? "Eventos divulgados e aprovados no feed. Consulte os detalhes em cada publicação." : collection === "agora" ? "Vídeos publicados pela equipe do Conecta ABC." : "Informações e histórias da nossa região."}</p><label className="social-city"><MapPin size={16}/><select aria-label="Filtrar por cidade" value={city} onChange={event => setCity(event.target.value)}>{cities.map(name => <option key={name}>{name}</option>)}</select></label></section>}
    {collection === "inicio" && visualExamples && <ExampleHighlights navigate={area=>navigate(area as Section)}/>}
    {collection === "inicio" && <><div className="social-shortcuts">{[{ id: "noticias" as Section, label: "Notícias", icon: FileText }, { id: "agenda" as Section, label: "Agenda", icon: CalendarDays }, { id: "mapa" as Section, label: "Mapa", icon: MapPin }, { id: "mercadao" as Section, label: "Mercadão", icon: Store }, { id: "mais" as Section, label: "Ver tudo", icon: Sparkles }].map(({ id, label, icon: Icon }) => <button key={id} onClick={() => navigate(id)}><span><Icon size={23}/></span><small>{label}</small></button>)}</div><button className="social-compose-prompt" onClick={create}><span className="social-avatar">{displayName?.slice(0,1) || <UserRound size={20}/>}</span><span>No que você está pensando?</span><ImagePlus size={22}/></button><div className="social-filter-tabs" aria-label="Filtrar publicações">{[{ id: "todos", label: "Cidade" }, {id:"amigos",label:"Amigos"},{id:"bairro",label:"Meu bairro"}].map(item => <button key={item.id} aria-pressed={tab === item.id} className={tab === item.id ? "selected" : ""} onClick={() => setTab(item.id)}>{item.label}</button>)}</div></>}
    {(collection === "busca" || collection === "explorar") && <><label className="social-search"><Search size={20}/><input type="search" aria-label="Pesquisar publicações carregadas" placeholder="Pesquisar nas publicações carregadas…" value={search} onChange={event => setSearch(event.target.value)}/></label><button className="secondary-btn" onClick={() => navigate("mais")}>Explorar todas as áreas <ArrowUpRight size={14}/></button></>}
    {collection==="inicio"&&(tab==="amigos"||tab==="bairro")&&<p className="muted">{scope.error|| (tab==="bairro"?"O filtro usa o bairro do seu perfil e autores que tornaram o bairro público.":"Mostra as publicações identificadas de suas amizades aceitas.")}</p>}
    <div className={collection === "agora" ? "social-video-feed" : "social-feed"} aria-busy={loading}>{loading ? <div className="social-empty" role="status">Carregando publicações da comunidade…</div> : visible.length ? visible.map((post,index) => <Fragment key={post.id}><FeedPostCard post={post} onLike={onLike} onReport={onReport} notify={notify}/>{collection==="inicio"&&index<homeFeedGroups.length&&homeFeedGroups[index].map(slot=><HomeFeedSection key={slot} slot={slot} navigate={area=>navigate(area as Section)} demonstration={visualExamples} city={city} videos={posts.filter(item=>item.official&&item.status==="approved"&&item.mediaKind==="video")}/>)} </Fragment>) : <div className="social-empty"><MessageSquare size={30}/><h2>{search ? "Nenhuma publicação encontrada" : "Este espaço está esperando novidades"}</h2><p>{search ? "Experimente outro termo ou selecione outra cidade." : "Quando houver publicações aprovadas nesta área, elas aparecerão aqui."}</p><button className="primary-btn" onClick={create}>Compartilhar com a comunidade</button></div>}</div>
    {collection==="inicio"&&!loading&&<>{homeFeedGroups.slice(visible.length).flat().map(slot=><HomeFeedSection key={slot} slot={slot} navigate={area=>navigate(area as Section)} demonstration={visualExamples} city={city} videos={posts.filter(item=>item.official&&item.status==="approved"&&item.mediaKind==="video")}/>)}<div className="home-feed-end"><CheckCircle2 size={24}/><strong>Você chegou ao fim desta seleção</strong><p>Continue explorando o que acontece nas sete cidades.</p><button type="button" className="secondary-btn" onClick={()=>navigate("busca")}>Pesquisar no Conecta ABC</button></div></>}
    <p className="social-footnote">Uma plataforma da SAD · <Link href="/termos">Regras da comunidade</Link></p>
  </div>{collection==="inicio"?<ReferenceRightRail name={displayName} navigate={area=>navigate(area as Section)} demonstration={visualExamples}/>:<aside className="social-right-rail"><button className="social-user-summary" onClick={() => navigate("perfil")}><span className="social-avatar">{displayName?.slice(0,1) || <UserRound/>}</span><span><strong>{displayName || "Faça parte do Conecta ABC"}</strong><small>{displayName ? "Ver perfil e carteirinha" : "Entre ou crie sua conta"}</small></span><ArrowUpRight size={16}/></button><button className="social-progress-promo" onClick={() => navigate("pontua")}><Trophy size={28}/><strong>Meu progresso</strong><p>Suas contribuições, seus pontos e suas conquistas.</p><span>Ver meu resumo →</span></button><section className="social-rail-ranking"><h2>Quem conecta o ABC</h2><p>Ranking da comunidade</p>{rankingLoading ? <p role="status">Carregando…</p> : rankingError ? <p role="alert">{rankingError}</p> : ranking.length ? ranking.map(person => <div key={person.position}><span>{person.position}</span><div><strong>{person.display_name}</strong><small>{person.city || "Grande ABC"}</small></div><b>{person.points} pts</b></div>) : <p>Nenhum membro no ranking ainda.</p>}<button onClick={() => navigate("pontua")}>Ver ranking completo →</button></section><section className="social-rail-cities"><h2>As cidades do ABC</h2>{cities.slice(1).map(name => <button key={name} onClick={() => { setCity(name); navigate("noticias"); }}><MapPin size={14}/>{name}</button>)}</section><div className="social-legal"><Link href="/privacidade">Privacidade</Link><Link href="/termos">Termos</Link><span>Uma plataforma da SAD</span></div></aside>}</div>;
}



