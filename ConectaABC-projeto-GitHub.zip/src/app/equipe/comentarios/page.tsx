"use client";
import { useState } from "react";
import Link from "next/link";
import { AuthPanel } from "@/components/AuthPanel";
import { SocialFeaturesProvider, SocialWorkspace } from "@/components/SocialFeatures";
import { useSupabaseAuth } from "@/lib/supabase/use-auth";
export default function CommentModerationPage() {
 const auth=useSupabaseAuth(); const [open,setOpen]=useState(false);
 return <main className="social-app" style={{padding:"24px 16px",minHeight:"100dvh"}}><div style={{maxWidth:760,margin:"auto"}}><Link href="/equipe/painel" style={{color:"#ffc107"}}>← Painel da equipe</Link>{auth.loading ? <p role="status">Verificando acesso…</p> : <SocialFeaturesProvider key={auth.user?.id ?? "visitor"} client={auth.client} userId={auth.user?.id} openAuth={()=>setOpen(true)}><SocialWorkspace area="comentarios-equipe"/></SocialFeaturesProvider>}<AuthPanel open={open} client={auth.client} user={auth.user} profile={auth.profile} onClose={()=>setOpen(false)} onSignedOut={()=>setOpen(false)}/></div></main>;
}
