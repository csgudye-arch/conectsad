"use client";
import { useState } from "react";
import Link from "next/link";
import { AuthPanel } from "@/components/AuthPanel";
import { SocialFeaturesProvider } from "@/components/SocialFeatures";
import { CommunityHub } from "@/components/CommunityHub";
import { useSupabaseAuth } from "@/lib/supabase/use-auth";
export default function CommunityModerationPage(){
 const auth=useSupabaseAuth();const [open,setOpen]=useState(false);
 return <main className="social-app" style={{padding:"24px 16px",minHeight:"100dvh"}}><div style={{maxWidth:760,margin:"auto"}}><Link href="/equipe/painel" style={{color:"#ffc107"}}>← Painel da equipe</Link>{auth.loading?<p role="status">Verificando acesso…</p>:!auth.user?<section className="social-empty"><h1>Moderação da comunidade</h1><button className="primary-btn" onClick={()=>setOpen(true)}>Entrar com conta da equipe</button></section>:<SocialFeaturesProvider key={auth.user.id} client={auth.client} userId={auth.user.id} openAuth={()=>setOpen(true)}><CommunityHub area="comunidade-equipe"/></SocialFeaturesProvider>}<AuthPanel open={open} client={auth.client} user={auth.user} profile={auth.profile} onClose={()=>setOpen(false)} onSignedOut={()=>setOpen(false)}/></div></main>;
}
