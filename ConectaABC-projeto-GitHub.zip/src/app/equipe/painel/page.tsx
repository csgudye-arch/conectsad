"use client";

import Image from "next/image";
import Link from "next/link";
import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { AlertCircle, CheckCircle2, ClipboardCheck, ExternalLink, LockKeyhole, RefreshCw, ShieldCheck } from "lucide-react";
import type { SupabaseClient } from "@supabase/supabase-js";
import { AuthPanel } from "@/components/AuthPanel";
import { useSupabaseAuth } from "@/lib/supabase/use-auth";
import { officialPostSchema } from "@/lib/validation";

type Roles = { is_admin: boolean; is_city_moderator: boolean; is_service_provider: boolean; is_referral_verifier: boolean };
type Tab = "feed" | "enquetes" | "comunicados" | "mercadao" | "classificados" | "animais" | "cidade" | "servicos" | "denuncias" | "lugares";
type QueueItem = { id: string; title?: string; author_name?: string; category?: string; report_type?: string; animal_name?: string | null; species?: string; city: string; neighborhood?: string | null; description?: string; body?: string; created_at: string; status?: string; media_path?: string | null; media_kind?: "image" | "video" | null; media_url?: string; post_id?: string; report_id?: string; reason?: string; details?: string | Record<string, string | number>; kind?: string; price?: number | null; reports?: string | null; post_body?: string; request_id?: string; member_name?: string; service_type?: string; contact?: string; latitude?: number; longitude?: number };

const baseRoles: Roles = { is_admin: false, is_city_moderator: false, is_service_provider: false, is_referral_verifier: false };
const labels: Record<Tab, string> = { feed: "Publicações", enquetes: "Enquetes e comunidades", comunicados: "Publicar comunicado", mercadao: "Mercadão", classificados: "Imóveis, vagas e achados", animais: "Animais", cidade: "Cidade", servicos: "Serviços", denuncias: "Denúncias", lugares: "Mapa · Locais" };
const classifiedLabels: Record<string, string> = { imoveis: "Imóvel", vagas: "Vaga", achados: "Achados e perdidos" };
const communityLabels: Record<string, string> = { poll: "Enquete", group: "Comunidade", group_post: "Post de comunidade" };
const reasonLabels: Record<string, string> = { spam: "Spam ou repetição", abusive: "Ofensa ou assédio", misinformation: "Informação possivelmente falsa", privacy: "Privacidade", other: "Outro motivo" };

async function signMedia(client: SupabaseClient, rows: QueueItem[], bucket = "submission-media") {
  const paths = [...new Set(rows.flatMap((row) => row.media_path ? [row.media_path] : []))];
  if (!paths.length) return rows;
  const { data } = await client.storage.from(bucket).createSignedUrls(paths, 60 * 60);
  const urls = new Map((data ?? []).map((entry) => [entry.path, entry.signedUrl]));
  return rows.map((row) => ({ ...row, media_url: row.media_path ? urls.get(row.media_path) ?? undefined : undefined }));
}

export default function TeamPanelPage() {
  const auth = useSupabaseAuth();
  const [authOpen, setAuthOpen] = useState(false);
  const [roles, setRoles] = useState(baseRoles);
  const [checking, setChecking] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>("feed");
  const [queues, setQueues] = useState<Record<Tab, QueueItem[]>>({ feed: [], enquetes: [], comunicados: [], mercadao: [], classificados: [], animais: [], cidade: [], servicos: [], denuncias: [], lugares: [] });
  const [reviewReasons, setReviewReasons] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [queueError, setQueueError] = useState("");
  const [initialized, setInitialized] = useState(false);
  const [publishing, setPublishing] = useState(false);

  useEffect(() => {
    let alive = true;
    if (auth.loading) return () => { alive = false; };
    if (!auth.client || !auth.user) { setRoles(baseRoles); setChecking(false); return () => { alive = false; }; }
    setChecking(true);
    void Promise.all([auth.client.rpc("get_current_access"), auth.client.rpc("can_verify_referrals")]).then(([accessResult, referralResult]) => {
      if (!alive) return;
      const row = Array.isArray(accessResult.data) ? accessResult.data[0] : null;
      const admin = !accessResult.error && row?.is_admin === true;
      setRoles({ is_admin: admin, is_city_moderator: admin || (!accessResult.error && row?.is_city_moderator === true), is_service_provider: admin || (!accessResult.error && row?.is_service_provider === true), is_referral_verifier: !referralResult.error && referralResult.data === true });
      setChecking(false);
    }, () => { if (alive) { setRoles(baseRoles); setChecking(false); setError("Não foi possível verificar as permissões da conta."); } });
    return () => { alive = false; };
  }, [auth.client, auth.loading, auth.user]);

  const availableTabs = useMemo(() => (Object.keys(labels) as Tab[]).filter((tab) => {
    if (tab === "comunicados") return roles.is_admin;
    if (tab === "feed" || tab === "enquetes" || tab === "mercadao" || tab === "classificados" || tab === "animais" || tab === "denuncias" || tab === "lugares") return roles.is_admin;
    if (tab === "cidade") return roles.is_city_moderator;
    return roles.is_service_provider;
  }), [roles]);

  const refresh = useCallback(async () => {
    if (!auth.client || !auth.user || !availableTabs.length) return;
    setLoading(true); setQueueError(""); setError("");
    const next: Record<Tab, QueueItem[]> = { feed: [], enquetes: [], comunicados: [], mercadao: [], classificados: [], animais: [], cidade: [], servicos: [], denuncias: [], lugares: [] };
    const requests: Promise<void>[] = [];
    const fetchRpc = async (tab: Tab, fn: string, transform?: (rows: QueueItem[]) => Promise<QueueItem[]>) => {
      const { data, error: rpcError } = await auth.client!.rpc(fn);
      if (rpcError) throw rpcError;
      const rows = (data ?? []) as QueueItem[];
      next[tab] = transform ? await transform(rows) : rows;
    };
    if (roles.is_admin) {
      requests.push(fetchRpc("feed", "list_pending_community_posts", (rows) => signMedia(auth.client!, rows, "feed-media")));
      requests.push(fetchRpc("enquetes", "social_hub_queue"));
      requests.push(fetchRpc("mercadao", "list_pending_marketplace_listings", (rows) => signMedia(auth.client!, rows)));
      requests.push(fetchRpc("classificados", "social_classified_queue", (rows) => signMedia(auth.client!, rows)));
      requests.push(fetchRpc("animais", "list_pending_animal_reports", (rows) => signMedia(auth.client!, rows)));
      requests.push(fetchRpc("denuncias", "list_pending_community_post_reports"));
      requests.push(fetchRpc("lugares", "list_pending_community_places"));
    }
    if (roles.is_city_moderator) requests.push(fetchRpc("cidade", "list_city_reports_for_moderation", (rows) => signMedia(auth.client!, rows)));
    if (roles.is_service_provider) requests.push(fetchRpc("servicos", "list_service_requests_for_moderation"));
    const results = await Promise.allSettled(requests);
    setQueues(next);
    const failed = results.some((result) => result.status === "rejected");
    setQueueError(failed ? "Algumas filas não carregaram. Verifique as migrações e o nível de acesso desta conta; você pode atualizar e tentar novamente." : "");
    setLoading(false); setInitialized(true);
  }, [auth.client, auth.user, availableTabs.length, roles]);

  useEffect(() => { if (!checking && auth.user && availableTabs.length && !initialized) void refresh(); }, [checking, auth.user, availableTabs.length, initialized, refresh]);
  useEffect(() => { if (!availableTabs.includes(activeTab) && availableTabs.length) setActiveTab(availableTabs[0]); }, [availableTabs, activeTab]);

  async function perform(item: QueueItem, decision: string) {
    if (!auth.client) return;
    const id = item.id ?? item.report_id ?? item.request_id ?? "";
    const reason = reviewReasons[id]?.trim() ?? "";
    if ((activeTab === "classificados" || activeTab === "enquetes") && reason.length < 3) {
      setError("Informe o motivo da decisão com pelo menos 3 caracteres.");
      return;
    }
    setBusyId(id); setError(""); setNotice("");
    let rpcName = ""; let params: Record<string, string> = {};
    if (activeTab === "feed") { rpcName = "moderate_community_post"; params = { post_id: id, decision }; }
    if (activeTab === "mercadao") { rpcName = "moderate_marketplace_listing"; params = { listing_id: id, decision }; }
    if (activeTab === "classificados") { rpcName = "social_review_classified"; params = { target_listing: id, decision, reason }; }
    if (activeTab === "enquetes") { rpcName = "social_review_hub"; params = { target_kind: item.kind ?? "", target_id: id, decision, reason }; }
    if (activeTab === "animais") { rpcName = "moderate_animal_report"; params = { report_id: id, decision }; }
    if (activeTab === "cidade") { rpcName = "moderate_city_report"; params = { report_id: id, decision }; }
    if (activeTab === "servicos") { rpcName = "moderate_service_request"; params = { request_id: id, decision }; }
    if (activeTab === "denuncias") { rpcName = "review_community_post_report"; params = { report_id: id }; }
    if (activeTab === "lugares") { rpcName = "moderate_community_place"; params = { place_id: id, decision }; }
    const { error: actionError } = await auth.client.rpc(rpcName, params);
    setBusyId("");
    if (actionError) { setError("A ação não foi concluída. Confira seu acesso, atualize a fila e tente novamente."); return; }
    setQueues((current) => ({ ...current, [activeTab]: activeTab === "cidade" && ["review", "in_progress"].includes(decision) || activeTab === "servicos" && ["review", "in_progress"].includes(decision)
      ? current[activeTab].map((row) => row === item ? { ...row, status: decision } : row)
      : current[activeTab].filter((row) => row !== item) }));
    setNotice(activeTab === "denuncias" ? "Denúncia marcada como analisada." : decision === "rejected" ? "Envio rejeitado." : "Atualização salva.");
  }

  async function publishOfficialPost(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(""); setNotice("");
    const formData = new FormData(event.currentTarget);
    const result = officialPostSchema.safeParse({ title: formData.get("title"), category: formData.get("category"), city: formData.get("city"), body: formData.get("body"), source: formData.get("source"), sensitive: formData.get("sensitive") === "on" });
    if (!result.success) { setError(result.error.issues[0]?.message ?? "Confira o formulário do comunicado."); return; }
    if (!auth.client) return;
    setPublishing(true);
    const { error: publishError } = await auth.client.rpc("create_official_post", { post_title: result.data.title, post_category: result.data.category, post_city: result.data.city, post_body: result.data.body, post_source: result.data.source, post_sensitive: result.data.sensitive });
    setPublishing(false);
    if (publishError) { setError("O comunicado não foi publicado. Confira sua permissão e tente novamente."); return; }
    event.currentTarget.reset(); setNotice("Comunicado publicado no Notícias do ABC.");
  }

  const currentQueue = queues[activeTab] ?? [];
  return <main className="auth-screen referral-review-screen team-panel-screen">
    <Link className="auth-screen-brand" href="/"><Image src="/conecta-abc-mark.svg" alt="" width={43} height={43} priority /><span>CONECTA <b>ABC</b><small>Uma plataforma da SAD</small></span></Link>
    <div className="referral-review-content team-panel-content">
      <header className="module-title-row"><div><div className="eyebrow">ÁREA INTERNA · EQUIPE</div><h1>Painel de moderação</h1><p className="muted">Revise envios da comunidade e acompanhe os pedidos atribuídos à sua função.</p></div><span className="badge"><LockKeyhole size={12} /> ACESSO RESTRITO</span></header>
      {!auth.isConfigured && <section className="panel"><p>O acesso ainda não está conectado ao serviço de autenticação.</p></section>}
      {auth.loading || checking ? <section className="panel"><div className="empty" role="status">Verificando sessão e permissões…</div></section> : !auth.user ? <section className="panel referral-review-gate"><span className="auth-brand-icon"><ShieldCheck size={20} /></span><h2>Entre com a conta da equipe</h2><p className="muted">Apenas contas autorizadas no Conecta ABC podem abrir as filas de moderação.</p><button className="primary-btn" type="button" onClick={() => setAuthOpen(true)}>Entrar com conta autorizada　→</button></section> : availableTabs.length === 0 ? <section className="panel referral-review-gate"><span className="auth-brand-icon"><LockKeyhole size={20} /></span><h2>Acesso não autorizado</h2><p className="muted">Esta conta não tem função de moderação ou atendimento cadastrada. Entrar não libera permissões automaticamente.</p><button className="secondary-btn" type="button" onClick={() => void auth.signOut()}>Sair desta conta</button></section> : <>
        <section className="panel team-panel-toolbar"><div><div className="team-panel-count"><ClipboardCheck size={17} />{availableTabs.reduce((sum, tab) => sum + queues[tab].length, 0)}<span>itens aguardando atenção</span></div><p className="muted">Ações autorizadas são executadas no Supabase com o usuário conectado.</p></div><button type="button" className="secondary-btn" onClick={() => void refresh()} disabled={loading}><RefreshCw size={13} /> {loading ? "Atualizando…" : "Atualizar filas"}</button></section>
        <nav className="team-panel-tabs" aria-label="Filas de moderação">{availableTabs.map((tab) => <button type="button" key={tab} className={activeTab === tab ? "active" : ""} aria-pressed={activeTab === tab} onClick={() => { setActiveTab(tab); if (tab === "enquetes" && !loading && !busyId) void refresh(); }}>{labels[tab]} <span>{queues[tab].length}</span></button>)}{roles.is_admin && <Link href="/?area=denuncias-equipe">Denúncias sociais <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/?area=cupons-equipe">Cupons <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/?area=exclusoes-equipe">Exclusões <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/?area=campanhas-equipe">Campanhas <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/?area=indica-equipe">Indica ABC <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/?area=utilidades-equipe">Utilidades <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/?area=stories-equipe">Stories <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/?area=avaliacoes-equipe">Avaliações <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/?area=empresas-equipe">Empresas <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/?area=midia-equipe">Vídeos oficiais <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/?area=niveis-equipe">Níveis <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/equipe/agenda">Agenda <ExternalLink size={12}/></Link>}{roles.is_admin && <Link href="/equipe/comentarios">Comentários <ExternalLink size={12}/></Link>}{roles.is_referral_verifier && <Link href="/equipe/validar-indicacoes">Indicações <ExternalLink size={12} /></Link>}</nav>
        {queueError && <p className="auth-error" role="alert"><AlertCircle size={14} /> {queueError}</p>}{error && <p className="auth-error" role="alert">{error}</p>}{notice && <p className="auth-success" role="status"><CheckCircle2 size={14} /> {notice}</p>}
        <section className="panel team-panel-queue"><div className="panel-title"><div><h2>{labels[activeTab]} pendentes</h2><p className="muted">{activeTab === "cidade" ? "Acompanhe o andamento e publique relatos que podem ser compartilhados com a comunidade." : activeTab === "servicos" ? "Pedidos e dados de contato ficam disponíveis somente para a equipe autorizada." : activeTab === "denuncias" ? "Denúncias privadas enviadas por membros do Feed." : activeTab === "lugares" ? "Confira se o local sugerido é público, está bem localizado e não expõe dados pessoais." : "Confira o conteúdo antes de aprovar ou rejeitar."}</p></div><span className="badge">{currentQueue.length} NA FILA</span></div>
          {activeTab === "comunicados" ? <form className="form-grid team-official-form" onSubmit={(event) => void publishOfficialPost(event)} noValidate><div className="field full"><label htmlFor="team-post-title">Título</label><input id="team-post-title" name="title" required minLength={5} maxLength={120} /></div><div className="field"><label htmlFor="team-post-category">Categoria</label><select id="team-post-category" name="category" defaultValue="" required><option value="" disabled>Selecione</option><option>Acidente ou ocorrência</option><option>Alerta à comunidade</option><option>Trânsito e serviço</option><option>Informação pública</option><option>Dados e prestação de contas</option><option>Atualização de projeto</option></select></div><div className="field"><label htmlFor="team-post-city">Alcance</label><select id="team-post-city" name="city" defaultValue="Grande ABC"><option>Grande ABC</option><option>Santo André</option><option>São Bernardo do Campo</option><option>São Caetano do Sul</option><option>Diadema</option><option>Mauá</option><option>Ribeirão Pires</option><option>Rio Grande da Serra</option></select></div><div className="field full"><label htmlFor="team-post-source">Fonte ou referência</label><input id="team-post-source" name="source" required minLength={3} maxLength={300} placeholder="Órgão, documento ou link" /></div><div className="field full"><label htmlFor="team-post-body">Conteúdo</label><textarea id="team-post-body" name="body" required minLength={30} maxLength={3000} /><small>De 30 a 3.000 caracteres. Inclua contexto, data e referência confiável.</small></div><div className="field full"><label className="consent-field"><input type="checkbox" name="sensitive" /><span>Marcar como conteúdo sensível: a comunidade verá um aviso antes de abrir.</span></label></div><div className="field full"><button className="primary-btn" disabled={publishing}>{publishing ? "Publicando…" : "Publicar no Notícias do ABC　→"}</button></div></form> : loading && (!initialized || activeTab === "enquetes") ? <div className="empty" role="status">Carregando fila…</div> : !currentQueue.length ? <div className="empty"><CheckCircle2 size={17} /> Nenhum item aguardando nesta fila.</div> : <div className="team-panel-list">{currentQueue.map((item, index) => { const id = item.id ?? item.report_id ?? item.request_id ?? String(index); const title = activeTab === "enquetes" ? `${communityLabels[item.kind ?? ""] ?? "Conteúdo da comunidade"} · ${item.city}` : activeTab === "feed" ? `${item.category} · ${item.city}` : activeTab === "mercadao" ? `${item.category} · ${item.title}` : activeTab === "classificados" ? `${classifiedLabels[item.kind ?? ""] ?? "Classificado"} · ${item.title} · ${item.city}` : activeTab === "animais" ? `${item.report_type === "perdido" ? "Perdido" : "Encontrado"} · ${item.animal_name || item.species}` : activeTab === "cidade" ? `${item.category} · ${item.city}` : activeTab === "servicos" ? `${item.service_type} · ${item.city}` : activeTab === "lugares" ? `${item.category} · ${item.title} · ${item.city}` : `${reasonLabels[item.reason ?? ""] ?? "Denúncia"} · ${item.category} · ${item.city}`; return <article className="team-panel-item" key={id}>
            <div className="panel-title"><strong>{title}</strong><span className="muted">{item.created_at ? new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(item.created_at)) : ""}</span></div>
            {item.member_name && <p className="muted">Solicitado por {item.member_name}{item.neighborhood ? ` · ${item.neighborhood}` : ""}</p>}
            {item.author_name && <p className="muted">Enviado por {item.author_name}</p>}
            {!item.member_name && item.neighborhood && <p className="muted">{item.neighborhood} · {item.city}</p>}
            {(item.body || item.description || item.post_body) && <p style={activeTab === "enquetes" ? { whiteSpace: "pre-line" } : undefined}>{item.body || item.description || item.post_body}</p>}
            {activeTab === "lugares" && item.latitude != null && item.longitude != null && <a className="secondary-btn" href={`https://www.openstreetmap.org/?mlat=${item.latitude}&mlon=${item.longitude}#map=17/${item.latitude}/${item.longitude}`} target="_blank" rel="noreferrer">Ver localização no mapa</a>}
            {item.contact && <p><b>Contato:</b> {item.contact}</p>}{typeof item.details === "string" && item.details && <p className="muted">Detalhes da denúncia: {item.details}</p>}
            {item.media_url && item.media_kind === "video" ? <video className="feed-post-media" src={item.media_url} controls preload="metadata" playsInline /> : item.media_url ? <Image className="feed-post-media" src={item.media_url} alt="Imagem anexada ao conteúdo enviado" width={960} height={720} unoptimized /> : null}
            {activeTab === "classificados" && <>
              {item.kind === "imoveis" && item.details && typeof item.details !== "string" && <p>{item.details.operation} · {item.details.type} · {item.details.area} m²</p>}
              {item.price != null && <p>{Number(item.price).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</p>}
              {item.reports && <p className="muted">Denúncias: {item.reports}</p>}
            </>}
            {(activeTab === "classificados" || activeTab === "enquetes") && <label className="auth-field">Motivo da decisão<input maxLength={500} value={reviewReasons[id] ?? ""} onChange={(event) => setReviewReasons((current) => ({ ...current, [id]: event.target.value }))} placeholder="Registre o motivo para aprovar ou rejeitar" /></label>}
            <div className="team-panel-actions">
              {activeTab === "cidade" ? <>{item.status === "pending" && <button className="primary-btn" disabled={Boolean(busyId)} onClick={() => void perform(item, "review")}>Publicar em análise</button>}{item.status === "review" && <button className="primary-btn" disabled={Boolean(busyId)} onClick={() => void perform(item, "in_progress")}>Marcar em andamento</button>}{item.status === "in_progress" && <button className="primary-btn" disabled={Boolean(busyId)} onClick={() => void perform(item, "resolved")}>Confirmar resolvido</button>}<button className="secondary-btn" disabled={Boolean(busyId)} onClick={() => void perform(item, "rejected")}>Recusar</button></> : activeTab === "servicos" ? <select aria-label="Atualizar status do pedido" value={item.status} disabled={Boolean(busyId)} onChange={(event) => void perform(item, event.target.value)}><option value="received">Recebido</option><option value="review">Em análise</option><option value="in_progress">Em andamento</option><option value="completed">Concluído</option><option value="closed">Encerrado</option></select> : activeTab === "denuncias" ? <><Link className="secondary-btn" href={`/?post=${encodeURIComponent(item.post_id ?? "")}`} target="_blank">Abrir publicação</Link><button className="primary-btn" disabled={Boolean(busyId)} onClick={() => void perform(item, "reviewed")}>Marcar como analisada</button></> : <><button className="primary-btn" disabled={Boolean(busyId)} onClick={() => void perform(item, ["feed", "lugares", "classificados", "enquetes"].includes(activeTab) ? "approved" : "active")}>Aprovar</button><button className="secondary-btn" disabled={Boolean(busyId)} onClick={() => void perform(item, "rejected")}>Rejeitar</button></>}
            </div>
          </article>; })}</div>}
        </section>
      </>}
      <p className="data-note team-panel-footnote">Permissões e transições são conferidas pelo banco. Ações disponíveis dependem da função cadastrada para a conta.</p>
    </div>
    <footer className="auth-screen-footer"><Link href="/">Voltar ao Conecta ABC</Link>{auth.user && <button className="text-button" onClick={() => void auth.signOut()}>Sair</button>}</footer>
    <AuthPanel open={authOpen} client={auth.client} user={auth.user} profile={auth.profile} onClose={() => setAuthOpen(false)} onSignedOut={() => setAuthOpen(false)} />
  </main>;
}
