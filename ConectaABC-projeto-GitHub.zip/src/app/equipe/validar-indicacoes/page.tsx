"use client";

import Image from "next/image";
import Link from "next/link";
import { useCallback, useEffect, useState, type FormEvent } from "react";
import { AlertCircle, CheckCircle2, Clock3, LockKeyhole, MapPin, RefreshCw, ShieldCheck } from "lucide-react";
import { AuthPanel } from "@/components/AuthPanel";
import { useSupabaseAuth } from "@/lib/supabase/use-auth";
import type { SupabaseClient } from "@supabase/supabase-js";

type ReferralReview = { referred_id: string; member_name: string; city: string | null; registered_at: string; email_confirmed_at: string };
type AccessState = "checking" | "allowed" | "denied" | "error";

function validCpf(value: string) {
  const digits = value.replace(/\D/g, "");
  if (!/^\d{11}$/.test(digits) || /^([0-9])\1{10}$/.test(digits)) return false;
  const digitFor = (length: number, startWeight: number) => {
    let sum = 0;
    for (let i = 0; i < length; i += 1) sum += Number(digits[i]) * (startWeight - i);
    const remainder = sum % 11;
    return remainder < 2 ? 0 : 11 - remainder;
  };
  return digitFor(9, 10) === Number(digits[9]) && digitFor(10, 11) === Number(digits[10]);
}

export default function ReferralVerificationPage() {
  const auth = useSupabaseAuth();
  const [authOpen, setAuthOpen] = useState(false);
  const [access, setAccess] = useState<AccessState>("checking");
  const [accessError, setAccessError] = useState("");
  const [items, setItems] = useState<ReferralReview[]>([]);
  const [loading, setLoading] = useState(false);
  const [listError, setListError] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    let active = true;
    if (auth.loading) return () => { active = false; };
    if (!auth.user || !auth.client) { setAccess("denied"); return () => { active = false; }; }
    setAccess("checking"); setAccessError("");
    void auth.client.rpc("can_verify_referrals").then(({ data, error }) => {
      if (!active) return;
      if (error) { setAccess("error"); setAccessError("Não conseguimos confirmar sua permissão agora. Tente novamente."); return; }
      setAccess(data === true ? "allowed" : "denied");
    }, () => {
      if (!active) return;
      setAccess("error"); setAccessError("Falha de conexão ao confirmar sua permissão.");
    });
    return () => { active = false; };
  }, [auth.client, auth.loading, auth.user]);

  const refresh = useCallback(async () => {
    if (!auth.client || !auth.user || access !== "allowed") return;
    setLoading(true); setListError(""); setMessage("");
    const { data, error } = await auth.client.rpc("list_referrals_pending_cpf");
    setLoading(false);
    if (error) { setListError("Não foi possível carregar a fila. Tente novamente."); return; }
    setItems((data ?? []) as ReferralReview[]);
  }, [access, auth.client, auth.user]);

  useEffect(() => { if (access === "allowed") void refresh(); }, [access, refresh]);

  function showResult(text: string) { setMessage(text); }

  return <main className="auth-screen referral-review-screen">
    <Link className="auth-screen-brand" href="/">
      <Image src="/conecta-abc-mark.svg" alt="" width={43} height={43} priority />
      <span>CONECTA <b>ABC</b><small>Uma plataforma da SAD</small></span>
    </Link>
    <div className="referral-review-content">
      <div className="module-title-row"><div><div className="eyebrow">ÁREA INTERNA · EQUIPE</div><h1>Validação de indicações</h1><p className="muted">Confira e valide uma indicação após a verificação segura do CPF.</p></div><span className="badge"><LockKeyhole size={12} /> RESTRITO</span></div>
      {auth.loading || access === "checking" ? <section className="panel"><div className="empty" role="status">Verificando sessão e permissão…</div></section> : !auth.user ? <section className="panel referral-review-gate"><span className="auth-brand-icon"><ShieldCheck size={20} /></span><h2>Entre com a conta da equipe</h2><p className="muted">Somente validadores autorizados podem acessar esta fila. Entrar não concede permissão automaticamente.</p><button className="primary-btn" type="button" onClick={() => setAuthOpen(true)}>Entrar com conta autorizada　→</button></section> : access === "denied" ? <section className="panel referral-review-gate"><span className="auth-brand-icon"><LockKeyhole size={20} /></span><h2>Acesso não autorizado</h2><p className="muted">Sua conta não foi designada como validadora de indicações. Peça à administração para conceder esse acesso.</p><button className="secondary-btn" type="button" onClick={() => void auth.signOut()}>Sair desta conta</button></section> : access === "error" ? <section className="panel referral-review-gate"><span className="auth-brand-icon"><AlertCircle size={20} /></span><h2>Não foi possível verificar seu acesso</h2><p className="auth-error" role="alert">{accessError}</p><button className="secondary-btn" type="button" onClick={() => window.location.reload()}>Tentar novamente</button></section> : <>
        <section className="panel referral-review-privacy"><ShieldCheck size={18} /><p>Confirme o documento original pelo canal seguro da equipe. O CPF é usado somente para verificar duplicidade e não é guardado em texto aberto.</p></section>
        <section className="panel referral-review-queue"><div className="panel-title"><div><h2>Indicações aguardando CPF</h2><p className="muted">O e-mail já foi confirmado. A indicação só pontua após esta conferência.</p></div><button className="secondary-btn" type="button" disabled={loading} onClick={() => void refresh()}><RefreshCw size={13} /> {loading ? "Atualizando…" : "Atualizar fila"}</button></div>
          {message && <p className="auth-success" role="status"><CheckCircle2 size={14} /> {message}</p>}
          {listError && <p className="auth-error" role="alert">{listError}</p>}
          {loading && !items.length ? <div className="empty" role="status">Carregando fila…</div> : items.length ? <div className="referral-review-list">{items.map((item) => <ReferralReviewCard key={item.referred_id} client={auth.client!} item={item} onVerified={async () => { await refresh(); showResult("CPF conferido. Os 10 pontos foram registrados uma única vez para quem fez a indicação."); }} />)}</div> : !listError ? <div className="empty"><CheckCircle2 size={18} /> Nenhuma indicação está aguardando validação.</div> : null}
        </section>
      </>}
      <p className="data-note referral-review-footnote">Não registre ou envie CPFs por e-mail, Feed, chat ou planilha compartilhada. A chave de proteção fica no servidor e não é exibida nesta tela.</p>
    </div>
    <footer className="auth-screen-footer"><Link href="/">Voltar ao Conecta ABC</Link></footer>
    <AuthPanel open={authOpen} client={auth.client} user={auth.user} profile={auth.profile} onClose={() => setAuthOpen(false)} onSignedOut={() => setAuthOpen(false)} />
  </main>;
}

function ReferralReviewCard({ client, item, onVerified }: { client: SupabaseClient; item: ReferralReview; onVerified: () => Promise<void> }) {
  const [cpf, setCpf] = useState("");
  const [attested, setAttested] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError("");
    if (!validCpf(cpf)) { setError("Confira o CPF informado."); return; }
    if (!attested) { setError("Confirme que conferiu o documento pelo canal seguro."); return; }
    setBusy(true);
    const { data, error: rpcError } = await client.rpc("verify_referral_cpf", { referred_id: item.referred_id, cpf_input: cpf });
    setCpf(""); setAttested(false); setBusy(false);
    if (rpcError) {
      if (rpcError.code === "23505") setError("Este CPF já foi usado para validar outra indicação.");
      else if (rpcError.code === "22023") setError("O CPF informado não é válido.");
      else if (rpcError.code === "42501") setError("Sua permissão de validação expirou. Entre novamente ou fale com a administração.");
      else setError("Não foi possível concluir a validação. Tente novamente.");
      return;
    }
    if (data !== true) { setError("Esta indicação não está mais aguardando validação. Atualize a fila."); return; }
    await onVerified();
  }

  return <article className="referral-review-item"><div className="referral-review-person"><span className="verification-avatar">{item.member_name.slice(0, 1).toUpperCase()}</span><div><strong>{item.member_name}</strong><span><MapPin size={12} /> {item.city || "Grande ABC"}</span><small>Cadastro em {new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium" }).format(new Date(item.registered_at))} · e-mail confirmado</small></div></div>
    <form className="referral-cpf-form" onSubmit={(event) => void submit(event)} noValidate><label className="field"><span>CPF conferido</span><input type="text" inputMode="numeric" autoComplete="off" maxLength={14} value={cpf} onChange={(event) => setCpf(event.target.value)} placeholder="000.000.000-00" aria-label={`CPF de conferência para ${item.member_name}`} /></label><label className="consent-field"><input type="checkbox" checked={attested} onChange={(event) => setAttested(event.target.checked)} disabled={busy} /><span>Conferi o CPF com o documento original pelo canal seguro da equipe.</span></label>{error && <p className="auth-error" role="alert">{error}</p>}<button className="primary-btn" type="submit" disabled={busy || !attested}>{busy ? "Validando…" : "Validar indicação · +10 pts ao indicador"}</button></form>
  </article>;
}
