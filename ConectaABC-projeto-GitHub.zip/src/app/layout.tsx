import type { Metadata, Viewport } from "next";
import { BetaSupport } from "@/components/BetaSupport";
import "./globals.css";
import "./social-theme.css";
import "leaflet/dist/leaflet.css";

export const metadata: Metadata = {
  applicationName: "Conecta ABC",
  title: "Conecta ABC",
  description: "Uma plataforma comunitária da SAD para os sete municípios do Grande ABC.",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "Conecta ABC",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: [{ url: "/conecta-abc-192.png", sizes: "192x192", type: "image/png" }],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#101110",
  colorScheme: "dark",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}<BetaSupport /></body></html>;
}

