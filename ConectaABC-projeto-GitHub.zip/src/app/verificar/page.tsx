"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { AlertCircle, CheckCircle2, Clock3, MapPin, ShieldCheck } from "lucide-react";
import { getSupabaseBrowserClient } from "@/lib/supabase/client";

type Verification = { first_name: string; city: string | null; email_confirmed: boolean };
type State = "loading" | "valid" | "pending" | "invalid" | "unavailable";
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export default function VerifyMemberPage() {
  const [state, setState] = useState<State>("loading");
  const [member, setMember] = useState<Verification | null>(null);

  async function verify(id: string | null) {
    setMember(null);
    if (!id || !UUID.test(id)) { setState("invalid"); return; }
    const client = getSupabaseBrowserClient();
    if (!client) { setState("unavailable"); return; }
    setState("loading");
    const { data, error } = await client.rpc("verify_member_card", { member_id_input: id });
    if (error) { setState("unavailable"); return; }
    const row = Array.isArray(data) ? data[0] : null;
    if (!row || typeof row.first_name !== "string") { setState("invalid"); return; }
    const safeMember: Verification = {
      first_name: row.first_name,
      city: typeof row.city === "string" ? row.city : null,
      email_confirmed: row.email_confirmed === true,
    };
    setMember(safeMember);
    setState(safeMember.email_confirmed ? "valid" : "pending");
  }

  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get("membro");
    void verify(id);
    // Query value is read once when the static page loads.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const status = {
    loading: { icon: <Clock3 size={22} />, title: "Consultando perfil…", detail: "Aguarde enquanto verificamos o cadastro.", tone: "neutral" },
    valid: { icon: <CheckCircle2 size={22} />, title: "Perfil confirmado", detail: "Este perfil está cadastrado no Conecta ABC e tem e-mail confirmado.", tone: "success" },
    pending: { icon: <Clock3 size={22} />, title: "Cadastro localizado", detail: "O perfil está cadastrado, mas ainda não confirmou o e-mail.", tone: "pending" },
    invalid: { icon: <AlertCircle size={22} />, title: "Perfil não encontrado", detail: "Não localizamos um cadastro válido para este QR Code. Confira se o código está completo.", tone: "error" },
    unavailable: { icon: <AlertCircle size={22} />, title: "Consulta indisponível", detail: "Não foi possível consultar o cadastro agora. Verifique sua conexão e tente novamente.", tone: "error" },
  }[state];

  return <main className="auth-screen verification-screen">
    <Link className="auth-screen-brand" href="/">
      <Image src="/conecta-abc-mark.svg" alt="" width={43} height={43} priority />
      <span>CONECTA <b>ABC</b><small>O Grande ABC conectado.</small></span>
    </Link>
    <section className="auth-dialog verification-card" aria-live="polite">
      <div className="auth-brand-icon"><ShieldCheck size={20} /></div>
      <span className="eyebrow">VALIDAÇÃO DE CARTEIRINHA</span>
      <h1>Perfil Conecta ABC</h1>
      <p className="muted">Consulta pública do cadastro associado a esta carteirinha.</p>
      <div className={`verification-status verification-${status.tone}`}>
        {status.icon}<div><strong>{status.title}</strong><p>{status.detail}</p></div>
      </div>
      {member && <div className="verification-member">
        <div className="verification-avatar">{member.first_name.slice(0, 1).toUpperCase()}</div>
        <div><strong>{member.first_name}</strong><span><MapPin size={13} /> {member.city || "Grande ABC"}</span></div>
      </div>}
      <p className="verification-disclaimer">Esta consulta confirma apenas a existência do cadastro e a confirmação do e-mail. Não comprova identidade civil, vínculo com o Clube de Benefícios nem direito a descontos.</p>
      {state === "unavailable" && <button className="primary-btn verification-retry" type="button" onClick={() => void verify(new URLSearchParams(window.location.search).get("membro"))}>Tentar novamente</button>}
      <Link className="verification-home" href="/">Ir para o Conecta ABC</Link>
    </section>
    <footer className="auth-screen-footer">Uma plataforma da SAD</footer>
  </main>;
}
