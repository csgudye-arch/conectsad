import type { Metadata } from "next";
import { LegalPage } from "@/components/LegalPage";

export const metadata: Metadata = { title: "Termos de Uso | Conecta ABC", description: "Termos preliminares de uso do Conecta ABC." };

export default function TermsPage() {
  return <LegalPage
    title="Termos de Uso"
    intro="Estes termos preliminares descrevem regras básicas para utilizar o Conecta ABC, uma plataforma comunitária da SAD para os sete municípios do Grande ABC."
    sections={[
      { title: "Sobre a plataforma", paragraphs: ["O Conecta ABC oferece ferramentas digitais de participação comunitária, como feed, relatos urbanos, solicitações de serviços e informações sobre os módulos em preparação. A plataforma é da AGENCIA SAD DE COMUNICACAO LTDA, CNPJ 47.782.327/0001-26, nome fantasia AGENCIA SAD. O comprovante da Receita Federal enviado pelo responsável informa situação cadastral ativa em 01/10/2026.", "O Conecta ABC não é um canal oficial de emergência nem representa prefeituras, órgãos públicos ou serviços de socorro. Em risco imediato, procure os serviços públicos de emergência apropriados."] },
      { title: "Conta e uso responsável", paragraphs: ["Mantenha os dados de cadastro corretos, proteja suas credenciais e não use a conta para se passar por outra pessoa, praticar fraude, assediar, ameaçar, violar direitos ou interferir no funcionamento da plataforma.", "Você é responsável pelo conteúdo que envia e deve ter autorização para compartilhar informações e materiais de terceiros. Não publique dados pessoais de outras pessoas sem necessidade e autorização apropriada."] },
      { title: "Publicações e moderação", paragraphs: ["Publicações e relatos podem ser revisados, ocultados ou removidos para proteger a comunidade e cumprir as regras da plataforma. O envio não garante aprovação, pontuação, atendimento, solução do problema ou resposta de um órgão público.", "Use localização aproximada quando possível e descreva a situação com clareza, sem incluir dados de contato ou documentos no conteúdo que possa se tornar público."] },
      { title: "Serviços e módulos em preparação", paragraphs: ["As solicitações de apoio social são recebidas para triagem pelo projeto e não constituem aconselhamento jurídico, veterinário, médico ou garantia de atendimento. A disponibilidade e os critérios dos serviços dependem da equipe e de parceiros.", "O Clube de benefícios está fechado. Assinaturas, cobranças recorrentes, pagamentos, missões com pontuação efetiva e premiações em dinheiro não estão ativos nesta versão. Qualquer ativação futura dependerá de regras próprias, informações claras e dos meios de pagamento configurados."] },
      { title: "Disponibilidade e alterações", paragraphs: ["A plataforma pode passar por manutenção, mudanças ou interrupções. Funcionalidades e estes termos podem ser atualizados; a versão vigente deverá ser apresentada aos usuários antes de produzir efeitos para novos usos."] },
      { title: "Contato", paragraphs: ["Dúvidas sobre estes termos ou sobre o uso da conta: santoandredepressao@gmail.com."] },
    ]}
  />;
}
