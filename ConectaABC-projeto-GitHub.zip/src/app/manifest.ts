import type { MetadataRoute } from "next";

export const dynamic = "force-static";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Conecta ABC",
    short_name: "Conecta ABC",
    description: "O Grande ABC conectado.",
    start_url: "/",
    display: "standalone",
    background_color: "#000000",
    theme_color: "#000000",
    icons: [
      { src: "/conecta-abc-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/conecta-abc-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
    ],
  };
}
