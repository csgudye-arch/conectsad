import { CompleteGoogleProfile } from "@/components/CompleteGoogleProfile";

export default function CompleteProfilePage() {
  return <CompleteGoogleProfile />;
}
