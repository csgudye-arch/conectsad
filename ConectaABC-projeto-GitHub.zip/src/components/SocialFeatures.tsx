"use client";

import { createContext, useCallback, useContext, useEffect, useState, type FormEvent, type ReactNode } from "react";
import { MemberConnections } from "./MemberConnections";
import { ContentReportButton } from "./ContentReports";
import type { SupabaseClient } from "@supabase/supabase-js";
import { Bell, Bookmark, MessageCircle, RefreshCw, Search, UsersRound } from "lucide-react";

type SocialContextValue = { client: SupabaseClient | null; userId?: string; openAuth: () => void; saved: Set<string>; refreshSaved: () => Promise<void> };
const SocialContext = createContext<SocialContextValue | null>(null);
export function useSocial() { const context = useContext(SocialContext); if (!context) throw new Error("SocialFeaturesProvider ausente"); return context; }
export function socialError(error: unknown) {
  const item = error as { code?: string; message?: string };
  if (["PGRST202", "42P01", "42883"].includes(item?.code ?? "")) return "Este recurso aguarda ativação da equipe. Tente novamente depois.";
  if (item?.code === "42501") return "Entre com uma conta autorizada para realizar esta ação.";
  if (["22023", "P0001", "P0002"].includes(item?.code ?? "")) return item.message || "Não foi possível concluir esta ação.";
  return "Não foi possível conectar. Tente novamente.";
}
export function SocialFeaturesProvider({ client, userId, openAuth, children }: { client: SupabaseClient | null; userId?: string; openAuth: () => void; children: ReactNode }) {
  const [saved, setSaved] = useState<Set<string>>(new Set());
  const refreshSaved = useCallback(async () => {
    if (!client || !userId) { setSaved(new Set()); return; }
    const { data, error } = await client.rpc("social_saved_posts");
    if (!error) setSaved(new Set((data ?? []).map((row: { post_id: string }) => row.post_id)));
  }, [client, userId]);
  useEffect(() => { const timer = window.setTimeout(() => { setSaved(new Set()); void refreshSaved().catch(() => {}); }, 0); return () => window.clearTimeout(timer); }, [refreshSaved]);
  return <SocialContext.Provider value={{ client, userId, openAuth, saved, refreshSaved }}>{children}</SocialContext.Provider>;
}
type Comment = { id: string; body: string; first_name: string; is_own: boolean; status: string; created_at: string };
export function PostSocialActions({ postId, approved, leadingActions, trailingActions, summary, compact=false }: { postId: string; approved: boolean; leadingActions?:ReactNode; trailingActions?:ReactNode; summary?:ReactNode; compact?:boolean }) {
  const { client, userId, openAuth, saved, refreshSaved } = useSocial();
  const [expanded, setExpanded] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [body, setBody] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(false);
  const refresh = useCallback(async () => {
    if (!client) { setError("Conexão indisponível."); return; }
    setLoading(true); setError("");
    try { const result = await client.rpc("social_list_comments", { target_post: postId }); if (result.error) throw result.error; setComments(result.data ?? []); }
    catch (err) { setError(socialError(err)); }
    finally { setLoading(false); }
  }, [client, postId]);
  useEffect(() => { if (!expanded) return; const timer = window.setTimeout(() => void refresh(), 0); return () => window.clearTimeout(timer); }, [expanded, refresh]);
  async function save() {
    if (!client || !userId) { openAuth(); return; }
    setBusy(true); setError(""); setNotice("");
    try { const result = await client.rpc("social_set_bookmark", { target_post: postId, saved: !saved.has(postId) }); if (result.error) throw result.error; await refreshSaved(); setNotice(result.data ? "Publicação salva no seu perfil." : "Publicação removida dos salvos."); }
    catch (err) { setError(socialError(err)); } finally { setBusy(false); }
  }
  async function submit(event: FormEvent) {
    event.preventDefault(); if (!userId || !client) { openAuth(); return; }
    if (body.trim().length < 2 || body.trim().length > 1000) { setError("Escreva de 2 a 1.000 caracteres."); return; }
    setBusy(true); setError(""); setNotice("");
    try { const result = await client.rpc("social_add_comment", { target_post: postId, comment_body: body.trim() }); if (result.error) throw result.error; setBody(""); setNotice("Comentário enviado para análise. Você pode acompanhá-lo abaixo."); await refresh(); }
    catch (err) { setError(socialError(err)); } finally { setBusy(false); }
  }
  if (!approved) return null;
  return <div className="social-interactions"><div className={`social-interaction-buttons ${compact?"ref-post-controls":""}`}>{leadingActions}<button aria-label="Comentários" title="Comentários" aria-expanded={expanded} onClick={() => setExpanded(!expanded)}><MessageCircle size={compact?24:18}/>{!compact&&"Comentários"}</button>{trailingActions}<button aria-label={saved.has(postId)?"Salvo":"Salvar"} title={saved.has(postId)?"Salvo":"Salvar"} disabled={busy} aria-pressed={saved.has(postId)} onClick={() => void save()}><Bookmark size={compact?24:18} fill={saved.has(postId) ? "currentColor" : "none"}/>{!compact&&(saved.has(postId) ? "Salvo" : "Salvar")}</button></div>{summary}{error && <p role="alert" className="auth-error">{error}</p>}{notice && <p role="status" className="social-feedback">{notice}</p>}{expanded && <section className="social-comments" aria-label="Comentários"><button className="secondary-btn" disabled={loading} onClick={() => void refresh()}><RefreshCw size={14}/> Atualizar comentários</button>{loading ? <p role="status">Carregando…</p> : !comments.length ? <p>Nenhum comentário disponível.</p> : comments.map(comment => <article key={comment.id}><strong>{comment.first_name}{comment.is_own ? " · você" : ""}</strong><small>{comment.status === "pending" ? "Em análise · visível só para você" : comment.status === "rejected" ? "Não aprovado · visível só para você" : new Date(comment.created_at).toLocaleDateString("pt-BR")}</small><p>{comment.body}</p>{comment.status==="approved"&&<ContentReportButton kind="comment" targetId={comment.id}/>}</article>)}<form onSubmit={submit}><label htmlFor={`comment-${postId}`}>Seu comentário</label><textarea id={`comment-${postId}`} value={body} onChange={event => setBody(event.target.value)} maxLength={1000} rows={3} placeholder="Participe com respeito…"/><small>Comentários são publicados após análise da equipe.</small><button className="primary-btn" disabled={busy || loading}>{busy ? "Enviando…" : userId ? "Enviar comentário" : "Entrar para comentar"}</button></form></section>}</div>;
}

type Saved = { post_id: string; body: string; title: string | null; city: string };
type Friendship = { request_id: string; first_name: string; city: string; status: string; incoming: boolean };
type Member = { member_id: string; first_name: string; city: string };
type Notice = { id: string; kind: string; message: string; post_id: string | null; read_at: string | null; created_at: string };
type Review = { id: string; post_id: string; body: string; first_name: string };
export function SocialWorkspace({ area }: { area: "salvos" | "amigos" | "notificacoes" | "comentarios-equipe" }) {
  const { client, userId, openAuth, refreshSaved } = useSocial();
  const [items, setItems] = useState<(Saved | Friendship | Notice | Review)[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [term, setTerm] = useState("");
  const [searched, setSearched] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [reasons, setReasons] = useState<Record<string,string>>({});
  const titles = { salvos: "Publicações salvas", amigos: "Amigos", notificacoes: "Notificações", "comentarios-equipe": "Moderação de comentários" };
  const refresh = useCallback(async () => {
    if (!client || !userId) { setLoading(false); setItems([]); return; }
    setLoading(true); setError("");
    try { const { data, error: rpcError } = await client.rpc({ salvos: "social_saved_posts", amigos: "social_my_friends", notificacoes: "social_my_notifications", "comentarios-equipe": "social_comment_queue" }[area]); if (rpcError) throw rpcError; setItems(data ?? []); }
    catch (err) { setError(socialError(err)); } finally { setLoading(false); }
  }, [client, userId, area]);
  useEffect(() => { const timer = window.setTimeout(() => { setItems([]); setNotice(""); void refresh(); }, 0); return () => window.clearTimeout(timer); }, [refresh]);
  async function act(rpc: string, args: Record<string,unknown>, success: string) {
    if (!client || !userId) { openAuth(); return; }
    setBusy(true); setError(""); setNotice("");
    try { const result = await client.rpc(rpc,args); if (result.error) throw result.error; setNotice(success); await refresh(); if (area === "salvos") await refreshSaved(); }
    catch (err) { setError(socialError(err)); } finally { setBusy(false); }
  }
  async function search(event: FormEvent) {
    event.preventDefault(); if (!client || !userId) { openAuth(); return; }
    if (term.trim().length < 2) { setError("Digite pelo menos duas letras do primeiro nome."); return; }
    setBusy(true); setError("");
    try { const result = await client.rpc("social_search_members", { term: term.trim() }); if (result.error) throw result.error; setMembers(result.data ?? []); setSearched(true); }
    catch (err) { setError(socialError(err)); } finally { setBusy(false); }
  }
  if (!userId) return <section className="social-empty"><h1>{titles[area]}</h1><p>Entre para acessar esta área da sua conta.</p><button className="primary-btn" onClick={openAuth}>Entrar ou criar conta</button></section>;
  return <section className="social-workspace"><div className="module-title-row"><div><h1>{titles[area]}</h1><p className="muted">{area === "salvos" ? "Somente você vê sua lista de salvos." : area === "amigos" ? "Conecte-se com outros moradores do Grande ABC." : area === "comentarios-equipe" ? "Revise o conteúdo e registre o motivo da decisão." : "Atualizações da sua participação na comunidade."}</p></div><button className="secondary-btn" onClick={() => void refresh()} disabled={loading || busy}>Atualizar</button></div>{error && <p className="auth-error" role="alert">{error}</p>}{notice && <p className="social-feedback" role="status">{notice}</p>}
  {area === "amigos" && <><MemberConnections/><form className="social-member-search" onSubmit={search}><label htmlFor="friend-term">Encontrar por primeiro nome</label><div><input id="friend-term" value={term} maxLength={80} onChange={event=>setTerm(event.target.value)}/><button className="primary-btn" disabled={busy}><Search size={16}/> Buscar</button></div></form>{searched && <section><h2>Resultados</h2>{!members.length && <p>Nenhum membro encontrado.</p>}{members.map(member=><article className="social-data-row" key={member.member_id}><UsersRound/><div><strong>{member.first_name}</strong><small>{member.city || "Grande ABC"}</small></div><button className="secondary-btn" disabled={busy} onClick={()=>void act("social_request_friend",{target_member:member.member_id},"Pedido registrado. A amizade depende da aceitação do outro membro.")}>Adicionar</button></article>)}</section>}<h2>Amizades e pedidos</h2></>}
  {loading ? <p role="status">Carregando…</p> : !items.length && !error ? <div className="social-empty">{area === "comentarios-equipe" ? "Nenhum comentário aguardando análise." : "Nenhum item por enquanto."}</div> : items.map((entry) => {
    if (area === "salvos") { const row=entry as Saved; return <article className="social-data-row" key={row.post_id}><Bookmark/><div><strong>{row.title || row.city}</strong><p>{row.body}</p><a href={`/?post=${encodeURIComponent(row.post_id)}`}>Abrir publicação</a></div><button className="secondary-btn" disabled={busy} onClick={()=>void act("social_set_bookmark",{target_post:row.post_id,saved:false},"Removida dos salvos.")}>Remover</button></article>; }
    if (area === "amigos") { const row=entry as Friendship; return <article className="social-data-row" key={row.request_id}><UsersRound/><div><strong>{row.first_name}</strong><small>{row.city || "Grande ABC"} · {row.status === "accepted" ? "Amigo" : row.incoming ? "Pedido recebido" : "Pedido enviado"}</small></div><div className="button-row"><button className="secondary-btn" disabled={busy} onClick={()=>void act("social_block_friend",{target_request:row.request_id},"Contato bloqueado.")}>Bloquear</button>{row.status === "pending" && row.incoming ? <><button className="primary-btn" disabled={busy} onClick={()=>void act("social_respond_friend",{request_id:row.request_id,accept_request:true},"Amizade aceita.")}>Aceitar</button><button className="secondary-btn" disabled={busy} onClick={()=>void act("social_respond_friend",{request_id:row.request_id,accept_request:false},"Pedido recusado.")}>Recusar</button></> : <button className="secondary-btn" disabled={busy} onClick={()=>void act("social_remove_friend",{request_id:row.request_id},row.status === "accepted" ? "Amizade encerrada." : "Pedido cancelado.")}>{row.status === "accepted" ? "Desfazer amizade" : "Cancelar pedido"}</button>}</div></article>; }
    // A navegação completa reinicia o roteador legado que lê area/post na montagem.
    // eslint-disable-next-line @next/next/no-html-link-for-pages
    if (area === "notificacoes") { const row=entry as Notice; return <article className={`social-data-row ${!row.read_at ? "unread" : ""}`} key={row.id}><Bell/><div><strong>{row.message}</strong><small>{new Date(row.created_at).toLocaleString("pt-BR")}</small>{row.kind === "friend_request" || row.kind === "friend_accepted" ? <a href="/?area=amigos">Ver amizades e pedidos</a> : row.kind === "post_review" ? <a href="/?area=envios">Acompanhar meus envios</a> : row.post_id && <a href={`/?post=${encodeURIComponent(row.post_id)}`}>Ver publicação</a>}</div>{!row.read_at && <button className="secondary-btn" disabled={busy} onClick={()=>void act("social_read_notification",{notification_id:row.id},"Notificação marcada como lida.")}>Marcar como lida</button>}</article>; }
    const row=entry as Review; return <article className="social-review-card" key={row.id}><strong>{row.first_name}</strong><p>{row.body}</p><a href={`/?post=${encodeURIComponent(row.post_id)}`}>Ver publicação original</a><label htmlFor={`reason-${row.id}`}>Motivo da decisão</label><input id={`reason-${row.id}`} value={reasons[row.id] || ""} onChange={event=>setReasons({...reasons,[row.id]:event.target.value})} maxLength={500}/><div className="button-row">{[{value:"approved",label:"Aprovar"},{value:"rejected",label:"Rejeitar"}].map(action=><button key={action.value} className="secondary-btn" disabled={busy || (reasons[row.id]?.trim().length || 0)<3} onClick={()=>void act("social_review_comment",{target_comment:row.id,decision:action.value,reason:reasons[row.id]},"Decisão registrada.")}>{action.label}</button>)}</div></article>;
  })}</section>;
}

