"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { MapPin, ShieldCheck } from "lucide-react";
import { useSupabaseAuth } from "@/lib/supabase/use-auth";
import { GRANDE_ABC_CITIES } from "@/lib/auth-validation";

export function CompleteGoogleProfile() {
  const auth = useSupabaseAuth();
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [consent, setConsent] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!auth.client || !auth.user) return;
    const form = new FormData(event.currentTarget);
    const displayName = String(form.get("display_name") ?? "").trim();
    const city = String(form.get("city") ?? "");
    if (displayName.length < 2 || displayName.length > 80) return setError("Informe seu nome com 2 a 80 caracteres.");
    if (!GRANDE_ABC_CITIES.includes(city as (typeof GRANDE_ABC_CITIES)[number])) return setError("Selecione uma cidade do Grande ABC.");
    if (!consent) return setError("Confirme a autorização para completar seu perfil.");

    setBusy(true);
    setError("");
    try {
    let referralCode = "";
    try { referralCode = window.localStorage.getItem("conecta-abc-referral-code") ?? ""; } catch { /* Indicação opcional. */ }
    if (referralCode) {
      const { error: referralError } = await auth.client.rpc("attribute_my_referral", { referral_code_input: referralCode });
      if (referralError) {
        setBusy(false);
        setError("Não foi possível vincular o link de indicação. Seu perfil ainda não foi alterado; tente novamente.");
        return;
      }
      try { window.localStorage.removeItem("conecta-abc-referral-code"); } catch { /* Indicação vinculada. */ }
    }
    const { error: updateError } = await auth.client.from("profiles").update({ display_name: displayName, city }).eq("id", auth.user.id);
    setBusy(false);
    if (updateError) {
      setError("Não foi possível salvar seu perfil. Tente novamente ou avise a equipe pelo menu de ajuda.");
      return;
    }
    router.push("/");
    } catch {
      setError("A conexão foi interrompida. Confira seu cadastro antes de tentar novamente.");
    } finally {
      setBusy(false);
    }
  }

  return <main className="auth-screen">
    <Link className="auth-screen-brand" href="/" aria-label="Conecta ABC início"><Image src="/conecta-abc-mark.svg" alt="" width={43} height={43} priority /><span>conecta <b>abc</b><small>Uma plataforma da SAD</small></span></Link>
    <section className="auth-dialog panel auth-page-dialog" aria-labelledby="profile-completion-title">
      <div className="auth-brand-icon"><MapPin size={20} /></div>
      <div className="eyebrow">CONECTA ABC · SEU PERFIL</div>
      <h2 id="profile-completion-title">Complete seu cadastro</h2>
      {auth.loading || auth.profileLoading ? <p role="status" className="muted">Conferindo seu perfil…</p> : !auth.user ? <>
        <p className="muted">Não encontramos uma sessão ativa. Entre com Google novamente para continuar.</p>
        <Link className="primary-btn auth-submit auth-link-button" href="/login">Voltar para o acesso</Link>
      </> : auth.profileError ? <p role="alert" className="auth-error">{auth.profileError}</p> : auth.profile?.city ? <>
        <p className="muted">Seu cadastro já está completo. Você pode continuar para o app.</p>
        <button className="primary-btn auth-submit" type="button" onClick={() => router.push("/")}>Continuar para o app</button>
      </> : <>
        <p className="muted">O Google confirmou sua conta. Informe sua cidade para concluir seu perfil comunitário.</p>
        <form className="auth-form" onSubmit={submit} noValidate>
          <label className="auth-field"><span>Nome de exibição</span><input name="display_name" autoComplete="name" defaultValue={auth.profile?.display_name === "Novo membro" ? String(auth.user.user_metadata?.full_name ?? auth.user.user_metadata?.name ?? "") : auth.profile?.display_name ?? ""} minLength={2} maxLength={80} required /></label>
          <label className="auth-field"><span>Cidade</span><span className="auth-input-wrap"><MapPin size={14} /><select name="city" defaultValue="" required><option value="" disabled>Selecione sua cidade</option>{GRANDE_ABC_CITIES.map((name) => <option key={name}>{name}</option>)}</select></span></label>
          <label className="auth-consent"><input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} /><span>Autorizo a criação do meu perfil com o nome e a cidade informados. O e-mail do Google será usado para autenticação e segurança.</span></label>
          {error && <p role="alert" className="auth-error">{error}</p>}
          <button className="primary-btn auth-submit" type="submit" disabled={busy}>{busy ? "Salvando…" : "Concluir meu cadastro"}</button>
        </form>
      </>}
      <p className="auth-privacy"><ShieldCheck size={13} /> Guardamos apenas os dados básicos necessários para seu perfil comunitário.</p>
    </section>
    <footer className="auth-screen-footer">O Grande ABC conectado · Uma plataforma da SAD</footer>
  </main>;
}
