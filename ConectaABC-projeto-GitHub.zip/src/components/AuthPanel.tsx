"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import type { SupabaseClient, User } from "@supabase/supabase-js";
import { ArrowLeft, Lock, Mail, MapPin, ShieldCheck, UserRound, X } from "lucide-react";
import type { MemberProfile } from "@/lib/supabase/use-auth";
import { GRANDE_ABC_CITIES, validateEmailInput, validateSignupInput } from "@/lib/auth-validation";
import { readableAuthError } from "@/lib/auth-errors";

type AuthPanelProps = {
  open: boolean;
  client: SupabaseClient | null;
  user: User | null;
  profile: MemberProfile | null;
  onClose: () => void;
  onSignedOut: () => void;
  presentation?: "modal" | "page";
  initialMode?: AuthMode;
  callbackNotice?: string;
  onBrowseAsGuest?: () => void;
};

type AuthMode = "signin" | "signup" | "recovery";

export function AuthPanel({ open, client, user, profile, onClose, onSignedOut, presentation = "modal", initialMode = "signin", callbackNotice = "", onBrowseAsGuest }: AuthPanelProps) {
  const router = useRouter();
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [consent, setConsent] = useState(false);
  const [pendingConfirmationEmail, setPendingConfirmationEmail] = useState("");

  useEffect(() => {
    const referral = new URLSearchParams(window.location.search).get("ref")?.trim().toUpperCase();
    if (referral && /^[A-F0-9]{10}$/.test(referral)) {
      try { window.localStorage.setItem("conecta-abc-referral-code", referral); } catch { /* Indicação opcional. */ }
    }
  }, []);

  if (presentation === "modal" && !open) return null;

  function switchMode(nextMode: AuthMode) {
    setMode(nextMode);
    setError("");
    setSuccess("");
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!client) return;
    setBusy(true);
    setError("");
    setSuccess("");

    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") ?? "").trim().toLowerCase();
    const password = String(form.get("password") ?? "");
    const displayName = String(form.get("display_name") ?? "").trim();
    const city = String(form.get("city") ?? "");
    const passwordConfirmation = String(form.get("password_confirmation") ?? "");

    const validationError = mode === "signup"
      ? validateSignupInput({ displayName, city, email, password, passwordConfirmation, consented: consent })
      : validateEmailInput(email) || (mode === "signin" && password.length < 8 ? "A senha precisa ter pelo menos 8 caracteres." : "");
    if (validationError) {
      setError(validationError);
      setBusy(false);
      return;
    }

    try {
      if (mode === "recovery") {
        const { error: recoveryError } = await client.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/login/recovery` });
        if (recoveryError) throw recoveryError;
        setSuccess("Se houver uma conta com esse e-mail, enviaremos um link para redefinir sua senha.");
      } else if (mode === "signup") {
        let referralCode = "";
        try { referralCode = window.localStorage.getItem("conecta-abc-referral-code") ?? ""; } catch { /* Indicação opcional. */ }
        const { data, error: authError } = await client.auth.signUp({
          email,
          password,
          options: { data: { display_name: displayName, city, ...(referralCode ? { referral_code: referralCode } : {}) }, emailRedirectTo: window.location.origin },
        });
        if (authError) throw authError;
        try { window.localStorage.removeItem("conecta-abc-referral-code"); } catch { /* Cadastro concluído. */ }
        if (!data.session) {
          setPendingConfirmationEmail(email);
          setSuccess("Cadastro criado. Confira seu e-mail e informe aqui o código de confirmação.");
        } else if (presentation === "page") {
          router.push("/");
        } else {
          onClose();
        }
      } else {
        const { error: authError } = await client.auth.signInWithPassword({ email, password });
        if (authError) throw authError;
        if (presentation === "page") router.push("/");
        else onClose();
      }
    } catch (authError) {
      setError(readableAuthError(authError));
    } finally {
      setBusy(false);
    }
  }

  async function confirmSignup(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!client || !pendingConfirmationEmail) return;
    const form = new FormData(event.currentTarget);
    const token = String(form.get("token") ?? "").replace(/\s/g, "");
    if (!/^\d{6,8}$/.test(token)) {
      setError("Digite o código numérico recebido por e-mail.");
      return;
    }
    setBusy(true);
    setError("");
    setSuccess("");
    try {
      const { error: verifyError } = await client.auth.verifyOtp({ email: pendingConfirmationEmail, token, type: "email" });
      if (verifyError) throw verifyError;
      setPendingConfirmationEmail("");
      setSuccess("E-mail confirmado. Sua conta já está pronta para usar.");
      if (presentation === "page") router.push("/");
      else onClose();
    } catch (verifyError) {
      setError(readableAuthError(verifyError));
    } finally {
      setBusy(false);
    }
  }

  async function resendConfirmation() {
    if (!client || !pendingConfirmationEmail) return;
    setBusy(true);
    setError("");
    setSuccess("");
    try {
      const { error: resendError } = await client.auth.resend({ type: "signup", email: pendingConfirmationEmail });
      if (resendError) throw resendError;
      setSuccess("Solicitação enviada. Confira a caixa de entrada e o spam.");
    } catch (resendError) {
      setError(readableAuthError(resendError));
    } finally {
      setBusy(false);
    }
  }

  async function updateRecoveredPassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!client) return;
    const form = new FormData(event.currentTarget);
    const password = String(form.get("password") ?? "");
    const confirmation = String(form.get("password_confirmation") ?? "");
    if (password.length < 8 || password !== confirmation) {
      setError(password.length < 8 ? "A senha precisa ter pelo menos 8 caracteres." : "As senhas não são iguais.");
      return;
    }
    setBusy(true);
    setError("");
    setSuccess("");
    try {
      const { error: updateError } = await client.auth.updateUser({ password });
      if (updateError) throw updateError;
      setSuccess("Senha atualizada. Você já pode continuar no app.");
      window.setTimeout(() => router.push("/"), 1200);
    } catch (updateError) {
      setError(readableAuthError(updateError));
    } finally {
      setBusy(false);
    }
  }

  async function signInWithGoogle() {
    if (!client) return;
    setBusy(true);
    setError("");
    setSuccess("");
    try {
      const { error: oauthError } = await client.auth.signInWithOAuth({ provider: "google", options: { redirectTo: `${window.location.origin}/login/complete-profile` } });
      if (oauthError) throw oauthError;
    } catch (oauthError) {
      setError(readableAuthError(oauthError));
      setBusy(false);
    }
  }

  async function signOut() {
    if (!client) return;
    setBusy(true);
    setError("");
    const { error: signOutError } = await client.auth.signOut();
    setBusy(false);
    if (signOutError) {
      setError("Não foi possível sair agora. Tente novamente.");
      return;
    }
    onSignedOut();
    if (presentation === "page") router.push("/");
    else onClose();
  }

  const panel = <section className={`auth-dialog panel ${presentation === "page" ? "auth-page-dialog" : ""}`} role={presentation === "modal" ? "dialog" : undefined} aria-modal={presentation === "modal" ? true : undefined} aria-labelledby="auth-title">
    {presentation === "modal" ? <button className="auth-close icon-btn" type="button" onClick={onClose} aria-label="Fechar"><X size={16} /></button> : onBrowseAsGuest ? <button className="auth-back-link auth-guest-link" type="button" onClick={onBrowseAsGuest}><ArrowLeft size={15} /> Explorar sem entrar</button> : <Link className="auth-back-link" href="/" aria-label="Voltar para o Conecta ABC"><ArrowLeft size={15} /> Voltar ao app</Link>}
    <div className="auth-brand-icon"><ShieldCheck size={20} /></div>
    <div className="eyebrow">CONECTA ABC · O GRANDE ABC CONECTADO</div>
    <h2 id="auth-title">{!client ? "Conexão em preparação" : mode === "recovery" ? "Redefinir senha" : user ? "Sua conta" : mode === "signin" ? "Bem-vindo de volta" : "Faça seu cadastro"}</h2>
    {callbackNotice && <p role="alert" className="auth-error">{callbackNotice}</p>}

    {!client ? <>
      <p className="muted">O banco já está preparado, mas falta configurar a URL e a chave publicável do seu projeto Supabase neste computador.</p>
      <div className="auth-config-note"><code>NEXT_PUBLIC_SUPABASE_URL</code><code>NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY</code></div>
    </> : mode === "recovery" && user ? <>
      <p className="muted">Escolha uma nova senha para sua conta.</p>
      <form className="auth-form" onSubmit={updateRecoveredPassword} noValidate>
        <label className="auth-field"><span>Nova senha</span><span className="auth-input-wrap"><Lock size={14} /><input name="password" type="password" autoComplete="new-password" minLength={8} required placeholder="Mínimo de 8 caracteres" /></span></label>
        <label className="auth-field"><span>Confirme a nova senha</span><span className="auth-input-wrap"><Lock size={14} /><input name="password_confirmation" type="password" autoComplete="new-password" minLength={8} required placeholder="Digite a senha novamente" /></span></label>
        {error && <p role="alert" className="auth-error">{error}</p>}{success && <p role="status" className="auth-success">{success}</p>}
        <button className="primary-btn auth-submit" disabled={busy}>{busy ? "Salvando…" : "Salvar nova senha"}</button>
      </form>
    </> : pendingConfirmationEmail ? <>
      <p className="muted">Enviamos uma confirmação para <strong>{pendingConfirmationEmail}</strong>. Digite o código recebido ou acesse o link de confirmação enviado no e-mail.</p>
      <form className="auth-form" onSubmit={confirmSignup} noValidate>
        <label className="auth-field"><span>Código de confirmação</span><input name="token" type="text" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6,8}" minLength={6} maxLength={8} required placeholder="Digite o código do e-mail" /></label>
        {error && <p role="alert" className="auth-error">{error}</p>}{success && <p role="status" className="auth-success">{success}</p>}
        <button className="primary-btn auth-submit" disabled={busy}>{busy ? "Verificando…" : "Confirmar e-mail"}</button>
      </form>
      <button type="button" className="auth-forgot-link" onClick={resendConfirmation} disabled={busy}>{busy ? "Aguarde…" : "Enviar nova confirmação"}</button>
    </> : user ? <>
      <p className="muted">Você está conectado com <strong>{user.email}</strong>.</p>
      {profile && <p className="auth-profile-line"><UserRound size={14} /> {profile.display_name}{profile.city ? ` · ${profile.city}` : ""}</p>}
      {error && <p role="alert" className="auth-error">{error}</p>}
      <button className="primary-btn auth-submit" type="button" onClick={signOut} disabled={busy}>{busy ? "Saindo…" : "Sair da conta"}</button>
    </> : <>
      <p className="muted">{mode === "recovery" ? "Informe o e-mail da sua conta e enviaremos um link seguro." : mode === "signin" ? "Entre para acompanhar sua comunidade e suas contribuições." : "Crie sua conta gratuita para participar da comunidade Conecta ABC."}</p>
      {mode !== "recovery" && <div className="auth-mode-switch" role="tablist" aria-label="Ação da conta">
        <button type="button" role="tab" aria-selected={mode === "signin"} className={mode === "signin" ? "selected" : ""} onClick={() => switchMode("signin")}>Entrar</button>
        <button type="button" role="tab" aria-selected={mode === "signup"} className={mode === "signup" ? "selected" : ""} onClick={() => switchMode("signup")}>Criar conta</button>
      </div>}
      <form className="auth-form" onSubmit={submit} noValidate>
        {mode === "signup" && <label className="auth-field"><span>Nome completo</span><input name="display_name" type="text" autoComplete="name" minLength={2} maxLength={80} required placeholder="Como devemos chamar você?" /></label>}
        {mode === "signup" && <label className="auth-field"><span>Cidade</span><span className="auth-input-wrap"><MapPin size={14} /><select name="city" autoComplete="address-level2" defaultValue="" required><option value="" disabled>Selecione sua cidade</option>{GRANDE_ABC_CITIES.map((name) => <option key={name}>{name}</option>)}</select></span></label>}
        <label className="auth-field"><span>E-mail</span><span className="auth-input-wrap"><Mail size={14} /><input name="email" type="email" autoComplete="email" required maxLength={254} placeholder="voce@email.com" /></span></label>
        {mode !== "recovery" && <label className="auth-field"><span>Senha</span><span className="auth-input-wrap"><Lock size={14} /><input name="password" type="password" autoComplete={mode === "signin" ? "current-password" : "new-password"} minLength={8} required placeholder="Mínimo de 8 caracteres" /></span></label>}
        {mode === "signup" && <label className="auth-field"><span>Confirme sua senha</span><span className="auth-input-wrap"><Lock size={14} /><input name="password_confirmation" type="password" autoComplete="new-password" minLength={8} required placeholder="Digite a senha novamente" /></span></label>}
        {mode === "signup" && <label className="auth-consent"><input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} /><span>Autorizo a criação do meu perfil com o nome, e-mail e cidade informados. O e-mail será usado para autenticação e segurança da conta.</span></label>}
        {error && <p role="alert" className="auth-error">{error}</p>}
        {success && <p role="status" className="auth-success">{success}</p>}
        <button className="primary-btn auth-submit" type="submit" disabled={busy}>{busy ? "Aguarde…" : mode === "recovery" ? "Enviar link de redefinição" : mode === "signin" ? "Entrar na minha conta" : "Criar minha conta"}</button>
      </form>
      {mode === "signin" && <button type="button" className="auth-forgot-link" onClick={() => switchMode("recovery")}>Esqueci minha senha</button>}
      {mode !== "recovery" && <><div className="auth-divider"><span>ou</span></div><button className="google-auth-btn" type="button" onClick={signInWithGoogle} disabled={busy}><span className="google-g" aria-hidden="true">G</span> Continuar com Google</button></>}
      {mode === "recovery" && <button type="button" className="auth-forgot-link" onClick={() => switchMode("signin")}>Voltar para entrar</button>}
      <p className="auth-privacy"><ShieldCheck size={13} /> Seu acesso é protegido. Seus dados pessoais são tratados conforme nossa Política de Privacidade.</p>
      {presentation === "modal" && <Link className="auth-full-page-link" href="/login">Abrir tela completa de acesso</Link>}
    </>}
  </section>;

  return presentation === "page" ? <main className="auth-screen"><Link className="auth-screen-brand" href="/" aria-label="Conecta ABC início"><Image src="/conecta-abc-mark.svg" alt="" width={43} height={43} priority /><span>conecta <b>abc</b><small>Uma plataforma da SAD</small></span></Link>{panel}<footer className="auth-screen-footer">O Grande ABC conectado · Uma plataforma da SAD</footer></main> : <div className="auth-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>{panel}</div>;
}
