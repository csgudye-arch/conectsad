"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { ArrowUpRight, Briefcase, CalendarDays, ChevronLeft, ChevronRight, Dog, Pause, Play, ShoppingBag, UsersRound, X } from "lucide-react";

const examples = [
  { name: "Comunidade", tag: "NO BAIRRO", title: "O ABC fica melhor quando a gente se conecta", city: "Santo André", image: "/demo-feed-1.webp", detail: "Uma conversa de vizinhos para mostrar como os stories da comunidade aparecem aqui.", area: "feed" },
  { name: "Vagas ABC", tag: "EMPREGO", title: "Auxiliar administrativo", city: "São Bernardo do Campo", image: "/demo-services-4.webp", detail: "Empresa Exemplo · CLT · Presencial. Vaga fictícia para visualizar o layout; não há processo seletivo ou candidatura.", area: "vagas" },
  { name: "Pets do ABC", tag: "ANIMAIS", title: "Thor procura sua família", city: "Santo André", image: "/demo-animals-1.webp", detail: "Nome e ocorrência fictícios. Esta foto é ilustrativa e não representa um animal realmente perdido.", area: "animais" },
  { name: "Mercadão", tag: "DESAPEGOS", title: "Bicicleta para novos caminhos", city: "São Caetano do Sul", image: "/demo-market-1.webp", detail: "Anúncio ilustrativo · R$ 850. Não existe vendedor, produto à venda ou contato neste exemplo.", area: "mercadao" },
  { name: "Agenda ABC", tag: "COMUNIDADE", title: "Um encontro para aproximar o bairro", city: "Mauá", image: "/demo-feed-2.webp", detail: "Evento fictício, sem data, inscrição ou organização reais. Apenas uma amostra do destaque visual.", area: "agenda" },
];

export function useVisualExamples() {
  const router = useRouter();
  const [enabled, setEnabled] = useState(false);
  useEffect(() => {
    const timer = window.setTimeout(() => setEnabled(new URLSearchParams(window.location.search).get("demonstracao") !== "0"), 0);
    return () => window.clearTimeout(timer);
  }, []);
  return { enabled, close: () => { setEnabled(false); const url = new URL(window.location.href); url.searchParams.set("demonstracao", "0"); router.replace(url.pathname + url.search + url.hash, {scroll:false}); } };
}

export function VisualExamplesBanner({onClose}:{onClose:()=>void}) {
  return <div className="visual-examples-banner"><span><b>CONTEÚDO DEMONSTRATIVO</b> Stories e destaques fictícios</span><button type="button" onClick={onClose}>Ocultar exemplos <X size={13}/></button></div>;
}

export function ExampleStoryItems() {
  const [selected, setSelected] = useState<number | null>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    if (selected === null) dialog.current?.close();
    else if (!dialog.current?.open) dialog.current?.showModal();
  }, [selected]);
  const current = selected === null ? null : examples[selected];
  return <>
    {examples.map((item, index) => <button type="button" key={item.name} className="story-ring example-story-ring" aria-label={`Abrir story de exemplo: ${item.name}`} onClick={() => setSelected(index)}><span><Image src={item.image} width={60} height={60} alt=""/></span><small>{item.name}</small><em>EXEMPLO</em></button>)}
    <dialog ref={dialog} className="example-story-dialog" aria-label="Story fictício de demonstração" onCancel={() => setSelected(null)}>
      {current && <><div className="example-story-progress" aria-hidden="true">{examples.map((item, i) => <span key={item.name} className={i === selected ? "active" : ""}/>)}</div><header><div><strong>{current.name}</strong><small>{current.city} · Demonstração</small></div><button type="button" aria-label="Fechar exemplo de story" onClick={() => setSelected(null)}><X/></button></header><div className="example-story-picture"><Image src={current.image} width={600} height={900} alt={`Imagem ilustrativa: ${current.title}`}/><span className="example-watermark">CONTEÚDO FICTÍCIO</span><div><small>{current.tag}</small><h2>{current.title}</h2></div></div><p>{current.detail}</p><div className="example-story-controls"><button type="button" className="secondary-btn" aria-label="Story de exemplo anterior" onClick={() => setSelected(((selected ?? 0) + examples.length - 1) % examples.length)}><ChevronLeft size={19}/> Anterior</button><button type="button" className="secondary-btn" aria-label="Próximo story de exemplo" onClick={() => setSelected(((selected ?? 0) + 1) % examples.length)}>Próximo <ChevronRight size={19}/></button></div></>}
    </dialog>
  </>;
}

export function ExampleHighlights({ navigate }: { navigate: (area: string) => void }) {
  const [index, setIndex] = useState(1);
  const [paused, setPaused] = useState(false);
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);
  const [opened, setOpened] = useState(false);
  const touchStart = useRef<number | null>(null);
  const current = examples[index];
  const Illustration=current.area==='vagas'?Briefcase:current.area==='animais'?Dog:current.area==='mercadao'?ShoppingBag:current.area==='agenda'?CalendarDays:UsersRound;
  function move(step: number) { setIndex(value => (value + step + examples.length) % examples.length); setOpened(false); }
  useEffect(() => {
    if (paused || hovered || focused || opened || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const timer = window.setInterval(() => { if (!document.hidden) setIndex(value => (value + 1) % examples.length); }, 5000);
    return () => window.clearInterval(timer);
  }, [paused, hovered, focused, opened]);
  return <section className="example-highlights" aria-label="Destaques fictícios de demonstração" aria-roledescription="carrossel" onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)} onFocusCapture={() => setFocused(true)} onBlurCapture={event => { if (!event.currentTarget.contains(event.relatedTarget)) setFocused(false); }}>
    <div className="example-highlight-frame" onTouchStart={event => { touchStart.current = event.touches[0].clientX; }} onTouchEnd={event => { if (touchStart.current !== null) { const distance = event.changedTouches[0].clientX - touchStart.current; if (Math.abs(distance) > 40) move(distance < 0 ? 1 : -1); } touchStart.current = null; }}>
      <button type="button" className={`example-highlight-card ref-highlight-${current.area}`} aria-expanded={opened} onClick={() => { setOpened(!opened); setPaused(true); }}><span className="ref-highlight-illustration"><Illustration size={84} strokeWidth={1.5}/></span><span className="example-highlight-shade"/><span className="example-highlight-copy"><small>{current.tag} · EXEMPLO</small><strong>{current.title}</strong><span>{current.city}</span></span></button>
      <button type="button" className="example-highlight-next" aria-label="Próximo destaque de exemplo" onClick={() => move(1)}><ChevronRight size={21}/></button>
    </div>
    <div className="example-carousel-controls"><button type="button" aria-label="Destaque de exemplo anterior" onClick={() => move(-1)}><ChevronLeft size={17}/></button><div>{examples.map((item, i) => <button key={item.name} type="button" aria-label={`Ver destaque de exemplo: ${item.name}`} aria-pressed={index === i} onClick={() => { setIndex(i); setOpened(false); }}/>)}</div><button type="button" aria-label={paused ? "Retomar rotação dos exemplos" : "Pausar rotação dos exemplos"} onClick={() => setPaused(!paused)}>{paused ? <Play size={14}/> : <Pause size={14}/>}</button></div>
    {opened && <div className="example-highlight-detail"><strong>Este conteúdo é fictício</strong><p>{current.detail}</p><button type="button" className="secondary-btn" onClick={() => navigate(current.area)}>Abrir a área real <ArrowUpRight size={14}/></button></div>}
  </section>;
}
