"use client";
import {useEffect,useRef,useState,type FormEvent} from 'react';
import type {SupabaseClient} from '@supabase/supabase-js';
import {ExampleStoryItems} from "./VisualExamples";
import Image from 'next/image';
import {ContentReportButton} from './ContentReports';
import {ImageOff,Play,Plus,X} from 'lucide-react';
import {useCommunityResource} from '@/lib/use-community-resource';
import {uploadCommunityMedia} from '@/lib/community-media';
import {abcCities} from '@/lib/validation';
import {ResourceFeedback} from './CommunityProfile';
import {useCurrentTime} from '@/lib/use-current-time';
type Story={id:string;caption:string;city:string;media_path:string;media_kind:string;status:string;first_name?:string;is_own?:boolean;expires_at:string;views:number|null;seen?:boolean};
function useStoryMedia(client:SupabaseClient|null,stories:Story[],scope:string,now:number){
 const key=JSON.stringify(stories.filter(s=>s.media_path&&Date.parse(s.expires_at)>now).map(s=>({path:s.media_path,expires:Date.parse(s.expires_at)})));
 const [record,setRecord]=useState<{key:string;scope:string;expires:number;urls:Record<string,string>;retry:number}|null>(null),[failure,setFailure]=useState<{key:string;scope:string}|null>(null),[retry,setRetry]=useState(0);
 useEffect(()=>{
  const items=JSON.parse(key) as {path:string;expires:number}[];
  if(!client||!items.length)return;
  const refreshAhead=Math.min(15000,Math.max(0,(Math.min(...items.map(s=>s.expires))-now)/2));
  if(record?.key===key&&record.scope===scope&&record.retry===retry&&record.expires>now+refreshAhead)return;
  let alive=true;
  const seconds=Math.max(1,Math.min(300,Math.floor((Math.min(...items.map(s=>s.expires))-Date.now())/1000)));
  void client.storage.from('social-stories').createSignedUrls([...new Set(items.map(s=>s.path))],seconds).then(({data,error})=>{
   if(!alive)return;
   if(error||!data){setFailure({key,scope});return;}
   const urls=Object.fromEntries(data.filter(item=>item.path&&item.signedUrl).map(item=>[item.path,item.signedUrl]));
   setRecord({key,scope,expires:Date.now()+seconds*1000,urls,retry});setFailure(Object.keys(urls).length<new Set(items.map(s=>s.path)).size?{key,scope}:null);
  },()=>{if(alive)setFailure({key,scope});});
  return()=>{alive=false;};
 },[client,key,scope,now,retry,record]);
 const valid=record?.scope===scope&&record.key===key&&record.expires>now;
 return {urls:valid?record.urls:{},error:failure?.key===key&&failure.scope===scope,retry:()=>setRetry(value=>value+1)};
}
function StoryMedia({story,url,error,retry}:{story:Story;url?:string;error:boolean;retry:()=>void}){return url?story.media_kind==='video'?<video src={url} controls playsInline preload="metadata"/>:<Image src={url} width={720} height={960} alt={story.caption||'Story da comunidade'} unoptimized/>:error?<div className="story-media-error" role="alert"><p>Não foi possível carregar a mídia.</p><button type="button" className="secondary-btn" onClick={retry}>Tentar novamente</button></div>:<p role="status">Carregando mídia…</p>;}
function StoryThumbnail({story,url}:{story:Story;url?:string}){
 const [failedUrl,setFailedUrl]=useState<string|null>(null);const failed=Boolean(url&&failedUrl===url);
 return <span className="story-thumbnail">{url&&!failed?(story.media_kind==='video'?<><video src={url} muted playsInline preload="metadata" tabIndex={-1} aria-hidden="true" onLoadedMetadata={event=>{const video=event.currentTarget;if(Number.isFinite(video.duration)&&video.duration>0)video.currentTime=Math.min(.1,video.duration/2);}} onError={()=>setFailedUrl(url)}/><i><Play size={10} fill="currentColor"/></i></>:<Image src={url} alt="" width={56} height={56} unoptimized onError={()=>setFailedUrl(url)}/>):failed?<ImageOff size={21}/>:<span className="story-thumbnail-loading">{story.first_name?.slice(0,2)||'ABC'}</span>}</span>;
}
export function Stories({moderation=false,startComposing=false,demonstration=false}:{moderation?:boolean;startComposing?:boolean;demonstration?:boolean}){
 const state=useCommunityResource<Story[]>(moderation?'social_story_queue':'social_list_stories',moderation?{}:{story_city:null});const [composer,setComposer]=useState(startComposing),[file,setFile]=useState<File|null>(null),[uploading,setUploading]=useState(false),[selected,setSelected]=useState<string|null>(null),[reasons,setReasons]=useState<Record<string,string>>({});const dialog=useRef<HTMLDialogElement>(null);const now=useCurrentTime();const current=(state.data||[]).find(s=>s.id===selected);const available=(state.data||[]).filter(s=>new Date(s.expires_at).getTime()>now&&s.status!=='hidden');
 const media=useStoryMedia(state.client,available,state.userId||'public',now);
 useEffect(()=>{if(selected){dialog.current?.showModal();}else{dialog.current?.close();}},[selected]);
 async function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();if(!state.client||!state.userId){state.openAuth();return;}if(!file){state.setError('Escolha uma foto ou um vídeo.');return;}const form=e.currentTarget,v=new FormData(form);if(String(v.get('caption')||'').length>280){state.setError('Use até 280 caracteres.');return;}setUploading(true);let path:string|null=null;try{path=(await uploadCommunityMedia(state.client,state.userId,file,'social-stories',true)).path;const okay=await state.act('social_create_story',{story_caption:v.get('caption'),story_city:v.get('city'),attachment_path:path,attachment_kind:file.type.startsWith('video/')?'video':'image'},'Story enviado para análise. Ele expira em 24 horas a partir do envio.');if(okay){form.reset();setFile(null);setComposer(false);}else if(!state.actionWasUncertain())await state.client.storage.from('social-stories').remove([path]);}catch(err){state.setError(path?'A conexão caiu. Atualize seus stories antes de tentar novamente.':(err as Error).message);}finally{setUploading(false);}}
 function open(story:Story){setSelected(story.id);if(state.userId&&story.status==='approved')void state.act('social_see_story',{target_story:story.id},'');}
 return <section className={moderation?'social-workspace':'stories-section'} aria-label={moderation?'Moderação de stories':'Stories da comunidade'}>{moderation&&<h1>Moderação de stories</h1>}<ResourceFeedback state={state}/>{!moderation&&<div className="stories-strip"><button className="story-ring story-create" onClick={()=>state.userId?setComposer(!composer):state.openAuth()}><span><Plus/></span><small>Seu story</small></button>{available.map(story=><button aria-label={`Abrir story de ${story.first_name||"Comunidade"}`} className={`story-ring story-real ${story.seen?'seen':''}`} key={story.id} onClick={()=>open(story)}><span><StoryThumbnail story={story} url={media.urls[story.media_path]}/></span><small>{story.is_own?'Seu story':story.first_name||'Comunidade'}</small>{story.status!=='approved'&&<small>Em análise</small>}</button>)}{demonstration&&<ExampleStoryItems/>}</div>}
 {composer&&!moderation&&<form className="hub-card" onSubmit={submit} noValidate><h2>Novo story</h2><p>Foto ou vídeo público após análise. Disponível por 24 horas desde o envio.</p><label htmlFor="story-file">Mídia (até 20 MB)</label><input id="story-file" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" onChange={e=>setFile(e.target.files?.[0]||null)}/><label htmlFor="story-caption">Legenda (opcional)</label><textarea id="story-caption" name="caption" maxLength={280}/><label htmlFor="story-city">Cidade</label><select id="story-city" name="city">{abcCities.map(c=><option key={c}>{c}</option>)}</select><div className="button-row"><button className="primary-btn" disabled={uploading||state.busy}>{uploading?'Enviando…':'Enviar para análise'}</button><button type="button" className="secondary-btn" disabled={uploading} onClick={()=>setComposer(false)}>Cancelar</button></div></form>}
 {moderation&&available.map(story=><article className="hub-card" key={story.id}><span className="badge">{story.city}</span><StoryMedia story={story} url={media.urls[story.media_path]} error={Boolean(media.error)} retry={media.retry}/><p>{story.caption}</p><small>Expira em {new Date(story.expires_at).toLocaleString('pt-BR')}</small><label htmlFor={`story-reason-${story.id}`}>Motivo da decisão</label><input id={`story-reason-${story.id}`} value={reasons[story.id]||''} onChange={e=>setReasons({...reasons,[story.id]:e.target.value})} maxLength={500}/><div className="button-row">{[['approved','Aprovar'],['rejected','Rejeitar']].map(([decision,label])=><button className="secondary-btn" key={decision} disabled={state.busy||(reasons[story.id]?.trim().length||0)<3} onClick={()=>void state.act('social_review_story',{target_story:story.id,decision,reason:reasons[story.id]},'Decisão registrada.')}>{label}</button>)}</div></article>)}{moderation&&!state.loading&&!state.error&&!available.length&&<p>Nenhum story aguardando análise.</p>}
 <dialog ref={dialog} className="story-viewer" aria-label="Story da comunidade" onCancel={()=>setSelected(null)}><button className="story-close" aria-label="Fechar story" onClick={()=>setSelected(null)}><X/></button>{current&&new Date(current.expires_at).getTime()>now?<><header><strong>{current.first_name||'Story'}</strong><small>{current.city} · {current.status==='approved'?'Publicado':'Em análise'}</small></header><StoryMedia key={current.id} story={current} url={media.urls[current.media_path]} error={Boolean(media.error)} retry={media.retry}/><p>{current.caption}</p>{current.status==="approved"&&<ContentReportButton kind="story" targetId={current.id}/>}{current.is_own&&<><small>{current.views||0} visualizações registradas</small><button className="secondary-btn" disabled={state.busy} onClick={async()=>{if(await state.act('social_hide_story',{target_story:current.id},'Story retirado.'))setSelected(null);}}>Retirar meu story</button></>}</>:<p>Este story expirou ou está indisponível.</p>}</dialog></section>;
}
