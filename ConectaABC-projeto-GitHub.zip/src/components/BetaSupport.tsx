"use client";

import { useRef, useState } from "react";
import { Bug, X } from "lucide-react";

const supportEmail = "santoandredepressao@gmail.com";

export function BetaSupport() {
  const dialog = useRef<HTMLDialogElement>(null);
  const [details, setDetails] = useState("");
  const [notice, setNotice] = useState("");

  function report() {
    // Deliberately omit query strings, hashes, account data and OAuth codes.
    return `Conecta ABC · versão de testes\nTela: ${window.location.pathname}\nData: ${new Date().toISOString()}\n\nO que aconteceu e como repetir:\n${details.trim()}`;
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(report());
      setNotice("Relato copiado. Envie para o e-mail da equipe abaixo.");
    } catch {
      setNotice("Não foi possível copiar. Você pode abrir seu aplicativo de e-mail pelo botão abaixo.");
    }
  }

  return <>
    <footer className="beta-support-bar">
      <span>Conecta ABC · versão de testes</span>
      <button onClick={() => { setNotice(""); dialog.current?.showModal(); }}><Bug size={15}/> Ajuda e relatar problema</button>
    </footer>
    <dialog ref={dialog} className="beta-support-dialog" aria-labelledby="beta-support-title">
      <div className="section-head"><h2 id="beta-support-title">Ajude a melhorar o Conecta ABC</h2><button className="secondary-btn" aria-label="Fechar ajuda" onClick={() => dialog.current?.close()}><X size={19}/></button></div>
      <p>Estamos em fase de testes. Conte à equipe se alguma tela ou envio não funcionar como esperado.</p>
      <p>Publicações e pedidos podem aguardar análise. Acompanhe o andamento em <strong>Meus envios</strong>. Exemplos estão identificados e não geram pontos. Clube e campanhas de prêmio ainda não estão disponíveis.</p>
      <label htmlFor="beta-report">O que aconteceu?</label>
      <textarea id="beta-report" rows={4} maxLength={2000} value={details} onChange={event => setDetails(event.target.value)} placeholder="Descreva a tela, a ação e a mensagem que apareceu."/>
      <small>Não informe senhas, CPF, códigos de acesso ou dados de outras pessoas.</small>
      <div className="button-row"><button className="primary-btn" onClick={() => { window.location.href = `mailto:${supportEmail}?subject=${encodeURIComponent("Conecta ABC — relato de teste")}&body=${encodeURIComponent(report())}`; setNotice("Seu aplicativo de e-mail será aberto. Revise e envie o relato para a equipe."); }}>Preparar e-mail</button><button className="secondary-btn" onClick={() => void copy()}>Copiar relato</button></div>
      <small>Contato da equipe: <a href={`mailto:${supportEmail}`}>{supportEmail}</a>. O relato só será enviado quando você enviar o e-mail.</small>
      {notice && <p role="status">{notice}</p>}
    </dialog>
  </>;
}
