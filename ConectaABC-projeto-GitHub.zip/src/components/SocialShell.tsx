"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { Bell, Bookmark, UsersRound, ArrowLeft, CalendarDays, Compass, House, IdCard, Menu, MessageSquare, Newspaper, PawPrint, Plus, Search, ShieldCheck, Store, Trophy, UserRound, Video, X, type LucideIcon } from "lucide-react";

export const socialNavigation: { id: string; label: string; icon: LucideIcon }[] = [
  { id: "inicio", label: "Página inicial", icon: House },
  { id: "busca", label: "Pesquisa", icon: Search },
  { id: "explorar", label: "Explorar", icon: Compass },
  { id: "agora", label: "Em alta", icon: Video },
  { id: "amigos", label: "Amigos", icon: UsersRound },
  { id: "salvos", label: "Salvos", icon: Bookmark },
  { id: "parceiros", label: "Parceiros", icon: Store },
  { id: "mercadao", label: "Mercadão", icon: Store },
  { id: "agenda", label: "Agenda", icon: CalendarDays },
  { id: "noticias", label: "Notícias", icon: Newspaper },
  { id: "animais", label: "Animais", icon: PawPrint },
  { id: "pontua", label: "Meu progresso", icon: Trophy },
  { id: "perfil", label: "Perfil e carteirinha", icon: IdCard },
];

export function SocialShell({ active, navigate, back, create, signedIn, login, canManage, children }: { active: string; navigate: (section: string) => void; back: () => void; create: () => void; signedIn: boolean; login: () => void; canManage: boolean; children: ReactNode }) {
  const bottom = [{ id: "inicio", label: "Início", icon: House }, { id: "explorar", label: "Explorar", icon: Compass }, { id: "criar", label: "Criar", icon: Plus }, { id: "agora", label: "Em alta", icon: Video }, { id: "perfil", label: "Perfil", icon: UserRound }];
  return <div className="social-app">
    <aside className="social-sidebar" aria-label="Menu principal">
      <button className="social-wordmark" onClick={() => navigate("inicio")} aria-label="Conecta ABC — início"><span className="social-mark" aria-hidden="true">∞</span><span>CONECTA <b>ABC</b></span></button>
      <nav>{socialNavigation.map(({ id, label, icon: Icon }) => <button title={label} key={id} aria-current={active === id ? "page" : undefined} className={active === id ? "selected" : ""} onClick={() => navigate(id)}><Icon size={23}/><span>{label}</span></button>)}<button onClick={create} title="Criar publicação"><Plus size={23}/><span>Criar</span></button>{canManage && <button onClick={() => navigate("admin")} title="Painel da equipe"><ShieldCheck size={23}/><span>Equipe</span></button>}<button onClick={() => navigate("mais")} title="Todos os recursos"><Menu size={23}/><span>Mais</span></button></nav>
      <div className="social-side-footer"><span>Uma plataforma da SAD</span><a href="/privacidade">Privacidade</a><a href="/termos">Termos</a></div>
    </aside>
    <main className="social-main">
      <header className="social-topbar"><button aria-label={active === "inicio" ? "Criar publicação" : "Voltar para a tela anterior"} onClick={active === "inicio" ? create : back}>{active === "inicio" ? <Plus/> : <ArrowLeft/>}</button><button className="social-wordmark" onClick={() => navigate("inicio")}>CONECTA <b>ABC</b></button><div><button aria-label="Notificações" onClick={() => signedIn ? navigate("notificacoes") : login()}><Bell size={22}/></button><button aria-label="Todos os recursos" onClick={() => navigate("mais")}><Menu size={23}/></button></div></header>
      <div className={`social-content social-content-${active}`}>{children}</div>
    </main>
    <nav className="social-bottom" aria-label="Navegação do celular">{bottom.map(({ id, label, icon: Icon }) => <button key={id} aria-current={active === id ? "page" : undefined} className={active === id ? "selected" : ""} onClick={() => id === "criar" ? create() : navigate(id)}><Icon size={24}/><span>{label}</span></button>)}</nav>
  </div>;
}

export function CreateSheet({ close, select }: { close: () => void; select: (section: string) => void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => { const element = dialog.current; element?.showModal(); return () => element?.close(); }, []);
  return <dialog ref={dialog} className="social-create-sheet" onCancel={close} onClick={(event) => { if (event.target === event.currentTarget) close(); }} aria-labelledby="create-title"><div className="social-sheet-heading"><h2 id="create-title">O que vamos compartilhar?</h2><button onClick={close} aria-label="Fechar"><X/></button></div><p>Escolha uma área. Seus envios podem ser acompanhados no seu perfil.</p>{[{id:"stories",label:"Story",detail:"Foto ou vídeo por 24 horas",icon:Plus},{id:"imoveis",label:"Imóvel",detail:"Aluguel ou venda no Grande ABC",icon:House},{id:"vagas",label:"Vaga de emprego",detail:"Divulgue uma oportunidade",icon:Store},{id:"achados",label:"Objeto perdido ou encontrado",detail:"Ajude a devolver algo a alguém",icon:Search},{ id: "agenda", label: "Evento", detail: "Divulgue data e local de um encontro", icon: CalendarDays }, { id: "enquetes", label: "Enquete", detail: "Ouça a opinião dos moradores", icon: MessageSquare }, { id: "comunidades", label: "Comunidade", detail: "Conecte pessoas com interesses em comum", icon: UsersRound }, { id: "feed", label: "Publicação", detail: "Texto, foto ou vídeo para a comunidade", icon: MessageSquare }, { id: "mercadao", label: "Anúncio ou vaga", detail: "Produtos e oportunidades no ABC", icon: Store }, { id: "animais", label: "Animal perdido ou encontrado", detail: "Ajude a reencontrar uma família", icon: PawPrint }, { id: "cidade", label: "Problema da cidade", detail: "Envie um relato para análise", icon: ShieldCheck }].map(({ id, label, detail, icon: Icon }) => <button className="social-create-option" key={id} onClick={() => { select(id); close(); }}><Icon/><span><strong>{label}</strong><small>{detail}</small></span><Plus size={18}/></button>)}</dialog>;
}
