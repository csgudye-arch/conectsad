"use client";

import {useEffect, type ReactNode} from "react";
import Image from "next/image";
import {ArrowUpRight,Briefcase,CalendarDays,Flag,Flame,Heart,Megaphone,MessageCircle,Play,Trophy,UsersRound,Vote} from "lucide-react";
import {useCommunityResource} from "@/lib/use-community-resource";
import {useCurrentTime} from "@/lib/use-current-time";
import {ResourceFeedback} from "./CommunityProfile";
import {ReferenceMiniMap,ReferencePeople,ReferenceListing} from "./ReferenceHomeParts";

export const homeFeedSlots=["videos","mapa","animais","pessoas","mercadao","ranking","agenda","top","vagas","bairros","comunidades","enquetes","voz","servicos"] as const;
export const homeFeedGroups=[["videos"],["mapa","animais","pessoas"],["mercadao"],["ranking"],["agenda"],["top"],["vagas"],["bairros"],["comunidades","enquetes"],["voz"],["servicos"]] as const;
export type HomeFeedSlot=typeof homeFeedSlots[number];
type Props={slot:HomeFeedSlot;navigate:(area:string)=>void;demonstration:boolean;city:string;videos:{id:string;title?:string;body:string;mediaUrl?:string}[]};

function Block({title,action,onOpen,children}:{title:string;action:string;onOpen:()=>void;children:ReactNode}){
 const symbols:Record<string,typeof Trophy>={'Ranking dos membros':Trophy,'Top da semana':Flame,'Placar dos bairros':Flag,'Em alta no ABC':Play,'Agenda da comunidade':CalendarDays,'Vagas no ABC':Briefcase,'Comunidades para você':UsersRound,'A comunidade quer saber':Vote,'Voz do bairro':Megaphone,'Serviços e apoio social':Heart};const Symbol=symbols[title];
 return <section className="home-feed-block"><div className="home-feed-block-heading"><h2>{Symbol&&<Symbol size={18}/>} {title}</h2><button type="button" onClick={onOpen}>{action}<ArrowUpRight size={14}/></button></div>{children}</section>;
}
function Empty({children}:{children:ReactNode}){return <p className="home-feed-empty">{children}</p>;}
function DemoTag(){return <span className="home-demo-tag">EXEMPLO FICTÍCIO</span>;}

export function HomeFeedSection({slot,navigate,demonstration,videos,city}:Props){
 if(slot==="videos")return <Block title="Em alta no ABC" action="Ver vídeos" onOpen={()=>navigate("agora")}><div className="home-media-strip" aria-label="Destaques em alta">{videos.length?videos.slice(0,6).map(item=><button type="button" className="home-clip" key={item.id} onClick={()=>navigate("agora")}><video src={item.mediaUrl} muted playsInline preload="metadata"/><span><Play size={20}/><strong>{item.title||item.body.slice(0,65)}</strong></span></button>):demonstration?[['/demo-feed-2.webp','Comunidade'],['/demo-animals-1.webp','Pets do ABC'],['/demo-market-1.webp','Mercadão'],['/demo-services-4.webp','Vagas ABC']].map(([image,label])=><button type="button" className="home-clip" key={label} onClick={()=>navigate(label==="Pets do ABC"?"animais":label==="Mercadão"?"mercadao":label==="Vagas ABC"?"vagas":"feed")}><Image src={image} width={200} height={300} alt="Imagem ilustrativa"/><span><DemoTag/><strong>{label}</strong></span></button>):<Empty>Os vídeos oficiais aprovados aparecerão aqui.</Empty>}</div></Block>;
 if(slot==="mapa")return <ReferenceMiniMap navigate={navigate} demonstration={demonstration} city={city}/>;
 if(slot==="ranking")return <HomeRanking navigate={navigate}/>;
 if(slot==="bairros")return <HomeNeighborhoods navigate={navigate}/>;
 if(slot==="vagas")return <HomeJobs navigate={navigate} demonstration={demonstration}/>;
 if(slot==="animais"||slot==="mercadao")return <ReferenceListing key={slot} kind={slot} navigate={navigate} demonstration={demonstration}/>;
 if(slot==="agenda")return <HomeEvents navigate={navigate} demonstration={demonstration}/>;
 if(slot==="top")return <HomeTop navigate={navigate}/>;
 if(slot==="comunidades")return <HomeGroups navigate={navigate} demonstration={demonstration}/>;
 if(slot==="pessoas")return <ReferencePeople navigate={navigate} demonstration={demonstration}/>;
 if(slot==="enquetes")return <HomePoll navigate={navigate}/>;
 if(slot==="voz")return <Block title="Voz do bairro" action="Ver comunidade" onOpen={()=>navigate("feed")}><div className="home-community-prompt"><MessageCircle/><div><strong>Uma história, um elogio ou uma ideia?</strong><p>Seu bairro também tem voz no Conecta ABC.</p><button type="button" className="secondary-btn" onClick={()=>navigate("feed")}>Compartilhar com a comunidade</button></div></div></Block>;
 return <Block title="Serviços e apoio social" action="Conhecer" onOpen={()=>navigate("servicos")}><div className="home-community-prompt"><Heart/><div><strong>Conte do que você precisa</strong><p>Solicite apoio ao projeto social e acompanhe o atendimento em Meus envios.</p><div className="button-row"><button type="button" className="secondary-btn" onClick={()=>navigate("servicos")}>Pedir apoio</button><button type="button" className="secondary-btn" onClick={()=>navigate("envios")}>Meus envios</button></div></div></div></Block>;
}

function HomeRanking({navigate}:{navigate:Props["navigate"]}){
 const levels=useCommunityResource<{name:string;minimum_points:number}[]>("social_get_levels");
 const state=useCommunityResource<{rank_position:number;first_name:string;city:string;points:number}[]>("get_public_leaderboard");
 return <Block title="Ranking dos membros" action="Ver ranking" onOpen={()=>navigate("pontua")}><p className="home-feed-subtitle">Ranking geral · pontos confirmados</p><ResourceFeedback state={state}/>{state.data?.slice(0,5).map((row,i)=><div className={`home-rank-row ref-rank-row rank-${i+1}`} key={row.rank_position}><span className="home-rank-number">{row.rank_position}</span><span className="home-rank-avatar">{row.first_name.slice(0,1)}</span><div><strong>{row.first_name}</strong><small>{(levels.data||[]).filter(level=>level.minimum_points<=Number(row.points)).at(-1)?.name||"Membro"} · {row.city||"Grande ABC"}</small></div><b>{Number(row.points).toLocaleString("pt-BR")}<small>XP</small></b></div>)}{!state.loading&&!state.error&&!state.data?.length&&<Empty>Os membros aparecerão aqui com seus pontos confirmados.</Empty>}</Block>;
}
function HomeNeighborhoods({navigate}:{navigate:Props["navigate"]}){
 const now=useCurrentTime();const month=new Intl.DateTimeFormat("en-CA",{year:"numeric",month:"2-digit",timeZone:"America/Sao_Paulo"}).format(new Date(now));
 const state=useCommunityResource<{neighborhood:string|null;city:string;points:number}[]>("social_season_ranking",{season_month:month+"-01"});
 const totals=new Map<string,{name:string;city:string;points:number}>();for(const row of state.data||[]){if(!row.neighborhood)continue;const key=row.city+":"+row.neighborhood;const prior=totals.get(key);totals.set(key,{name:row.neighborhood,city:row.city,points:(prior?.points||0)+Number(row.points)});}const rows=[...totals.values()].sort((a,b)=>b.points-a.points).slice(0,5);const max=rows[0]?.points||1;
 return <Block title="Placar dos bairros" action="Ver temporada" onOpen={()=>navigate("pontua")}><p className="home-feed-subtitle">Pontos do mês entre os bairros públicos do ranking</p><ResourceFeedback state={state}/>{rows.map((row,i)=><div className="home-neighborhood-row" key={row.city+row.name}><span>{i+1}</span><div><strong>{row.name}</strong><small>{row.city}</small><div className="home-neighborhood-track"><span style={{width:`${Math.max(2,row.points/max*100)}%`}}/></div></div><b>{row.points.toLocaleString("pt-BR")}</b></div>)}{!state.loading&&!state.error&&!rows.length&&<Empty>Quando membros com bairro público somarem pontos nesta temporada, o placar aparecerá aqui.</Empty>}</Block>;
}
function HomeJobs({navigate,demonstration}:{navigate:Props["navigate"];demonstration:boolean}){
 const state=useCommunityResource<{id:string;title:string;city:string;status:string;details:{company?:string;contract?:string;model?:string}}[]>("social_list_classifieds",{listing_kind:"vagas",page_number:0,mine_only:false});const rows=(state.data||[]).filter(r=>r.status==="approved").slice(0,3);
 return <Block title="Vagas no ABC" action="Mais vagas" onOpen={()=>navigate("vagas")}><ResourceFeedback state={state}/>{rows.map(row=><a className="home-job-row" key={row.id} href={`/?area=vagas&anuncio=${row.id}`}><span className="home-job-icon"><Briefcase size={21}/></span><div><strong>{row.title}</strong><small>{row.details.company} · {row.city}</small><span>{[row.details.contract,row.details.model].filter(Boolean).join(" · ")}</span></div><ArrowUpRight size={17}/></a>)}{!state.loading&&!state.error&&!rows.length&&(demonstration?<div className="home-example-job"><DemoTag/><div className="home-job-row"><span className="home-job-icon"><Briefcase size={21}/></span><div><strong>Auxiliar administrativo</strong><small>Empresa Exemplo · São Bernardo do Campo</small><span>CLT · Presencial</span></div></div><p>Vaga fictícia. Não há processo seletivo ou candidatura.</p><button type="button" className="secondary-btn" onClick={()=>navigate("vagas")}>Ver vagas reais</button></div>:<Empty>As vagas aprovadas aparecerão aqui. Divulgue uma oportunidade na área de empregos.</Empty>)}</Block>;
}
function HomeEvents({navigate,demonstration}:{navigate:Props["navigate"];demonstration:boolean}){
 const now=useCurrentTime();const state=useCommunityResource<{id:string;title:string;city:string;starts_at:string;ends_at:string;venue:string;status:string}[]>("social_list_events",{target_event:null});const rows=(state.data||[]).filter(r=>r.status==="approved"&&Date.parse(r.ends_at)>now).sort((a,b)=>a.starts_at.localeCompare(b.starts_at)).slice(0,2);
 return <Block title="Agenda da comunidade" action="Ver agenda" onOpen={()=>navigate("agenda")}><ResourceFeedback state={state}/>{rows.map(row=><a className="home-event-row" key={row.id} href={`/?area=agenda&evento=${row.id}`}><span><CalendarDays size={20}/><b>{new Intl.DateTimeFormat("pt-BR",{day:"2-digit",month:"short",timeZone:"America/Sao_Paulo"}).format(new Date(row.starts_at))}</b></span><div><strong>{row.title}</strong><small>{row.venue} · {row.city}</small><p>{new Date(row.starts_at).toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit",timeZone:"America/Sao_Paulo"})}</p></div><ArrowUpRight size={17}/></a>)}{!state.loading&&!state.error&&!rows.length&&(demonstration?<div className="home-example-event"><DemoTag/><h3>Encontro da comunidade</h3><p>Evento fictício, sem data ou inscrições reais.</p><button className="secondary-btn" onClick={()=>navigate("agenda")}>Explorar eventos reais</button></div>:<Empty>Os próximos eventos aprovados aparecerão aqui.</Empty>)}</Block>;
}
function HomeTop({navigate}:{navigate:Props["navigate"]}){
 const state=useCommunityResource<{id:string;title:string;city:string;score:number}[]>("social_top_week");return <Block title="Top da semana" action="Ver top 5" onOpen={()=>navigate("top")}><ResourceFeedback state={state}/>{state.data?.slice(0,3).map((row,i)=><a className="home-top-row" key={row.id} href={`/?post=${row.id}`}><b>{i+1}</b><div><strong>{row.title}</strong><small>{row.city} · {row.score} interações</small></div><ArrowUpRight size={16}/></a>)}{!state.loading&&!state.error&&!state.data?.length&&<Empty>As publicações com mais interações aparecerão aqui.</Empty>}</Block>;
}
function HomeGroups({navigate,demonstration}:{navigate:Props["navigate"];demonstration:boolean}){
 const state=useCommunityResource<{groups:{id:string;name:string;city:string;members:number;status:string}[]}>("social_list_groups");const rows=(state.data?.groups||[]).filter(r=>r.status==="approved").slice(0,3);return <Block title="Comunidades para você" action="Ver todas" onOpen={()=>navigate("comunidades")}><ResourceFeedback state={state}/>{rows.map(row=><a className="home-top-row" key={row.id} href={`/?area=comunidades&grupo=${row.id}`}><UsersRound size={21}/><div><strong>{row.name}</strong><small>{row.city} · {row.members} membros</small></div><ArrowUpRight size={16}/></a>)}{!state.loading&&!state.error&&!rows.length&&(demonstration?<div className="home-community-prompt"><UsersRound/><div><DemoTag/><strong>Pedal ABC</strong><p>Comunidade ilustrativa, sem membros ou adesões reais.</p><button className="secondary-btn" onClick={()=>navigate("comunidades")}>Conhecer comunidades reais</button></div></div>:<Empty>Os grupos aprovados aparecerão aqui.</Empty>)}</Block>;
}
type HomePollItem = {
  id: string;
  question: string;
  city: string;
  closes_at: string;
  options: { id: string; label: string }[];
};

function HomePoll({ navigate }: { navigate: Props["navigate"] }) {
  const state = useCommunityResource<HomePollItem>("social_next_home_poll");
  const now = useCurrentTime();
  const poll = state.data;
  const expired = Boolean(poll && Date.parse(poll.closes_at) <= now);
  const refresh = state.refresh;

  useEffect(() => {
    if (expired) void refresh();
  }, [expired, refresh]);

  return <Block title="A comunidade quer saber" action="Ver enquetes" onOpen={() => navigate("enquetes")}>
    <ResourceFeedback state={state} />
    {state.error && <button className="secondary-btn" disabled={state.loading || state.busy} onClick={() => void refresh()}>Atualizar enquetes</button>}
    {poll && !expired && <div className="home-example-event">
      <span className="badge">{poll.city}</span>
      <h3>{poll.question}</h3>
      <div className="hub-options" role="group" aria-label={poll.question}>
        {poll.options.map((option) => <button
          key={option.id}
          type="button"
          disabled={state.busy || state.loading || Boolean(state.error)}
          onClick={() => void state.act("social_vote_poll", { target_poll: poll.id, target_option: option.id }, "Voto registrado.")}
        >{option.label}</button>)}
      </div>
      <p>{state.userId ? "Escolha uma opção para votar e seguir para a próxima." : "Entre na sua conta para votar."}</p>
    </div>}
    {!poll && !state.loading && !state.error && <Empty>{state.userId ? "Você está em dia com as enquetes abertas." : "Não há enquetes abertas no momento."}</Empty>}
  </Block>;
}
