"use client";
import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import { ArrowLeft, Check, Flag, UsersRound, Vote } from "lucide-react";
import { useSocial, socialError } from "./SocialFeatures";
import { useCurrentTime } from "@/lib/use-current-time";
import { abcCities } from "@/lib/validation";

type Option={id:string;label:string;votes:number};
type Poll={id:string;question:string;city:string;status:string;closes_at:string;is_own:boolean;my_vote:string|null;options:Option[]};
type Group={id:string;name:string;description:string;category:string;city:string;status:string;is_own:boolean;joined:boolean;members:number};
type Post={id:string;body:string;first_name:string;is_own:boolean;status:string;created_at:string};
type Queue={id:string;kind:string;body:string;city:string;status:string};
const categories=['Bairro','Esporte','Pets','Família','Cultura','Negócios','Games','Fé','Outros'];
const statusName=(status:string)=>({pending:'Em análise',approved:'Publicado',hidden:'Em revisão',rejected:'Não aprovado'}[status] || status);
const MIN_POLL_OPTIONS = 2;
const INITIAL_POLL_OPTIONS = 3;
const MAX_POLL_OPTIONS = 6;

export function CommunityHub({area}:{area:'enquetes'|'comunidades'|'comunidade-equipe'}) {
 const {client,userId,openAuth}=useSocial();
 const now=useCurrentTime();
 const loadVersion=useRef(0);
 const [polls,setPolls]=useState<Poll[]>([]),[groups,setGroups]=useState<Group[]>([]),[queue,setQueue]=useState<Queue[]>([]);
 const [selected,setSelected]=useState<string|null>(null),[posts,setPosts]=useState<Post[]>([]),[minimum,setMinimum]=useState<number|null>(null);
 const [target,setTarget]=useState<string|null>(null);useEffect(()=>{const timer=window.setTimeout(()=>{const id=new URLSearchParams(location.search).get('grupo');if(id&&/^[0-9a-f-]{36}$/i.test(id)){setTarget(id);setSelected(id);}},0);return()=>window.clearTimeout(timer);},[]);
 const [loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const [tab,setTab]=useState('ativas'),[city,setCity]=useState('Todas as cidades');
 const [report,setReport]=useState<{kind:string;id:string}|null>(null),[reportReason,setReportReason]=useState('');
 const [reasons,setReasons]=useState<Record<string,string>>({});
 const [pollOptionCount, setPollOptionCount] = useState(INITIAL_POLL_OPTIONS);
 const [pollOptionsError, setPollOptionsError] = useState('');
 const refresh=useCallback(async()=>{
  if(!client){setError('Conexão indisponível.');setLoading(false);return;}
  const version=++loadVersion.current; const current=()=>version===loadVersion.current;
  setLoading(true);setError('');
  try {
   if(area==='enquetes'){const r=await client.rpc('social_list_polls');if(!current())return;if(r.error)throw r.error;setPolls(r.data??[]);}
   if(area==='comunidades'){const r=target?await client.rpc('social_get_group',{target_group:target}):await client.rpc('social_list_groups');if(!current())return;if(r.error)throw r.error;setGroups(r.data?.groups??[]);setMinimum(r.data?.minimum_points??null);if(selected){const feed=await client.rpc('social_group_feed',{target_group:selected});if(!current())return;if(feed.error)throw feed.error;setPosts(feed.data??[]);}}
   if(area==='comunidade-equipe'){const r=await client.rpc('social_hub_queue');if(!current())return;if(r.error)throw r.error;setQueue(r.data??[]);}
  }catch(err){if(current())setError(socialError(err));}finally{if(current())setLoading(false);}
 },[client,area,selected,target]);
 const invalidate=useCallback(()=>{loadVersion.current++;},[]);
 useEffect(()=>{const timer=window.setTimeout(()=>void refresh(),0);return()=>{window.clearTimeout(timer);invalidate();};},[refresh,invalidate]);
 async function action(rpc:string,args:Record<string,unknown>,message:string):Promise<boolean>{
  if(!userId||!client){openAuth();return false;}setBusy(true);setError('');setNotice('');
  try{const r=await client.rpc(rpc,args);if(r.error)throw r.error;setNotice(message);await refresh();return true;}
  catch(err){setError(socialError(err));return false;}finally{setBusy(false);}
 }
 async function create(event:FormEvent<HTMLFormElement>){
  event.preventDefault();const form=event.currentTarget;const values=new FormData(form);let okay=false;
  if(area==='enquetes'){
   const optionLabels = values.getAll('options').map((value) => String(value).trim()).filter(Boolean);
   if (optionLabels.length < MIN_POLL_OPTIONS) {
    setPollOptionsError('Preencha pelo menos duas opções de resposta.');
    return;
   }
   if (new Set(optionLabels.map((label) => label.toLowerCase())).size !== optionLabels.length) {
    setPollOptionsError('Digite respostas diferentes em cada opção.');
    return;
   }
   setPollOptionsError('');
   const closing=String(values.get('closing')||'');const date=new Date(closing);
   if(!Number.isFinite(date.getTime())){setError('Selecione a data e a hora de encerramento.');return;}
   okay=await action('social_create_poll',{question_text:String(values.get('question')||''),poll_city:values.get('city'),option_labels:optionLabels,closing_at:date.toISOString()},'Enquete enviada para análise da equipe.');
  }else{okay=await action('social_create_group',{group_name:values.get('name'),group_description:values.get('description'),group_category:values.get('category'),group_city:values.get('city')},'Comunidade enviada para análise da equipe.');}
  if (okay) {
   form.reset();
   if (area === 'enquetes') setPollOptionCount(INITIAL_POLL_OPTIONS);
  }
 }
 const selectedGroup=groups.find(group=>group.id===selected);
 const askReport=(kind:string,id:string)=>{if(!userId){openAuth();return;}setReport({kind,id});setReportReason('');};
 const renderReport=(kind:string,id:string)=>report?.kind===kind&&report.id===id?<form className="hub-report" onSubmit={async event=>{event.preventDefault();if(await action('social_report_hub',{target_kind:kind,target_id:id,report_reason:reportReason},'Denúncia enviada em sigilo à equipe.'))setReport(null);}}><label htmlFor={`report-${id}`}>Motivo da denúncia</label><textarea id={`report-${id}`} value={reportReason} onChange={event=>setReportReason(event.target.value)} maxLength={500}/><div className="button-row"><button className="primary-btn" disabled={busy||reportReason.trim().length<3}>Enviar denúncia</button><button type="button" className="secondary-btn" onClick={()=>setReport(null)}>Cancelar</button></div></form>:null;
 return <section className="social-workspace hub"><div className="module-title-row"><div><h1>{area==='enquetes'?'Enquetes':area==='comunidades'?'Comunidades':'Moderação da comunidade'}</h1><p className="muted">{area==='enquetes'?'Sua opinião ajuda a construir o ABC. Um voto por pessoa.':area==='comunidades'?'Encontre pessoas com interesses em comum.':'Revise enquetes, comunidades e publicações de grupos.'}</p></div><button className="secondary-btn" disabled={busy||loading} onClick={()=>void refresh()}>Atualizar</button></div>{error&&<p className="auth-error" role="alert">{error}</p>}{notice&&<p className="social-feedback" role="status">{notice}</p>}
 {area!=='comunidade-equipe'&&!selected&&<details className="hub-create"><summary>{area==='enquetes'?'Criar enquete':'Criar comunidade'}</summary>{!userId?<button className="primary-btn" onClick={openAuth}>Entrar para criar</button>:<form noValidate onSubmit={create} className="form-grid">{area==='enquetes'?<><div className="field full"><label htmlFor="poll-question">Pergunta</label><input id="poll-question" name="question" required minLength={10} maxLength={160}/></div><div className="field full" role="group" aria-labelledby="poll-options-title" aria-describedby="poll-options-help">
   <strong id="poll-options-title">Opções de resposta</strong>
   <small id="poll-options-help">Preencha de 2 a 6 opções, uma por campo.</small>
   {Array.from({ length: pollOptionCount }, (_, index) => {
    const number = index + 1;
    return <div className="field" key={number}>
     <label htmlFor={`poll-option-${number}`}>Opção {number}</label>
     <input id={`poll-option-${number}`} name="options" maxLength={80} placeholder={`Digite a opção ${number}`} onChange={() => setPollOptionsError('')} />
    </div>;
   })}
   {pollOptionsError && <p className="auth-error" role="alert">{pollOptionsError}</p>}
   <div className="button-row">
    {pollOptionCount < MAX_POLL_OPTIONS && <button type="button" className="secondary-btn" disabled={busy} onClick={() => setPollOptionCount(pollOptionCount + 1)}>Adicionar opção</button>}
    {pollOptionCount > MIN_POLL_OPTIONS && <button type="button" className="secondary-btn" disabled={busy} onClick={() => { setPollOptionCount(pollOptionCount - 1); setPollOptionsError(''); }}>Remover última opção</button>}
   </div>
  </div><div className="field"><label htmlFor="poll-closing">Encerramento (horário deste aparelho)</label><input id="poll-closing" type="datetime-local" name="closing" required/><small>De 30 minutos a 30 dias a partir de agora.</small></div></>:<><p className="field full muted">{minimum===null?'Carregando requisito…':`Para criar, são necessários ${minimum} pontos confirmados. Participar é livre.`}</p><div className="field full"><label htmlFor="group-name">Nome</label><input id="group-name" name="name" required minLength={3} maxLength={80}/></div><div className="field full"><label htmlFor="group-description">Descrição e proposta</label><textarea id="group-description" name="description" required minLength={20} maxLength={1500}/></div><div className="field"><label htmlFor="group-category">Categoria</label><select name="category" id="group-category">{categories.map(v=><option key={v}>{v}</option>)}</select></div></>}<div className="field"><label htmlFor="hub-city">Cidade</label><select id="hub-city" name="city">{abcCities.map(v=><option key={v}>{v}</option>)}</select></div><div className="field full"><button className="primary-btn" disabled={busy||loading}>{busy?'Enviando…':'Enviar para análise'}</button></div></form>}</details>}
 {area!=='comunidade-equipe'&&!selected&&<label className="social-city">Cidade<select aria-label="Filtrar cidade" value={city} onChange={event=>setCity(event.target.value)}><option>Todas as cidades</option>{abcCities.map(v=><option key={v}>{v}</option>)}</select></label>}
 {area==='enquetes'&&<><div className="social-filter-tabs">{[['ativas','Ativas'],['encerradas','Encerradas'],['minhas','Minhas']].map(([id,label])=><button key={id} className={tab===id?'selected':''} aria-pressed={tab===id} onClick={()=>setTab(id)}>{label}</button>)}</div>{polls.filter(p=>(city==='Todas as cidades'||p.city===city)&&(tab==='minhas'?p.is_own:p.status==='approved'&&(tab==='encerradas'?new Date(p.closes_at).getTime()<=now:new Date(p.closes_at).getTime()>now))).map(p=>{const total=p.options.reduce((n,o)=>n+Number(o.votes),0),closed=new Date(p.closes_at).getTime()<=now;return <article className="hub-card" key={p.id}><span className="badge">{p.city} · {statusName(p.status)}</span><h2><Vote size={20}/>{p.question}</h2><small>{closed?'Encerrada em':'Encerra em'} {new Date(p.closes_at).toLocaleString('pt-BR')}</small><div className="hub-options">{p.options.map(o=><button key={o.id} disabled={busy||closed||Boolean(p.my_vote)||p.status!=='approved'} onClick={()=>void action('social_vote_poll',{target_poll:p.id,target_option:o.id},'Voto registrado.')}><span className="hub-vote-bar" style={{width:`${total?Number(o.votes)/total*100:0}%`}}/><span>{p.my_vote===o.id&&<Check size={16}/>} {o.label}</span><b>{total?Math.round(Number(o.votes)/total*100):0}%</b></button>)}</div><small>{total} {total===1?'voto':'votos'}{p.my_vote?' · Você já votou':''}</small>{p.status==='approved'&&<button className="hub-report-link" onClick={()=>askReport('poll',p.id)}><Flag size={14}/>Denunciar</button>}{renderReport('poll',p.id)}</article>;})}{!loading&&!polls.some(p=>(city==='Todas as cidades'||p.city===city)&&(tab==='minhas'?p.is_own:p.status==='approved'&&(tab==='encerradas'?new Date(p.closes_at).getTime()<=now:new Date(p.closes_at).getTime()>now)))&&<div className="social-empty">Nenhuma enquete nesta seleção.</div>}</>}
 {area==='comunidades'&&(selected?<><button className="secondary-btn" onClick={()=>{setSelected(null);setTarget(null);setPosts([]);}}><ArrowLeft size={16}/> Todas as comunidades</button>{selectedGroup?<><article className="hub-card"><span className="badge">{selectedGroup.city} · {selectedGroup.category} · {statusName(selectedGroup.status)}</span><h2>{selectedGroup.name}</h2><p>{selectedGroup.description}</p><p>{selectedGroup.members} participantes</p><button className="primary-btn" disabled={busy||selectedGroup.status!=='approved'} onClick={()=>void action('social_join_group',{target_group:selectedGroup.id,joining:!selectedGroup.joined},selectedGroup.joined?'Você saiu da comunidade.':'Você entrou na comunidade.')}>{selectedGroup.joined?'Sair da comunidade':'Participar'}</button>{selectedGroup.status==='approved'&&<button className="hub-report-link" onClick={()=>askReport('group',selectedGroup.id)}>Denunciar comunidade</button>}{renderReport('group',selectedGroup.id)}</article>{selectedGroup.joined&&selectedGroup.status==='approved'&&<form noValidate className="hub-card" onSubmit={async event=>{event.preventDefault();const form=event.currentTarget;const body=new FormData(form).get('body');if(await action('social_add_group_post',{target_group:selectedGroup.id,post_body:body},'Publicação enviada para análise.'))form.reset();}}><label htmlFor="group-post">Compartilhe com a comunidade</label><textarea id="group-post" name="body" required minLength={10} maxLength={2000} rows={4}/><button className="primary-btn" disabled={busy}>Enviar para análise</button></form>}{posts.map(p=><article className="hub-card" key={p.id}><strong>{p.first_name}{p.is_own?' · você':''}</strong><small>{statusName(p.status)} · {new Date(p.created_at).toLocaleDateString('pt-BR')}</small><p>{p.body}</p>{p.status==='approved'&&<button className="hub-report-link" onClick={()=>askReport('group_post',p.id)}>Denunciar</button>}{renderReport('group_post',p.id)}</article>)}{!loading&&!posts.length&&<p>Nenhuma publicação disponível nesta comunidade.</p>}</>:!loading&&<div className="social-empty">Comunidade indisponível.</div>}</>:<>{groups.filter(g=>city==='Todas as cidades'||g.city===city).map(g=><article className="hub-card" key={g.id}><span className="badge">{g.category} · {statusName(g.status)}</span><h2><UsersRound size={20}/>{g.name}</h2><p>{g.description}</p><small>{g.city} · {g.members} participantes</small><button className="secondary-btn" onClick={()=>setSelected(g.id)}>Abrir comunidade</button></article>)}{!loading&&!groups.some(g=>city==='Todas as cidades'||g.city===city)&&<div className="social-empty">Nenhuma comunidade nesta seleção.</div>}</>)}
 {area==='comunidade-equipe'&&queue.map(item=><article className="hub-card" key={item.id}><span className="badge">{{poll:'Enquete',group:'Comunidade',group_post:'Post de comunidade'}[item.kind]} · {item.city} · {statusName(item.status)}</span><p>{item.body}</p><label htmlFor={`review-${item.id}`}>Motivo da decisão</label><input id={`review-${item.id}`} value={reasons[item.id]||''} onChange={e=>setReasons({...reasons,[item.id]:e.target.value})} maxLength={500}/><div className="button-row">{[['approved','Aprovar'],['rejected','Rejeitar']].map(([value,label])=><button key={value} className="secondary-btn" disabled={busy||(reasons[item.id]?.trim().length||0)<3} onClick={()=>void action('social_review_hub',{target_kind:item.kind,target_id:item.id,decision:value,reason:reasons[item.id]},'Decisão registrada.')}>{label}</button>)}</div></article>)}{area==='comunidade-equipe'&&!loading&&!error&&!queue.length&&<div className="social-empty">Nenhum conteúdo aguardando revisão.</div>}
 {loading&&<p role="status">Carregando…</p>}
 </section>;
}
