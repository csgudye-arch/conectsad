"use client";

import { AuthPanel } from "@/components/AuthPanel";
import { useSupabaseAuth } from "@/lib/supabase/use-auth";

export function AuthPage({ initialMode = "signin" }: { initialMode?: "signin" | "recovery" }) {
  const auth = useSupabaseAuth();

  if (auth.loading) {
    return <main className="auth-screen" aria-busy="true"><div className="auth-loading">Verificando sua conta…</div></main>;
  }

  return <AuthPanel
    open
    presentation="page"
    initialMode={initialMode}
    client={auth.client}
    user={auth.user}
    profile={auth.profile}
    callbackNotice={auth.authNotice}
    onClose={() => {}}
    onSignedOut={() => {}}
  />;
}
