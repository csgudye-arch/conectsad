import Link from "next/link";

type Section = { title: string; paragraphs: string[] };

export function LegalPage({ title, intro, sections }: { title: string; intro: string; sections: Section[] }) {
  return <main className="legal-screen">
    <Link className="auth-screen-brand" href="/" aria-label="Conecta ABC início">
      <span className="legal-mark" aria-hidden="true">ABC</span>
      <span>conecta <b>abc</b><small>Uma plataforma da SAD</small></span>
    </Link>
    <article className="legal-document">
      <Link className="legal-back" href="/">← Voltar para o Conecta ABC</Link>
      <div className="eyebrow">CONECTA ABC · POLÍTICAS DA PLATAFORMA</div>
      <h1>{title}</h1>
      <p className="legal-intro">{intro}</p>
      <p className="legal-updated">Atualizado em 2 de novembro de 2026</p>
      {sections.map((section) => <section className="legal-section" key={section.title}>
        <h2>{section.title}</h2>
        {section.paragraphs.map((paragraph, index) => <p key={index}>{paragraph}</p>)}
      </section>)}
      <footer className="legal-footer">Dúvidas ou solicitações sobre dados: <a href="mailto:santoandredepressao@gmail.com">santoandredepressao@gmail.com</a></footer>
    </article>
  </main>;
}
