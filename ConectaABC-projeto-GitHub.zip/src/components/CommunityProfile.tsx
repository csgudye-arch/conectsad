"use client";
import {useEffect,useState,type FormEvent,type ReactNode} from 'react';
import Image from 'next/image';
import {useCommunityResource} from '@/lib/use-community-resource';
import {uploadCommunityMedia} from '@/lib/community-media';
import {BlockMemberButton} from './MemberConnections';
import {MemberBadges} from './ActivitySummary';
import {ContentReportButton} from './ContentReports';
import {abcCities} from '@/lib/validation';
import {useSocial} from './SocialFeatures';

type Details={handle:string;bio:string;neighborhood:string;cover_path:string|null;public_enabled:boolean;show_presence:boolean;moderation_hidden?:boolean};
type Profile={member_id:string;first_name:string;handle:string;bio:string;neighborhood:string;city:string;cover_path:string|null;avatar_path:string|null;recently_active:boolean;is_moderator:boolean;points:number;posts:number};
type Post={id:string;title:string|null;body:string;city:string;created_at:string;media_path:string|null;media_kind:string|null};
export function SignedCommunityImage({path,bucket,alt,className}:{path:string|null;bucket:string;alt:string;className?:string}){
 const {client}=useSocial();const [url,setUrl]=useState('');
 useEffect(()=>{let alive=true;if(path&&client)void client.storage.from(bucket).createSignedUrl(path,300).then(({data})=>{if(alive)setUrl(data?.signedUrl||'');});return()=>{alive=false;};},[client,path,bucket]);
 return path&&url?<Image src={url} width={800} height={400} unoptimized alt={alt} className={className}/>:null;
}
export function CommunityProfileEditor({navigate,name,city,onSaved}:{navigate:(area:string)=>void;name:string;city:string;onSaved:()=>Promise<void>}){
 const state=useCommunityResource<Details>('social_my_details',{},Boolean(useSocial().userId));const [file,setFile]=useState<File|null>(null),[saving,setSaving]=useState(false);
 const d=state.data;
 async function save(event:FormEvent<HTMLFormElement>){event.preventDefault();if(!state.client||!state.userId){state.openAuth();return;}const form=new FormData(event.currentTarget);setSaving(true);state.setError('');let uploaded:string|null=null;
 try{if(file)uploaded=(await uploadCommunityMedia(state.client,state.userId,file,'social-covers')).path;const okay=await state.act('social_save_full_profile',{member_name:form.get('display_name'),member_city:form.get('city'),member_handle:String(form.get('handle')||'').toLowerCase(),member_bio:form.get('bio'),member_neighborhood:form.get('neighborhood'),member_cover:form.get('remove_cover')==='on'?null:uploaded||d?.cover_path||null,make_public:form.get('public')==='on',presence_public:form.get('presence')==='on'},'Perfil atualizado.');if(okay){setFile(null);await onSaved();}else if(uploaded&&!state.actionWasUncertain())await state.client.storage.from('social-covers').remove([uploaded]);}
 catch(err){state.setError((err as Error).message);}finally{setSaving(false);}}
 if(!state.userId)return null;
 return <section className="panel social-profile-editor"><h2>Seu espaço na comunidade</h2>{d?.moderation_hidden&&<p className="notice">Seu perfil público foi ocultado para análise da equipe.</p>}{d?.cover_path&&<SignedCommunityImage path={d.cover_path} bucket="social-covers" alt="Sua capa" className="social-profile-cover"/>}<ResourceFeedback state={state}/>{!state.loading&&<form key={d?.handle||'new'} onSubmit={save} noValidate className="form-grid">
 <div className="field"><label htmlFor="social-name">Seu nome</label><input id="social-name" name="display_name" defaultValue={name} maxLength={80}/></div><div className="field"><label htmlFor="social-city">Cidade</label><select id="social-city" name="city" defaultValue={city}><option value="" disabled>Selecione sua cidade</option>{abcCities.map(value=><option key={value}>{value}</option>)}</select></div>
 <div className="field"><label htmlFor="social-handle">Nome de usuário</label><input id="social-handle" name="handle" defaultValue={d?.handle||''} maxLength={24} placeholder="seunome"/><small>3 a 24 letras, números ou _. Não use dados pessoais.</small></div>
 <div className="field"><label htmlFor="social-neighborhood">Bairro (opcional)</label><input id="social-neighborhood" name="neighborhood" defaultValue={d?.neighborhood||''} maxLength={80}/></div>
 <div className="field full"><label htmlFor="social-bio">Bio</label><textarea id="social-bio" name="bio" defaultValue={d?.bio||''} maxLength={300}/></div>
 <div className="field full"><label htmlFor="social-cover">Foto de capa (até 5 MB)</label><input id="social-cover" type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>setFile(e.target.files?.[0]||null)}/>{d?.cover_path&&<label><input type="checkbox" name="remove_cover"/> Remover capa do perfil</label>}</div>
 <div className="field full"><label><input name="public" type="checkbox" defaultChecked={d?.public_enabled}/> Exibir publicamente meu perfil, bio, bairro e capa. Meu sobrenome e meus contatos continuam privados.</label><label><input name="presence" type="checkbox" defaultChecked={d?.show_presence}/> Mostrar quando estive ativo recentemente no perfil público.</label></div>
 <div className="field full"><button className="primary-btn" disabled={saving||state.busy}>{saving?'Salvando…':'Salvar perfil'}</button></div></form>}
 {d?.public_enabled&&!d.moderation_hidden&&<a className="secondary-btn" href={`/?area=membro&usuario=${encodeURIComponent(d.handle)}`}>Abrir meu perfil público</a>}
 <div className="social-profile-highlights">{[['amigos','Amigos'],['salvos','Salvos'],['pontua','Meu nível e convites'],['cupons','Cupons'],['mais','Todos os recursos']].map(([id,label])=><button className="secondary-btn" key={id} onClick={()=>navigate(id)}>{label}</button>)}</div></section>;
}
export function ResourceFeedback({state}:{state:{error:string;notice:string;loading:boolean}}){return <>{state.error&&<p className="auth-error" role="alert">{state.error}</p>}{state.notice&&<p className="social-feedback" role="status">{state.notice}</p>}{state.loading&&<p role="status">Carregando…</p>}</>;}
export function PublicMemberProfile({handle}:{handle:string}){
 const state=useCommunityResource<Profile>('social_public_profile',{member_handle:handle});const posts=useCommunityResource<Post[]>('social_member_posts',{member_handle:handle,page_number:0});const p=state.data;
 return <section className="social-workspace"><ResourceFeedback state={state}/>{!state.loading&&!p?<div className="social-empty">Perfil indisponível ou não publicado.</div>:p&&<><SignedCommunityImage path={p.cover_path} bucket="social-covers" alt="Capa do perfil" className="social-profile-cover"/><div className="social-profile-heading"><SignedCommunityImage path={p.avatar_path} bucket="member-avatars" alt={`Foto de ${p.first_name}`} className="social-profile-avatar"/><div><h1>{p.first_name} {p.is_moderator&&<small className="badge">EQUIPE</small>}</h1><p>@{p.handle} · {p.city}{p.neighborhood?` · ${p.neighborhood}`:''}</p>{p.recently_active&&<small className="presence">● Ativo nos últimos minutos</small>}</div></div><MemberBadges memberId={p.member_id}/><p className="agenda-description">{p.bio}</p><ContentReportButton kind="profile" targetId={p.member_id}/><BlockMemberButton memberId={p.member_id}/><div className="social-profile-counts"><strong>{p.posts} publicações</strong><strong>{p.points} pontos confirmados</strong></div>{p.member_id!==state.userId&&<button className="primary-btn" disabled={state.busy} onClick={()=>void state.act('social_request_friend',{target_member:p.member_id},'Pedido de amizade registrado.')}>Adicionar amigo</button>}<h2>Publicações públicas</h2><ResourceFeedback state={posts}/>{posts.data?.map(post=><article className="hub-card" key={post.id}>{post.media_kind==='image'&&<SignedCommunityImage path={post.media_path} bucket="feed-media" alt="Imagem da publicação"/>}{post.title&&<h3>{post.title}</h3>}<p>{post.body}</p><a href={`/?post=${encodeURIComponent(post.id)}`}>Abrir publicação</a></article>)}{!posts.loading&&!posts.data?.length&&<p>Nenhuma publicação pública.</p>}</>}</section>;
}
export function PresenceHeartbeat({children}:{children:ReactNode}){const {client,userId}=useSocial();useEffect(()=>{if(!client||!userId)return;const pulse=()=>{if(document.visibilityState==='visible')void client.rpc('social_touch_presence');};pulse();const timer=window.setInterval(pulse,60000);return()=>window.clearInterval(timer);},[client,userId]);return <>{children}</>;}
