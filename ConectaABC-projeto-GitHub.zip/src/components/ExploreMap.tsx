"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { SupabaseClient, User } from "@supabase/supabase-js";
import { ArrowLeft, Building2, Crosshair, House, MapPin, Maximize2, Minimize2, Minus, Plus, Search, Send, Trees, Utensils, X } from "lucide-react";
import { PlaceParticipation } from "./PlaceParticipation";
import type * as Leaflet from "leaflet";

type PlaceCategory = "comer" | "comercio" | "pracas" | "esporte" | "cultura" | "saude" | "religiao" | "servicos" | "outros";
type CommunityPlace = { id: string; title: string; category: PlaceCategory; city: string; description: string; latitude: number; longitude: number; status: string };
type CategoryFilter = "Tudo" | PlaceCategory;
const cities = ["Santo André", "São Bernardo do Campo", "São Caetano do Sul", "Diadema", "Mauá", "Ribeirão Pires", "Rio Grande da Serra"];
const categoryOptions: { id: PlaceCategory; label: string; icon: typeof MapPin; color: string }[] = [
  { id: "comer", label: "Comer e beber", icon: Utensils, color: "#e48121" },
  { id: "comercio", label: "Comércios", icon: Building2, color: "#152b64" },
  { id: "pracas", label: "Praças e parques", icon: Trees, color: "#14864a" },
  { id: "esporte", label: "Esporte", icon: MapPin, color: "#2472da" },
  { id: "cultura", label: "Cultura e história", icon: MapPin, color: "#8252bd" },
  { id: "saude", label: "Saúde e serviços", icon: MapPin, color: "#d84d4d" },
  { id: "religiao", label: "Religião", icon: MapPin, color: "#62708a" },
  { id: "servicos", label: "Serviços", icon: MapPin, color: "#268693" },
  { id: "outros", label: "Outros", icon: MapPin, color: "#576579" },
];
const categoryName = (id: PlaceCategory) => categoryOptions.find((item) => item.id === id)?.label ?? "Outros";
let lastSearchAt = 0;
const geocodeCache = new Map<string, { lat: number; lon: number }>();

export function ExploreMap({ client, user, onLogin, compact=false }: { client: SupabaseClient | null; user: Pick<User,"id"> | null; onLogin: () => void; compact?: boolean }) {
  const mapElement = useRef<HTMLDivElement>(null);
  const mapRef = useRef<Leaflet.Map | null>(null);
  const leafletRef = useRef<typeof Leaflet | null>(null);
  const markerLayerRef = useRef<Leaflet.LayerGroup | null>(null);
  const selectionMarkerRef = useRef<Leaflet.Marker | null>(null);
  const [selectedPlace,setSelectedPlace] = useState("");
  const [places, setPlaces] = useState<CommunityPlace[]>([]);
  const [activeFilter, setActiveFilter] = useState<CategoryFilter>("Tudo");
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [mapError, setMapError] = useState("");
  const [mapReady, setMapReady] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [point, setPoint] = useState<{ lat: number; lng: number } | null>(null);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const [notice, setNotice] = useState("");
  const [expanded, setExpanded] = useState(false);
  const placingRef = useRef(false);
  useEffect(() => { placingRef.current = placing; }, [placing]);

  useEffect(() => {
    if (!expanded) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const timer = window.setTimeout(() => mapRef.current?.invalidateSize(), 120);
    return () => { window.clearTimeout(timer); document.body.style.overflow = previousOverflow; };
  }, [expanded]);

  const refresh = useCallback(async () => {
    if (!client) { setLoading(false); setMapError("O mapa comunitário precisa da conexão com a plataforma."); return; }
    setLoading(true); setMapError("");
    const { data, error } = await client.from("community_places").select("id,title,category,city,description,latitude,longitude,status").order("created_at", { ascending: false }).limit(500);
    if (error) { setMapError(error.code === "42P01" || error.code === "PGRST205" ? "O mapa precisa ser ativado no banco Supabase pela equipe." : "Não foi possível carregar os locais. Tente atualizar o mapa."); setPlaces([]); }
    else { setPlaces((data ?? []) as CommunityPlace[]); setMapError(""); }
    setLoading(false);
  }, [client]);

  useEffect(() => { const timer=window.setTimeout(()=>void refresh(),0);return()=>window.clearTimeout(timer); }, [refresh]);

  useEffect(() => {
    if (!mapElement.current || mapRef.current) return;
    let disposed = false;
    void import("leaflet").then((L) => {
      if (disposed || !mapElement.current) return;
      leafletRef.current = L;
      const map = L.map(mapElement.current, { center: [-23.665, -46.535], zoom: 12, zoomControl: false, scrollWheelZoom: false, dragging:!compact, touchZoom:!compact, doubleClickZoom:!compact });
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors', maxZoom: 19 }).addTo(map);
      const layer = L.layerGroup().addTo(map);
      map.on("click", (event: Leaflet.LeafletMouseEvent) => {
        if (placingRef.current) setPoint({ lat: Number(event.latlng.lat.toFixed(6)), lng: Number(event.latlng.lng.toFixed(6)) });
      });
      mapRef.current = map; markerLayerRef.current = layer; setMapReady(true);
      window.setTimeout(() => map.invalidateSize(), 100);
    }).catch(() => setMapError("O mapa não carregou. Confira sua conexão e tente atualizar."));
    return () => { disposed = true; mapRef.current?.remove(); mapRef.current = null; markerLayerRef.current = null; };
  }, [compact]);

  useEffect(() => {
    if(!compact || !mapReady || !mapRef.current)return;
    const map=mapRef.current;
    if(expanded){map.dragging.enable();map.touchZoom.enable();map.doubleClickZoom.enable();}
    else{map.dragging.disable();map.touchZoom.disable();map.doubleClickZoom.disable();}
  },[compact,expanded,mapReady]);

  useEffect(() => {
    const L = leafletRef.current; const layer = markerLayerRef.current;
    if (!L || !layer) return;
    layer.clearLayers();
    for (const place of places) {
      if (activeFilter !== "Tudo" && place.category !== activeFilter) continue;
      const info = categoryOptions.find((item) => item.id === place.category) ?? categoryOptions[8];
      const isPending = place.status === "pending";
      const glyph = info.label === "Comer e beber" ? "🍴" : info.label === "Praças e parques" ? "🌳" : info.label === "Comércios" ? "🏪" : info.label === "Esporte" ? "⚽" : info.label === "Cultura e história" ? "🎨" : info.label === "Saúde e serviços" ? "💊" : info.label === "Religião" ? "⛪" : info.label === "Serviços" ? "🛠️" : "📍";
      const icon = L.divIcon({ className: "community-place-icon-wrap", html: `<span class="community-place-icon ${isPending ? "is-pending" : ""}" style="--pin:${info.color}"><span class="community-place-glyph">${glyph}</span></span>`, iconSize: [42, 46], iconAnchor: [21, 42] });
      const marker = L.marker([place.latitude, place.longitude], { icon }).bindPopup(`<strong>${escapeHtml(place.title)}</strong><br>${escapeHtml(place.city)} · ${escapeHtml(info.label)}<br><small>${escapeHtml(place.description)}</small>${isPending ? "<br><small><b>Aguardando revisão da equipe</b></small>" : ""}`);
      marker.on("click",()=>setSelectedPlace(place.id));
      marker.addTo(layer);
    }
    if (point) {
      selectionMarkerRef.current?.remove();
      const selectedIcon = L.divIcon({ className: "community-place-icon-wrap", html: '<span class="community-place-icon is-selected"><span class="community-place-glyph">📍</span></span>', iconSize: [42, 46], iconAnchor: [21, 42] });
      selectionMarkerRef.current = L.marker([point.lat, point.lng], { title: "Local escolhido", icon: selectedIcon }).addTo(mapRef.current!).bindPopup("Local selecionado para o seu envio.");
    } else { selectionMarkerRef.current?.remove(); selectionMarkerRef.current = null; }
  }, [activeFilter, places, point, mapReady]);

  const visibleCount = useMemo(() => places.filter((place) => activeFilter === "Tudo" || place.category === activeFilter).length, [places, activeFilter]);

  async function searchPlace(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); const term = query.trim();
    if (term.length < 3) { setMapError("Digite pelo menos 3 caracteres para buscar um endereço ou local."); return; }
    setSearching(true); setMapError("");
    const cacheKey = term.toLocaleLowerCase("pt-BR");
    let result = geocodeCache.get(cacheKey);
    try {
      if (!result) {
        const wait = Math.max(0, 1100 - (Date.now() - lastSearchAt));
        if (wait) await new Promise((resolve) => window.setTimeout(resolve, wait));
        lastSearchAt = Date.now();
        const url = new URL("https://nominatim.openstreetmap.org/search");
        url.search = new URLSearchParams({ q: `${term}, Grande ABC, Brasil`, format: "jsonv2", limit: "1", viewbox: "-46.85,-23.45,-46.25,-23.90", bounded: "1" }).toString();
        const response = await fetch(url, { headers: { Accept: "application/json" } });
        if (!response.ok) throw new Error("search failed");
        const rows = await response.json() as { lat: string; lon: string }[];
        if (!rows[0]) throw new Error("not found");
        result = { lat: Number(rows[0].lat), lon: Number(rows[0].lon) }; geocodeCache.set(cacheKey, result);
      }
      mapRef.current?.setView([result.lat, result.lon], 16);
      if (placing) setPoint({ lat: Number(result.lat.toFixed(6)), lng: Number(result.lon.toFixed(6)) });
    } catch { setMapError("Não encontramos esse local no Grande ABC. Tente buscar um endereço, praça ou comércio próximo."); }
    finally { setSearching(false); }
  }

  function startAdding() {
    if (!user) { onLogin(); return; }
    if(compact)setExpanded(true);
    setShowForm(true); setPlacing(true); setPoint(null); setFormError(""); setNotice("");
  }

  async function submitPlace(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setFormError(""); setNotice("");
    const data = new FormData(event.currentTarget);
    const title = String(data.get("title") ?? "").trim(); const description = String(data.get("description") ?? "").trim();
    if (title.length < 3 || title.length > 90) { setFormError("O nome precisa ter entre 3 e 90 caracteres."); return; }
    if (description.length < 10 || description.length > 500) { setFormError("A descrição precisa ter entre 10 e 500 caracteres."); return; }
    if (!point) { setFormError("Escolha a localização clicando no mapa ou use a busca acima."); return; }
    if (!client || !user) { setFormError("Entre na sua conta para sugerir um local."); return; }
    setSaving(true);
    const { error } = await client.from("community_places").insert({ author_id: user.id, title, category: String(data.get("category")) as PlaceCategory, city: String(data.get("city")), description, latitude: point.lat, longitude: point.lng, status: "pending" });
    setSaving(false);
    if (error) { setFormError(error.code === "42P01" || error.code === "PGRST205" ? "O recurso ainda não foi ativado no banco Supabase." : error.code === "42501" ? "O banco recusou o envio. Entre na sua conta e tente novamente." : error.code === "P0001" ? "Você já enviou cinco locais nas últimas 24 horas. Tente novamente mais tarde." : "Não foi possível enviar o local agora. Revise os campos e tente novamente."); return; }
    setNotice("Local enviado para revisão da equipe. Ele será exibido no mapa após a aprovação."); setShowForm(false); setPlacing(false); setPoint(null); event.currentTarget.reset(); await refresh();
  }

  return <section className={`portal-map-section ${expanded ? "is-expanded" : ""}`} aria-label="Mapa explorável do Grande ABC"><svg className="map-art-filter-defs" aria-hidden="true" focusable="false"><filter id="map-cartoon-filter" color-interpolation-filters="sRGB"><feColorMatrix type="saturate" values="1.35" result="saturated"/><feComponentTransfer in="saturated"><feFuncR type="discrete" tableValues="0 .28 .62 1"/><feFuncG type="discrete" tableValues="0 .28 .62 1"/><feFuncB type="discrete" tableValues="0 .28 .62 1"/></feComponentTransfer></filter></svg>
    <header className="portal-map-heading"><div><span className="dashboard-kicker">MAPA COLABORATIVO · GRANDE ABC</span><h2>Explore o ABC</h2><p>Encontre espaços e serviços públicos cadastrados pela comunidade.</p></div><div className="portal-map-heading-actions"><span>{visibleCount} locais no mapa</span><button type="button" onClick={startAdding}><MapPin size={14}/> Adicionar local</button><button type="button" className="portal-map-expand" onClick={() => setExpanded((value) => !value)}>{expanded ? <><Minimize2 size={14}/> Reduzir</> : <><Maximize2 size={14}/> Expandir mapa</>}</button>{expanded && <><button type="button" className="portal-map-nav-button" onClick={() => setExpanded(false)}><ArrowLeft size={14}/> Voltar</button><button type="button" className="portal-map-nav-button" onClick={() => { setExpanded(false); window.scrollTo({ top: 0, behavior: "smooth" }); }}><House size={14}/> Início</button></>}</div></header>
    <form className="portal-map-search" onSubmit={(event) => void searchPlace(event)}><Search size={18}/><input aria-label="Buscar endereço ou local" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar praça, parque, comércio…"/><button type="submit" disabled={searching}>{searching ? "Buscando…" : "Buscar"}</button></form>
    <div className="portal-map-filters" aria-label="Filtrar locais">{(["Tudo", ...categoryOptions.map((option) => option.id)] as CategoryFilter[]).map((item) => <button type="button" key={item} className={activeFilter === item ? "active" : ""} onClick={() => setActiveFilter(item)}>{item === "Tudo" ? "Tudo" : categoryName(item)}</button>)}</div>
    <div className={`portal-map-canvas ${placing ? "is-placing" : ""}`}><div className="portal-leaflet-map" ref={mapElement} role="application" aria-label={compact&&!expanded?"Prévia do mapa do Grande ABC. Expanda o mapa para arrastar e explorar.":"Mapa interativo do Grande ABC. Arraste para explorar, use os controles de zoom e selecione um ponto durante a adição de local."}/><div className="portal-map-controls"><button type="button" aria-label="Aproximar" onClick={() => mapRef.current?.zoomIn()}><Plus size={18}/></button><button type="button" aria-label="Afastar" onClick={() => mapRef.current?.zoomOut()}><Minus size={18}/></button></div><button className="portal-map-nearby" type="button" onClick={() => { if (!navigator.geolocation) { setMapError("Este navegador não oferece localização."); return; } navigator.geolocation.getCurrentPosition(({ coords }) => mapRef.current?.setView([coords.latitude, coords.longitude], 16), () => setMapError("A localização está bloqueada. Você pode navegar pelo mapa manualmente."), { timeout: 8000 }); }}><Crosshair size={14}/> Perto de mim</button>{placing && <div className="portal-map-instruction"><MapPin size={15}/> Toque no ponto do mapa para marcar o local <button type="button" aria-label="Cancelar marcação" onClick={() => { setPlacing(false); setPoint(null); }}><X size={14}/></button></div>}{loading && <span className="portal-map-status">Carregando locais…</span>}</div>
    {mapError && <p className="portal-map-error" role="alert">{mapError}</p>}{notice && <p className="portal-map-success" role="status">{notice}</p>}
    {showForm && <form className="portal-place-form" onSubmit={(event) => void submitPlace(event)} noValidate><div className="portal-place-form-heading"><div><strong>Sugerir um local público</strong><small>Os dados enviados passam pela revisão da equipe antes de aparecerem no mapa.</small></div><button type="button" aria-label="Fechar formulário" onClick={() => { setShowForm(false); setPlacing(false); }}><X size={17}/></button></div><div className="portal-place-fields"><label>Nome do local<input name="title" required minLength={3} maxLength={90} placeholder="Ex.: Praça do bairro"/></label><label>Categoria<select name="category" defaultValue="comercio">{categoryOptions.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</select></label><label>Cidade<select name="city" defaultValue="Santo André">{cities.map((city) => <option key={city}>{city}</option>)}</select></label><label>Descrição<textarea name="description" required minLength={10} maxLength={500} placeholder="Conte brevemente o que as pessoas encontram aqui."/></label></div><div className="portal-place-position"><MapPin size={15}/>{point ? `Ponto escolhido: ${point.lat.toFixed(4)}, ${point.lng.toFixed(4)}` : "Ainda não marcou o ponto no mapa."}<button type="button" onClick={() => setPlacing(true)}>Marcar no mapa</button></div>{formError && <p className="portal-map-error" role="alert">{formError}</p>}<div className="portal-place-form-footer"><small>Não inclua sua casa, telefone ou dados pessoais. Sugira somente lugares públicos ou estabelecimentos abertos ao público.</small><button type="submit" disabled={saving}><Send size={14}/>{saving ? "Enviando…" : "Enviar para análise"}</button></div></form>}
    <div className="map-participation"><label htmlFor="place-participation-select">Selecione um local para avaliar ou registrar visita</label><select id="place-participation-select" value={selectedPlace} onChange={e=>setSelectedPlace(e.target.value)}><option value="">Selecione</option>{places.filter(p=>p.status==="approved").map(p=><option value={p.id} key={p.id}>{p.title} · {p.city}</option>)}</select>{selectedPlace&&<PlaceParticipation key={selectedPlace} placeId={selectedPlace}/>}</div>
    <footer className="portal-map-attribution">Mapa © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors · Busca de endereço via Nominatim</footer>
  </section>;
}

function escapeHtml(value: string) { return value.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char] ?? char); }
