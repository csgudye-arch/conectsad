"use client";

import { useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { CalendarDays, MapPin, Share2 } from "lucide-react";
import { useSocial, socialError } from "./SocialFeatures";
import { useCurrentTime } from "@/lib/use-current-time";
import { abcCities } from "@/lib/validation";
import { eventCalendar, type CalendarEvent } from "@/lib/event-calendar";

type EventItem = CalendarEvent & { status: string; is_own: boolean; attending: boolean; attendees: number };
const statusLabel: Record<string,string> = { pending: "Em análise", approved: "Publicado", rejected: "Não aprovado", cancelled: "Cancelado" };
const dateLabel = (value: string) => new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium", timeStyle: "short", timeZone: "America/Sao_Paulo" }).format(new Date(value));

export function EventAgenda({ moderation = false, children }: { moderation?: boolean; children?: ReactNode }) {
  const { client, userId, openAuth } = useSocial();
  const now = useCurrentTime();
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loading, setLoading] = useState(true), [busy, setBusy] = useState(false);
  const [error, setError] = useState(""), [notice, setNotice] = useState("");
  const [city, setCity] = useState("Todas as cidades"), [filter, setFilter] = useState("proximos");
  const [target, setTarget] = useState<string | null | undefined>(undefined);
  const [reasons, setReasons] = useState<Record<string,string>>({});
  const [shareLink, setShareLink] = useState("");
  const version = useRef(0);
  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get("evento");
    const timer = window.setTimeout(() => setTarget(id && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id) ? id : null), 0);
    return () => window.clearTimeout(timer);
  }, []);
  const refresh = useCallback(async () => {
    if (target === undefined) return;
    if (!client) { setLoading(false); setError("Conexão indisponível."); return; }
    const attempt = ++version.current; setLoading(true); setError("");
    try {
      const result = moderation ? await client.rpc("social_event_queue") : await client.rpc("social_list_events", { target_event: target });
      if (attempt !== version.current) return;
      if (result.error) throw result.error;
      setEvents(result.data ?? []);
    } catch (err) { if (attempt === version.current) setError(socialError(err)); }
    finally { if (attempt === version.current) setLoading(false); }
  }, [client, moderation, target]);
  const invalidate = useCallback(() => { version.current++; }, []);
  useEffect(() => { const timer=window.setTimeout(() => void refresh(),0); return () => { window.clearTimeout(timer); invalidate(); }; }, [refresh,invalidate]);
  async function act(name: string, args: Record<string,unknown>, message: string) {
    if (!client || !userId) { openAuth(); return false; }
    setBusy(true); setError(""); setNotice("");
    try { const result = await client.rpc(name, args); if (result.error) throw result.error; setNotice(message); await refresh(); return true; }
    catch (err) { setError(socialError(err)); return false; } finally { setBusy(false); }
  }
  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = event.currentTarget; const values = new FormData(form);
    const start = new Date(String(values.get("start") || "")), end = new Date(String(values.get("end") || ""));
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime())) { setError("Preencha as datas e os horários de início e término."); return; }
    const success = await act("social_create_event", { event_title: values.get("title"), event_description: values.get("description"), event_city: values.get("city"), event_venue: values.get("venue"), event_start: start.toISOString(), event_end: end.toISOString() }, "Evento enviado para análise. Acompanhe na aba Meus eventos.");
    if (success) { form.reset(); setFilter("meus"); setCity("Todas as cidades"); }
  }
  async function share(item: EventItem) {
    const url = new URL("/", window.location.origin); url.searchParams.set("area", "agenda"); url.searchParams.set("evento", item.id);
    setShareLink("");
    try { if (navigator.share) { await navigator.share({ title: item.title, text: `${item.title} · ${item.city}`, url: url.href }); } else { await navigator.clipboard.writeText(url.href); setNotice("Link do evento copiado."); } }
    catch (err) { if ((err as Error).name !== "AbortError") { setShareLink(url.href); setNotice("Copie o link abaixo para compartilhar."); } }
  }
  function calendar(item: EventItem) {
    try {
      const url = URL.createObjectURL(new Blob([eventCalendar(item)], { type: "text/calendar;charset=utf-8" }));
      const anchor = document.createElement("a"); anchor.href = url; anchor.download = `conecta-abc-evento-${item.id}.ics`; anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setNotice("Arquivo de calendário preparado. Abra-o no calendário do aparelho para salvar e configurar seu lembrete.");
    } catch { setError("Não foi possível preparar o calendário deste evento."); }
  }
  const visible = events.filter(item => moderation || target || ((city === "Todas as cidades" || city === item.city) && (filter === "meus" ? item.is_own : filter === "presencas" ? item.attending : item.status === "approved" && (filter === "anteriores" ? new Date(item.ends_at).getTime() <= now : new Date(item.ends_at).getTime() > now))));
  if (moderation && !userId) return <section className="social-empty"><h1>Moderação da agenda</h1><button className="primary-btn" onClick={openAuth}>Entrar com conta da equipe</button></section>;
  return <section className="social-workspace hub agenda">
    <div className="module-title-row"><div><h1>{moderation ? "Moderação da agenda" : "Agenda da comunidade"}</h1><p className="muted">{moderation ? "Revise informações, data e local antes de publicar." : "Encontros, cultura e ações no Grande ABC. Horários exibidos no fuso de Brasília."}</p></div><button className="secondary-btn" disabled={loading || busy} onClick={() => void refresh()}>Atualizar</button></div>
    {error && <p className="auth-error" role="alert">{error}</p>}{notice && <p className="social-feedback" role="status">{notice}</p>}
    {shareLink && <label>Link para compartilhar<input readOnly value={shareLink} onFocus={event => event.target.select()}/></label>}
    {!moderation && !target && <>
      <details className="hub-create"><summary>Divulgar evento</summary>{!userId ? <button className="primary-btn" onClick={openAuth}>Entrar para divulgar</button> : <form onSubmit={create} noValidate className="form-grid">
        <div className="field full"><label htmlFor="event-title">Nome do evento</label><input id="event-title" name="title" maxLength={120} required/></div>
        <div className="field full"><label htmlFor="event-description">Descrição</label><textarea id="event-description" name="description" maxLength={2000} rows={4} required/><small>De 20 a 2.000 caracteres. Informe programação, acesso e eventuais custos.</small></div>
        <div className="field"><label htmlFor="event-city">Cidade</label><select id="event-city" name="city">{abcCities.map(value => <option key={value}>{value}</option>)}</select></div>
        <div className="field"><label htmlFor="event-venue">Local público do evento</label><input id="event-venue" name="venue" maxLength={200} required/><small>Este local será público. Não informe a residência de outras pessoas.</small></div>
        <div className="field"><label htmlFor="event-start">Início (horário deste aparelho)</label><input type="datetime-local" id="event-start" name="start" required/></div>
        <div className="field"><label htmlFor="event-end">Término (horário deste aparelho)</label><input type="datetime-local" id="event-end" name="end" required/></div>
        <div className="field full"><button className="primary-btn" disabled={busy}>{busy ? "Enviando…" : "Enviar para análise"}</button></div>
      </form>}</details>
      <label className="social-city">Cidade<select value={city} onChange={event => setCity(event.target.value)}><option>Todas as cidades</option>{abcCities.map(value => <option key={value}>{value}</option>)}</select></label>
      <div className="social-filter-tabs">{[["proximos","Próximos"],["presencas","Vou participar"],["meus","Meus eventos"],["anteriores","Anteriores"]].map(([id,label]) => <button key={id} aria-pressed={filter===id} className={filter===id?"selected":""} onClick={() => setFilter(id)}>{label}</button>)}</div>
    </>}
    {target && !moderation && <button className="secondary-btn" onClick={() => { const url = new URL(window.location.href); url.searchParams.delete("evento"); window.history.replaceState(null,"",url); setTarget(null); }}>Ver agenda completa</button>}
    {loading && <p role="status">Carregando eventos…</p>}
    {!loading && !error && !visible.length && <div className="social-empty">{target ? "Evento indisponível ou aguardando aprovação." : moderation ? "Nenhum evento aguardando revisão." : "Nenhum evento nesta seleção."}</div>}
    {visible.map(item => <article className="hub-card" key={item.id}>
      <span className="badge">{item.city} · {statusLabel[item.status]}</span><h2><CalendarDays size={21}/>{item.title}</h2>
      <p><time dateTime={item.starts_at}>{dateLabel(item.starts_at)}</time> até <time dateTime={item.ends_at}>{dateLabel(item.ends_at)}</time></p>
      <p><MapPin size={16}/> {item.venue}</p><p className="agenda-description">{item.description}</p>
      {!moderation && <><small>{item.attendees} {item.attendees===1?"presença confirmada":"presenças confirmadas"} · lista de participantes privada</small>
      <div className="button-row">{(item.attending || (item.status==="approved" && new Date(item.ends_at).getTime()>now)) && <button className="primary-btn" disabled={busy} onClick={() => void act("social_attend_event",{target_event:item.id,attending:!item.attending},item.attending?"Confirmação de presença removida.":"Presença confirmada. Isso não representa reserva de ingresso.")}>{item.attending?"Não vou mais":"Confirmar presença"}</button>}
      {item.status==="approved" && <button className="secondary-btn" onClick={() => calendar(item)}>Salvar no calendário</button>}
      {["approved","cancelled"].includes(item.status) && <button className="secondary-btn" onClick={() => void share(item)}><Share2 size={16}/> Compartilhar</button>}</div>
      {item.status==="approved" && <small>O arquivo de calendário não atualiza automaticamente. Consulte o evento antes de sair.</small>}</>}
      {(moderation || (item.is_own && item.status!=="cancelled" && item.status!=="rejected")) && <div className="agenda-review"><label htmlFor={`event-reason-${item.id}`}>{moderation?"Motivo da decisão":"Motivo para cancelar ou retirar o evento"}</label><input id={`event-reason-${item.id}`} value={reasons[item.id]||""} onChange={event => setReasons({...reasons,[item.id]:event.target.value})} maxLength={500}/><div className="button-row">{(moderation ? [["approved","Aprovar"],["rejected","Rejeitar"]] : [["cancelled",item.status==="approved"?"Cancelar evento":"Retirar da análise"]]).map(([decision,label]) => <button className="secondary-btn" key={decision} disabled={busy||(reasons[item.id]?.trim().length||0)<3} onClick={() => void act("social_review_event",{target_event:item.id,decision,reason:reasons[item.id]},"Situação do evento atualizada.")}>{label}</button>)}</div></div>}
    </article>)}
    {!moderation && !target && children && <section className="agenda-legacy"><h2>Divulgações no feed</h2><p className="muted">Publicações anteriores continuam aqui. Confira datas e informações diretamente no texto.</p>{children}</section>}
  </section>;
}
