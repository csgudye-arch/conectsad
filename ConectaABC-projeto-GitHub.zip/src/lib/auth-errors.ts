export function readableAuthError(error: unknown) {
  const details = error && typeof error === "object"
    ? error as { code?: unknown; message?: unknown; status?: unknown }
    : undefined;
  const code = details?.code;
  const status = details?.status;
  const message = (typeof error === "string" ? error : typeof details?.message === "string" ? details.message : "").toLowerCase();

  if (code === "email_address_not_authorized" || /error sending .*email|\bsmtp\b|\b535\b.*authentication/.test(message)) {
    return "O serviço de e-mail está indisponível e não conseguiu enviar a mensagem. Tente novamente mais tarde ou avise a equipe pela Ajuda.";
  }
  if (status === 429 || code === "over_email_send_rate_limit" || code === "over_request_rate_limit" || message.includes("rate limit")) {
    return "Muitas tentativas em pouco tempo. Aguarde alguns minutos e tente novamente.";
  }
  if (status === 0 || /failed to fetch|networkerror|network request failed/.test(message)) {
    return "Não foi possível conectar ao serviço de acesso. Confira sua conexão e tente novamente.";
  }
  if (code === "invalid_credentials" || message.includes("invalid login credentials")) return "E-mail ou senha incorretos.";
  if (code === "email_exists" || code === "user_already_exists" || message.includes("already registered")) return "Este e-mail já tem cadastro. Tente entrar.";
  if (code === "email_address_invalid" || message.includes("invalid email")) return "O serviço não aceitou esse endereço de e-mail. Confira o endereço ou use outro e-mail válido.";
  if (code === "signup_disabled" || code === "email_provider_disabled" || message.includes("signups not allowed")) return "O cadastro por e-mail está indisponível no momento. Tente entrar com Google ou avise a equipe pela Ajuda.";
  if (code === "provider_disabled" || message.includes("provider is not enabled") || message.includes("unsupported provider")) return "O acesso com Google está indisponível no momento. Entre com e-mail ou tente novamente mais tarde.";
  if (message.includes("database error saving new user") || message.includes("error creating new user")) return "O serviço não conseguiu salvar seu cadastro. Tente novamente mais tarde ou avise a equipe pela Ajuda.";
  if (code === "email_not_confirmed" || message.includes("email not confirmed")) return "Confirme seu e-mail pelo link que enviamos antes de entrar.";
  if (code === "otp_expired" || /token has expired|invalid token|otp expired/.test(message)) return "Esse código expirou ou já foi usado. Solicite um novo e-mail de confirmação.";
  if (code === "weak_password" || message.includes("password should")) return "A senha não atende aos requisitos de segurança. Use pelo menos 8 caracteres e evite senhas comuns.";
  if ((typeof status === "number" && status >= 500) || code === "unexpected_failure") return "O serviço de acesso apresentou uma falha. Tente novamente mais tarde ou avise a equipe pela Ajuda.";

  return "Não foi possível concluir a solicitação. Tente novamente ou avise a equipe pela Ajuda se o problema continuar.";
}
