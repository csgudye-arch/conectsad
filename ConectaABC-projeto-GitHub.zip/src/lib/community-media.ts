import type {SupabaseClient} from "@supabase/supabase-js";
async function prepareImage(file:File):Promise<File>{
 const url=URL.createObjectURL(file);try{const image=new window.Image();image.src=url;await image.decode();if(!image.naturalWidth||!image.naturalHeight)throw Error('Imagem inválida.');const scale=Math.min(1,1600/Math.max(image.naturalWidth,image.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));const context=canvas.getContext('2d');if(!context)throw Error('Este navegador não conseguiu preparar a imagem.');context.drawImage(image,0,0,canvas.width,canvas.height);const blob=await new Promise<Blob|null>(resolve=>canvas.toBlob(resolve,'image/webp',0.85));if(!blob)throw Error('Não foi possível preparar a foto.');return new File([blob],file.name,{type:blob.type});}catch{throw Error('Não foi possível ler esta foto. Escolha uma imagem JPG, PNG ou WebP válida.');}finally{URL.revokeObjectURL(url);}
}
export async function uploadCommunityMedia(client:SupabaseClient,userId:string,file:File,bucket:string,video=false){
 const images=['image/jpeg','image/png','image/webp'];const types=video?[...images,'video/mp4','video/webm','video/quicktime']:images;
 if(!types.includes(file.type)||file.size>(video?20:5)*1024*1024)throw new Error(video?'Escolha foto ou vídeo de até 20 MB.':'Escolha JPG, PNG ou WebP de até 5 MB.');
 if(file.type.startsWith('image/'))file=await prepareImage(file);
 const extension:Record<string,string>={'image/jpeg':'jpg','image/png':'png','image/webp':'webp','video/mp4':'mp4','video/webm':'webm','video/quicktime':'mov'};
 const path=`${userId}/${crypto.randomUUID()}.${extension[file.type]}`;
 const result=await client.storage.from(bucket).upload(path,file,{contentType:file.type,upsert:false});
 if(result.error)throw new Error('Não foi possível enviar o arquivo. Tente novamente.');
 return {path,kind:file.type.startsWith('video/')?'video':'image'};
}
