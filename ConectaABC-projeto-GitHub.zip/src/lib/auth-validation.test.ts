import { describe, expect, it } from "vitest";
import { validateEmailInput, validateSignupInput } from "./auth-validation";

const validSignup = {
  displayName: "Maria da Silva",
  city: "Santo André",
  email: "maria@example.com",
  password: "uma-senha-segura",
  passwordConfirmation: "uma-senha-segura",
  consented: true,
};

describe("validateSignupInput", () => {
  it("aceita os campos válidos de cadastro do Grande ABC", () => {
    expect(validateSignupInput(validSignup)).toBe("");
  });

  it("rejeita cidade fora do Grande ABC", () => {
    expect(validateSignupInput({ ...validSignup, city: "São Paulo" })).toMatch(/cidade do Grande ABC/);
  });

  it("rejeita e-mail inválido", () => {
    expect(validateSignupInput({ ...validSignup, email: "email-invalido" })).toMatch(/e-mail válido/);
  });

  it("exige senha longa e confirmação idêntica", () => {
    expect(validateSignupInput({ ...validSignup, password: "curta", passwordConfirmation: "curta" })).toMatch(/8 caracteres/);
    expect(validateSignupInput({ ...validSignup, passwordConfirmation: "outra-senha" })).toMatch(/senhas não são iguais/);
  });

  it("exige autorização para criar o perfil", () => {
    expect(validateSignupInput({ ...validSignup, consented: false })).toMatch(/autorização/);
  });
});

describe("validateEmailInput", () => {
  it("trata espaços periféricos e rejeita e-mail malformado", () => {
    expect(validateEmailInput(" maria@example.com ")).toBe("");
    expect(validateEmailInput("sem-arroba")).toMatch(/e-mail válido/);
  });
});
