export type SocialCollection = "inicio" | "explorar" | "busca" | "noticias" | "agenda" | "agora";
type PublicPost = { demo: boolean; status?: string; city: string; official: boolean; mediaKind?: string; mediaUrl?: string; category: string; title?: string; body: string; author: string; sensitive: boolean };
export function selectPublicPosts<T extends PublicPost>(posts: T[], collection: SocialCollection, city: string, query = ""): T[] {
  const normalized = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR");
  const term = normalized(query.trim());
  return posts.filter((post) => {
    if (post.demo || post.status !== "approved") return false;
    if (city !== "Todas as cidades" && post.city !== city && post.city !== "Grande ABC") return false;
    if (collection === "noticias" && !post.official) return false;
    if (collection === "agenda" && post.category !== "Evento comunitário") return false;
    if (collection === "agora" && (!post.official || post.mediaKind !== "video" || !post.mediaUrl)) return false;
    return !term || normalized([post.title, post.body, post.category, post.city, post.author].join(" ")).includes(term);
  });
}
