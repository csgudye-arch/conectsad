import { describe, expect, it } from "vitest";
import { selectPublicPosts } from "./social-feed";
const base = { demo: false, status: "approved", city: "Santo André", official: false, category: "Conversa do bairro", body: "Ajuda à comunidade", author: "Ana", sensitive: false };
describe("coleções públicas do novo layout", () => {
  it("nunca mostra exemplos, pendências, rejeitados ou ocultos", () => {
    const rows = [base, { ...base, demo: true }, ...["pending", "rejected", "hidden", undefined].map(status => ({ ...base, status }))];
    expect(selectPublicPosts(rows, "inicio", "Todas as cidades")).toEqual([base]);
  });
  it("combina filtro da cidade com comunicados regionais", () => {
    const regional = { ...base, city: "Grande ABC" };
    expect(selectPublicPosts([base, regional, { ...base, city: "Mauá" }], "inicio", "Santo André")).toEqual([base, regional]);
  });
  it("pesquisa sem diferenciar acentos e mantém a privacidade dos pendentes", () => {
    expect(selectPublicPosts([base, { ...base, status: "pending" }], "busca", "Todas as cidades", "santo andre")).toEqual([base]);
  });
  it("Em alta só contém vídeos oficiais aprovados com mídia disponível", () => {
    const video = { ...base, official: true, mediaKind: "video", mediaUrl: "https://example.org/video.mp4" };
    expect(selectPublicPosts([base, video, { ...video, official: false }, { ...video, status: "hidden" }, { ...video, mediaUrl: undefined }], "agora", "Todas as cidades")).toEqual([video]);
  });
  it("separa notícias e eventos sem inventar datas", () => {
    const news = { ...base, official: true };
    const event = { ...base, category: "Evento comunitário" };
    expect(selectPublicPosts([base, news, event], "noticias", "Todas as cidades")).toEqual([news]);
    expect(selectPublicPosts([base, news, event], "agenda", "Todas as cidades")).toEqual([event]);
  });
});
