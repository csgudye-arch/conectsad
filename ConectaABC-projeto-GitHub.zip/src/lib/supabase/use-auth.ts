"use client";

import { useEffect, useMemo, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { getSupabaseBrowserClient } from "./client";

export type MemberProfile = {
  id: string;
  display_name: string;
  city: string | null;
  referral_code: string;
  leaderboard_public: boolean;
  avatar_path: string | null;
  avatar_public: boolean;
  created_at: string;
};

export function useSupabaseAuth() {
  const client = useMemo(() => getSupabaseBrowserClient(), []);
  const [user, setUser] = useState<User | null>(null);
  const [profileRecord, setProfileRecord] = useState<{
    userId: string;
    profile: MemberProfile | null;
    error: string;
  } | null>(null);
  const [loading, setLoading] = useState(Boolean(client));
  const [authNotice, setAuthNotice] = useState("");

  useEffect(() => {
    if (!client) {
      return;
    }

    let active = true;
    const callbackParams = new URLSearchParams(`${window.location.search.slice(1)}&${window.location.hash.replace(/^#/, "")}`);
    const callbackError = callbackParams.get("error_code") ?? callbackParams.get("error");
    if (callbackError) {
      const message = callbackError === "otp_expired" || callbackError === "access_denied"
        ? "Este link de confirmação expirou ou já foi usado. Solicite um novo link e abra-o uma única vez."
        : "Não foi possível confirmar o e-mail. Solicite um novo link e tente novamente.";
      queueMicrotask(() => { if (active) setAuthNotice(message); });
    }
    let settled = false;
    let timeout: number | undefined;
    const finishLoading = () => {
      if (!active || settled) return;
      settled = true;
      if (timeout !== undefined) window.clearTimeout(timeout);
      setLoading(false);
    };
    const { data: { subscription } } = client.auth.onAuthStateChange((_event, session) => {
      if (!active) return;
      setUser(session?.user ?? null);
      finishLoading();
    });

    if (!settled) {
      timeout = window.setTimeout(() => {
        if (!active || settled) return;
        setAuthNotice("A conexão de acesso demorou mais que o esperado. Atualize a página ou tente entrar novamente.");
        finishLoading();
      }, 10000);
    }
    void client.auth.getSession().then(({ data, error }) => {
      if (!active || settled) return;
      if (error) setAuthNotice("Não foi possível verificar sua sessão. Tente entrar novamente.");
      setUser(data.session?.user ?? null);
      finishLoading();
    }).catch(() => {
      if (!active || settled) return;
      setAuthNotice("Falha ao conectar com o serviço de acesso. Atualize a página ou tente novamente.");
      finishLoading();
    }).finally(() => window.clearTimeout(timeout));

    return () => {
      active = false;
      window.clearTimeout(timeout);
      subscription.unsubscribe();
    };
  }, [client]);

  useEffect(() => {
    if (!client || !user) return;

    let active = true;
    const profileFailure = () => {
      if (active) setProfileRecord({ userId: user.id, profile: null,
        error: "Não foi possível carregar seu perfil. Atualize a página ou tente novamente mais tarde." });
    };
    const profileTimeout = window.setTimeout(profileFailure, 10000);
    void Promise.resolve(client
      .from("profiles")
      .select("id, display_name, city, referral_code, leaderboard_public, avatar_path, avatar_public, created_at")
      .eq("id", user.id)
      .maybeSingle())
      .then(({ data, error }) => {
        if (!active) return;
        if (error) {
          setProfileRecord({
            userId: user.id,
            profile: null,
            error: "Sua conta entrou, mas não foi possível carregar o perfil. Atualize a página ou avise a equipe pelo menu de ajuda.",
          });
          return;
        }
        setProfileRecord({ userId: user.id, profile: data as MemberProfile | null, error: "" });
      }).catch(profileFailure).finally(() => window.clearTimeout(profileTimeout));

    return () => {
      active = false;
      window.clearTimeout(profileTimeout);
    };
  }, [client, user]);

  const currentProfile = user?.id === profileRecord?.userId ? profileRecord : null;

  async function refreshProfile() {
    if (!client || !user) return;
    const { data, error } = await client
      .from("profiles")
      .select("id, display_name, city, referral_code, leaderboard_public, avatar_path, avatar_public, created_at")
      .eq("id", user.id)
      .maybeSingle();
    setProfileRecord({
      userId: user.id,
      profile: (data as MemberProfile | null) ?? currentProfile?.profile ?? null,
      error: error ? "Não foi possível atualizar seu perfil agora. Tente novamente." : "",
    });
  }

  return {
    client,
    user,
    profile: currentProfile?.profile ?? null,
    profileLoading: Boolean(user && profileRecord?.userId !== user.id),
    loading,
    authNotice,
    profileError: currentProfile?.error ?? "",
    refreshProfile,
    isConfigured: Boolean(client),
    async signOut() {
      if (!client) return { error: new Error("Supabase não configurado.") };
      const { error } = await client.auth.signOut();
      return { error };
    },
  };
}
