import { describe, expect, it } from "vitest";
import { readableAuthError } from "./auth-errors";

describe("readableAuthError", () => {
  it("identifies email delivery failures without exposing the provider response", () => {
    for (const message of ["Error sending confirmation email", "535 5.7.8 Error: authentication failed"]) {
      const feedback = readableAuthError({ code: "unexpected_failure", status: 500, message });
      expect(feedback).toContain("não conseguiu enviar a mensagem");
      expect(feedback).not.toContain(message);
    }
  });

  it("distinguishes rate limiting, network errors and service failures from invalid credentials", () => {
    expect(readableAuthError({ code: "over_email_send_rate_limit", status: 429 })).toContain("Aguarde");
    expect(readableAuthError(new TypeError("Failed to fetch"))).toContain("Confira sua conexão");
    expect(readableAuthError({ code: "unexpected_failure", status: 500 })).toContain("serviço de acesso apresentou uma falha");
    expect(readableAuthError({ code: "invalid_credentials", status: 400 })).toBe("E-mail ou senha incorretos.");
  });
});
