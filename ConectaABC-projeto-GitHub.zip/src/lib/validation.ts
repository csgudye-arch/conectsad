import { z } from "zod";

z.config(z.locales.pt());

export const abcCities = [
  "Santo André",
  "São Bernardo do Campo",
  "São Caetano do Sul",
  "Diadema",
  "Mauá",
  "Ribeirão Pires",
  "Rio Grande da Serra",
] as const;

export const cityReportSchema = z.object({
  category: z.string().trim().min(1, "Selecione o tipo de problema.").max(50),
  city: z.enum(abcCities, "Selecione uma cidade do Grande ABC."),
  neighborhood: z.string().trim().max(80, "Use até 80 caracteres."),
  details: z.string().trim().min(15, "Conte um pouco mais (mínimo 15 caracteres).").max(2000, "Use até 2.000 caracteres."),
});

export const socialServiceRequestSchema = z.object({
  contact: z.string().trim().min(8, "Informe um telefone ou e-mail para retorno.").max(120, "Confira o contato informado."),
  city: z.string().min(1, "Selecione a cidade."),
  neighborhood: z.string().trim().max(80, "Use até 80 caracteres."),
  service: z.string().min(1, "Selecione o tipo de apoio."),
  details: z.string().trim().min(20, "Conte um pouco mais sobre o que precisa (mínimo 20 caracteres).")
    .max(1500, "Use até 1.500 caracteres."),
  consent: z.literal("on", "Autorize o contato para continuar."),
});

export const communityPostSchema = z.object({
  category: z.string("Escolha o tipo de publicação.").trim().min(1, "Escolha o tipo de publicação."),
  city: z.string().trim().min(1, "Selecione a cidade."),
  body: z.string().trim().min(10, "Escreva pelo menos 10 caracteres.").max(1200, "Use até 1.200 caracteres."),
});

export const officialPostSchema = z.object({
  title: z.string().trim().min(5, "Informe um título com pelo menos 5 caracteres.").max(120, "Use até 120 caracteres."),
  category: z.string().trim().min(1, "Escolha a categoria do comunicado."),
  city: z.string().trim().min(1, "Selecione o alcance do comunicado."),
  body: z.string().trim().min(30, "Escreva pelo menos 30 caracteres.").max(3000, "Use até 3.000 caracteres."),
  source: z.string().trim().min(3, "Informe a fonte ou referência.").max(300, "Use até 300 caracteres."),
  sensitive: z.boolean(),
});

export const marketplaceSearchSchema = z.object({
  query: z.string().trim().max(100),
  category: z.string().trim().max(50),
  city: z.string().trim().max(80),
});

export const marketplaceListingSchema = z.object({
  title: z.string().trim().min(5, "Informe um título com pelo menos 5 caracteres.").max(100),
  category: z.string().trim().min(2, "Escolha uma categoria.").max(50),
  city: z.enum(abcCities, "Selecione uma cidade do Grande ABC."),
  neighborhood: z.string().trim().max(80, "Use até 80 caracteres."),
  description: z.string().trim().min(20, "Descreva o anúncio com pelo menos 20 caracteres.").max(1200),
  price: z.number().nonnegative("O valor não pode ser negativo.").nullable(),
  contact: z.string().trim().min(8, "Informe um contato válido.").max(120),
});

export const animalReportSchema = z.object({
  reportType: z.enum(["perdido", "encontrado"], "Selecione se o animal está perdido ou foi encontrado."),
  name: z.string().trim().max(80),
  species: z.string().trim().min(2, "Informe a espécie.").max(40),
  city: z.enum(abcCities, "Selecione uma cidade do Grande ABC."),
  neighborhood: z.string().trim().max(80),
  description: z.string().trim().min(20, "Descreva o animal e a situação (mínimo 20 caracteres). ").max(1200),
  contact: z.string().trim().min(8, "Informe um contato válido.").max(120),
});
