import { describe, expect, it } from "vitest";
import { cityReportSchema, communityPostSchema, officialPostSchema, marketplaceSearchSchema } from "./validation";

describe("validação dos formulários do Conecta ABC", () => {
  it("orienta em português quando o seletor de assunto não foi preenchido", () => {
    const result = communityPostSchema.safeParse({ category: null, city: "Santo André", body: "Publicação com conteúdo suficiente." });
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.issues[0].message).toBe("Escolha o tipo de publicação.");
  });
  it("aceita um relato com informações mínimas válidas", () => {
    expect(cityReportSchema.safeParse({ category: "Iluminação pública", city: "Santo André", neighborhood: "Centro", details: "A iluminação está apagada há três dias." }).success).toBe(true);
  });

  it("rejeita relato curto e cidade fora do Grande ABC", () => {
    const result = cityReportSchema.safeParse({ category: "Iluminação", city: "São Paulo", neighborhood: "", details: "Curto" });
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.issues.length).toBeGreaterThanOrEqual(2);
  });

  it("limita os termos de busca para reduzir entradas excessivas", () => {
    expect(marketplaceSearchSchema.safeParse({ query: "bicicleta", category: "Bicicletas", city: "Santo André" }).success).toBe(true);
    expect(marketplaceSearchSchema.safeParse({ query: "x".repeat(101), category: "Todos", city: "Santo André" }).success).toBe(false);
  });

  it("valida publicação comunitária e limita o tamanho do texto", () => {
    expect(communityPostSchema.safeParse({ category: "Evento comunitário", city: "Santo André", body: "Convite para participar da reunião do bairro neste sábado." }).success).toBe(true);
    expect(communityPostSchema.safeParse({ category: "", city: "", body: "curto" }).success).toBe(false);
    expect(communityPostSchema.safeParse({ category: "Conversa do bairro", city: "Mauá", body: "x".repeat(1201) }).success).toBe(false);
  });

  it("exige referência e contexto em comunicado oficial", () => {
    const post = { title: "Atualização de serviço municipal", category: "Informação pública", city: "Grande ABC", body: "A equipe informa a atualização do serviço e orienta os moradores sobre os próximos passos.", source: "Portal oficial · 22/10/2026", sensitive: false };
    expect(officialPostSchema.safeParse(post).success).toBe(true);
    expect(officialPostSchema.safeParse({ ...post, source: "" }).success).toBe(false);
    expect(officialPostSchema.safeParse({ ...post, body: "Muito curto" }).success).toBe(false);
    expect(officialPostSchema.safeParse({ ...post, sensitive: true }).success).toBe(true);
  });
});
