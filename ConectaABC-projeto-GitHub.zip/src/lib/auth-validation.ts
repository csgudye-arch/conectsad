export const GRANDE_ABC_CITIES = [
  "Santo André",
  "São Bernardo do Campo",
  "São Caetano do Sul",
  "Diadema",
  "Mauá",
  "Ribeirão Pires",
  "Rio Grande da Serra",
] as const;

export type SignupFields = {
  displayName: string;
  city: string;
  email: string;
  password: string;
  passwordConfirmation: string;
  consented: boolean;
};

export function isValidEmail(email: string) {
  return email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function validateSignupInput(fields: SignupFields): string {
  const name = fields.displayName.trim();
  if (name.length < 2 || name.length > 80) return "Informe seu nome com 2 a 80 caracteres.";
  if (!GRANDE_ABC_CITIES.includes(fields.city as (typeof GRANDE_ABC_CITIES)[number])) return "Selecione uma cidade do Grande ABC.";
  if (!isValidEmail(fields.email.trim())) return "Informe um e-mail válido.";
  if (fields.password.length < 8) return "A senha precisa ter pelo menos 8 caracteres.";
  if (fields.password !== fields.passwordConfirmation) return "As senhas não são iguais.";
  if (!fields.consented) return "Confirme a autorização para criar seu perfil.";
  return "";
}

export function validateEmailInput(email: string): string {
  return isValidEmail(email.trim()) ? "" : "Informe um e-mail válido.";
}
