"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useSocial, socialError } from "@/components/SocialFeatures";

export function useCommunityResource<T>(rpc: string, args: Record<string,unknown> = {}, enabled = true) {
  const { client, userId, openAuth } = useSocial();
  const argsKey = JSON.stringify(args);
  const sequence = useRef(0);
  const uncertain=useRef(false);
  const [data,setData] = useState<T|null>(null), [loading,setLoading] = useState(enabled), [busy,setBusy] = useState(false);
  const [error,setError] = useState(""), [notice,setNotice] = useState("");
  const invalidate = useCallback(() => { sequence.current++; }, []);
  const refresh = useCallback(async () => {
    if (!enabled) { setLoading(false); return; }
    if (!client) { setError("Conexão indisponível."); setLoading(false); return; }
    const attempt=++sequence.current; setLoading(true); setError("");
    try { const result=await client.rpc(rpc,JSON.parse(argsKey)); if(attempt!==sequence.current)return; if(result.error)throw result.error; setData(result.data); }
    catch(err) { if(attempt===sequence.current)setError(socialError(err)); }
    finally { if(attempt===sequence.current)setLoading(false); }
  },[client,rpc,argsKey,enabled]);
  useEffect(()=>{const timer=window.setTimeout(()=>void refresh(),0);return()=>{window.clearTimeout(timer);invalidate();};},[refresh,invalidate]);
  async function act(name:string,params:Record<string,unknown>,message:string) {
    if(!client||!userId){openAuth();return false;} setBusy(true);setError("");setNotice("");uncertain.current=false;
    try{const result=await client.rpc(name,params);if(result.error)throw result.error;setNotice(message);await refresh();return true;}
    catch(err){uncertain.current=!(err as {code?:string})?.code;setError(uncertain.current?"Não foi possível confirmar o envio. Atualize sua lista antes de tentar novamente.":socialError(err));return false;}finally{setBusy(false);}
  }
  return {client,userId,openAuth,data,loading,busy,error,notice,setError,setNotice,refresh,act,actionWasUncertain:()=>uncertain.current};
}
