"use client";
import { useEffect, useState } from "react";

/** Atualiza controles de prazo sem depender de uma renderização incidental. */
export function useCurrentTime() {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const interval = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(interval);
  }, []);
  return now;
}
