import { describe, expect, it } from "vitest";
import { eventCalendar } from "./event-calendar";
const event={id:"11111111-1111-4111-8111-111111111111",title:"Evento comunitário",description:"Informações do evento.",venue:"Parque público",city:"Santo André",starts_at:"2026-12-01T18:00:00-03:00",ends_at:"2026-12-01T19:00:00-03:00"};
describe("exportação de calendário",()=>{
 it("preserva o instante em UTC",()=>expect(eventCalendar(event)).toContain("DTSTART:20261201T210000Z"));
 it("escapa texto para impedir injeção de campos",()=>{const result=eventCalendar({...event,title:"Teste\r\nATTENDEE:intruso",description:"vírgula, ponto; barra\\"});expect(result).not.toContain("\r\nATTENDEE:");expect(result).toContain("DESCRIPTION:vírgula\\, ponto\\; barra\\\\");});
 it("dobra linhas longas por bytes sem corromper Unicode",()=>{const result=eventCalendar({...event,title:"São André ".repeat(12)});for(const line of result.split("\r\n"))expect(new TextEncoder().encode(line).length).toBeLessThanOrEqual(75);expect(result.replace(/\r\n /g,"")).toContain("São André ".repeat(12));});
 it("rejeita datas inválidas e término anterior",()=>{expect(()=>eventCalendar({...event,starts_at:"inválido"})).toThrow();expect(()=>eventCalendar({...event,ends_at:event.starts_at})).toThrow();});
});
