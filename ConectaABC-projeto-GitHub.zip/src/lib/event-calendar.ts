export type CalendarEvent = { id: string; title: string; description: string; venue: string; city: string; starts_at: string; ends_at: string };
const escapeText = (value: string) => value.replace(/\\/g, "\\\\").replace(/\r\n|\r|\n/g, "\\n").replace(/;/g, "\\;").replace(/,/g, "\\,");
function stamp(value: string | Date) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) throw new Error("Data inválida no evento.");
  return date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
}
// RFC 5545: dobra por bytes UTF-8, sem quebrar caracteres acentuados.
function fold(line: string) {
  const parts: string[] = []; let part = ""; let bytes = 0;
  for (const character of line) {
    const size = new TextEncoder().encode(character).length;
    if (bytes + size > 75) { parts.push(part); part = " "; bytes = 1; }
    part += character; bytes += size;
  }
  parts.push(part); return parts.join("\r\n");
}
export function eventCalendar(event: CalendarEvent, now = new Date()) {
  if (!/^[0-9a-f-]{36}$/i.test(event.id) || new Date(event.ends_at) <= new Date(event.starts_at)) throw new Error("Evento inválido.");
  return ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Conecta ABC//Agenda//PT-BR", "CALSCALE:GREGORIAN", "BEGIN:VEVENT", `UID:${event.id}@conectaabc.com`, `DTSTAMP:${stamp(now)}`, `DTSTART:${stamp(event.starts_at)}`, `DTEND:${stamp(event.ends_at)}`, `SUMMARY:${escapeText(event.title)}`, `DESCRIPTION:${escapeText(event.description)}`, `LOCATION:${escapeText(`${event.venue}, ${event.city}`)}`, "END:VEVENT", "END:VCALENDAR"].map(fold).join("\r\n") + "\r\n";
}
