> Migração visual de 06/11/2026: consulte [estado atual, recursos e verificações](docs/layout-migration/ESTADO-ATUAL.md). As seções históricas abaixo não substituem esse estado consolidado.

# Conecta ABC

Plataforma comunitária para os sete municípios do Grande ABC. Marca institucional: SAD. Slogan: **O Grande ABC conectado.**

## Arquitetura escolhida

O workspace estava vazio. A base usa **Next.js App Router, React e TypeScript**, com **Tailwind CSS 4** e estilos próprios para construir a identidade preta, cinza e amarela do Conecta ABC. É uma base adequada para evoluir para páginas renderizadas no servidor e módulos autenticados. Zod valida os formulários na interface. As dependências estão fixadas no `package.json`; instale-as com pnpm para gerar o lockfile local.

Cadastro/login, Feed, relatos da cidade, avisos de animais, anúncios/vagas, solicitações de serviço e candidaturas de parceiros têm formulários de envio ao Supabase. Todos exigem login; publicações ficam pendentes até revisão e pedidos com dados de contato são privados. Pontos são registrados por funções seguras do banco. Para que os envios funcionem no site público, publique o build atual e aplique as migrações `001` a `010` na ordem. O upload de imagens, publicação de ofertas pelo parceiro, pagamentos e resgate do prêmio de R$ 500 ainda não estão ativos. Veja [docs/supabase-setup.md](docs/supabase-setup.md) para os passos e os limites desta etapa.

## Aplicativos Android e iOS

A interface web é empacotada com Capacitor para gerar projetos nativos Android e iOS. O build do Next.js é exportado para `out/` e sincronizado com as plataformas.

```bash
pnpm install
pnpm build
pnpm cap:add:android
pnpm cap:add:ios
pnpm assets:generate
pnpm cap:sync
pnpm cap:open:android
pnpm cap:open:ios
```

Requisitos nativos: Android Studio com JDK/Android SDK para compilar e assinar Android; macOS com Xcode para compilar e assinar iOS. Este projeto contém os projetos `android/` e `ios/`, além dos ícones e telas de abertura. O script `pnpm assets:generate` regenera os recursos a partir de `public/conecta-abc-mark.svg`. Android Studio consegue gerar APK/AAB. iOS precisa de Xcode para gerar e enviar o build ao App Store Connect. O identificador do app está definido em `capacitor.config.ts` e deve ser confirmado antes da publicação, pois costuma ser permanente nas lojas.

Foram incluídos ajustes de viewport, ícones PWA/iOS, alvos de toque e cache de assets. A configuração e os limites de segurança, proteção de tráfego e fila estão descritos em [docs/mobile-scalability-security.md](docs/mobile-scalability-security.md). O projeto ainda não possui sala de espera nem fila de processamento ativa.

Os envios autenticados contam com limites por conta após aplicar a migração `supabase/migrations/202611040001_authenticated_submission_limits.sql`. Para uma verificação de leitura controlada em localhost/preview: `pnpm load:smoke -- http://localhost:3000/ 8 15`. O script bloqueia o domínio público e não mede o Supabase.

Esta etapa prepara o empacotamento, não significa que o app esteja aprovado ou pronto para publicação. As telas ainda contêm dados de demonstração e serviços sem backend. Antes de enviar, conecte autenticação e dados reais, faça testes em dispositivos, configure ícones, privacidade, termos, suporte, conta de revisão e declarações de dados. A Apple exige utilidade e experiência além de um site empacotado; ambas as lojas exigem funcionalidade estável e conteúdo suficiente.

## Executar localmente

Requisitos: Node.js 20.9 ou superior e pnpm.

```bash
pnpm install
pnpm dev
```

Abra `http://localhost:3000`.

### Cadastro, login e Google

- A tela dedicada fica em `http://localhost:3000/login`; o app também abre o mesmo acesso pelo ícone de perfil. O cadastro coleta nome, cidade do Grande ABC, e-mail e senha (com confirmação). CPF e telefone não são coletados no cadastro inicial. O primeiro acesso com Google completa o perfil em `/login/complete-profile`.
- Aplique `supabase/migrations/202611020003_auth_signup_profile.sql` no SQL Editor do Supabase para gravar nome/cidade após cadastro por e-mail ou Google.
- Para login Google, crie um cliente OAuth do tipo Web no Google Cloud Console. Em **Supabase → Authentication → Sign In / Providers → Google**, habilite o provedor e guarde Client ID e Client Secret somente no painel Supabase. Não os coloque em `.env.local` ou no frontend.
- No Google Cloud, configure o URI de redirecionamento mostrado pelo Supabase (formato `https://<project-ref>.supabase.co/auth/v1/callback`). O OAuth externo ainda exige concluir a página de branding, publicar o app e, conforme os escopos e as regras do Google, concluir a verificação.
- Em **Supabase → Authentication → URL Configuration**, use `https://conectaabc.com` como Site URL e permita `https://conectaabc.com/**`, `https://conecta-abc.netlify.app/**` e `http://localhost:3000/**` em Redirect URLs.
- Confirmação de e-mail e redefinição de senha dependem de links permitidos nessa configuração e de entrega de e-mail ativa no Supabase. Teste em janela anônima depois de publicar.
- O app aceita confirmação por OTP quando o modelo do Supabase usa `{{ .Token }}`. Para configurar SMTP e o modelo Conecta ABC, siga [docs/supabase-confirmacao-otp.md](docs/supabase-confirmacao-otp.md). Sem isso, a confirmação segue pelo link padrão do e-mail.

Consulte a [documentação oficial do Supabase para Google OAuth](https://supabase.com/docs/guides/auth/social-login/auth-google) e [Redirect URLs](https://supabase.com/docs/guides/auth/redirect-urls). A interface não declara Google ativo até o provedor estar configurado e testado.

## Hospedar publicamente

O projeto já está configurado para exportação estática em `out/` e inclui [netlify.toml](netlify.toml). O caminho preparado é Netlify: Vercel Hobby é limitado a uso pessoal ou não comercial; o plano Free atual do Netlify custa US$ 0, inclui 300 créditos mensais e pausa o site quando o limite é excedido.

Para publicar manualmente a partir deste computador:

1. Crie/acesse uma conta em [Netlify](https://app.netlify.com/) e entre no CLI com `pnpm dlx netlify-cli login`.
2. Garanta que `.env.local` tenha apenas `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`; não use a service role key.
3. Rode `pnpm build` e depois `pnpm dlx netlify-cli deploy --dir=out --prod`. Na primeira publicação, o Netlify pedirá para criar um site; escolha um nome disponível para gerar o link público `*.netlify.app`.
4. No Supabase, defina **Authentication → URL Configuration → Site URL** como o link de produção e adicione esse mesmo endereço às **Redirect URLs** para confirmação de e-mail.
5. Abra o link público em janela anônima e confira login/cadastro, navegação e leitura do conteúdo público.

Cada alteração futura deve ser compilada e publicada novamente com os passos 3 e 5. O deploy manual envia apenas `out/`; o `.env.local` não deve ser enviado ao provedor. A chave publicável do Supabase é incluída no JavaScript final por ser uma chave pública; RLS permanece obrigatória. A publicação expõe a interface e seus exemplos para qualquer pessoa, mas não transforma os módulos demonstrativos em serviços ativos.

## Verificações

```bash
pnpm typecheck
pnpm lint
pnpm test
pnpm build
```

## O que a interface inclui

- Navegação lateral e navegação compacta para celular.
- Página inicial com atalhos para todos os módulos.
- Mercadão com busca, filtro por categoria e cidade, favoritos locais e estados vazios.
- Formulário de relato urbano com validação Zod no cliente e aviso de privacidade.
- Páginas demonstrativas para Clube, parceiros, Animais Perdidos, SAD Pontua, Serviços, Portal do parceiro e Administração.
- Feed comunitário ligado ao Supabase: leitura de publicações permitidas por RLS e envio autenticado para moderação.
- Problemas da cidade ligado ao Supabase: relatos autenticados privados enquanto pendentes e acompanhamento público após mudança de status autorizada.
- Mercadão, avisos de animais, pedidos de serviços e cadastro de parceiros enviam registros ao banco; anúncios e avisos precisam de moderação, enquanto solicitações e contatos ficam protegidos.
- Estados de demonstração explícitos; ações que dependem de servidor informam que ainda precisam ser configuradas.

## Próximas etapas técnicas

1. Aplicar a migração de moderação e cadastrar as contas autorizadas no projeto Supabase.
2. Ligar solicitações sociais a dados reais e configurar upload privado/validado para imagens de relatos.
3. Persistir reações, denúncias e pontuação por funções confiáveis; adicionar testes de regras críticas no servidor.
4. Integrar pagamentos recorrentes apenas com credenciais do responsável, webhooks autenticados e idempotência.

Copie `.env.example` para `.env.local` apenas quando os serviços forem configurados. Não coloque `SUPABASE_SERVICE_ROLE_KEY`, tokens ou segredos em componentes client-side.

## Migração social — novembro de 2026

O estado atual e as pendências estão em [MIGRACAO-CONECTA-ABC.md](MIGRACAO-CONECTA-ABC.md), que substitui as descrições históricas de demonstração acima. O layout usa dados reais aprovados e estados vazios; exemplos não são publicados.

Comentários, salvos, amizades, notificações, enquetes, comunidades e agenda estruturada foram adicionados. As três migrações `202611060001` a `202611060003` já foram aplicadas no projeto Supabase existente; não as repita nesse banco. Para um banco novo, aplique as dependências anteriores primeiro. Não execute o SQL ilustrativo de `docs/layout-migration` como migração.

Para desenvolver: `pnpm dev` e abrir `http://localhost:3000`. Para revisar a exportação: `pnpm build`, `node tmp/serve-layout.cjs` e abrir `http://localhost:3100`. A prévia usa o banco configurado; envios reais serão gravados nele. O arquivo ZIP de implantação deve conter somente `out/`, sem credenciais ou código de migração.

Verificações adicionais: `node scripts/test-social-db.mjs` (PostgreSQL isolado; instalação indicada no documento de migração). Os novos painéis são `/equipe/comentarios`, `/equipe/comunidades` e `/equipe/agenda`, com autorização no servidor. O site público ainda não recebeu esta migração visual.

