-- Preserve saldos antigos. Novos apoios anônimos não revelam autor por variação no ranking.
begin;
create or replace function public.list_public_community_posts()
returns table (
  id uuid,
  author_id uuid,
  category text,
  city text,
  body text,
  status text,
  created_at timestamptz,
  title text,
  source text,
  sensitive boolean,
  is_official boolean,
  is_anonymous boolean,
  media_path text,
  media_kind text
)
language sql
stable
security definer
set search_path = ''
as $$
  select p.id,
    case when p.is_anonymous then null else p.author_id end,
    p.category, p.city, p.body, p.status, p.created_at, p.title, p.source,
    p.sensitive, p.is_official, p.is_anonymous, case when p.is_anonymous and p.status='approved' then null else p.media_path end, p.media_kind
  from public.community_posts p
  where p.status = 'approved' or p.author_id = (select auth.uid())
  order by p.created_at desc
  limit 50;
$$;

revoke all on function public.list_public_community_posts() from public;
grant execute on function public.list_public_community_posts() to anon, authenticated;


create or replace function public.social_public_post(target_post uuid) returns jsonb language sql stable security definer set search_path='' as $$ select jsonb_build_object('id',p.id,'author_id',case when p.is_anonymous then null else p.author_id end,'category',p.category,'city',p.city,'body',p.body,'status',p.status,'created_at',p.created_at,'title',p.title,'source',p.source,'sensitive',p.sensitive,'is_official',p.is_official,'is_anonymous',p.is_anonymous,'media_path',case when p.is_anonymous then null else p.media_path end,'media_kind',p.media_kind) from public.community_posts p where p.id=target_post and p.status='approved' $$;

-- Acesso a anexos sem reabrir SELECT direto na tabela do Feed.


create or replace function public.can_access_feed_media(object_name text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select
    (select auth.uid())::text = (storage.foldername(object_name))[1]
    or exists (
      select 1 from public.community_posts p
      where p.media_path = object_name
        and ((p.status = 'approved' and not p.is_anonymous) or p.author_id = (select auth.uid()))
    )
    or (
      (select auth.uid()) is not null
      and exists (select 1 from public.community_moderators m where m.user_id = (select auth.uid()))
      and exists (select 1 from public.community_posts p where p.media_path = object_name and p.status = 'pending')
    );
$$;

revoke all on function public.can_access_feed_media(text) from public;
grant execute on function public.can_access_feed_media(text) to anon, authenticated;

drop policy if exists "Members view feed media they may access" on storage.objects;
create policy "Members view feed media they may access"
  on storage.objects for select to anon, authenticated
  using (bucket_id = 'feed-media' and public.can_access_feed_media(name));



create or replace function public.toggle_community_post_reaction(post_id uuid)
returns table (
  liked boolean,
  reaction_count bigint,
  points_awarded integer,
  author_points_awarded integer
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  member_id uuid := auth.uid();
  post_author_id uuid;
  anonymous_post boolean;
  award_id uuid;
  removed integer := 0;
  inserted integer := 0;
  award_rows integer := 0;
  liker_ledger_rows integer := 0;
  author_ledger_rows integer := 0;
  granted_points integer := 0;
  granted_author_points integer := 0;
begin
  if member_id is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended(member_id::text || ':' || post_id::text, 0)
  );

  select p.author_id,p.is_anonymous into post_author_id,anonymous_post
  from public.community_posts p
  where p.id = toggle_community_post_reaction.post_id
    and p.status = 'approved';
  if not found then
    raise exception 'Post is not available for reactions' using errcode = 'P0002';
  end if;
  if post_author_id = member_id then
    raise exception 'You cannot earn points for supporting your own post' using errcode = 'P0001';
  end if;

  delete from public.community_post_reactions r
  where r.post_id = toggle_community_post_reaction.post_id
    and r.user_id = member_id;
  get diagnostics removed = row_count;

  if removed = 0 then
    insert into public.community_post_reactions (post_id, user_id)
    values (toggle_community_post_reaction.post_id, member_id)
    on conflict on constraint community_post_reactions_pkey do nothing;
    get diagnostics inserted = row_count;

    if inserted = 1 then
      insert into public.feed_reaction_point_awards (post_id, supporter_id, post_author_id)
      values (toggle_community_post_reaction.post_id, member_id, post_author_id)
      on conflict on constraint feed_reaction_point_awards_post_id_supporter_id_key do nothing
      returning id into award_id;
      get diagnostics award_rows = row_count;

      if award_rows = 1 then
        insert into public.points_ledger (user_id, event_type, points, evidence_id)
        values (member_id, 'feed_like', 3, toggle_community_post_reaction.post_id)
        on conflict do nothing;
        get diagnostics liker_ledger_rows = row_count;
        if liker_ledger_rows = 1 then granted_points := 3; end if;

        if not anonymous_post then
        insert into public.points_ledger (user_id, event_type, points, evidence_id)
        values (post_author_id, 'feed_like_received', 1, award_id);
        get diagnostics author_ledger_rows = row_count;
        if author_ledger_rows = 1 then granted_author_points := 1; end if;
        end if;
      end if;
    end if;
  end if;

  return query
    select exists (
      select 1 from public.community_post_reactions r
      where r.post_id = toggle_community_post_reaction.post_id
        and r.user_id = member_id
    ),
    (
      select count(*)::bigint from public.community_post_reactions r
      where r.post_id = toggle_community_post_reaction.post_id
    ),
    granted_points,
    granted_author_points;
end;
$$;


commit;
