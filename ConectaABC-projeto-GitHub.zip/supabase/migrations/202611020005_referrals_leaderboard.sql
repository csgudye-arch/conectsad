-- Atribuição de indicação sem armazenar CPF. A equipe verifica o documento fora do
-- aplicativo e registra apenas o resultado da verificação.
alter table public.profiles
  add column if not exists leaderboard_public boolean not null default false;
grant update (leaderboard_public) on public.profiles to authenticated;

create table if not exists public.referral_attributions (
  referred_user_id uuid primary key references public.profiles (id) on delete cascade,
  referrer_user_id uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  email_confirmed_at timestamptz,
  cpf_verified_at timestamptz,
  points_awarded_at timestamptz,
  check (referred_user_id <> referrer_user_id)
);
create index if not exists referral_attributions_referrer_idx
  on public.referral_attributions (referrer_user_id, created_at desc);
alter table public.referral_attributions enable row level security;
revoke all on public.referral_attributions from anon, authenticated;

create table if not exists public.referral_verifiers (
  user_id uuid primary key references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.referral_verifiers enable row level security;
revoke all on public.referral_verifiers from anon, authenticated;

create or replace function public.create_profile_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  requested_city text := nullif(trim(new.raw_user_meta_data ->> 'city'), '');
  requested_name text := coalesce(
    nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''),
    nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''),
    nullif(trim(new.raw_user_meta_data ->> 'name'), '')
  );
  referral_code_input text := upper(nullif(trim(new.raw_user_meta_data ->> 'referral_code'), ''));
  referrer_id uuid;
begin
  insert into public.profiles (id, display_name, city)
  values (
    new.id,
    coalesce(left(requested_name, 80), 'Novo membro'),
    case when requested_city in (
      'Santo André', 'São Bernardo do Campo', 'São Caetano do Sul',
      'Diadema', 'Mauá', 'Ribeirão Pires', 'Rio Grande da Serra'
    ) then requested_city else null end
  );

  if referral_code_input is not null and referral_code_input ~ '^[A-F0-9]{10}$' then
    select id into referrer_id from public.profiles
    where referral_code = referral_code_input and id <> new.id;
    if referrer_id is not null then
      insert into public.referral_attributions (referred_user_id, referrer_user_id)
      values (new.id, referrer_id)
      on conflict (referred_user_id) do nothing;
    end if;
  end if;
  return new;
end;
$$;
revoke all on function public.create_profile_for_new_user() from public, anon, authenticated;

create or replace function public.record_referral_email_confirmation()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if old.email_confirmed_at is null and new.email_confirmed_at is not null then
    update public.referral_attributions
      set email_confirmed_at = new.email_confirmed_at
      where referred_user_id = new.id and email_confirmed_at is null;
  end if;
  return new;
end;
$$;
revoke all on function public.record_referral_email_confirmation() from public, anon, authenticated;
drop trigger if exists on_referral_email_confirmed on auth.users;
create trigger on_referral_email_confirmed
  after update of email_confirmed_at on auth.users
  for each row execute function public.record_referral_email_confirmation();

create or replace function public.award_verified_referral_points()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if old.cpf_verified_at is null and new.cpf_verified_at is not null
     and new.email_confirmed_at is not null and new.points_awarded_at is null then
    insert into public.points_ledger (user_id, event_type, points, evidence_id)
    values (new.referrer_user_id, 'verified_referral', 10, new.referred_user_id);
    update public.referral_attributions
      set points_awarded_at = now()
      where referred_user_id = new.referred_user_id;
  end if;
  return new;
end;
$$;
revoke all on function public.award_verified_referral_points() from public, anon, authenticated;
drop trigger if exists on_referral_cpf_verified on public.referral_attributions;
create trigger on_referral_cpf_verified
  after update of cpf_verified_at on public.referral_attributions
  for each row execute function public.award_verified_referral_points();

create or replace function public.verify_referral_cpf(referred_id uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  changed integer;
begin
  if auth.uid() is null or not exists (
    select 1 from public.referral_verifiers where user_id = auth.uid()
  ) then
    raise exception 'Not authorized to verify referrals';
  end if;
  update public.referral_attributions
    set cpf_verified_at = now()
    where referred_user_id = referred_id
      and email_confirmed_at is not null
      and cpf_verified_at is null;
  get diagnostics changed = row_count;
  return changed = 1;
end;
$$;
revoke all on function public.verify_referral_cpf(uuid) from public, anon;
grant execute on function public.verify_referral_cpf(uuid) to authenticated;

create or replace function public.get_my_referral_summary()
returns table (registered bigint, email_confirmed bigint, awaiting_cpf bigint, validated bigint)
language sql
security definer
set search_path = ''
as $$
  select count(*),
    count(*) filter (where r.email_confirmed_at is not null),
    count(*) filter (where r.email_confirmed_at is not null and r.cpf_verified_at is null),
    count(*) filter (where r.points_awarded_at is not null)
  from public.referral_attributions r
  where r.referrer_user_id = auth.uid();
$$;
revoke all on function public.get_my_referral_summary() from public, anon;
grant execute on function public.get_my_referral_summary() to authenticated;

create or replace function public.get_public_leaderboard()
returns table (rank_position bigint, display_name text, city text, points bigint)
language sql
security definer
set search_path = ''
as $$
  select row_number() over (order by totals.points desc, totals.display_name)::bigint,
    totals.display_name, totals.city, totals.points
  from (
    select p.display_name, p.city, coalesce(sum(l.points), 0)::bigint as points
    from public.profiles p
    left join public.points_ledger l on l.user_id = p.id
    where p.leaderboard_public = true
    group by p.id, p.display_name, p.city
  ) totals
  order by totals.points desc, totals.display_name
  limit 50;
$$;
revoke all on function public.get_public_leaderboard() from public, anon;
grant execute on function public.get_public_leaderboard() to authenticated;
