-- Reações persistentes no Feed. A interface não recebe a lista de usuários que reagiram.
create table if not exists public.community_post_reactions (
  post_id uuid not null references public.community_posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

alter table public.community_post_reactions enable row level security;
revoke all on public.community_post_reactions from anon, authenticated;

create or replace function public.get_community_post_reaction_summary(post_ids uuid[])
returns table(post_id uuid, reaction_count bigint, liked boolean)
language plpgsql
security definer
set search_path = ''
stable
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  return query
    select p.id,
      count(r.user_id)::bigint,
      coalesce(bool_or(r.user_id = auth.uid()), false)
    from public.community_posts p
    left join public.community_post_reactions r on r.post_id = p.id
    where p.id = any(post_ids)
      and p.status = 'approved'
    group by p.id;
end;
$$;
revoke all on function public.get_community_post_reaction_summary(uuid[]) from public, anon;
grant execute on function public.get_community_post_reaction_summary(uuid[]) to authenticated;

create or replace function public.toggle_community_post_reaction(post_id uuid)
returns table(liked boolean, reaction_count bigint)
language plpgsql
security definer
set search_path = ''
as $$
declare
  member_id uuid := auth.uid();
  removed integer;
begin
  if member_id is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;
  if not exists (
    select 1 from public.community_posts p
    where p.id = toggle_community_post_reaction.post_id and p.status = 'approved'
  ) then
    raise exception 'Post is not available for reactions' using errcode = 'P0002';
  end if;

  delete from public.community_post_reactions r
    where r.post_id = toggle_community_post_reaction.post_id and r.user_id = member_id;
  get diagnostics removed = row_count;
  if removed = 0 then
    insert into public.community_post_reactions(post_id, user_id)
    values (toggle_community_post_reaction.post_id, member_id)
    on conflict (post_id, user_id) do nothing;
  end if;

  return query
    select exists (
      select 1 from public.community_post_reactions r
      where r.post_id = toggle_community_post_reaction.post_id and r.user_id = member_id
    ),
    (select count(*)::bigint from public.community_post_reactions r where r.post_id = toggle_community_post_reaction.post_id);
end;
$$;
revoke all on function public.toggle_community_post_reaction(uuid) from public, anon;
grant execute on function public.toggle_community_post_reaction(uuid) to authenticated;
