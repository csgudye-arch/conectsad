begin;
create table public.social_place_visits(place_id uuid not null references public.community_places(id) on delete cascade,user_id uuid not null references public.profiles(id) on delete cascade,visited_on date not null default (now() at time zone 'America/Sao_Paulo')::date,created_at timestamptz not null default now(),primary key(place_id,user_id,visited_on));
create table public.social_place_reviews(id uuid primary key default gen_random_uuid(),place_id uuid not null references public.community_places(id) on delete cascade,user_id uuid not null references public.profiles(id) on delete cascade,rating integer not null check(rating between 1 and 5),body text not null check(char_length(body) between 10 and 500),status text not null default 'pending' check(status in ('pending','approved','rejected')),created_at timestamptz not null default now(),updated_at timestamptz not null default now(),unique(place_id,user_id));
create table public.social_place_review_audit(id bigint generated always as identity primary key,review_id uuid not null references public.social_place_reviews(id) on delete cascade,moderator_id uuid not null references auth.users(id),decision text not null,reason text not null,created_at timestamptz not null default now());
alter table public.social_place_visits enable row level security;alter table public.social_place_reviews enable row level security;alter table public.social_place_review_audit enable row level security;
revoke all on public.social_place_visits,public.social_place_reviews,public.social_place_review_audit from public,anon,authenticated;
create function public.social_checkin_place(target_place uuid) returns void language plpgsql security definer set search_path='' as $$
declare day date:=(now() at time zone 'America/Sao_Paulo')::date;
begin
 if auth.uid() is null then raise exception 'Entre para registrar uma visita.' using errcode='42501';end if;
 if not exists(select 1 from public.community_places where id=target_place and status='approved') then raise exception 'Local indisponível.' using errcode='P0002';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,460));
 if exists(select 1 from public.social_place_visits where place_id=target_place and user_id=auth.uid() and visited_on=day) then return;end if;
 if (select count(*) from public.social_place_visits where user_id=auth.uid() and visited_on=day)>=5 then raise exception 'Você já registrou cinco visitas hoje.' using errcode='P0001';end if;
 insert into public.social_place_visits(place_id,user_id,visited_on) values(target_place,auth.uid(),day);
end; $$;
create function public.social_rate_place(target_place uuid,place_rating integer,review_body text) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para avaliar um local.' using errcode='42501';end if;
 if not exists(select 1 from public.community_places where id=target_place and status='approved') then raise exception 'Local indisponível.' using errcode='P0002';end if;
 if place_rating is null or place_rating not between 1 and 5 or review_body is null or char_length(trim(review_body)) not between 10 and 500 then raise exception 'Selecione uma nota de 1 a 5 e escreva de 10 a 500 caracteres.' using errcode='22023';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,461));
 if exists(select 1 from public.social_place_reviews where user_id=auth.uid() and place_id=target_place and updated_at>now()-interval '5 minutes') then raise exception 'Aguarde cinco minutos antes de alterar esta avaliação.' using errcode='P0001';end if;
 if (select count(*) from public.social_place_reviews where user_id=auth.uid() and updated_at>now()-interval '24 hours')>=5 then raise exception 'Limite de cinco avaliações por 24 horas atingido.' using errcode='P0001';end if;
 insert into public.social_place_reviews(place_id,user_id,rating,body) values(target_place,auth.uid(),place_rating,trim(review_body)) on conflict(place_id,user_id) do update set rating=excluded.rating,body=excluded.body,status='pending',updated_at=now();
end; $$;
create function public.social_place_activity(target_place uuid) returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('average_rating',(select round(avg(rating),1) from public.social_place_reviews where place_id=p.id and status='approved'),'review_count',(select count(*) from public.social_place_reviews where place_id=p.id and status='approved'),'visited_today',exists(select 1 from public.social_place_visits where place_id=p.id and user_id=auth.uid() and visited_on=(now() at time zone 'America/Sao_Paulo')::date),'places_visited',(select count(distinct place_id) from public.social_place_visits where user_id=auth.uid()),'reviews',coalesce((select jsonb_agg(to_jsonb(x)) from (select r.id,r.rating,r.body,r.status,r.updated_at,split_part(trim(pr.display_name),' ',1) first_name,coalesce(r.user_id=auth.uid(),false) is_own from public.social_place_reviews r join public.profiles pr on pr.id=r.user_id where r.place_id=p.id and (r.status='approved' or r.user_id=auth.uid()) order by r.updated_at desc limit 50) x),'[]'::jsonb)) from public.community_places p where p.id=target_place and p.status='approved';
$$;
create function public.social_place_review_queue() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 return (select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb) from (select r.id,r.rating,r.body,p.title,p.city from public.social_place_reviews r join public.community_places p on p.id=r.place_id where r.status='pending' order by r.updated_at limit 100) x);
end; $$;
create function public.social_review_place_rating(target_review uuid,decision text,reason text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 if decision is null or decision not in ('approved','rejected') or reason is null or char_length(trim(reason)) not between 3 and 500 then raise exception 'Informe decisão e motivo.' using errcode='22023';end if;
 update public.social_place_reviews set status=decision where id=target_review;if not found then raise exception 'Avaliação não encontrada.' using errcode='P0002';end if;
 insert into public.social_place_review_audit(review_id,moderator_id,decision,reason) values(target_review,auth.uid(),decision,trim(reason));
end; $$;
revoke all on function public.social_checkin_place(uuid),public.social_rate_place(uuid,integer,text),public.social_place_activity(uuid),public.social_place_review_queue(),public.social_review_place_rating(uuid,text,text) from public,anon,authenticated;
grant execute on function public.social_place_activity(uuid) to anon,authenticated;
grant execute on function public.social_checkin_place(uuid),public.social_rate_place(uuid,integer,text),public.social_place_review_queue(),public.social_review_place_rating(uuid,text,text) to authenticated;
commit;
