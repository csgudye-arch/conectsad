-- Public QR lookup for membership cards. Exposes only first name, city and
-- whether the account email is confirmed; never returns email or full profile.
create or replace function public.verify_member_card(member_id_input uuid)
returns table(first_name text, city text, email_confirmed boolean)
language sql
stable
security definer
set search_path = ''
as $$
  select
    split_part(trim(p.display_name), ' ', 1) as first_name,
    p.city,
    (u.email_confirmed_at is not null) as email_confirmed
  from public.profiles as p
  left join auth.users as u on u.id = p.id
  where p.id = member_id_input
  limit 1;
$$;

revoke all on function public.verify_member_card(uuid) from public;
grant execute on function public.verify_member_card(uuid) to anon, authenticated;
