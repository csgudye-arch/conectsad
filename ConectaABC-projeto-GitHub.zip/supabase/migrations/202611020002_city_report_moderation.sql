-- Revisão segura de relatos urbanos. Aplicar após a migração inicial.
-- Moderadores são designados manualmente por um administrador do projeto.

create table if not exists public.city_report_moderators (
  user_id uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.city_report_moderators enable row level security;
revoke all on public.city_report_moderators from public, anon, authenticated;

alter table public.city_reports
  add column if not exists moderated_by uuid references public.profiles (id) on delete set null,
  add column if not exists moderated_at timestamptz;

create index if not exists city_reports_pending_queue_idx
  on public.city_reports (created_at asc) where status = 'pending';

create or replace function public.list_city_reports_for_moderation()
returns table (
  id uuid,
  category text,
  city text,
  neighborhood text,
  description text,
  status text,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
stable
as $$
begin
  if not exists (
    select 1 from public.city_report_moderators m
    where m.user_id = (select auth.uid())
  ) then
    raise exception 'city report moderator access required' using errcode = '42501';
  end if;

  return query
    select r.id, r.category, r.city, r.neighborhood, r.description, r.status, r.created_at
    from public.city_reports r
    where r.status in ('pending', 'review', 'in_progress')
    order by r.created_at asc
    limit 100;
end;
$$;

create or replace function public.moderate_city_report(report_id uuid, decision text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not exists (
    select 1 from public.city_report_moderators m
    where m.user_id = (select auth.uid())
  ) then
    raise exception 'city report moderator access required' using errcode = '42501';
  end if;

  if decision is null or decision not in ('review', 'in_progress', 'resolved', 'rejected') then
    raise exception 'invalid city report decision' using errcode = '22023';
  end if;

  update public.city_reports
    set status = decision,
        moderated_by = (select auth.uid()),
        moderated_at = now()
    where id = report_id
      and (
        (status = 'pending' and decision in ('review', 'rejected'))
        or (status = 'review' and decision in ('in_progress', 'rejected'))
        or (status = 'in_progress' and decision in ('resolved', 'rejected'))
      );

  if not found then
    raise exception 'city report not found or invalid status transition' using errcode = 'P0002';
  end if;
end;
$$;

revoke all on function public.list_city_reports_for_moderation() from public, anon;
revoke all on function public.moderate_city_report(uuid, text) from public, anon;
grant execute on function public.list_city_reports_for_moderation() to authenticated;
grant execute on function public.moderate_city_report(uuid, text) to authenticated;
