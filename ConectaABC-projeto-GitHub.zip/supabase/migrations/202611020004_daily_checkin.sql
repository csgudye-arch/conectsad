-- Check-in diário com limite enforced no banco; o cliente nunca grava pontos diretamente.
create table if not exists public.daily_mission_claims (
  user_id uuid not null references public.profiles (id) on delete cascade,
  mission_key text not null check (mission_key = 'checkin'),
  claimed_on date not null,
  points integer not null check (points = 5),
  created_at timestamptz not null default now(),
  primary key (user_id, mission_key, claimed_on)
);

alter table public.daily_mission_claims enable row level security;
revoke all on public.daily_mission_claims from anon, authenticated;
grant select on public.daily_mission_claims to authenticated;

create policy "Members can read their own daily mission claims"
  on public.daily_mission_claims for select to authenticated
  using (user_id = (select auth.uid()));

create or replace function public.claim_daily_checkin()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  member_id uuid := auth.uid();
  today_local date := (now() at time zone 'America/Sao_Paulo')::date;
begin
  if member_id is null then
    raise exception 'Authentication required';
  end if;

  insert into public.daily_mission_claims (user_id, mission_key, claimed_on, points)
  values (member_id, 'checkin', today_local, 5)
  on conflict (user_id, mission_key, claimed_on) do nothing;

  if not found then
    return 0;
  end if;

  insert into public.points_ledger (user_id, event_type, points)
  values (member_id, 'daily_checkin', 5);

  return 5;
end;
$$;

revoke all on function public.claim_daily_checkin() from public, anon;
grant execute on function public.claim_daily_checkin() to authenticated;
