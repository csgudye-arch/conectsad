-- Comunicados do Plantão ABC são publicados somente por moderadores autorizados.
alter table public.community_posts
  add column if not exists title text,
  add column if not exists source text,
  add column if not exists sensitive boolean not null default false,
  add column if not exists is_official boolean not null default false;
alter table public.community_posts drop constraint if exists community_posts_city_check;
alter table public.community_posts add constraint community_posts_city_check check (city in ('Santo André','São Bernardo do Campo','São Caetano do Sul','Diadema','Mauá','Ribeirão Pires','Rio Grande da Serra','Grande ABC'));

create or replace function public.create_official_post(post_title text, post_category text, post_city text, post_body text, post_source text, post_sensitive boolean)
returns uuid language plpgsql security definer set search_path='' as $$
declare created_id uuid;
begin
  if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Not authorized'; end if;
  if char_length(trim(post_title)) not between 5 and 120 or char_length(trim(post_category)) not between 1 and 50 or char_length(trim(post_body)) not between 30 and 3000 or char_length(trim(post_source)) not between 3 and 300 then raise exception 'Invalid post'; end if;
  if post_city not in ('Santo André','São Bernardo do Campo','São Caetano do Sul','Diadema','Mauá','Ribeirão Pires','Rio Grande da Serra','Grande ABC') then raise exception 'Invalid city'; end if;
  insert into public.community_posts(author_id,category,city,body,status,title,source,sensitive,is_official)
  values(auth.uid(),trim(post_category),post_city,trim(post_body),'approved',trim(post_title),trim(post_source),coalesce(post_sensitive,false),true)
  returning id into created_id;
  return created_id;
end;
$$;
revoke all on function public.create_official_post(text,text,text,text,text,boolean) from public,anon;
grant execute on function public.create_official_post(text,text,text,text,text,boolean) to authenticated;

create or replace function public.list_service_requests_for_moderation()
returns table(request_id uuid,member_name text,service_type text,city text,neighborhood text,contact text,description text,status text,created_at timestamptz)
language plpgsql security definer set search_path='' as $$
begin
  if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Not authorized'; end if;
  return query select s.id,p.display_name,s.service_type,s.city,s.neighborhood,s.contact,s.description,s.status,s.created_at
  from public.service_requests s join public.profiles p on p.id=s.author_id
  where s.status in ('received','review','in_progress') order by s.created_at limit 100;
end;
$$;
revoke all on function public.list_service_requests_for_moderation() from public,anon;
grant execute on function public.list_service_requests_for_moderation() to authenticated;

create or replace function public.moderate_service_request(request_id uuid, decision text)
returns void language plpgsql security definer set search_path='' as $$
begin
  if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Not authorized'; end if;
  if decision not in ('review','in_progress','completed','closed') then raise exception 'Invalid decision'; end if;
  update public.service_requests set status=decision where id=request_id and status in ('received','review','in_progress');
  if not found then raise exception 'Request not available'; end if;
end;
$$;
revoke all on function public.moderate_service_request(uuid,text) from public,anon;
grant execute on function public.moderate_service_request(uuid,text) to authenticated;
