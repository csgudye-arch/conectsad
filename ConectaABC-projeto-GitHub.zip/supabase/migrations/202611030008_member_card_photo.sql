alter table public.profiles
  add column avatar_path text,
  add constraint profiles_avatar_path_owner
    check (avatar_path is null or avatar_path like (id::text || '/%'));

grant update (avatar_path) on public.profiles to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('member-avatars', 'member-avatars', false, 5242880, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
set public = false,
    file_size_limit = 5242880,
    allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp'];

create policy "Members can read their own card photo"
  on storage.objects for select to authenticated
  using (bucket_id = 'member-avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "Members can upload their own card photo"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'member-avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "Members can update their own card photo"
  on storage.objects for update to authenticated
  using (bucket_id = 'member-avatars' and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'member-avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "Members can delete their own card photo"
  on storage.objects for delete to authenticated
  using (bucket_id = 'member-avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);
