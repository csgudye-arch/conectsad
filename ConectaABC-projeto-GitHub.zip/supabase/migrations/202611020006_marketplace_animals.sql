-- Anúncios e avisos de animais são moderados antes de aparecerem publicamente.
create table if not exists public.marketplace_listings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 5 and 100),
  category text not null check (char_length(category) between 2 and 50),
  city text not null check (city in ('Santo André','São Bernardo do Campo','São Caetano do Sul','Diadema','Mauá','Ribeirão Pires','Rio Grande da Serra')),
  neighborhood text check (neighborhood is null or char_length(neighborhood) <= 80),
  description text not null check (char_length(description) between 20 and 1200),
  price numeric(10,2) check (price is null or price >= 0),
  contact text not null check (char_length(contact) between 8 and 120),
  status text not null default 'pending' check (status in ('pending','active','sold','rejected','hidden')),
  created_at timestamptz not null default now()
);
create index if not exists marketplace_public_idx on public.marketplace_listings(city,category,created_at desc) where status='active';
alter table public.marketplace_listings enable row level security;
revoke all on public.marketplace_listings from anon,authenticated;
grant select (id,title,category,city,neighborhood,description,price,status,created_at) on public.marketplace_listings to anon,authenticated;
grant insert (owner_id,title,category,city,neighborhood,description,price,contact) on public.marketplace_listings to authenticated;
create policy "Public may read active marketplace listings" on public.marketplace_listings for select to anon,authenticated using (status='active' or owner_id=(select auth.uid()));
create policy "Members submit own marketplace listings" on public.marketplace_listings for insert to authenticated with check (owner_id=(select auth.uid()) and status='pending');

create table if not exists public.animal_reports (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  report_type text not null check (report_type in ('perdido','encontrado')),
  animal_name text check (animal_name is null or char_length(animal_name) <= 80),
  species text not null check (char_length(species) between 2 and 40),
  city text not null check (city in ('Santo André','São Bernardo do Campo','São Caetano do Sul','Diadema','Mauá','Ribeirão Pires','Rio Grande da Serra')),
  neighborhood text check (neighborhood is null or char_length(neighborhood) <= 80),
  description text not null check (char_length(description) between 20 and 1200),
  contact text not null check (char_length(contact) between 8 and 120),
  status text not null default 'pending' check (status in ('pending','active','reunido','encerrado','rejected')),
  created_at timestamptz not null default now()
);
create index if not exists animal_reports_public_idx on public.animal_reports(city,status,created_at desc);
alter table public.animal_reports enable row level security;
revoke all on public.animal_reports from anon,authenticated;
grant select (id,report_type,animal_name,species,city,neighborhood,description,status,created_at) on public.animal_reports to anon,authenticated;
grant insert (owner_id,report_type,animal_name,species,city,neighborhood,description,contact) on public.animal_reports to authenticated;
create policy "Public may read active animal reports" on public.animal_reports for select to anon,authenticated using (status='active' or owner_id=(select auth.uid()));
create policy "Members submit own animal reports" on public.animal_reports for insert to authenticated with check (owner_id=(select auth.uid()) and status='pending');

create or replace function public.get_listing_contact(listing_id uuid) returns text language plpgsql security definer set search_path='' as $$ declare v text; begin if auth.uid() is null then raise exception 'Sign in required'; end if; select contact into v from public.marketplace_listings where id=listing_id and status='active'; return v; end; $$;
revoke all on function public.get_listing_contact(uuid) from public,anon;
grant execute on function public.get_listing_contact(uuid) to authenticated;
create or replace function public.get_animal_contact(report_id uuid) returns text language plpgsql security definer set search_path='' as $$ declare v text; begin if auth.uid() is null then raise exception 'Sign in required'; end if; select contact into v from public.animal_reports where id=report_id and status='active'; return v; end; $$;
revoke all on function public.get_animal_contact(uuid) from public,anon;
grant execute on function public.get_animal_contact(uuid) to authenticated;

create or replace function public.list_pending_marketplace_listings() returns table(id uuid,title text,category text,city text,description text,created_at timestamptz) language plpgsql security definer set search_path='' as $$ begin if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Not authorized'; end if; return query select l.id,l.title,l.category,l.city,l.description,l.created_at from public.marketplace_listings l where l.status='pending' order by l.created_at limit 100; end; $$;
revoke all on function public.list_pending_marketplace_listings() from public,anon;
grant execute on function public.list_pending_marketplace_listings() to authenticated;
create or replace function public.moderate_marketplace_listing(listing_id uuid,decision text) returns void language plpgsql security definer set search_path='' as $$ begin if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Not authorized'; end if; if decision not in ('active','rejected') then raise exception 'Invalid decision'; end if; update public.marketplace_listings set status=decision where id=listing_id and status='pending'; if not found then raise exception 'Listing not pending'; end if; end; $$;
revoke all on function public.moderate_marketplace_listing(uuid,text) from public,anon;
grant execute on function public.moderate_marketplace_listing(uuid,text) to authenticated;
create or replace function public.list_pending_animal_reports() returns table(id uuid,report_type text,animal_name text,species text,city text,neighborhood text,description text,created_at timestamptz) language plpgsql security definer set search_path='' as $$ begin if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Not authorized'; end if; return query select a.id,a.report_type,a.animal_name,a.species,a.city,a.neighborhood,a.description,a.created_at from public.animal_reports a where a.status='pending' order by a.created_at limit 100; end; $$;
revoke all on function public.list_pending_animal_reports() from public,anon;
grant execute on function public.list_pending_animal_reports() to authenticated;
create or replace function public.moderate_animal_report(report_id uuid,decision text) returns void language plpgsql security definer set search_path='' as $$ begin if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Not authorized'; end if; if decision not in ('active','rejected') then raise exception 'Invalid decision'; end if; update public.animal_reports set status=decision where id=report_id and status='pending'; if not found then raise exception 'Report not pending'; end if; end; $$;
revoke all on function public.moderate_animal_report(uuid,text) from public,anon;
grant execute on function public.moderate_animal_report(uuid,text) to authenticated;
