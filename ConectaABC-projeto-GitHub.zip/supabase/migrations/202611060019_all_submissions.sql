begin;
create function public.social_my_submissions(page_number integer default 0) returns table(submission_id uuid,submission_type text,title text,city text,status text,description text,created_at timestamptz) language plpgsql stable security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para acompanhar seus envios.' using errcode='42501';end if;
 return query select * from (
 select p.id,'feed'::text,coalesce(p.title,p.category),p.city,p.status,left(p.body,240),p.created_at from public.community_posts p where p.author_id=auth.uid()
 union all select r.id,'cidade',r.category,r.city,r.status,left(r.description,240),r.created_at from public.city_reports r where r.author_id=auth.uid()
 union all select a.id,'animal',coalesce(a.animal_name,a.species),a.city,a.status,left(a.description,240),a.created_at from public.animal_reports a where a.owner_id=auth.uid()
 union all select l.id,'mercadao',l.title,l.city,l.status,left(l.description,240),l.created_at from public.marketplace_listings l where l.owner_id=auth.uid()
 union all select s.id,'servico',s.service_type,s.city,s.status,left(s.description,240),s.created_at from public.service_requests s where s.author_id=auth.uid()
 union all select e.id,'agenda',e.title,e.city,e.status,left(e.description,240),e.created_at from public.social_events e where e.owner_id=auth.uid()
 union all select c.id,c.kind,c.title,c.city,c.status,left(c.description,240),c.created_at from public.social_classifieds c where c.owner_id=auth.uid()
 union all select b.id,'empresa',b.name,b.city,b.status,left(b.description,240),b.created_at from public.social_businesses b where b.owner_id=auth.uid()
 union all select s.id,'story',left(coalesce(nullif(s.caption,''),'Story'),120),s.city,case when s.expires_at<=now() then 'expired' else s.status end,s.caption,s.created_at from public.social_stories s where s.author_id=auth.uid()
 union all select p.id,'enquete',p.question,p.city,p.status,'Enquete da comunidade',p.created_at from public.social_polls p where p.author_id=auth.uid()
 union all select g.id,'grupo',g.name,g.city,g.status,left(g.description,240),g.created_at from public.social_groups g where g.owner_id=auth.uid()
 union all select p.id,'post_grupo',g.name,g.city,p.status,left(p.body,240),p.created_at from public.social_group_posts p join public.social_groups g on g.id=p.group_id where p.author_id=auth.uid()
 union all select c.id,'comentario','Comentário na publicação',p.city,c.status,left(c.body,240),c.created_at from public.social_comments c join public.community_posts p on p.id=c.post_id where c.author_id=auth.uid()
 union all select r.id,'avaliacao',p.title,p.city,r.status,left(r.body,240),r.created_at from public.social_place_reviews r join public.community_places p on p.id=r.place_id where r.user_id=auth.uid()
 union all select r.id,'indica',r.category,r.city,r.status,left(r.body,240),r.created_at from public.social_recommendation_requests r where r.author_id=auth.uid()
 union all select p.id,'mapa',p.title,p.city,p.status,left(p.description,240),p.created_at from public.community_places p where p.author_id=auth.uid()
 union all select a.id,'indica',r.category,r.city,a.status,left(a.body,240),a.created_at from public.social_recommendations a join public.social_recommendation_requests r on r.id=a.request_id where a.author_id=auth.uid()
 union all select c.id,'cupom',c.title,b.city,c.status,left(c.rules,240),c.created_at from public.social_coupons c join public.social_businesses b on b.id=c.business_id where b.owner_id=auth.uid()
 ) items order by 7 desc,1 limit 50 offset least(greatest(coalesce(page_number,0),0),1000)*50;
end; $$;
revoke all on function public.social_my_submissions(integer) from public,anon,authenticated;
grant execute on function public.social_my_submissions(integer) to authenticated;
commit;
