-- Perfil social e níveis: extensões sem apagar pontos, perfis ou publicações.
begin;
create table public.social_levels(level integer primary key check(level between 1 and 10),name text not null check(char_length(name) between 3 and 40),minimum_points integer not null unique check(minimum_points>=0),color text not null check(color in ('gold','silver','blackgold','legend')));
insert into public.social_levels values (1,'Morador do ABC',0,'gold'),(2,'Participante',500,'gold'),(3,'Agente do ABC',1500,'gold'),(4,'Guardião do ABC',3500,'silver'),(5,'Destaque do ABC',6000,'silver'),(6,'Referência do ABC',10000,'silver'),(7,'Líder da comunidade',15000,'blackgold'),(8,'Embaixador do ABC',22000,'blackgold'),(9,'Ícone do ABC',32000,'blackgold'),(10,'Lenda do ABC',45000,'legend');
create table public.social_member_details(user_id uuid primary key references public.profiles(id) on delete cascade,handle text not null unique check(handle ~ '^[a-z0-9_]{3,24}$'),bio text not null default '' check(char_length(bio)<=300),neighborhood text not null default '' check(char_length(neighborhood)<=80),cover_path text,public_enabled boolean not null default false,show_presence boolean not null default false,last_seen_at timestamptz,updated_at timestamptz not null default now(),check(cover_path is null or cover_path like user_id::text||'/%'));
create table public.social_account_requests(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles(id) on delete cascade,kind text not null check(kind='delete_account'),status text not null default 'requested' check(status in ('requested','cancelled','completed')),created_at timestamptz not null default now());
create unique index social_account_open_request on public.social_account_requests(user_id) where status='requested';
alter table public.social_levels enable row level security;
alter table public.social_member_details enable row level security;
alter table public.social_account_requests enable row level security;
revoke all on public.social_levels,public.social_member_details,public.social_account_requests from public,anon,authenticated;
create function public.social_get_levels() returns setof public.social_levels language sql stable security definer set search_path='' as $$ select * from public.social_levels order by level $$;
create function public.social_set_levels(entries jsonb) returns void language plpgsql security definer set search_path='' as $$
declare previous integer:=-1; item jsonb; i integer:=0;
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501'; end if;
 if entries is null or jsonb_typeof(entries)<>'array' or jsonb_array_length(entries)<>10 then raise exception 'Informe os dez níveis.' using errcode='22023'; end if;
 perform pg_advisory_xact_lock(20261106,4);
 for item in select value from jsonb_array_elements(entries) loop
 i:=i+1;
 if item->>'level' is null or item->>'minimum_points' is null or item->>'name' is null or item->>'color' is null or (item->>'level')::integer<>i or (item->>'minimum_points')::integer<=previous or (i=1 and (item->>'minimum_points')::integer<>0) or char_length(trim(item->>'name')) not between 3 and 40 or item->>'color' not in ('gold','silver','blackgold','legend') then raise exception 'Os níveis devem estar em ordem crescente, começando em zero.' using errcode='22023'; end if;
 previous:=(item->>'minimum_points')::integer;
 end loop;
 -- A transação substitui somente a configuração, nunca o livro de pontos.
 delete from public.social_levels;
 insert into public.social_levels select (x->>'level')::integer,trim(x->>'name'),(x->>'minimum_points')::integer,x->>'color' from jsonb_array_elements(entries) x;
end; $$;
create function public.social_my_details() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para acessar o perfil.' using errcode='42501'; end if;
 return (select jsonb_build_object('handle',d.handle,'bio',d.bio,'neighborhood',d.neighborhood,'cover_path',d.cover_path,'public_enabled',d.public_enabled,'show_presence',d.show_presence) from public.social_member_details d where d.user_id=auth.uid());
end; $$;
create function public.social_save_details(member_handle text,member_bio text,member_neighborhood text,member_cover text,make_public boolean,presence_public boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para editar seu perfil.' using errcode='42501'; end if;
 if member_handle is null or lower(trim(member_handle)) !~ '^[a-z0-9_]{3,24}$' or lower(member_handle) in ('admin','conectaabc','conecta_abc','equipe','suporte','oficial') or member_bio is null or char_length(member_bio)>300 or member_neighborhood is null or char_length(trim(member_neighborhood))>80 or make_public is null or presence_public is null then raise exception 'Confira o nome de usuário (3 a 24 letras, números ou _), bio e bairro.' using errcode='22023'; end if;
 if member_cover is not null and (member_cover not like auth.uid()::text||'/%' or not exists(select 1 from storage.objects where bucket_id='social-covers' and name=member_cover)) then raise exception 'Capa inválida.' using errcode='22023'; end if;
 insert into public.social_member_details(user_id,handle,bio,neighborhood,cover_path,public_enabled,show_presence) values(auth.uid(),lower(trim(member_handle)),trim(member_bio),trim(member_neighborhood),member_cover,make_public,presence_public)
 on conflict(user_id) do update set handle=excluded.handle,bio=excluded.bio,neighborhood=excluded.neighborhood,cover_path=excluded.cover_path,public_enabled=excluded.public_enabled,show_presence=excluded.show_presence,updated_at=now();
exception when unique_violation then raise exception 'Este nome de usuário já está em uso.' using errcode='22023';
end; $$;
create function public.social_touch_presence() returns void language sql security definer set search_path='' as $$ update public.social_member_details set last_seen_at=now() where user_id=auth.uid() and show_presence and public_enabled and (last_seen_at is null or last_seen_at<now()-interval '45 seconds') $$;
create function public.social_public_profile(member_handle text) returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('member_id',p.id,'first_name',split_part(trim(p.display_name),' ',1),'handle',d.handle,'bio',d.bio,'neighborhood',d.neighborhood,'city',p.city,'cover_path',d.cover_path,'avatar_path',case when p.avatar_public then p.avatar_path else null end,'recently_active',coalesce(d.show_presence and d.last_seen_at>now()-interval '2 minutes',false),'is_moderator',exists(select 1 from public.community_moderators where user_id=p.id),'points',(select coalesce(sum(points),0) from public.points_ledger where user_id=p.id),'posts',(select count(*) from public.community_posts where author_id=p.id and status='approved' and not is_anonymous)) from public.social_member_details d join public.profiles p on p.id=d.user_id where d.handle=lower(member_handle) and (d.public_enabled or d.user_id=auth.uid());
$$;
create function public.social_member_posts(member_handle text,page_number integer default 0) returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb) from (select c.id,c.title,c.body,c.city,c.created_at,c.media_path,c.media_kind from public.community_posts c join public.social_member_details d on d.user_id=c.author_id where d.handle=lower(member_handle) and (d.public_enabled or d.user_id=auth.uid()) and c.status='approved' and not c.is_anonymous order by c.created_at desc limit 24 offset least(greatest(coalesce(page_number,0),0),1000)*24) x;
$$;
create function public.social_my_progress() returns jsonb language plpgsql stable security definer set search_path='' as $$
declare total bigint; tier public.social_levels; next_tier public.social_levels;
begin
 if auth.uid() is null then raise exception 'Entre para consultar seu progresso.' using errcode='42501'; end if;
 select coalesce(sum(points),0) into total from public.points_ledger where user_id=auth.uid();
 select * into tier from public.social_levels where minimum_points<=total order by level desc limit 1;
 select * into next_tier from public.social_levels where level=tier.level+1;
 return jsonb_build_object('points',total,'level',to_jsonb(tier),'next_level',case when next_tier.level is null then null else to_jsonb(next_tier) end);
end; $$;
create function public.social_season_ranking(season_month date) returns table(rank_position bigint,first_name text,city text,neighborhood text,points bigint) language plpgsql stable security definer set search_path='' as $$
begin
 if season_month is null then raise exception 'Selecione o mês.' using errcode='22023'; end if;
 return query select row_number() over(order by t.total desc,t.id),split_part(trim(t.display_name),' ',1),t.city,t.neighborhood,t.total from (
 select p.id,p.display_name,p.city,case when d.public_enabled then nullif(d.neighborhood,'') else null end neighborhood,sum(l.points)::bigint total from public.points_ledger l join public.profiles p on p.id=l.user_id left join public.social_member_details d on d.user_id=p.id where l.created_at>=date_trunc('month',season_month::timestamp) at time zone 'America/Sao_Paulo' and l.created_at<(date_trunc('month',season_month::timestamp)+interval '1 month') at time zone 'America/Sao_Paulo' group by p.id,p.display_name,p.city,d.public_enabled,d.neighborhood) t order by t.total desc,t.id limit 100;
end; $$;
create function public.social_cover_readable(object_name text) returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.social_member_details where cover_path=object_name and (public_enabled or user_id=auth.uid())) $$;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('social-covers','social-covers',false,5242880,array['image/jpeg','image/png','image/webp']);
create policy "Member inserts unique profile cover" on storage.objects for insert to authenticated with check(bucket_id='social-covers' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Read shared profile cover" on storage.objects for select to anon,authenticated using(bucket_id='social-covers' and ((storage.foldername(name))[1]=auth.uid()::text or public.social_cover_readable(name)));
create policy "Member removes own profile cover" on storage.objects for delete to authenticated using(bucket_id='social-covers' and (storage.foldername(name))[1]=auth.uid()::text);
alter table public.community_posts drop constraint if exists community_posts_body_check;
alter table public.community_posts add constraint community_posts_body_check check(char_length(body) between 10 and case when is_official then 3000 else 1200 end);
-- Somente a equipe pode associar mídia a um comunicado oficial.
create function public.social_publish_official(post_title text,post_category text,post_city text,post_body text,post_source text,post_sensitive boolean,attachment_path text,attachment_kind text) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid;
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Somente a equipe pode publicar conteúdo oficial.' using errcode='42501'; end if;
 if post_title is null or post_body is null or post_source is null or post_category is null or post_city is null then raise exception 'Preencha todos os campos do comunicado.' using errcode='22023'; end if;
 if (attachment_path is null)<>(attachment_kind is null) or attachment_kind not in ('image','video') or (attachment_path is not null and (attachment_path not like auth.uid()::text||'/%' or not exists(select 1 from storage.objects where bucket_id='feed-media' and name=attachment_path))) then raise exception 'Anexo inválido.' using errcode='22023'; end if;
 result:=public.create_official_post(post_title,post_category,post_city,post_body,post_source,post_sensitive);
 update public.community_posts set media_path=attachment_path,media_kind=attachment_kind where id=result;
 return result;
end; $$;
revoke all on function public.social_get_levels(),public.social_set_levels(jsonb),public.social_my_details(),public.social_save_details(text,text,text,text,boolean,boolean),public.social_touch_presence(),public.social_public_profile(text),public.social_member_posts(text,integer),public.social_my_progress(),public.social_season_ranking(date),public.social_cover_readable(text),public.social_publish_official(text,text,text,text,text,boolean,text,text) from public,anon,authenticated;
grant execute on function public.social_get_levels(),public.social_public_profile(text),public.social_member_posts(text,integer),public.social_season_ranking(date),public.social_cover_readable(text) to anon,authenticated;
grant execute on function public.social_set_levels(jsonb),public.social_my_details(),public.social_save_details(text,text,text,text,boolean,boolean),public.social_touch_presence(),public.social_my_progress(),public.social_publish_official(text,text,text,text,text,boolean,text,text) to authenticated;
commit;
