alter table public.profiles
  add column avatar_public boolean not null default false;

grant update (avatar_public) on public.profiles to authenticated;

create or replace function public.get_public_member_avatar_paths(member_ids uuid[])
returns table (member_id uuid, avatar_path text)
language sql
stable
security definer
set search_path = ''
as $$
  select p.id, p.avatar_path
  from public.profiles p
  where p.id = any(coalesce(member_ids, array[]::uuid[]))
    and p.avatar_public = true
    and p.avatar_path is not null;
$$;

revoke all on function public.get_public_member_avatar_paths(uuid[]) from public;
grant execute on function public.get_public_member_avatar_paths(uuid[]) to anon, authenticated;

create or replace function public.member_avatar_path_is_public(object_name text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.avatar_path = object_name and p.avatar_public = true
  );
$$;

revoke all on function public.member_avatar_path_is_public(text) from public;
grant execute on function public.member_avatar_path_is_public(text) to anon, authenticated;

create policy "Visitors can view opted-in member photos"
  on storage.objects for select to anon, authenticated
  using (bucket_id = 'member-avatars' and public.member_avatar_path_is_public(name));
