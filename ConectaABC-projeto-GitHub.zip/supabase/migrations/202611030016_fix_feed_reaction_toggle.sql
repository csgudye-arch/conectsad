-- Corrige a ambiguidade de post_id no ON CONFLICT da função de apoio do Feed.
create or replace function public.toggle_community_post_reaction(post_id uuid)
returns table(liked boolean, reaction_count bigint)
language plpgsql
security definer
set search_path = ''
as $$
declare
  member_id uuid := auth.uid();
  removed integer;
begin
  if member_id is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  if not exists (
    select 1 from public.community_posts p
    where p.id = toggle_community_post_reaction.post_id and p.status = 'approved'
  ) then
    raise exception 'Post is not available for reactions' using errcode = 'P0002';
  end if;

  delete from public.community_post_reactions r
  where r.post_id = toggle_community_post_reaction.post_id
    and r.user_id = member_id;
  get diagnostics removed = row_count;

  if removed = 0 then
    insert into public.community_post_reactions(post_id, user_id)
    values (toggle_community_post_reaction.post_id, member_id)
    on conflict on constraint community_post_reactions_pkey do nothing;
  end if;

  return query
  select exists (
    select 1 from public.community_post_reactions r
    where r.post_id = toggle_community_post_reaction.post_id
      and r.user_id = member_id
  ),
  (
    select count(*)::bigint from public.community_post_reactions r
    where r.post_id = toggle_community_post_reaction.post_id
  );
end;
$$;

revoke all on function public.toggle_community_post_reaction(uuid) from public, anon;
grant execute on function public.toggle_community_post_reaction(uuid) to authenticated;
