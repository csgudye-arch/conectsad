-- Expose only first name, city, and validated point totals in the public ranking.
-- Profiles remain opt-in; private profile fields and full names are never returned.
drop function if exists public.get_public_leaderboard();

create function public.get_public_leaderboard()
returns table (rank_position bigint, first_name text, city text, points bigint)
language sql
security definer
set search_path = ''
stable
as $$
  select row_number() over (order by totals.points desc, totals.first_name)::bigint,
    totals.first_name, totals.city, totals.points
  from (
    select split_part(trim(p.display_name), ' ', 1) as first_name,
      p.city, coalesce(sum(l.points), 0)::bigint as points
    from public.profiles p
    left join public.points_ledger l on l.user_id = p.id
    where p.leaderboard_public = true
    group by p.id, p.display_name, p.city
  ) totals
  order by totals.points desc, totals.first_name
  limit 50;
$$;

revoke all on function public.get_public_leaderboard() from public;
grant execute on function public.get_public_leaderboard() to anon, authenticated;
