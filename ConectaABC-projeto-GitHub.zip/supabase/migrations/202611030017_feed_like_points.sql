-- Credita 3 pontos no primeiro apoio de cada membro em cada publicação aprovada.
-- O registro único no ledger impede novos créditos ao retirar/refazer o apoio.
begin;

create unique index if not exists points_ledger_feed_like_once_idx
  on public.points_ledger (user_id, evidence_id)
  where event_type = 'feed_like' and evidence_id is not null;

drop function if exists public.toggle_community_post_reaction(uuid);

create function public.toggle_community_post_reaction(post_id uuid)
returns table (liked boolean, reaction_count bigint, points_awarded integer)
language plpgsql
security definer
set search_path = ''
as $$
declare
  member_id uuid := auth.uid();
  post_author_id uuid;
  removed integer := 0;
  inserted integer := 0;
  ledger_rows integer := 0;
  granted_points integer := 0;
begin
  if member_id is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended(member_id::text || ':' || post_id::text, 0)
  );

  select p.author_id into post_author_id
  from public.community_posts p
  where p.id = toggle_community_post_reaction.post_id
    and p.status = 'approved';
  if not found then
    raise exception 'Post is not available for reactions' using errcode = 'P0002';
  end if;
  if post_author_id = member_id then
    raise exception 'You cannot earn points for supporting your own post' using errcode = 'P0001';
  end if;

  delete from public.community_post_reactions r
  where r.post_id = toggle_community_post_reaction.post_id
    and r.user_id = member_id;
  get diagnostics removed = row_count;

  if removed = 0 then
    insert into public.community_post_reactions (post_id, user_id)
    values (toggle_community_post_reaction.post_id, member_id)
    on conflict on constraint community_post_reactions_pkey do nothing;
    get diagnostics inserted = row_count;

    if inserted = 1 then
      insert into public.points_ledger (user_id, event_type, points, evidence_id)
      values (member_id, 'feed_like', 3, toggle_community_post_reaction.post_id)
      on conflict do nothing;
      get diagnostics ledger_rows = row_count;
      if ledger_rows = 1 then
        granted_points := 3;
      end if;
    end if;
  end if;

  return query
    select exists (
      select 1 from public.community_post_reactions r
      where r.post_id = toggle_community_post_reaction.post_id
        and r.user_id = member_id
    ),
    (
      select count(*)::bigint from public.community_post_reactions r
      where r.post_id = toggle_community_post_reaction.post_id
    ),
    granted_points;
end;
$$;

revoke all on function public.toggle_community_post_reaction(uuid) from public, anon;
grant execute on function public.toggle_community_post_reaction(uuid) to authenticated;

commit;
