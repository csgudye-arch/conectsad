begin;
alter table public.community_post_reactions add column reaction_kind text not null default 'like' check(reaction_kind in ('like','love','fun','fire'));
create function public.social_set_reaction(target_post uuid,target_kind text) returns table(liked boolean,reaction_count bigint,points_awarded integer) language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid();result record;awarded integer:=0;
begin
 if actor is null then raise exception 'Entre para reagir.' using errcode='42501';end if;
 if target_kind is null or target_kind not in ('like','love','fun','fire') then raise exception 'Selecione uma reação válida.' using errcode='22023';end if;
 if not exists(select 1 from public.community_posts where id=target_post and status='approved') then raise exception 'Publicação indisponível.' using errcode='P0002';end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text||':'||target_post::text,510));
 if not exists(select 1 from public.community_post_reactions r where r.post_id=target_post and r.user_id=actor) then select * into result from public.toggle_community_post_reaction(target_post);awarded:=coalesce(result.points_awarded,0);end if;
 update public.community_post_reactions r set reaction_kind=target_kind where r.post_id=target_post and r.user_id=actor;
 return query select exists(select 1 from public.community_post_reactions r where r.post_id=target_post and r.user_id=actor),(select count(*) from public.community_post_reactions r where r.post_id=target_post),awarded;
end; $$;
create function public.social_reaction_details(target_post uuid) returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('mine',(select reaction_kind from public.community_post_reactions where post_id=p.id and user_id=auth.uid()),'counts',coalesce((select jsonb_object_agg(reaction_kind,total) from(select reaction_kind,count(*) total from public.community_post_reactions where post_id=p.id group by reaction_kind) x),'{}'::jsonb)) from public.community_posts p where p.id=target_post and p.status='approved';
$$;
revoke all on function public.social_set_reaction(uuid,text),public.social_reaction_details(uuid) from public,anon,authenticated;
grant execute on function public.social_set_reaction(uuid,text) to authenticated;
grant execute on function public.social_reaction_details(uuid) to anon,authenticated;
commit;
