begin;
create table public.social_businesses(
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references public.profiles(id) on delete cascade,
 name text not null check(char_length(name) between 2 and 120),category text not null check(char_length(category) between 2 and 60),city text not null,
 description text not null check(char_length(description) between 20 and 1500),address text not null default '' check(char_length(address)<=200),hours text not null default '' check(char_length(hours)<=240),phone text not null default '' check(phone='' or phone ~ '^[0-9]{10,15}$'),instagram text not null default '' check(instagram='' or instagram ~ '^[A-Za-z0-9_.]{1,30}$'),
 status text not null default 'pending' check(status in ('pending','approved','rejected','hidden')),created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create index social_businesses_owner on public.social_businesses(owner_id,created_at);
create table public.social_business_followers(business_id uuid not null references public.social_businesses(id) on delete cascade,user_id uuid not null references public.profiles(id) on delete cascade,created_at timestamptz not null default now(),primary key(business_id,user_id));
create table public.social_business_audit(id bigint generated always as identity primary key,business_id uuid not null references public.social_businesses(id) on delete cascade,moderator_id uuid not null references auth.users(id),decision text not null,reason text not null,created_at timestamptz not null default now());
alter table public.social_businesses enable row level security;
alter table public.social_business_followers enable row level security;
alter table public.social_business_audit enable row level security;
revoke all on public.social_businesses,public.social_business_followers,public.social_business_audit from public,anon,authenticated;
create function public.social_save_business(business_id uuid,business_name text,business_category text,business_city text,business_description text,business_address text,business_hours text,business_phone text,business_instagram text,public_consent boolean) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid; actor uuid:=auth.uid();
begin
 if actor is null then raise exception 'Entre para cadastrar seu negócio.' using errcode='42501'; end if;
 if public_consent is distinct from true then raise exception 'Autorize a publicação das informações comerciais.' using errcode='22023'; end if;
 if business_name is null or char_length(trim(business_name)) not between 2 and 120 or business_description is null or char_length(trim(business_description)) not between 20 and 1500 or business_category is null or business_category not in ('Alimentação','Bares e restaurantes','Mercado','Beleza','Saúde','Jurídico','Contabilidade','Construção','Imóveis','Educação','Esporte','Moda','Pets','Automotivo','Tecnologia','Eventos','Música','Serviços gerais') or not public.social_valid_city(business_city) or business_address is null or char_length(business_address)>200 or business_hours is null or char_length(business_hours)>240 or business_phone is null or (business_phone<>'' and business_phone !~ '^[0-9]{10,15}$') or business_instagram is null or (business_instagram<>'' and business_instagram !~ '^[A-Za-z0-9_.]{1,30}$') then raise exception 'Confira nome, descrição, categoria, cidade e contatos comerciais.' using errcode='22023'; end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,440));
 if business_id is null then
 if (select count(*) from public.social_businesses b where b.owner_id=actor)>=3 then raise exception 'Cada conta pode cadastrar até três negócios. Procure a equipe se precisar ampliar.' using errcode='P0001'; end if;
 insert into public.social_businesses(owner_id,name,category,city,description,address,hours,phone,instagram) values(actor,trim(business_name),business_category,business_city,trim(business_description),trim(business_address),trim(business_hours),business_phone,business_instagram) returning id into result;
 else
 update public.social_businesses b set name=trim(business_name),category=business_category,city=business_city,description=trim(business_description),address=trim(business_address),hours=trim(business_hours),phone=business_phone,instagram=business_instagram,status='pending',updated_at=now() where b.id=business_id and b.owner_id=actor and b.status<>'hidden' returning b.id into result;
 if result is null then raise exception 'Somente o responsável pode editar um negócio disponível.' using errcode='42501'; end if;
 end if;return result;
end; $$;
create function public.social_list_businesses(target_business uuid default null,page_number integer default 0) returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(item order by name),'[]'::jsonb) from (select b.name,jsonb_build_object('id',b.id,'name',b.name,'category',b.category,'city',b.city,'description',b.description,'address',b.address,'hours',b.hours,'phone',b.phone,'instagram',b.instagram,'status',b.status,'is_own',coalesce(b.owner_id=auth.uid(),false),'following',exists(select 1 from public.social_business_followers f where f.business_id=b.id and f.user_id=auth.uid()),'followers',(select count(*) from public.social_business_followers f where f.business_id=b.id)) item from public.social_businesses b where (target_business is null or b.id=target_business) and (b.status='approved' or b.owner_id=auth.uid()) order by b.name,b.id limit 24 offset least(greatest(coalesce(page_number,0),0),1000)*24) rows;
$$;
create function public.social_my_businesses() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para acessar seus negócios.' using errcode='42501'; end if;
 return (select coalesce(jsonb_agg(to_jsonb(b)-'owner_id' order by b.created_at),'[]'::jsonb) from public.social_businesses b where b.owner_id=auth.uid());
end; $$;
create function public.social_follow_business(target_business uuid,following boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para seguir empresas.' using errcode='42501'; end if;
 if following is null then raise exception 'Selecione a ação.' using errcode='22023'; end if;
 if not following then delete from public.social_business_followers where business_id=target_business and user_id=auth.uid();return;end if;
 if not exists(select 1 from public.social_businesses where id=target_business and status='approved' and owner_id<>auth.uid()) then raise exception 'Negócio indisponível para seguir.' using errcode='P0002'; end if;
 insert into public.social_business_followers(business_id,user_id) values(target_business,auth.uid()) on conflict do nothing;
end; $$;
create function public.social_business_queue() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501'; end if;
 return (select coalesce(jsonb_agg(to_jsonb(b)-'owner_id' order by b.updated_at),'[]'::jsonb) from (select * from public.social_businesses where status in ('pending','hidden') order by updated_at limit 100) b);
end; $$;
create function public.social_review_business(target_business uuid,decision text,reason text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501'; end if;
 if decision is null or decision not in ('approved','rejected','hidden') or reason is null or char_length(trim(reason)) not between 3 and 500 then raise exception 'Informe decisão e motivo.' using errcode='22023'; end if;
 update public.social_businesses set status=decision,updated_at=now() where id=target_business;
 if not found then raise exception 'Negócio não encontrado.' using errcode='P0002'; end if;
 insert into public.social_business_audit(business_id,moderator_id,decision,reason) values(target_business,auth.uid(),decision,trim(reason));
end; $$;
revoke all on function public.social_save_business(uuid,text,text,text,text,text,text,text,text,boolean),public.social_list_businesses(uuid,integer),public.social_my_businesses(),public.social_follow_business(uuid,boolean),public.social_business_queue(),public.social_review_business(uuid,text,text) from public,anon,authenticated;
grant execute on function public.social_list_businesses(uuid,integer) to anon,authenticated;
grant execute on function public.social_save_business(uuid,text,text,text,text,text,text,text,text,boolean),public.social_my_businesses(),public.social_follow_business(uuid,boolean),public.social_business_queue(),public.social_review_business(uuid,text,text) to authenticated;
commit;
