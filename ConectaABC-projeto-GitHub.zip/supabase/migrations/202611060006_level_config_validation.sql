begin;
create or replace function public.social_set_levels(entries jsonb) returns void language plpgsql security definer set search_path='' as $$
declare previous integer:=-1; item jsonb; i integer:=0;
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501'; end if;
 if entries is null or jsonb_typeof(entries)<>'array' or jsonb_array_length(entries)<>10 then raise exception 'Informe os dez níveis.' using errcode='22023'; end if;
 perform pg_advisory_xact_lock(20261106,4);
 for item in select value from jsonb_array_elements(entries) loop
 i:=i+1;
 if item->>'level' is null or item->>'minimum_points' is null or item->>'name' is null or item->>'color' is null or (item->>'level')::integer<>i or (item->>'minimum_points')::integer<=previous or (i=1 and (item->>'minimum_points')::integer<>0) or char_length(trim(item->>'name')) not between 3 and 40 or item->>'color' not in ('gold','silver','blackgold','legend') then raise exception 'Os níveis devem estar em ordem crescente, começando em zero.' using errcode='22023'; end if;
 previous:=(item->>'minimum_points')::integer;
 end loop;
 -- A transação substitui somente a configuração, nunca o livro de pontos.
 delete from public.social_levels;
 insert into public.social_levels select (x->>'level')::integer,trim(x->>'name'),(x->>'minimum_points')::integer,x->>'color' from jsonb_array_elements(entries) x;
end; $$;
commit;
