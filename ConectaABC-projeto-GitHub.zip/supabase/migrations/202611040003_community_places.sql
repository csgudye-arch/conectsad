-- Locais sugeridos pela comunidade: só pontos aprovados são públicos.
create table if not exists public.community_places (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 3 and 90),
  category text not null check (category in ('comer','comercio','pracas','esporte','cultura','saude','religiao','servicos','outros')),
  city text not null check (city in ('Santo André','São Bernardo do Campo','São Caetano do Sul','Diadema','Mauá','Ribeirão Pires','Rio Grande da Serra')),
  description text not null check (char_length(description) between 10 and 500),
  latitude double precision not null check (latitude between -23.90 and -23.45),
  longitude double precision not null check (longitude between -46.85 and -46.25),
  status text not null default 'pending' check (status in ('pending','approved','rejected','hidden')),
  created_at timestamptz not null default now(),
  moderated_by uuid references public.profiles(id),
  moderated_at timestamptz
);

create index if not exists community_places_public_idx
  on public.community_places(category, city, created_at desc) where status = 'approved';
create index if not exists community_places_owner_idx
  on public.community_places(author_id, created_at desc);

alter table public.community_places enable row level security;
revoke all on public.community_places from public, anon, authenticated;
grant select (id,title,category,city,description,latitude,longitude,status,created_at)
  on public.community_places to anon, authenticated;
grant insert (author_id,title,category,city,description,latitude,longitude,status)
  on public.community_places to authenticated;

drop policy if exists "Public reads approved places and members read their own submissions" on public.community_places;
create policy "Public reads approved places and members read their own submissions"
  on public.community_places for select to anon, authenticated
  using (status = 'approved' or author_id = (select auth.uid()));
drop policy if exists "Members submit a pending public place suggestion" on public.community_places;
create policy "Members submit a pending public place suggestion"
  on public.community_places for insert to authenticated
  with check (author_id = (select auth.uid()) and status = 'pending');

create or replace function public.limit_community_place_suggestions()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  member_id uuid := auth.uid();
  started_at timestamptz;
  current_count integer;
  now_at timestamptz := clock_timestamp();
begin
  if member_id is null then return new; end if;
  if new.author_id is distinct from member_id then raise exception 'submission_owner_must_match_authenticated_user' using errcode = '42501'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(member_id::text || ':community_places', 0));
  select window_started_at, submission_count into started_at, current_count
    from public.submission_rate_limits where user_id = member_id and submission_kind = 'community_places' for update;
  if not found then
    insert into public.submission_rate_limits(user_id, submission_kind, window_started_at, submission_count)
      values (member_id, 'community_places', now_at, 1);
  elsif started_at <= now_at - interval '24 hours' then
    update public.submission_rate_limits set window_started_at = now_at, submission_count = 1
      where user_id = member_id and submission_kind = 'community_places';
  elsif current_count >= 5 then
    raise exception 'submission_rate_limited' using errcode = 'P0001', detail = 'Aguarde 24 horas antes de sugerir mais locais.';
  else
    update public.submission_rate_limits set submission_count = submission_count + 1
      where user_id = member_id and submission_kind = 'community_places';
  end if;
  return new;
end;
$$;
revoke all on function public.limit_community_place_suggestions() from public, anon, authenticated;
drop trigger if exists community_places_submission_limit on public.community_places;
create trigger community_places_submission_limit before insert on public.community_places
  for each row execute function public.limit_community_place_suggestions();

create or replace function public.list_pending_community_places()
returns table(id uuid,title text,category text,city text,description text,latitude double precision,longitude double precision,created_at timestamptz)
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id = auth.uid()) then
    raise exception 'Not authorized' using errcode = '42501';
  end if;
  return query select p.id,p.title,p.category,p.city,p.description,p.latitude,p.longitude,p.created_at
    from public.community_places p where p.status = 'pending' order by p.created_at asc limit 100;
end;
$$;

create or replace function public.moderate_community_place(place_id uuid, decision text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id = auth.uid()) then
    raise exception 'Not authorized' using errcode = '42501';
  end if;
  if decision not in ('approved','rejected') then raise exception 'Invalid decision' using errcode = '22023'; end if;
  update public.community_places set status = decision, moderated_by = auth.uid(), moderated_at = now()
    where id = place_id and status = 'pending';
  if not found then raise exception 'Place not pending' using errcode = 'P0002'; end if;
end;
$$;
revoke all on function public.list_pending_community_places() from public, anon;
revoke all on function public.moderate_community_place(uuid,text) from public, anon;
grant execute on function public.list_pending_community_places() to authenticated;
grant execute on function public.moderate_community_place(uuid,text) to authenticated;
