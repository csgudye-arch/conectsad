-- Queue and moderation actions for community posts.
-- Assign moderators by inserting their auth user id from the trusted SQL editor.

create table public.community_moderators (
  user_id uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.community_moderators enable row level security;
revoke all on public.community_moderators from anon, authenticated;

create or replace function public.list_pending_community_posts()
returns table (
  id uuid,
  author_name text,
  city text,
  category text,
  body text,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
stable
as $$
begin
  if not exists (
    select 1 from public.community_moderators m
    where m.user_id = (select auth.uid())
  ) then
    raise exception 'moderator access required' using errcode = '42501';
  end if;

  return query
    select p.id, coalesce(pr.display_name, 'Membro da comunidade'), p.city,
      p.category, p.body, p.created_at
    from public.community_posts p
    left join public.profiles pr on pr.id = p.author_id
    where p.status = 'pending'
    order by p.created_at asc
    limit 100;
end;
$$;

create or replace function public.moderate_community_post(post_id uuid, decision text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not exists (
    select 1 from public.community_moderators m
    where m.user_id = (select auth.uid())
  ) then
    raise exception 'moderator access required' using errcode = '42501';
  end if;

  if decision not in ('approved', 'rejected') then
    raise exception 'invalid moderation decision' using errcode = '22023';
  end if;

  update public.community_posts
    set status = decision
    where id = post_id and status = 'pending';

  if not found then
    raise exception 'pending post not found' using errcode = 'P0002';
  end if;
end;
$$;

revoke all on function public.list_pending_community_posts() from public, anon;
revoke all on function public.moderate_community_post(uuid, text) from public, anon;
grant execute on function public.list_pending_community_posts() to authenticated;
grant execute on function public.moderate_community_post(uuid, text) to authenticated;
