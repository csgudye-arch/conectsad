-- Role-scoped navigation and private, unified status tracking for a member's submissions.
create table if not exists public.service_providers (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.service_providers enable row level security;
revoke all on public.service_providers from public, anon, authenticated;

create or replace function public.get_current_access()
returns table(is_admin boolean, is_city_moderator boolean, is_service_provider boolean)
language sql stable security definer set search_path = ''
as $$
  select
    exists(select 1 from public.community_moderators m where m.user_id = (select auth.uid())) as is_admin,
    exists(select 1 from public.city_report_moderators c where c.user_id = (select auth.uid()))
      or exists(select 1 from public.community_moderators m where m.user_id = (select auth.uid())) as is_city_moderator,
    exists(select 1 from public.service_providers s where s.user_id = (select auth.uid()))
      or exists(select 1 from public.community_moderators m where m.user_id = (select auth.uid())) as is_service_provider;
$$;
revoke all on function public.get_current_access() from public, anon;
grant execute on function public.get_current_access() to authenticated;

create or replace function public.list_my_submissions()
returns table(submission_id uuid, submission_type text, title text, city text, status text, description text, created_at timestamptz)
language sql stable security definer set search_path = ''
as $$
  select p.id, 'feed'::text, coalesce(nullif(p.title, ''), p.category), p.city, p.status, left(p.body, 240), p.created_at
    from public.community_posts p where p.author_id = (select auth.uid()) and not p.is_official
  union all
  select r.id, 'cidade'::text, r.category, r.city, r.status, left(r.description, 240), r.created_at
    from public.city_reports r where r.author_id = (select auth.uid())
  union all
  select a.id, 'animal'::text, coalesce(nullif(a.animal_name, ''), a.species), a.city, a.status, left(a.description, 240), a.created_at
    from public.animal_reports a where a.owner_id = (select auth.uid())
  union all
  select l.id, 'mercadao'::text, l.title, l.city, l.status, left(l.description, 240), l.created_at
    from public.marketplace_listings l where l.owner_id = (select auth.uid())
  union all
  select s.id, 'servico'::text, s.service_type, s.city, s.status, left(s.description, 240), s.created_at
    from public.service_requests s where s.author_id = (select auth.uid())
  order by 7 desc
  limit 200;
$$;
revoke all on function public.list_my_submissions() from public, anon;
grant execute on function public.list_my_submissions() to authenticated;

-- A provider may handle only service requests. Administrators retain all tools.
create or replace function public.list_service_requests_for_moderation()
returns table(request_id uuid,member_name text,service_type text,city text,neighborhood text,contact text,description text,status text,created_at timestamptz)
language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null or (
    not exists(select 1 from public.community_moderators where user_id=auth.uid()) and
    not exists(select 1 from public.service_providers where user_id=auth.uid())
  ) then raise exception 'Not authorized' using errcode='42501'; end if;
  return query select s.id,p.display_name,s.service_type,s.city,s.neighborhood,s.contact,s.description,s.status,s.created_at
    from public.service_requests s join public.profiles p on p.id=s.author_id
    where s.status in ('received','review','in_progress') order by s.created_at limit 100;
end;
$$;
create or replace function public.moderate_service_request(request_id uuid, decision text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null or (
    not exists(select 1 from public.community_moderators where user_id=auth.uid()) and
    not exists(select 1 from public.service_providers where user_id=auth.uid())
  ) then raise exception 'Not authorized' using errcode='42501'; end if;
  if decision not in ('review','in_progress','completed','closed') then raise exception 'Invalid decision'; end if;
  update public.service_requests set status=decision
    where id=request_id and status in ('received','review','in_progress');
  if not found then raise exception 'Request not available'; end if;
end;
$$;
revoke all on function public.list_service_requests_for_moderation() from public, anon;
revoke all on function public.moderate_service_request(uuid,text) from public, anon;
grant execute on function public.list_service_requests_for_moderation() to authenticated;
grant execute on function public.moderate_service_request(uuid,text) to authenticated;

-- Admins can process city reports too; city moderators remain limited to that queue.
create or replace function public.list_city_reports_for_moderation()
returns table(id uuid,category text,city text,neighborhood text,description text,status text,created_at timestamptz)
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null or (
    not exists(select 1 from public.city_report_moderators where user_id=auth.uid()) and
    not exists(select 1 from public.community_moderators where user_id=auth.uid())
  ) then raise exception 'city report moderator access required' using errcode='42501'; end if;
  return query select r.id,r.category,r.city,r.neighborhood,r.description,r.status,r.created_at
    from public.city_reports r where r.status in ('pending','review','in_progress') order by r.created_at asc limit 100;
end;
$$;
create or replace function public.moderate_city_report(report_id uuid, decision text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null or (
    not exists(select 1 from public.city_report_moderators where user_id=auth.uid()) and
    not exists(select 1 from public.community_moderators where user_id=auth.uid())
  ) then raise exception 'city report moderator access required' using errcode='42501'; end if;
  if decision is null or decision not in ('review','in_progress','resolved','rejected') then raise exception 'invalid city report decision' using errcode='22023'; end if;
  update public.city_reports set status=decision, moderated_by=auth.uid(), moderated_at=now()
    where id=report_id and ((status='pending' and decision in ('review','rejected')) or (status='review' and decision in ('in_progress','rejected')) or (status='in_progress' and decision in ('resolved','rejected')));
  if not found then raise exception 'city report not found or invalid status transition' using errcode='P0002'; end if;
end;
$$;
revoke all on function public.list_city_reports_for_moderation() from public, anon;
revoke all on function public.moderate_city_report(uuid,text) from public, anon;
grant execute on function public.list_city_reports_for_moderation() to authenticated;
grant execute on function public.moderate_city_report(uuid,text) to authenticated;
