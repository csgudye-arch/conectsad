begin;
create function public.social_search_public(search_term text,search_city text default null,page_number integer default 0) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare term text:=trim(coalesce(search_term,''));
begin
 if char_length(term) not between 2 and 80 then raise exception 'Digite de 2 a 80 caracteres para pesquisar.' using errcode='22023';end if;
 return (select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb) from (
 select * from (
 select p.id,'feed'::text kind,coalesce(p.title,p.category)::text title,case when p.sensitive then 'Conteúdo sensível. Abra a publicação para ver o aviso.' else left(p.body,240) end description,p.city,p.created_at,'/?post='||p.id::text url from public.community_posts p where p.status='approved' and (search_city is null or p.city in (search_city,'Grande ABC')) and (coalesce(p.title,'')||' '||p.body||' '||p.category) ilike '%'||term||'%'
 union all select b.id,'empresas',b.name,left(b.description,240),b.city,b.created_at,'/?area=empresas&empresa='||b.id::text from public.social_businesses b where b.status='approved' and (search_city is null or b.city=search_city) and (b.name||' '||b.description||' '||b.category) ilike '%'||term||'%'
 union all select e.id,'agenda',e.title,left(e.description,240),e.city,e.created_at,'/?area=agenda&evento='||e.id::text from public.social_events e where e.status='approved' and (search_city is null or e.city=search_city) and (e.title||' '||e.description) ilike '%'||term||'%'
 union all select l.id,'mercadao',l.title,left(l.description,240),l.city,l.created_at,'/?area=mercadao&anuncio='||l.id::text from public.marketplace_listings l where l.status='active' and (search_city is null or l.city=search_city) and (l.title||' '||l.description||' '||l.category) ilike '%'||term||'%'
 union all select c.id,c.kind,c.title,left(c.description,240),c.city,c.created_at,'/?area='||c.kind||'&anuncio='||c.id::text from public.social_classifieds c where c.status='approved' and (search_city is null or c.city=search_city) and (c.title||' '||c.description) ilike '%'||term||'%'
 union all select g.id,'comunidades',g.name,left(g.description,240),g.city,g.created_at,'/?area=comunidades&grupo='||g.id::text from public.social_groups g where g.status='approved' and (search_city is null or g.city=search_city) and (g.name||' '||g.description) ilike '%'||term||'%'
 union all select a.id,'animais',coalesce(nullif(a.animal_name,''),'Animal '||a.report_type),left(a.description,240),a.city,a.created_at,'/?area=animais' from public.animal_reports a where a.status='active' and (search_city is null or a.city=search_city) and (coalesce(a.animal_name,'')||' '||a.description||' '||a.species) ilike '%'||term||'%'
 ) results order by created_at desc,id limit 24 offset least(greatest(coalesce(page_number,0),0),1000)*24) x);
end; $$;
create function public.social_top_week() returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(to_jsonb(x) order by score desc,created_at desc),'[]'::jsonb) from (select p.id,coalesce(p.title,p.category) title,p.city,case when p.sensitive then 'Conteúdo sensível. Abra para ver o aviso.' else left(p.body,180) end description,p.created_at,(select count(*) from public.community_post_reactions r where r.post_id=p.id and r.created_at>now()-interval '7 days')+(select count(*) from public.social_comments c where c.post_id=p.id and c.status='approved' and c.created_at>now()-interval '7 days') score from public.community_posts p where p.status='approved' and p.created_at>now()-interval '7 days' order by score desc,p.created_at desc limit 5) x;
$$;
revoke all on function public.social_search_public(text,text,integer),public.social_top_week() from public,anon,authenticated;
grant execute on function public.social_search_public(text,text,integer),public.social_top_week() to anon,authenticated;
commit;
