-- Credita +1 ao autor a cada primeiro apoio de outro membro na publicação.
-- A dupla (publicação, apoiador) só pode gerar pontos para o autor uma vez.
begin;

create table if not exists public.feed_reaction_point_awards (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.community_posts(id) on delete cascade,
  supporter_id uuid not null references public.profiles(id) on delete cascade,
  post_author_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (post_id, supporter_id),
  check (supporter_id <> post_author_id)
);

alter table public.feed_reaction_point_awards enable row level security;
revoke all on public.feed_reaction_point_awards from public, anon, authenticated;

drop function if exists public.toggle_community_post_reaction(uuid);

create function public.toggle_community_post_reaction(post_id uuid)
returns table (
  liked boolean,
  reaction_count bigint,
  points_awarded integer,
  author_points_awarded integer
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  member_id uuid := auth.uid();
  post_author_id uuid;
  award_id uuid;
  removed integer := 0;
  inserted integer := 0;
  award_rows integer := 0;
  liker_ledger_rows integer := 0;
  author_ledger_rows integer := 0;
  granted_points integer := 0;
  granted_author_points integer := 0;
begin
  if member_id is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended(member_id::text || ':' || post_id::text, 0)
  );

  select p.author_id into post_author_id
  from public.community_posts p
  where p.id = toggle_community_post_reaction.post_id
    and p.status = 'approved';
  if not found then
    raise exception 'Post is not available for reactions' using errcode = 'P0002';
  end if;
  if post_author_id = member_id then
    raise exception 'You cannot earn points for supporting your own post' using errcode = 'P0001';
  end if;

  delete from public.community_post_reactions r
  where r.post_id = toggle_community_post_reaction.post_id
    and r.user_id = member_id;
  get diagnostics removed = row_count;

  if removed = 0 then
    insert into public.community_post_reactions (post_id, user_id)
    values (toggle_community_post_reaction.post_id, member_id)
    on conflict on constraint community_post_reactions_pkey do nothing;
    get diagnostics inserted = row_count;

    if inserted = 1 then
      insert into public.feed_reaction_point_awards (post_id, supporter_id, post_author_id)
      values (toggle_community_post_reaction.post_id, member_id, post_author_id)
      on conflict (post_id, supporter_id) do nothing
      returning id into award_id;
      get diagnostics award_rows = row_count;

      if award_rows = 1 then
        insert into public.points_ledger (user_id, event_type, points, evidence_id)
        values (member_id, 'feed_like', 3, toggle_community_post_reaction.post_id)
        on conflict do nothing;
        get diagnostics liker_ledger_rows = row_count;
        if liker_ledger_rows = 1 then granted_points := 3; end if;

        insert into public.points_ledger (user_id, event_type, points, evidence_id)
        values (post_author_id, 'feed_like_received', 1, award_id);
        get diagnostics author_ledger_rows = row_count;
        if author_ledger_rows = 1 then granted_author_points := 1; end if;
      end if;
    end if;
  end if;

  return query
    select exists (
      select 1 from public.community_post_reactions r
      where r.post_id = toggle_community_post_reaction.post_id
        and r.user_id = member_id
    ),
    (
      select count(*)::bigint from public.community_post_reactions r
      where r.post_id = toggle_community_post_reaction.post_id
    ),
    granted_points,
    granted_author_points;
end;
$$;

revoke all on function public.toggle_community_post_reaction(uuid) from public, anon;
grant execute on function public.toggle_community_post_reaction(uuid) to authenticated;

commit;
