begin;
create table public.social_stories(id uuid primary key default gen_random_uuid(),author_id uuid not null references public.profiles(id) on delete cascade,caption text not null default '' check(char_length(caption)<=280),city text not null,media_path text not null,media_kind text not null check(media_kind in ('image','video')),status text not null default 'pending' check(status in ('pending','approved','rejected','hidden')),created_at timestamptz not null default now(),expires_at timestamptz not null default now()+interval '24 hours',check(media_path like author_id::text||'/%'));
create index social_stories_active on public.social_stories(expires_at,status);
create index social_stories_author on public.social_stories(author_id,created_at);
create table public.social_story_views(story_id uuid not null references public.social_stories(id) on delete cascade,user_id uuid not null references public.profiles(id) on delete cascade,seen_at timestamptz not null default now(),primary key(story_id,user_id));
create table public.social_story_audit(id bigint generated always as identity primary key,story_id uuid not null references public.social_stories(id) on delete cascade,moderator_id uuid not null references auth.users(id),decision text not null,reason text not null,created_at timestamptz not null default now());
alter table public.social_stories enable row level security;alter table public.social_story_views enable row level security;alter table public.social_story_audit enable row level security;
revoke all on public.social_stories,public.social_story_views,public.social_story_audit from public,anon,authenticated;
create function public.social_create_story(story_caption text,story_city text,attachment_path text,attachment_kind text) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid;
begin
 if auth.uid() is null then raise exception 'Entre para publicar um story.' using errcode='42501';end if;
 if story_caption is null or char_length(trim(story_caption))>280 or not public.social_valid_city(story_city) or attachment_path is null or attachment_path not like auth.uid()::text||'/%' or attachment_kind is null or attachment_kind not in ('image','video') or not exists(select 1 from storage.objects where bucket_id='social-stories' and name=attachment_path and case when attachment_kind='image' then metadata->>'mimetype' in ('image/jpeg','image/png','image/webp') else metadata->>'mimetype' in ('video/mp4','video/webm','video/quicktime') end) then raise exception 'Confira legenda, cidade e mídia do story.' using errcode='22023';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,450));
 if (select count(*) from public.social_stories where author_id=auth.uid() and created_at>now()-interval '24 hours')>=5 then raise exception 'Limite de cinco stories por 24 horas atingido.' using errcode='P0001';end if;
 insert into public.social_stories(author_id,caption,city,media_path,media_kind) values(auth.uid(),trim(story_caption),story_city,attachment_path,attachment_kind) returning id into result;return result;
end; $$;
create function public.social_list_stories(story_city text default null) returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(item order by created_at desc),'[]'::jsonb) from (select s.created_at,jsonb_build_object('id',s.id,'caption',s.caption,'city',s.city,'media_path',s.media_path,'media_kind',s.media_kind,'status',s.status,'first_name',split_part(trim(p.display_name),' ',1),'is_own',coalesce(s.author_id=auth.uid(),false),'expires_at',s.expires_at,'seen',exists(select 1 from public.social_story_views where story_id=s.id and user_id=auth.uid()),'views',case when s.author_id=auth.uid() then (select count(*) from public.social_story_views where story_id=s.id) else null end) item from public.social_stories s join public.profiles p on p.id=s.author_id where s.expires_at>now() and (s.status='approved' or s.author_id=auth.uid()) and (story_city is null or s.city=story_city) order by s.created_at desc limit 100) x;
$$;
create function public.social_see_story(target_story uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para registrar visualização.' using errcode='42501';end if;
 if not exists(select 1 from public.social_stories where id=target_story and status='approved' and expires_at>now()) then raise exception 'Story indisponível.' using errcode='P0002';end if;
 insert into public.social_story_views(story_id,user_id) values(target_story,auth.uid()) on conflict do nothing;
end; $$;
create function public.social_story_queue() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 return (select coalesce(jsonb_agg(to_jsonb(s)-'author_id' order by s.created_at),'[]'::jsonb) from (select * from public.social_stories where status='pending' and expires_at>now() order by created_at limit 100) s);
end; $$;
create function public.social_review_story(target_story uuid,decision text,reason text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 if decision is null or decision not in ('approved','rejected','hidden') or reason is null or char_length(trim(reason)) not between 3 and 500 then raise exception 'Informe decisão e motivo.' using errcode='22023';end if;
 update public.social_stories set status=decision where id=target_story and expires_at>now();if not found then raise exception 'Story indisponível ou expirado.' using errcode='P0002';end if;
 insert into public.social_story_audit(story_id,moderator_id,decision,reason) values(target_story,auth.uid(),decision,trim(reason));
end; $$;
create function public.social_hide_story(target_story uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para retirar o story.' using errcode='42501';end if;
 update public.social_stories set status='hidden' where id=target_story and author_id=auth.uid();if not found then raise exception 'Somente o autor pode retirar seu story.' using errcode='42501';end if;
end; $$;
create function public.social_story_media_readable(object_name text) returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.social_stories where media_path=object_name and expires_at>now() and (status='approved' or author_id=auth.uid() or exists(select 1 from public.community_moderators where user_id=auth.uid()))) $$;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('social-stories','social-stories',false,20971520,array['image/jpeg','image/png','image/webp','video/mp4','video/webm','video/quicktime']);
create policy "Upload own story media" on storage.objects for insert to authenticated with check(bucket_id='social-stories' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Read available story media" on storage.objects for select to anon,authenticated using(bucket_id='social-stories' and public.social_story_media_readable(name));
create policy "Remove own story media" on storage.objects for delete to authenticated using(bucket_id='social-stories' and (storage.foldername(name))[1]=auth.uid()::text);
revoke all on function public.social_create_story(text,text,text,text),public.social_list_stories(text),public.social_see_story(uuid),public.social_story_queue(),public.social_review_story(uuid,text,text),public.social_hide_story(uuid),public.social_story_media_readable(text) from public,anon,authenticated;
grant execute on function public.social_list_stories(text),public.social_story_media_readable(text) to anon,authenticated;
grant execute on function public.social_create_story(text,text,text,text),public.social_see_story(uuid),public.social_story_queue(),public.social_review_story(uuid,text,text),public.social_hide_story(uuid) to authenticated;
commit;
