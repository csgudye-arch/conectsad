begin;

create or replace function public.social_next_home_poll()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select jsonb_build_object(
    'id', poll.id,
    'question', poll.question,
    'city', poll.city,
    'closes_at', poll.closes_at,
    'options', (
      select jsonb_agg(jsonb_build_object('id', opt.id, 'label', opt.label) order by opt.position)
      from public.social_poll_options opt
      where opt.poll_id = poll.id
    )
  )
  from public.social_polls poll
  where poll.status = 'approved'
    and poll.closes_at > now()
    and not exists (
      select 1 from public.social_poll_votes vote
      where vote.poll_id = poll.id and vote.user_id = (select auth.uid())
    )
  order by poll.created_at desc, poll.id
  limit 1;
$$;

revoke all on function public.social_next_home_poll() from public;
grant execute on function public.social_next_home_poll() to anon, authenticated;

commit;
