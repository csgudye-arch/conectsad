begin;
create table public.social_classifieds(id uuid primary key default gen_random_uuid(),owner_id uuid not null references public.profiles(id) on delete cascade,kind text not null check(kind in ('imoveis','vagas','achados')),title text not null check(char_length(title) between 5 and 120),description text not null check(char_length(description) between 20 and 1500),city text not null,neighborhood text not null default '' check(char_length(neighborhood)<=80),price numeric(12,2) check(price is null or price>=0),details jsonb not null,contact text not null check(char_length(contact) between 8 and 120),media_path text check(media_path is null or media_path like owner_id::text||'/%'),status text not null default 'pending' check(status in ('pending','approved','rejected','resolved','hidden')),created_at timestamptz not null default now());
create index social_classifieds_kind on public.social_classifieds(kind,status,created_at desc);
create index social_classifieds_owner on public.social_classifieds(owner_id,created_at desc);
create table public.social_classified_reports(listing_id uuid not null references public.social_classifieds(id) on delete cascade,user_id uuid not null references public.profiles(id) on delete cascade,reason text not null check(char_length(reason) between 3 and 500),reviewed_at timestamptz,primary key(listing_id,user_id));
create table public.social_classified_audit(id bigint generated always as identity primary key,listing_id uuid not null references public.social_classifieds(id) on delete cascade,moderator_id uuid not null references auth.users(id),decision text not null,reason text not null,created_at timestamptz not null default now());
alter table public.social_classifieds enable row level security;alter table public.social_classified_reports enable row level security;alter table public.social_classified_audit enable row level security;
revoke all on public.social_classifieds,public.social_classified_reports,public.social_classified_audit from public,anon,authenticated;
create function public.social_create_classified(listing_kind text,listing_title text,listing_description text,listing_city text,listing_neighborhood text,listing_price numeric,listing_details jsonb,listing_contact text,attachment_path text,contact_consent boolean) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid; safe_details jsonb;
begin
 if auth.uid() is null then raise exception 'Entre para publicar.' using errcode='42501';end if;
 if contact_consent is distinct from true or listing_kind is null or listing_kind not in ('imoveis','vagas','achados') or listing_title is null or char_length(trim(listing_title)) not between 5 and 120 or listing_description is null or char_length(trim(listing_description)) not between 20 and 1500 or not public.social_valid_city(listing_city) or listing_neighborhood is null or char_length(trim(listing_neighborhood))>80 or listing_contact is null or char_length(trim(listing_contact)) not between 8 and 120 or listing_details is null or jsonb_typeof(listing_details)<>'object' or char_length(listing_details::text)>2000 or (listing_price is not null and (listing_price<0 or listing_price>9999999999.99)) then raise exception 'Confira os campos e autorize compartilhar seu contato com membros interessados.' using errcode='22023';end if;
 if attachment_path is not null and (attachment_path not like auth.uid()::text||'/%' or not exists(select 1 from storage.objects where bucket_id='submission-media' and name=attachment_path and metadata->>'mimetype' in ('image/jpeg','image/png','image/webp'))) then raise exception 'Foto inválida.' using errcode='22023';end if;
 if listing_kind='imoveis' then
 if listing_price is null or listing_price<=0 or coalesce(listing_details->>'operation','') not in ('Aluguel','Venda') or coalesce(listing_details->>'type','') not in ('Apartamento','Casa','Comercial','Terreno') or coalesce((listing_details->>'area')::numeric,0) not between 1 and 100000 or coalesce((listing_details->>'bedrooms')::integer,-1) not between 0 and 50 or coalesce((listing_details->>'bathrooms')::integer,-1) not between 0 and 50 or coalesce((listing_details->>'parking')::integer,-1) not between 0 and 50 or coalesce((listing_details->>'condo')::numeric,0) not between 0 and 1000000 then raise exception 'Confira tipo, preço, área e características do imóvel.' using errcode='22023';end if;
 safe_details:=jsonb_build_object('operation',listing_details->>'operation','type',listing_details->>'type','area',(listing_details->>'area')::numeric,'bedrooms',(listing_details->>'bedrooms')::integer,'bathrooms',(listing_details->>'bathrooms')::integer,'parking',(listing_details->>'parking')::integer,'condo',coalesce((listing_details->>'condo')::numeric,0));
 elsif listing_kind='vagas' then
 if char_length(trim(coalesce(listing_details->>'company',''))) not between 2 and 120 or coalesce(listing_details->>'contract','') not in ('CLT','PJ','Estágio','Temporário','Freelancer','Meio período','Aprendiz') or coalesce(listing_details->>'model','') not in ('Presencial','Híbrido','Remoto') then raise exception 'Confira empresa, contrato e modelo de trabalho.' using errcode='22023';end if;
 safe_details:=jsonb_build_object('company',trim(listing_details->>'company'),'contract',listing_details->>'contract','model',listing_details->>'model');
 else
 if coalesce(listing_details->>'report_type','') not in ('Perdi','Achei') or coalesce(listing_details->>'category','') not in ('Documento','Carteira','Chave','Celular','Bolsa','Óculos','Bicicleta','Outro') or (listing_details->>'occurred_on') is null or (listing_details->>'occurred_on')::date>current_date or (listing_details->>'occurred_on')::date<date '2000-01-01' then raise exception 'Confira tipo de aviso, categoria e data do ocorrido.' using errcode='22023';end if;
 safe_details:=jsonb_build_object('report_type',listing_details->>'report_type','category',listing_details->>'category','occurred_on',(listing_details->>'occurred_on')::date);
 end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,470));
 if (select count(*) from public.social_classifieds where owner_id=auth.uid() and created_at>now()-interval '24 hours')>=5 then raise exception 'Limite de cinco anúncios por 24 horas atingido.' using errcode='P0001';end if;
 insert into public.social_classifieds(owner_id,kind,title,description,city,neighborhood,price,details,contact,media_path) values(auth.uid(),listing_kind,trim(listing_title),trim(listing_description),listing_city,trim(listing_neighborhood),case when listing_kind='achados' then null else listing_price end,safe_details,trim(listing_contact),attachment_path) returning id into result;return result;
 exception when invalid_text_representation or invalid_datetime_format or datetime_field_overflow or numeric_value_out_of_range then raise exception 'Revise as datas e os campos numéricos.' using errcode='22023';
end; $$;
create function public.social_list_classifieds(listing_kind text,page_number integer default 0,mine_only boolean default false) returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(item order by created_at desc),'[]'::jsonb) from (select c.created_at,(to_jsonb(c)-'owner_id'-'contact')||jsonb_build_object('is_own',coalesce(c.owner_id=auth.uid(),false)) item from public.social_classifieds c where c.kind=listing_kind and (case when mine_only then c.owner_id=auth.uid() else c.status in ('approved','resolved') end) order by c.created_at desc limit 24 offset least(greatest(coalesce(page_number,0),0),1000)*24) x;
$$;
create function public.social_classified_contact(target_listing uuid) returns text language plpgsql stable security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para solicitar contato.' using errcode='42501';end if;
 return (select contact from public.social_classifieds where id=target_listing and status='approved');
end; $$;
create function public.social_resolve_classified(target_listing uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para atualizar seu anúncio.' using errcode='42501';end if;
 update public.social_classifieds set status='resolved' where id=target_listing and owner_id=auth.uid() and status='approved';if not found then raise exception 'Somente o autor pode encerrar um anúncio publicado.' using errcode='42501';end if;
end; $$;
create function public.social_classified_queue() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 return (select coalesce(jsonb_agg((to_jsonb(c)-'owner_id'-'contact')||jsonb_build_object('reports',(select string_agg(reason,E'\n') from public.social_classified_reports where listing_id=c.id and reviewed_at is null))),'[]'::jsonb) from (select * from public.social_classifieds where status in ('pending','hidden') order by created_at limit 100) c);
end; $$;
create function public.social_review_classified(target_listing uuid,decision text,reason text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 if decision is null or decision not in ('approved','rejected','hidden') or reason is null or char_length(trim(reason)) not between 3 and 500 then raise exception 'Informe decisão e motivo.' using errcode='22023';end if;
 update public.social_classifieds set status=decision where id=target_listing;if not found then raise exception 'Anúncio não encontrado.' using errcode='P0002';end if;
 update public.social_classified_reports set reviewed_at=now() where listing_id=target_listing and reviewed_at is null;
 insert into public.social_classified_audit(listing_id,moderator_id,decision,reason) values(target_listing,auth.uid(),decision,trim(reason));
end; $$;
create function public.social_report_classified(target_listing uuid,report_reason text) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para denunciar.' using errcode='42501';end if;
 if report_reason is null or char_length(trim(report_reason)) not between 3 and 500 then raise exception 'Descreva o motivo em 3 a 500 caracteres.' using errcode='22023';end if;
 perform 1 from public.social_classifieds where id=target_listing and status='approved' for update;if not found then raise exception 'Anúncio indisponível.' using errcode='P0002';end if;
 insert into public.social_classified_reports(listing_id,user_id,reason) values(target_listing,auth.uid(),trim(report_reason)) on conflict do nothing;
 if (select count(*) from public.social_classified_reports where listing_id=target_listing and reviewed_at is null)>=3 then update public.social_classifieds set status='hidden' where id=target_listing;end if;
end; $$;
create function public.social_classified_media_readable(object_name text) returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.social_classifieds where media_path=object_name and (status in ('approved','resolved') or owner_id=auth.uid() or exists(select 1 from public.community_moderators where user_id=auth.uid()))) $$;
create policy "Read available classified photos" on storage.objects for select to anon,authenticated using(bucket_id='submission-media' and public.social_classified_media_readable(name));
revoke all on function public.social_create_classified(text,text,text,text,text,numeric,jsonb,text,text,boolean),public.social_list_classifieds(text,integer,boolean),public.social_classified_contact(uuid),public.social_resolve_classified(uuid),public.social_classified_queue(),public.social_review_classified(uuid,text,text),public.social_report_classified(uuid,text),public.social_classified_media_readable(text) from public,anon,authenticated;
grant execute on function public.social_list_classifieds(text,integer,boolean),public.social_classified_media_readable(text) to anon,authenticated;
grant execute on function public.social_create_classified(text,text,text,text,text,numeric,jsonb,text,text,boolean),public.social_classified_contact(uuid),public.social_resolve_classified(uuid),public.social_classified_queue(),public.social_review_classified(uuid,text,text),public.social_report_classified(uuid,text) to authenticated;
commit;
