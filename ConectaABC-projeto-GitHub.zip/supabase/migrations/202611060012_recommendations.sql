begin;
create table public.social_recommendation_requests(id uuid primary key default gen_random_uuid(),author_id uuid not null references public.profiles(id) on delete cascade,category text not null check(char_length(category) between 2 and 60),city text not null,body text not null check(char_length(body) between 20 and 1000),status text not null default 'pending' check(status in ('pending','approved','rejected','resolved')),created_at timestamptz not null default now());
create table public.social_recommendations(id uuid primary key default gen_random_uuid(),request_id uuid not null references public.social_recommendation_requests(id) on delete cascade,business_id uuid not null references public.social_businesses(id) on delete cascade,author_id uuid not null references public.profiles(id) on delete cascade,body text not null check(char_length(body) between 10 and 500),status text not null default 'pending' check(status in ('pending','approved','rejected')),resolved boolean not null default false,created_at timestamptz not null default now(),unique(request_id,business_id,author_id));
create unique index social_one_solution on public.social_recommendations(request_id) where resolved;
create table public.social_recommendation_audit(id bigint generated always as identity primary key,kind text not null,target_id uuid not null,moderator_id uuid not null references auth.users(id),decision text not null,reason text not null,created_at timestamptz not null default now());
alter table public.social_recommendation_requests enable row level security;alter table public.social_recommendations enable row level security;alter table public.social_recommendation_audit enable row level security;
revoke all on public.social_recommendation_requests,public.social_recommendations,public.social_recommendation_audit from public,anon,authenticated;
create function public.social_ask_recommendation(request_category text,request_city text,request_body text) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid;
begin
 if auth.uid() is null then raise exception 'Entre para pedir uma indicação.' using errcode='42501';end if;
 if request_category is null or char_length(trim(request_category)) not between 2 and 60 or not public.social_valid_city(request_city) or request_body is null or char_length(trim(request_body)) not between 20 and 1000 then raise exception 'Confira categoria, cidade e descrição do pedido.' using errcode='22023';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,480));if (select count(*) from public.social_recommendation_requests where author_id=auth.uid() and created_at>now()-interval '24 hours')>=3 then raise exception 'Limite de três pedidos por dia atingido.' using errcode='P0001';end if;
 insert into public.social_recommendation_requests(author_id,category,city,body) values(auth.uid(),trim(request_category),request_city,trim(request_body)) returning id into result;return result;
end; $$;
create function public.social_recommend_business(target_request uuid,target_business uuid,recommendation_body text) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para indicar uma empresa.' using errcode='42501';end if;
 if recommendation_body is null or char_length(trim(recommendation_body)) not between 10 and 500 then raise exception 'Escreva de 10 a 500 caracteres.' using errcode='22023';end if;
 if not exists(select 1 from public.social_recommendation_requests where id=target_request and status='approved') or not exists(select 1 from public.social_businesses where id=target_business and status='approved' and owner_id<>auth.uid()) then raise exception 'Pedido ou empresa indisponível. O responsável não pode indicar seu próprio negócio.' using errcode='P0002';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,481));if (select count(*) from public.social_recommendations where author_id=auth.uid() and created_at>now()-interval '24 hours')>=10 then raise exception 'Limite diário de indicações atingido.' using errcode='P0001';end if;
 insert into public.social_recommendations(request_id,business_id,author_id,body) values(target_request,target_business,auth.uid(),trim(recommendation_body)) on conflict do nothing;
end; $$;
create function public.social_list_recommendations() returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(item order by created_at desc),'[]'::jsonb) from (select r.created_at,jsonb_build_object('id',r.id,'category',r.category,'city',r.city,'body',r.body,'status',r.status,'is_own',coalesce(r.author_id=auth.uid(),false),'answers',coalesce((select jsonb_agg(jsonb_build_object('id',a.id,'body',a.body,'business_id',b.id,'business_name',b.name,'status',a.status,'resolved',a.resolved)) from public.social_recommendations a join public.social_businesses b on b.id=a.business_id where a.request_id=r.id and b.status='approved' and (a.status='approved' or a.author_id=auth.uid())),'[]'::jsonb)) item from public.social_recommendation_requests r where r.status in ('approved','resolved') or r.author_id=auth.uid() order by r.created_at desc limit 100) x;
$$;
create function public.social_accept_recommendation(target_answer uuid) returns void language plpgsql security definer set search_path='' as $$
declare req uuid;
begin
 if auth.uid() is null then raise exception 'Entre para atualizar seu pedido.' using errcode='42501';end if;
 select a.request_id into req from public.social_recommendations a join public.social_businesses b on b.id=a.business_id where a.id=target_answer and a.status='approved' and b.status='approved';
 if req is null then raise exception 'Indicação indisponível.' using errcode='P0002';end if;
 perform 1 from public.social_recommendation_requests where id=req and author_id=auth.uid() and status='approved' for update;if not found then raise exception 'Somente o autor pode resolver um pedido aberto.' using errcode='42501';end if;
 update public.social_recommendations set resolved=true where id=target_answer;update public.social_recommendation_requests set status='resolved' where id=req;
end; $$;
create function public.social_recommendation_queue() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 return (select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb) from (select id,'request'::text kind,body,city from public.social_recommendation_requests where status='pending' union all select a.id,'answer',a.body||E'\nEmpresa: '||b.name,r.city from public.social_recommendations a join public.social_businesses b on b.id=a.business_id join public.social_recommendation_requests r on r.id=a.request_id where a.status='pending' limit 100) x);
end; $$;
create function public.social_review_recommendation(target_kind text,target_id uuid,decision text,reason text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 if decision is null or decision not in ('approved','rejected') or reason is null or char_length(trim(reason)) not between 3 and 500 then raise exception 'Informe decisão e motivo.' using errcode='22023';end if;
 if target_kind='request' then update public.social_recommendation_requests set status=decision where id=target_id and status='pending';elsif target_kind='answer' then update public.social_recommendations set status=decision where id=target_id and status='pending';else raise exception 'Tipo inválido.' using errcode='22023';end if;
 if not found then raise exception 'Conteúdo não está pendente.' using errcode='P0002';end if;
 insert into public.social_recommendation_audit(kind,target_id,moderator_id,decision,reason) values(target_kind,target_id,auth.uid(),decision,trim(reason));
end; $$;
create function public.social_recommendation_ranking() returns jsonb language sql stable security definer set search_path='' as $$ select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb) from (select b.id,b.name,b.city,count(*) solutions from public.social_recommendations a join public.social_businesses b on b.id=a.business_id where a.resolved and a.status='approved' and b.status='approved' group by b.id,b.name,b.city order by count(*) desc,b.name limit 50) x $$;
revoke all on function public.social_ask_recommendation(text,text,text),public.social_recommend_business(uuid,uuid,text),public.social_list_recommendations(),public.social_accept_recommendation(uuid),public.social_recommendation_queue(),public.social_review_recommendation(text,uuid,text,text),public.social_recommendation_ranking() from public,anon,authenticated;
grant execute on function public.social_list_recommendations(),public.social_recommendation_ranking() to anon,authenticated;
grant execute on function public.social_ask_recommendation(text,text,text),public.social_recommend_business(uuid,uuid,text),public.social_accept_recommendation(uuid),public.social_recommendation_queue(),public.social_review_recommendation(text,uuid,text,text) to authenticated;
commit;
