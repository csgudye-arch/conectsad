-- Agenda aditiva: inscrições privadas; divulgação sempre passa pela equipe.
begin;
create table public.social_events (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.profiles(id) on delete cascade,
 title text not null check(char_length(title) between 5 and 120), description text not null check(char_length(description) between 20 and 2000),
 city text not null, venue text not null check(char_length(venue) between 5 and 200),
 starts_at timestamptz not null, ends_at timestamptz not null check(ends_at>starts_at),
 status text not null default 'pending' check(status in ('pending','approved','rejected','cancelled')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index social_events_start on public.social_events(starts_at);
create index social_events_owner on public.social_events(owner_id,created_at);
create table public.social_event_attendance (
 event_id uuid not null references public.social_events(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(event_id,user_id)
);
create table public.social_event_audit (
 id bigint generated always as identity primary key,event_id uuid not null references public.social_events(id) on delete cascade,
 actor_id uuid not null references auth.users(id),decision text not null,reason text not null,created_at timestamptz not null default now()
);
alter table public.social_events enable row level security;
alter table public.social_event_attendance enable row level security;
alter table public.social_event_audit enable row level security;
revoke all on public.social_events,public.social_event_attendance,public.social_event_audit from public,anon,authenticated;

create function public.social_create_event(event_title text,event_description text,event_city text,event_venue text,event_start timestamptz,event_end timestamptz) returns uuid
language plpgsql security definer set search_path='' as $$
declare result uuid; actor uuid:=auth.uid();
begin
 if actor is null then raise exception 'Entre para divulgar um evento.' using errcode='42501'; end if;
 if event_title is null or char_length(trim(event_title)) not between 5 and 120 or event_description is null or char_length(trim(event_description)) not between 20 and 2000 or not public.social_valid_city(event_city) or event_venue is null or char_length(trim(event_venue)) not between 5 and 200 then raise exception 'Confira título, descrição, cidade e local público do evento.' using errcode='22023'; end if;
 if event_start is null or event_end is null or event_start<now()+interval '30 minutes' or event_start>now()+interval '1 year' or event_end<=event_start or event_end>event_start+interval '7 days' then raise exception 'Informe uma data futura e um término posterior ao início (duração máxima de sete dias).' using errcode='22023'; end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,430));
 if (select count(*) from public.social_events where owner_id=actor and created_at>now()-interval '24 hours')>=3 then raise exception 'Limite de três eventos por dia atingido.' using errcode='P0001'; end if;
 insert into public.social_events(owner_id,title,description,city,venue,starts_at,ends_at) values(actor,trim(event_title),trim(event_description),event_city,trim(event_venue),event_start,event_end) returning id into result;
 return result;
end; $$;

create function public.social_list_events(target_event uuid default null) returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(item order by starts_at),'[]'::jsonb) from (
 select e.starts_at,jsonb_build_object('id',e.id,'title',e.title,'description',e.description,'city',e.city,'venue',e.venue,'starts_at',e.starts_at,'ends_at',e.ends_at,'status',e.status,'is_own',coalesce(e.owner_id=auth.uid(),false),'attending',exists(select 1 from public.social_event_attendance a where a.event_id=e.id and a.user_id=auth.uid()),'attendees',(select count(*) from public.social_event_attendance a where a.event_id=e.id)) item
 from public.social_events e where (target_event is null or e.id=target_event) and (e.status in ('approved','cancelled') or e.owner_id=auth.uid())
 order by case when e.ends_at>=now() then 0 else 1 end,e.starts_at desc limit 200) rows;
$$;

create function public.social_attend_event(target_event uuid,attending boolean) returns void language plpgsql security definer set search_path='' as $$
declare item public.social_events;
begin
 if auth.uid() is null then raise exception 'Entre para confirmar presença.' using errcode='42501'; end if;
 if attending is null then raise exception 'Selecione a ação.' using errcode='22023'; end if;
 if not attending then delete from public.social_event_attendance where event_id=target_event and user_id=auth.uid(); return; end if;
 select * into item from public.social_events where id=target_event for update;
 if not found or item.status<>'approved' or item.ends_at<=now() then raise exception 'Este evento não aceita confirmações de presença.' using errcode='P0002'; end if;
 insert into public.social_event_attendance(event_id,user_id) values(target_event,auth.uid()) on conflict do nothing;
end; $$;

create function public.social_event_queue() returns setof public.social_events language plpgsql stable security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501'; end if;
 return query select * from public.social_events where status='pending' order by created_at limit 100;
end; $$;

create function public.social_review_event(target_event uuid,decision text,reason text) returns void language plpgsql security definer set search_path='' as $$
declare item public.social_events; is_moderator boolean;
begin
 if auth.uid() is null then raise exception 'Entre para continuar.' using errcode='42501'; end if;
 select exists(select 1 from public.community_moderators where user_id=auth.uid()) into is_moderator;
 select * into item from public.social_events where id=target_event for update;
 if not found then raise exception 'Evento não encontrado.' using errcode='P0002'; end if;
 if not is_moderator and not (item.owner_id=auth.uid() and decision='cancelled') then raise exception 'Ação restrita ao responsável ou à equipe.' using errcode='42501'; end if;
 if decision is null or decision not in ('approved','rejected','cancelled') or reason is null or char_length(trim(reason)) not between 3 and 500 then raise exception 'Informe a decisão e o motivo (3 a 500 caracteres).' using errcode='22023'; end if;
 if item.status=decision then return; end if;
 if item.status='cancelled' then raise exception 'Um evento cancelado não pode ser reaberto.' using errcode='P0001'; end if;
 if decision='approved' and item.ends_at<=now() then raise exception 'O evento já terminou.' using errcode='P0001'; end if;
 -- Cancelamento de rascunho não torna um evento rejeitado/pendente público.
 if decision='cancelled' and item.status<>'approved' then decision:='rejected'; end if;
 update public.social_events set status=decision,updated_at=now() where id=target_event;
 insert into public.social_event_audit(event_id,actor_id,decision,reason) values(target_event,auth.uid(),decision,trim(reason));
end; $$;
revoke all on function public.social_create_event(text,text,text,text,timestamptz,timestamptz),public.social_list_events(uuid),public.social_attend_event(uuid,boolean),public.social_event_queue(),public.social_review_event(uuid,text,text) from public,anon,authenticated;
grant execute on function public.social_list_events(uuid) to anon,authenticated;
grant execute on function public.social_create_event(text,text,text,text,timestamptz,timestamptz),public.social_attend_event(uuid,boolean),public.social_event_queue(),public.social_review_event(uuid,text,text) to authenticated;
-- Índices de apoio às contagens e consultas das etapas anteriores.
create index social_poll_votes_option_idx on public.social_poll_votes(option_id);
create index social_group_members_user_idx on public.social_group_members(user_id,group_id);
commit;
