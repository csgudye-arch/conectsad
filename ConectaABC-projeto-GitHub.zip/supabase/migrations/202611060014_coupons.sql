begin;
create table public.social_coupon_settings(id boolean primary key default true check(id),enabled boolean not null default false);
insert into public.social_coupon_settings(id) values(true);
create table public.social_coupons(id uuid primary key default gen_random_uuid(),business_id uuid not null references public.social_businesses(id) on delete cascade,title text not null check(char_length(title) between 5 and 120),rules text not null check(char_length(rules) between 20 and 1500),minimum_level integer not null check(minimum_level between 1 and 10),stock integer check(stock is null or stock between 1 and 1000000),expires_at timestamptz not null,status text not null default 'pending' check(status in ('pending','approved','rejected','closed')),created_at timestamptz not null default now());
create index social_coupons_business on public.social_coupons(business_id,created_at);
create table public.social_coupon_claims(id uuid primary key default gen_random_uuid(),coupon_id uuid not null references public.social_coupons(id) on delete cascade,user_id uuid not null references public.profiles(id) on delete cascade,created_at timestamptz not null default now(),used_at timestamptz,used_by uuid references auth.users(id),unique(coupon_id,user_id));
create table public.social_coupon_audit(id bigint generated always as identity primary key,coupon_id uuid not null references public.social_coupons(id) on delete cascade,moderator_id uuid not null references auth.users(id),decision text not null,reason text not null,created_at timestamptz not null default now());
alter table public.social_coupon_settings enable row level security;alter table public.social_coupons enable row level security;alter table public.social_coupon_claims enable row level security;alter table public.social_coupon_audit enable row level security;
revoke all on public.social_coupon_settings,public.social_coupons,public.social_coupon_claims,public.social_coupon_audit from public,anon,authenticated;
create function public.social_create_coupon(target_business uuid,coupon_title text,coupon_rules text,coupon_level integer,coupon_stock integer,coupon_expiry timestamptz) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid;
begin
 if auth.uid() is null or not exists(select 1 from public.social_businesses where id=target_business and owner_id=auth.uid() and status='approved') then raise exception 'Somente o responsável por uma empresa aprovada pode criar cupons.' using errcode='42501';end if;
 if coupon_title is null or char_length(trim(coupon_title)) not between 5 and 120 or coupon_rules is null or char_length(trim(coupon_rules)) not between 20 and 1500 or coupon_level is null or coupon_level not between 1 and 10 or coupon_stock is not null and coupon_stock not between 1 and 1000000 or coupon_expiry is null or coupon_expiry<=now() or coupon_expiry>now()+interval '1 year' then raise exception 'Confira título, regras, nível, estoque e validade futura.' using errcode='22023';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,490));if (select count(*) from public.social_coupons c join public.social_businesses b on b.id=c.business_id where b.owner_id=auth.uid() and c.created_at>now()-interval '24 hours')>=5 then raise exception 'Limite de cinco cupons criados por dia atingido.' using errcode='P0001';end if;
 insert into public.social_coupons(business_id,title,rules,minimum_level,stock,expires_at) values(target_business,trim(coupon_title),trim(coupon_rules),coupon_level,coupon_stock,coupon_expiry) returning id into result;return result;
end; $$;
create function public.social_list_coupons() returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('enabled',(select enabled from public.social_coupon_settings where id),'coupons',coalesce((select jsonb_agg(item order by expires_at) from (select c.expires_at,jsonb_build_object('id',c.id,'title',c.title,'rules',c.rules,'minimum_level',c.minimum_level,'minimum_points',l.minimum_points,'stock',c.stock,'claimed',(select count(*) from public.social_coupon_claims where coupon_id=c.id),'expires_at',c.expires_at,'status',c.status,'business_id',b.id,'business_name',b.name,'city',b.city,'is_own',coalesce(b.owner_id=auth.uid(),false),'my_claim',(select jsonb_build_object('id',id,'used_at',used_at) from public.social_coupon_claims where coupon_id=c.id and user_id=auth.uid())) item from public.social_coupons c join public.social_businesses b on b.id=c.business_id join public.social_levels l on l.level=c.minimum_level where b.owner_id=auth.uid() or ((select enabled from public.social_coupon_settings where id) and b.status='approved' and c.status='approved' and c.expires_at>now()) order by c.expires_at limit 100) x),'[]'::jsonb));
$$;
create function public.social_claim_coupon(target_coupon uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare item public.social_coupons;result uuid;minimum integer;
begin
 if auth.uid() is null then raise exception 'Entre para resgatar um cupom.' using errcode='42501';end if;
 if not coalesce((select enabled from public.social_coupon_settings where id),false) then raise exception 'O clube de benefícios está fechado por enquanto.' using errcode='P0001';end if;
 select * into item from public.social_coupons where id=target_coupon for update;
 if not found or item.status<>'approved' or item.expires_at<=now() or not exists(select 1 from public.social_businesses where id=item.business_id and status='approved' and owner_id<>auth.uid()) then raise exception 'Cupom indisponível.' using errcode='P0002';end if;
 select id into result from public.social_coupon_claims where coupon_id=target_coupon and user_id=auth.uid();if result is not null then return result;end if;
 select minimum_points into minimum from public.social_levels where level=item.minimum_level;
 if minimum is null or (select coalesce(sum(points),0) from public.points_ledger where user_id=auth.uid())<minimum then raise exception 'Seu nível ainda não atende às regras deste cupom.' using errcode='P0001';end if;
 if item.stock is not null and (select count(*) from public.social_coupon_claims where coupon_id=target_coupon)>=item.stock then raise exception 'Estoque esgotado.' using errcode='P0001';end if;
 insert into public.social_coupon_claims(coupon_id,user_id) values(target_coupon,auth.uid()) returning id into result;return result;
end; $$;
create function public.social_my_coupons() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para acessar seus cupons.' using errcode='42501';end if;
 return (select coalesce(jsonb_agg(jsonb_build_object('id',a.id,'title',c.title,'business_name',b.name,'used_at',a.used_at,'expires_at',c.expires_at)),'[]'::jsonb) from public.social_coupon_claims a join public.social_coupons c on c.id=a.coupon_id join public.social_businesses b on b.id=c.business_id where a.user_id=auth.uid());
end; $$;
create function public.social_validate_coupon(claim_code uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare claim public.social_coupon_claims; item public.social_coupons; biz public.social_businesses;
begin
 if auth.uid() is null then raise exception 'Entre com a conta responsável pelo negócio.' using errcode='42501';end if;
 if not coalesce((select enabled from public.social_coupon_settings where id),false) then raise exception 'A validação está fechada enquanto o clube estiver fechado.' using errcode='P0001';end if;
 select * into claim from public.social_coupon_claims where id=claim_code for update;
 if not found then raise exception 'Código não encontrado.' using errcode='P0002';end if;
 select * into item from public.social_coupons where id=claim.coupon_id;select * into biz from public.social_businesses where id=item.business_id;
 if biz.owner_id<>auth.uid() and not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Este cupom pertence a outro negócio.' using errcode='42501';end if;
 if item.status<>'approved' or biz.status<>'approved' or item.expires_at<=now() then raise exception 'Cupom expirado ou indisponível.' using errcode='P0002';end if;
 if claim.used_at is not null then return jsonb_build_object('already_used',true,'used_at',claim.used_at,'title',item.title);end if;
 update public.social_coupon_claims set used_at=now(),used_by=auth.uid() where id=claim_code;
 return jsonb_build_object('already_used',false,'used_at',now(),'title',item.title,'first_name',(select split_part(trim(display_name),' ',1) from public.profiles where id=claim.user_id));
end; $$;
create function public.social_coupon_queue() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 return (select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb) from (select c.*,b.name business_name from public.social_coupons c join public.social_businesses b on b.id=c.business_id where c.status='pending' order by c.created_at limit 100) x);
end; $$;
create function public.social_review_coupon(target_coupon uuid,decision text,reason text) returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 if decision is null or decision not in ('approved','rejected','closed') or reason is null or char_length(trim(reason)) not between 3 and 500 then raise exception 'Informe decisão e motivo.' using errcode='22023';end if;
 update public.social_coupons set status=decision where id=target_coupon;if not found then raise exception 'Cupom não encontrado.' using errcode='P0002';end if;
 insert into public.social_coupon_audit(coupon_id,moderator_id,decision,reason) values(target_coupon,auth.uid(),decision,trim(reason));
end; $$;
revoke all on function public.social_create_coupon(uuid,text,text,integer,integer,timestamptz),public.social_list_coupons(),public.social_claim_coupon(uuid),public.social_my_coupons(),public.social_validate_coupon(uuid),public.social_coupon_queue(),public.social_review_coupon(uuid,text,text) from public,anon,authenticated;
grant execute on function public.social_list_coupons() to anon,authenticated;
grant execute on function public.social_create_coupon(uuid,text,text,integer,integer,timestamptz),public.social_claim_coupon(uuid),public.social_my_coupons(),public.social_validate_coupon(uuid),public.social_coupon_queue(),public.social_review_coupon(uuid,text,text) to authenticated;
commit;
