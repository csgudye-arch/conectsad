begin;
create function public.social_export_my_data() returns jsonb language plpgsql stable security definer set search_path='' as $$
declare actor uuid:=auth.uid();result jsonb;spec record;records jsonb;
begin
 if actor is null then raise exception 'Entre para exportar seus dados.' using errcode='42501';end if;
 select jsonb_build_object('generated_at',now(),'profile',jsonb_build_object('id',p.id,'display_name',p.display_name,'city',p.city,'referral_code',p.referral_code,'avatar_path',p.avatar_path,'avatar_public',p.avatar_public,'created_at',p.created_at),'social_profile',(select to_jsonb(d) from public.social_member_details d where d.user_id=actor)) into result from public.profiles p where p.id=actor;
 for spec in select * from (values('community_posts','author_id'),('city_reports','author_id'),('service_requests','author_id'),('marketplace_listings','owner_id'),('animal_reports','owner_id'),('community_places','author_id'),('points_ledger','user_id'),('social_comments','author_id'),('social_bookmarks','user_id'),('social_notifications','user_id'),('social_polls','author_id'),('social_poll_votes','user_id'),('social_groups','owner_id'),('social_group_members','user_id'),('social_group_posts','author_id'),('social_events','owner_id'),('social_event_attendance','user_id'),('social_businesses','owner_id'),('social_business_followers','user_id'),('social_stories','author_id'),('social_story_views','user_id'),('social_place_visits','user_id'),('social_place_reviews','user_id'),('social_classifieds','owner_id'),('social_recommendation_requests','author_id'),('social_recommendations','author_id'),('social_coupon_claims','user_id')) as t(table_name,column_name) loop
 execute format('select coalesce(jsonb_agg(to_jsonb(t)),''[]''::jsonb) from public.%I t where %I=$1',spec.table_name,spec.column_name) into records using actor;
 result:=coalesce(result,'{}'::jsonb)||jsonb_build_object(spec.table_name,records);
 end loop;
 return result;
end; $$;
create function public.social_request_account_deletion(confirm_text text) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid;
begin
 if auth.uid() is null then raise exception 'Entre para solicitar exclusão.' using errcode='42501';end if;
 if confirm_text is distinct from 'EXCLUIR MINHA CONTA' then raise exception 'Digite EXCLUIR MINHA CONTA para confirmar.' using errcode='22023';end if;
 insert into public.social_account_requests(user_id,kind) values(auth.uid(),'delete_account') on conflict(user_id) where status='requested' do update set kind='delete_account' returning id into result;return result;
end; $$;
create function public.social_cancel_account_deletion(request_id uuid) returns void language plpgsql security definer set search_path='' as $$ begin update public.social_account_requests set status='cancelled' where id=request_id and user_id=auth.uid() and status='requested';end; $$;
create function public.social_my_account_requests() returns jsonb language plpgsql stable security definer set search_path='' as $$ begin if auth.uid() is null then raise exception 'Entre para consultar solicitações.' using errcode='42501';end if;return (select coalesce(jsonb_agg(to_jsonb(r)),'[]'::jsonb) from public.social_account_requests r where r.user_id=auth.uid());end; $$;
create function public.social_account_deletion_queue() returns jsonb language plpgsql stable security definer set search_path='' as $$ begin if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;return (select coalesce(jsonb_agg(jsonb_build_object('id',r.id,'user_id',r.user_id,'first_name',split_part(trim(p.display_name),' ',1),'city',p.city,'created_at',r.created_at)),'[]'::jsonb) from public.social_account_requests r join public.profiles p on p.id=r.user_id where r.status='requested');end; $$;
-- Somente a Edge Function com credencial de serviço pode preparar a exclusão.
create function public.social_prepare_account_delete(target_user uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare fk record; blocked boolean;files jsonb;
begin
 if target_user is null or not exists(select 1 from auth.users where id=target_user) then raise exception 'Conta não encontrada.' using errcode='P0002';end if;
 if exists(select 1 from public.community_moderators where user_id=target_user) or exists(select 1 from public.city_report_moderators where user_id=target_user) or exists(select 1 from public.service_providers where user_id=target_user) or exists(select 1 from public.referral_verifiers where user_id=target_user) then raise exception 'Contas da equipe exigem transferência de responsabilidades antes da exclusão. Solicite análise pelo perfil.' using errcode='P0001';end if;
 for fk in select ns.nspname schema_name,cl.relname table_name,a.attname column_name from pg_catalog.pg_constraint c join pg_catalog.pg_class cl on cl.oid=c.conrelid join pg_catalog.pg_namespace ns on ns.oid=cl.relnamespace join pg_catalog.pg_attribute a on a.attrelid=c.conrelid and a.attnum=c.conkey[1] where c.contype='f' and c.confrelid in ('auth.users'::regclass,'public.profiles'::regclass) and c.confdeltype in ('a','r') and array_length(c.conkey,1)=1 and ns.nspname<>'storage' loop
 execute format('select exists(select 1 from %I.%I where %I=$1)',fk.schema_name,fk.table_name,fk.column_name) into blocked using target_user;
 if blocked then raise exception 'Há registros operacionais vinculados à conta. Solicite análise da equipe pelo perfil.' using errcode='P0001';end if;
 end loop;
 select coalesce(jsonb_agg(jsonb_build_object('bucket',bucket_id,'path',name)),'[]'::jsonb) into files from storage.objects where name like target_user::text||'/%' and bucket_id in ('member-avatars','feed-media','submission-media','social-covers','social-stories');
 return jsonb_build_object('user_id',target_user,'files',files);
end; $$;
revoke all on function public.social_export_my_data(),public.social_request_account_deletion(text),public.social_cancel_account_deletion(uuid),public.social_my_account_requests(),public.social_account_deletion_queue(),public.social_prepare_account_delete(uuid) from public,anon,authenticated;
grant execute on function public.social_export_my_data(),public.social_request_account_deletion(text),public.social_cancel_account_deletion(uuid),public.social_my_account_requests(),public.social_account_deletion_queue() to authenticated;
grant execute on function public.social_prepare_account_delete(uuid) to service_role;
commit;
