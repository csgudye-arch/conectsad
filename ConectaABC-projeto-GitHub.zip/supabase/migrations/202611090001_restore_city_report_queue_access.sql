-- Keep queue access aligned with get_current_access() and moderate_city_report().
-- The attachment migration replaced the queue function and omitted community moderators.
begin;

create or replace function public.list_city_reports_for_moderation()
returns table (
  id uuid, category text, city text, neighborhood text, description text,
  status text, created_at timestamptz, media_path text
)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is null or (
    not exists (
      select 1 from public.city_report_moderators m where m.user_id = (select auth.uid())
    ) and not exists (
      select 1 from public.community_moderators m where m.user_id = (select auth.uid())
    )
  ) then
    raise exception 'city report moderator access required' using errcode = '42501';
  end if;

  return query
    select r.id, r.category, r.city, r.neighborhood, r.description, r.status, r.created_at, r.media_path
    from public.city_reports r
    where r.status in ('pending', 'review', 'in_progress')
    order by r.created_at asc
    limit 100;
end;
$$;

revoke all on function public.list_city_reports_for_moderation() from public, anon;
grant execute on function public.list_city_reports_for_moderation() to authenticated;

commit;
