begin;
create function public.social_feed_scope(post_scope text) returns uuid[] language plpgsql stable security definer set search_path='' as $$
declare ids uuid[];
begin
 if auth.uid() is null then return array[]::uuid[];end if;
 if post_scope='amigos' then
 select array_agg(p.id) into ids from public.community_posts p where p.status='approved' and not p.is_anonymous and exists(select 1 from public.social_friendships f where f.status='accepted' and (f.sender_id=auth.uid() and f.receiver_id=p.author_id or f.receiver_id=auth.uid() and f.sender_id=p.author_id));
 elsif post_scope='bairro' then
 select array_agg(p.id) into ids from public.community_posts p join public.social_member_details author on author.user_id=p.author_id and author.public_enabled join public.social_member_details me on me.user_id=auth.uid() join public.profiles own on own.id=auth.uid() where p.status='approved' and not p.is_anonymous and me.neighborhood<>'' and lower(author.neighborhood)=lower(me.neighborhood) and p.city=own.city;
 else raise exception 'Selecione amigos ou bairro.' using errcode='22023';end if;
 return coalesce(ids,array[]::uuid[]);
end; $$;
create function public.social_public_post(target_post uuid) returns jsonb language sql stable security definer set search_path='' as $$ select jsonb_build_object('id',p.id,'author_id',case when p.is_anonymous then null else p.author_id end,'category',p.category,'city',p.city,'body',p.body,'status',p.status,'created_at',p.created_at,'title',p.title,'source',p.source,'sensitive',p.sensitive,'is_official',p.is_official,'is_anonymous',p.is_anonymous,'media_path',p.media_path,'media_kind',p.media_kind) from public.community_posts p where p.id=target_post and p.status='approved' $$;
create function public.social_get_classified(target_listing uuid) returns jsonb language sql stable security definer set search_path='' as $$ select coalesce(jsonb_agg((to_jsonb(c)-'owner_id'-'contact')||jsonb_build_object('is_own',coalesce(c.owner_id=auth.uid(),false))),'[]'::jsonb) from public.social_classifieds c where c.id=target_listing and (c.status in ('approved','resolved') or c.owner_id=auth.uid()) $$;
create function public.social_get_group(target_group uuid) returns jsonb language sql stable security definer set search_path='' as $$ select jsonb_build_object('minimum_points',(select community_min_points from public.social_hub_settings where id),'groups',coalesce((select jsonb_agg(jsonb_build_object('id',g.id,'name',g.name,'description',g.description,'category',g.category,'city',g.city,'status',g.status,'is_own',coalesce(g.owner_id=auth.uid(),false),'joined',exists(select 1 from public.social_group_members m where m.group_id=g.id and m.user_id=auth.uid()),'members',(select count(*) from public.social_group_members m where m.group_id=g.id))) from public.social_groups g where g.id=target_group and (g.status='approved' or g.owner_id=auth.uid())),'[]'::jsonb)) $$;
revoke all on function public.social_feed_scope(text),public.social_public_post(uuid),public.social_get_classified(uuid),public.social_get_group(uuid) from public,anon,authenticated;
grant execute on function public.social_public_post(uuid),public.social_get_classified(uuid),public.social_get_group(uuid) to anon,authenticated;
grant execute on function public.social_feed_scope(text) to authenticated;

create or replace function public.social_search_public(search_term text,search_city text default null,page_number integer default 0) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare term text:=trim(coalesce(search_term,''));
begin
 if char_length(term) not between 2 and 80 then raise exception 'Digite de 2 a 80 caracteres para pesquisar.' using errcode='22023';end if;
 return (select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb) from (
 select * from (
 select p.id,'feed'::text kind,coalesce(p.title,p.category)::text title,case when p.sensitive then 'Conteúdo sensível. Abra a publicação para ver o aviso.' else left(p.body,240) end description,p.city,p.created_at,'/?post='||p.id::text url from public.community_posts p where p.status='approved' and (search_city is null or p.city in (search_city,'Grande ABC')) and (coalesce(p.title,'')||' '||p.body||' '||p.category) ilike '%'||term||'%'
 union all select b.id,'empresas',b.name,left(b.description,240),b.city,b.created_at,'/?area=empresas&empresa='||b.id::text from public.social_businesses b where b.status='approved' and (search_city is null or b.city=search_city) and (b.name||' '||b.description||' '||b.category) ilike '%'||term||'%'
 union all select e.id,'agenda',e.title,left(e.description,240),e.city,e.created_at,'/?area=agenda&evento='||e.id::text from public.social_events e where e.status='approved' and (search_city is null or e.city=search_city) and (e.title||' '||e.description) ilike '%'||term||'%'
 union all select l.id,'mercadao',l.title,left(l.description,240),l.city,l.created_at,'/?area=mercadao&anuncio='||l.id::text from public.marketplace_listings l where l.status='active' and (search_city is null or l.city=search_city) and (l.title||' '||l.description||' '||l.category) ilike '%'||term||'%'
 union all select c.id,c.kind,c.title,left(c.description,240),c.city,c.created_at,'/?area='||c.kind||'&anuncio='||c.id::text from public.social_classifieds c where c.status='approved' and (search_city is null or c.city=search_city) and (c.title||' '||c.description) ilike '%'||term||'%'
 union all select g.id,'comunidades',g.name,left(g.description,240),g.city,g.created_at,'/?area=comunidades&grupo='||g.id::text from public.social_groups g where g.status='approved' and (search_city is null or g.city=search_city) and (g.name||' '||g.description) ilike '%'||term||'%'
 union all select a.id,'animais',coalesce(nullif(a.animal_name,''),'Animal '||a.report_type),left(a.description,240),a.city,a.created_at,'/?area=animais' from public.animal_reports a where a.status='active' and (search_city is null or a.city=search_city) and (coalesce(a.animal_name,'')||' '||a.description||' '||a.species) ilike '%'||term||'%'
 ) results order by created_at desc,id limit 24 offset least(greatest(coalesce(page_number,0),0),1000)*24) x);
end; $$;
commit;
