-- Acesso a anexos sem reabrir SELECT direto na tabela do Feed.
begin;

create or replace function public.can_access_feed_media(object_name text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select
    (select auth.uid())::text = (storage.foldername(object_name))[1]
    or exists (
      select 1 from public.community_posts p
      where p.media_path = object_name
        and (p.status = 'approved' or p.author_id = (select auth.uid()))
    )
    or (
      (select auth.uid()) is not null
      and exists (select 1 from public.community_moderators m where m.user_id = (select auth.uid()))
      and exists (select 1 from public.community_posts p where p.media_path = object_name and p.status = 'pending')
    );
$$;

revoke all on function public.can_access_feed_media(text) from public;
grant execute on function public.can_access_feed_media(text) to anon, authenticated;

drop policy if exists "Members view feed media they may access" on storage.objects;
create policy "Members view feed media they may access"
  on storage.objects for select to anon, authenticated
  using (bucket_id = 'feed-media' and public.can_access_feed_media(name));

commit;
