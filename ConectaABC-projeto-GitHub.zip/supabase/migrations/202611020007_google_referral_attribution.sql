-- OAuth users visit the profile completion screen after auth.users/profile creation.
create or replace function public.attribute_my_referral(referral_code_input text)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  member_id uuid := auth.uid();
  referrer_id uuid;
  confirmed_at timestamptz;
begin
  if member_id is null or referral_code_input !~ '^[A-Fa-f0-9]{10}$' then
    return false;
  end if;
  select p.id into referrer_id from public.profiles p
    where p.referral_code = upper(referral_code_input) and p.id <> member_id;
  if referrer_id is null then return false; end if;
  select u.email_confirmed_at into confirmed_at from auth.users u where u.id = member_id;
  insert into public.referral_attributions (referred_user_id, referrer_user_id, email_confirmed_at)
    values (member_id, referrer_id, confirmed_at)
    on conflict (referred_user_id) do nothing;
  return found;
end;
$$;
revoke all on function public.attribute_my_referral(text) from public, anon;
grant execute on function public.attribute_my_referral(text) to authenticated;
