-- Completa a criação de perfis para cadastro por e-mail e OAuth (Google).
-- Apenas cidades do Grande ABC são aceitas; metadados do provedor são não confiáveis.

create or replace function public.create_profile_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  requested_city text := nullif(trim(new.raw_user_meta_data ->> 'city'), '');
  requested_name text := coalesce(
    nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''),
    nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''),
    nullif(trim(new.raw_user_meta_data ->> 'name'), '')
  );
begin
  insert into public.profiles (id, display_name, city)
  values (
    new.id,
    coalesce(left(requested_name, 80), 'Novo membro'),
    case when requested_city in (
      'Santo André', 'São Bernardo do Campo', 'São Caetano do Sul',
      'Diadema', 'Mauá', 'Ribeirão Pires', 'Rio Grande da Serra'
    ) then requested_city else null end
  );
  return new;
end;
$$;

revoke all on function public.create_profile_for_new_user() from public, anon, authenticated;
