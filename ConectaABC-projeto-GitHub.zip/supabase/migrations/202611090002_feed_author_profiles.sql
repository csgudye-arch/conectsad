begin;

-- Only resolve identity for posts visible to the caller. Never match anonymous posts.
create or replace function public.social_feed_authors(post_ids uuid[])
returns table (post_id uuid, first_name text, avatar_path text)
language sql
stable
security definer
set search_path = ''
as $$
  select post.id,
    substring(btrim(profile.display_name) from '^[^[:space:]]+'),
    case when profile.avatar_public then profile.avatar_path end
  from public.community_posts post
  join public.profiles profile on profile.id = post.author_id
  where post.id = any(post_ids)
    and not post.is_anonymous
    and not post.is_official
    and (post.status = 'approved' or post.author_id = (select auth.uid()))
  limit 51;
$$;

revoke all on function public.social_feed_authors(uuid[]) from public;
grant execute on function public.social_feed_authors(uuid[]) to anon, authenticated;

commit;
