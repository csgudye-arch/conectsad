-- Fundação inicial do Conecta ABC. Execute em um projeto Supabase novo.
-- Dados pessoais sensíveis (CPF, telefone de atendimento) e operações privilegiadas
-- não fazem parte das tabelas públicas desta primeira migração.

create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text not null default 'Novo membro'
    check (char_length(display_name) between 2 and 80),
  city text check (city is null or city in (
    'Santo André', 'São Bernardo do Campo', 'São Caetano do Sul',
    'Diadema', 'Mauá', 'Ribeirão Pires', 'Rio Grande da Serra'
  )),
  referral_code text not null unique
    default upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10)),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.community_posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles (id) on delete cascade,
  category text not null check (char_length(category) between 1 and 50),
  city text not null check (city in (
    'Santo André', 'São Bernardo do Campo', 'São Caetano do Sul',
    'Diadema', 'Mauá', 'Ribeirão Pires', 'Rio Grande da Serra'
  )),
  body text not null check (char_length(body) between 10 and 1200),
  status text not null default 'pending'
    check (status in ('pending', 'approved', 'rejected', 'hidden')),
  created_at timestamptz not null default now()
);

create table public.city_reports (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles (id) on delete cascade,
  category text not null check (char_length(category) between 1 and 50),
  city text not null check (city in (
    'Santo André', 'São Bernardo do Campo', 'São Caetano do Sul',
    'Diadema', 'Mauá', 'Ribeirão Pires', 'Rio Grande da Serra'
  )),
  neighborhood text check (neighborhood is null or char_length(neighborhood) <= 80),
  approximate_location text check (
    approximate_location is null or char_length(approximate_location) <= 240
  ),
  description text not null check (char_length(description) between 15 and 2000),
  status text not null default 'pending'
    check (status in ('pending', 'review', 'in_progress', 'resolved', 'rejected')),
  created_at timestamptz not null default now()
);

create table public.service_requests (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles (id) on delete cascade,
  service_type text not null check (char_length(service_type) between 1 and 80),
  city text not null check (city in (
    'Santo André', 'São Bernardo do Campo', 'São Caetano do Sul',
    'Diadema', 'Mauá', 'Ribeirão Pires', 'Rio Grande da Serra'
  )),
  neighborhood text check (neighborhood is null or char_length(neighborhood) <= 80),
  contact text not null check (char_length(contact) between 8 and 120),
  description text not null check (char_length(description) between 20 and 1500),
  consented_at timestamptz not null default now(),
  status text not null default 'received'
    check (status in ('received', 'review', 'in_progress', 'completed', 'closed')),
  created_at timestamptz not null default now()
);

create table public.points_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  event_type text not null check (char_length(event_type) between 1 and 60),
  points integer not null check (points > 0 and points <= 1000),
  evidence_id uuid,
  created_at timestamptz not null default now()
);

create index community_posts_public_feed_idx
  on public.community_posts (created_at desc) where status = 'approved';
create index community_posts_author_idx on public.community_posts (author_id, created_at desc);
create index city_reports_public_idx on public.city_reports (city, status, created_at desc);
create index city_reports_author_idx on public.city_reports (author_id, created_at desc);
create index service_requests_author_idx on public.service_requests (author_id, created_at desc);
create index points_ledger_user_idx on public.points_ledger (user_id, created_at desc);

-- Criar perfil mínimo ao registrar usuário. Metadados do cadastro são não confiáveis.
create or replace function public.create_profile_for_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(
      nullif(left(trim(new.raw_user_meta_data ->> 'display_name'), 80), ''),
      'Novo membro'
    )
  );
  return new;
end;
$$;

revoke all on function public.create_profile_for_new_user() from public, anon, authenticated;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.create_profile_for_new_user();

alter table public.profiles enable row level security;
alter table public.community_posts enable row level security;
alter table public.city_reports enable row level security;
alter table public.service_requests enable row level security;
alter table public.points_ledger enable row level security;

revoke all on public.profiles, public.community_posts, public.city_reports,
  public.service_requests, public.points_ledger from anon, authenticated;

grant select on public.profiles to authenticated;
grant update (display_name, city) on public.profiles to authenticated;
grant select on public.community_posts to anon, authenticated;
grant insert (author_id, category, city, body) on public.community_posts to authenticated;
grant update (category, city, body) on public.community_posts to authenticated;
grant delete on public.community_posts to authenticated;
grant select on public.city_reports to authenticated;
grant insert (author_id, category, city, neighborhood, approximate_location, description)
  on public.city_reports to authenticated;
grant select on public.city_reports to anon;
grant select on public.service_requests to authenticated;
grant insert (author_id, service_type, city, neighborhood, contact, description)
  on public.service_requests to authenticated;
grant delete on public.service_requests to authenticated;
grant select on public.points_ledger to authenticated;

create policy "Members can read safe profile fields"
  on public.profiles for select to authenticated using (true);
create policy "Members can update their own profile"
  on public.profiles for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

create policy "Anyone can read approved community posts and members can read their own"
  on public.community_posts for select to anon, authenticated
  using (status = 'approved' or author_id = (select auth.uid()));
create policy "Members can submit community posts for moderation"
  on public.community_posts for insert to authenticated
  with check (author_id = (select auth.uid()) and status = 'pending');
create policy "Members can edit only their own pending posts"
  on public.community_posts for update to authenticated
  using (author_id = (select auth.uid()) and status = 'pending')
  with check (author_id = (select auth.uid()) and status = 'pending');
create policy "Members can remove only their own pending posts"
  on public.community_posts for delete to authenticated
  using (author_id = (select auth.uid()) and status = 'pending');

create policy "Anyone can read non-pending city reports"
  on public.city_reports for select to anon, authenticated
  using (
    status in ('review', 'in_progress', 'resolved')
    or author_id = (select auth.uid())
  );
create policy "Members can submit city reports for review"
  on public.city_reports for insert to authenticated
  with check (author_id = (select auth.uid()) and status = 'pending');

create policy "Members can read their own service requests"
  on public.service_requests for select to authenticated
  using (author_id = (select auth.uid()));
create policy "Members can submit service requests for themselves"
  on public.service_requests for insert to authenticated
  with check (author_id = (select auth.uid()) and status = 'received');
create policy "Members can delete their own service requests"
  on public.service_requests for delete to authenticated
  using (author_id = (select auth.uid()));

create policy "Members can read their own points history"
  on public.points_ledger for select to authenticated
  using (user_id = (select auth.uid()));

-- Não há permissões para inserir/alterar pontos no cliente.
-- Pontuação, moderação, verificação de identidade e premiação exigem funções confiáveis.
