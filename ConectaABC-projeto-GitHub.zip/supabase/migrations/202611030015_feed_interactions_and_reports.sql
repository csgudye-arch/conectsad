-- Reações visíveis sem login e denúncias persistentes, restritas à equipe.
begin;

create table if not exists public.community_post_reports (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.community_posts(id) on delete cascade,
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reason text not null check (reason in ('spam', 'abusive', 'misinformation', 'privacy', 'other')),
  details text not null default '' check (char_length(details) <= 1000),
  status text not null default 'pending' check (status in ('pending', 'reviewed')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references auth.users(id) on delete set null
);

create index if not exists community_post_reports_queue_idx
  on public.community_post_reports(created_at asc) where status = 'pending';
create unique index if not exists community_post_reports_one_pending_idx
  on public.community_post_reports(post_id, reporter_id) where status = 'pending';

alter table public.community_post_reports enable row level security;
revoke all on public.community_post_reports from public, anon, authenticated;

create or replace function public.get_community_post_reaction_summary(post_ids uuid[])
returns table(post_id uuid, reaction_count bigint, liked boolean)
language sql
stable
security definer
set search_path = ''
as $$
  select p.id,
    count(r.user_id)::bigint,
    coalesce(bool_or(r.user_id = (select auth.uid())), false)
  from public.community_posts p
  left join public.community_post_reactions r on r.post_id = p.id
  where p.id = any(coalesce(post_ids, array[]::uuid[]))
    and p.status = 'approved'
  group by p.id;
$$;
revoke all on function public.get_community_post_reaction_summary(uuid[]) from public;
grant execute on function public.get_community_post_reaction_summary(uuid[]) to anon, authenticated;

create or replace function public.create_community_post_report(reported_post_id uuid, report_reason text, report_details text default '')
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  created_report_id uuid;
begin
  if (select auth.uid()) is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;
  if report_reason not in ('spam', 'abusive', 'misinformation', 'privacy', 'other') then
    raise exception 'Invalid report reason' using errcode = '22023';
  end if;
  if char_length(coalesce(report_details, '')) > 1000 then
    raise exception 'Report details are too long' using errcode = '22023';
  end if;
  if not exists (
    select 1 from public.community_posts p
    where p.id = reported_post_id and p.status = 'approved'
  ) then
    raise exception 'Post cannot be reported' using errcode = 'P0002';
  end if;

  insert into public.community_post_reports(post_id, reporter_id, reason, details)
  values (reported_post_id, (select auth.uid()), report_reason, trim(coalesce(report_details, '')))
  returning id into created_report_id;
  return created_report_id;
exception when unique_violation then
  raise exception 'A pending report for this post already exists' using errcode = '23505';
end;
$$;
revoke all on function public.create_community_post_report(uuid, text, text) from public, anon;
grant execute on function public.create_community_post_report(uuid, text, text) to authenticated;

create or replace function public.list_pending_community_post_reports()
returns table(report_id uuid, post_id uuid, reason text, details text, category text, city text, post_body text, created_at timestamptz)
language plpgsql
security definer
set search_path = ''
stable
as $$
begin
  if (select auth.uid()) is null or not exists (
    select 1 from public.community_moderators m where m.user_id = (select auth.uid())
  ) then
    raise exception 'moderator access required' using errcode = '42501';
  end if;

  return query
    select r.id, p.id, r.reason, r.details, p.category, p.city, p.body, r.created_at
    from public.community_post_reports r
    join public.community_posts p on p.id = r.post_id
    where r.status = 'pending'
    order by r.created_at asc
    limit 100;
end;
$$;
revoke all on function public.list_pending_community_post_reports() from public, anon;
grant execute on function public.list_pending_community_post_reports() to authenticated;

create or replace function public.review_community_post_report(report_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is null or not exists (
    select 1 from public.community_moderators m where m.user_id = (select auth.uid())
  ) then
    raise exception 'moderator access required' using errcode = '42501';
  end if;
  update public.community_post_reports
  set status = 'reviewed', reviewed_at = now(), reviewed_by = (select auth.uid())
  where id = report_id and status = 'pending';
  if not found then
    raise exception 'Report is not pending' using errcode = 'P0002';
  end if;
end;
$$;
revoke all on function public.review_community_post_report(uuid) from public, anon;
grant execute on function public.review_community_post_report(uuid) to authenticated;

commit;
