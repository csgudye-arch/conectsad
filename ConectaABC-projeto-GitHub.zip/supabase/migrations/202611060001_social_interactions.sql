-- Extensão social aditiva. Não altera pontuação, perfis, posts ou regras existentes.
begin;
create table public.social_comments (
 id uuid primary key default gen_random_uuid(), post_id uuid not null references public.community_posts(id) on delete cascade,
 author_id uuid not null references public.profiles(id) on delete cascade, body text not null check(char_length(body) between 2 and 1000),
 status text not null default 'pending' check(status in ('pending','approved','rejected')), created_at timestamptz not null default now(),
 reviewed_at timestamptz, reviewed_by uuid references auth.users(id) on delete set null
);
create index social_comments_post_idx on public.social_comments(post_id,created_at);
create index social_comments_author_idx on public.social_comments(author_id,created_at);
create table public.social_bookmarks (
 user_id uuid not null references public.profiles(id) on delete cascade, post_id uuid not null references public.community_posts(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(user_id,post_id)
);
create table public.social_friendships (
 id uuid primary key default gen_random_uuid(), sender_id uuid not null references public.profiles(id) on delete cascade,
 receiver_id uuid not null references public.profiles(id) on delete cascade, status text not null default 'pending' check(status in ('pending','accepted','declined')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(), check(sender_id<>receiver_id)
);
create unique index social_friendship_pair on public.social_friendships(least(sender_id,receiver_id),greatest(sender_id,receiver_id));
create index social_friendship_receiver on public.social_friendships(receiver_id,status);
create table public.social_notifications (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 kind text not null check(kind in ('comment','friend_request','friend_accepted','post_review')),
 message text not null, post_id uuid references public.community_posts(id) on delete cascade,
 read_at timestamptz, created_at timestamptz not null default now()
);
create index social_notifications_owner on public.social_notifications(user_id,created_at desc);
create table public.social_comment_audit (
 id bigint generated always as identity primary key, comment_id uuid not null references public.social_comments(id) on delete cascade,
 moderator_id uuid not null references auth.users(id), decision text not null, reason text not null, created_at timestamptz not null default now()
);
alter table public.social_comments enable row level security;
alter table public.social_bookmarks enable row level security;
alter table public.social_friendships enable row level security;
alter table public.social_notifications enable row level security;
alter table public.social_comment_audit enable row level security;
revoke all on public.social_comments,public.social_bookmarks,public.social_friendships,public.social_notifications,public.social_comment_audit from public,anon,authenticated;

create function public.social_list_comments(target_post uuid)
returns table(id uuid,body text,first_name text,is_own boolean,status text,created_at timestamptz)
language sql stable security definer set search_path='' as $$
 select c.id,c.body,split_part(trim(p.display_name),' ',1),c.author_id=auth.uid(),c.status,c.created_at
 from public.social_comments c join public.profiles p on p.id=c.author_id
 join public.community_posts post on post.id=c.post_id
 where c.post_id=target_post and post.status='approved' and (c.status='approved' or c.author_id=auth.uid())
 order by c.created_at desc limit 100;
$$;
create function public.social_add_comment(target_post uuid,comment_body text) returns uuid
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); result uuid;
begin
 if actor is null then raise exception 'Entre para comentar.' using errcode='42501'; end if;
 if comment_body is null or char_length(trim(comment_body)) not between 2 and 1000 then raise exception 'Escreva de 2 a 1.000 caracteres.' using errcode='22023'; end if;
 if not exists(select 1 from public.community_posts where id=target_post and status='approved') then raise exception 'Publicação indisponível.' using errcode='P0002'; end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,410));
 if (select count(*) from public.social_comments where author_id=actor and created_at>now()-interval '1 minute')>=5
 or (select count(*) from public.social_comments where author_id=actor and created_at>now()-interval '24 hours')>=30 then
 raise exception 'Limite de comentários atingido. Tente novamente mais tarde.' using errcode='P0001'; end if;
 insert into public.social_comments(post_id,author_id,body) values(target_post,actor,trim(comment_body)) returning id into result;
 return result;
end; $$;
create function public.social_comment_queue() returns table(id uuid,post_id uuid,body text,first_name text,created_at timestamptz)
language plpgsql stable security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à moderação.' using errcode='42501'; end if;
 return query select c.id,c.post_id,c.body,split_part(trim(p.display_name),' ',1),c.created_at from public.social_comments c join public.profiles p on p.id=c.author_id where c.status='pending' order by c.created_at limit 100;
end; $$;
create function public.social_review_comment(target_comment uuid,decision text,reason text) returns void
language plpgsql security definer set search_path='' as $$
declare item public.social_comments; post_owner uuid;
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à moderação.' using errcode='42501'; end if;
 if decision is null or decision not in ('approved','rejected') or reason is null or char_length(trim(reason)) not between 3 and 500 then raise exception 'Informe a decisão e um motivo de 3 a 500 caracteres.' using errcode='22023'; end if;
 select * into item from public.social_comments where id=target_comment for update;
 if not found then raise exception 'Comentário não encontrado.' using errcode='P0002'; end if;
 if item.status=decision then return; end if;
 update public.social_comments set status=decision,reviewed_at=now(),reviewed_by=auth.uid() where id=target_comment;
 insert into public.social_comment_audit(comment_id,moderator_id,decision,reason) values(target_comment,auth.uid(),decision,trim(reason));
 if decision='approved' then
 select author_id into post_owner from public.community_posts where id=item.post_id and status='approved';
 if post_owner is not null and post_owner<>item.author_id then insert into public.social_notifications(user_id,kind,message,post_id) values(post_owner,'comment','Sua publicação recebeu um comentário aprovado.',item.post_id); end if;
 end if;
end; $$;
create function public.social_set_bookmark(target_post uuid,saved boolean) returns boolean
language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para salvar publicações.' using errcode='42501'; end if;
 if saved is null then raise exception 'Informe se deseja salvar.' using errcode='22023'; end if;
 if not saved then delete from public.social_bookmarks where user_id=auth.uid() and post_id=target_post; return false; end if;
 if not exists(select 1 from public.community_posts where id=target_post and status='approved') then raise exception 'Publicação indisponível.' using errcode='P0002'; end if;
 insert into public.social_bookmarks(user_id,post_id) values(auth.uid(),target_post) on conflict do nothing;
 return true;
end; $$;
create function public.social_saved_posts() returns table(post_id uuid,body text,title text,city text,created_at timestamptz)
language sql stable security definer set search_path='' as $$
 select p.id,p.body,p.title,p.city,b.created_at from public.social_bookmarks b join public.community_posts p on p.id=b.post_id
 where b.user_id=auth.uid() and p.status='approved' order by b.created_at desc limit 200;
$$;
create function public.social_search_members(term text) returns table(member_id uuid,first_name text,city text)
language plpgsql stable security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para procurar amigos.' using errcode='42501'; end if;
 if term is null or char_length(trim(term)) not between 2 and 80 then return; end if;
 return query select p.id,split_part(trim(p.display_name),' ',1),p.city from public.profiles p
 where p.id<>auth.uid() and position(lower(trim(term)) in lower(split_part(trim(p.display_name),' ',1)))>0
 order by p.display_name,p.id limit 20;
end; $$;
create function public.social_request_friend(target_member uuid) returns void
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); relation public.social_friendships;
begin
 if actor is null then raise exception 'Entre para adicionar amigos.' using errcode='42501'; end if;
 if target_member=actor or target_member is null then raise exception 'Selecione outro membro.' using errcode='22023'; end if;
 if not exists(select 1 from public.profiles where id=target_member) then raise exception 'Membro não encontrado.' using errcode='P0002'; end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,411));
 perform pg_advisory_xact_lock(hashtextextended(least(actor,target_member)::text||greatest(actor,target_member)::text,412));
 select * into relation from public.social_friendships where least(sender_id,receiver_id)=least(actor,target_member) and greatest(sender_id,receiver_id)=greatest(actor,target_member) for update;
 if found then
 if relation.status in ('pending','accepted') then return; end if;
 raise exception 'Este pedido já foi encerrado.' using errcode='P0001';
 end if;
 if (select count(*) from public.social_friendships where sender_id=actor and created_at>now()-interval '24 hours')>=20 then raise exception 'Você atingiu o limite diário de convites.' using errcode='P0001'; end if;
 insert into public.social_friendships(sender_id,receiver_id) values(actor,target_member);
 insert into public.social_notifications(user_id,kind,message) values(target_member,'friend_request','Você recebeu um pedido de amizade.');
end; $$;
create function public.social_respond_friend(request_id uuid,accept_request boolean) returns void
language plpgsql security definer set search_path='' as $$
declare relation public.social_friendships;
begin
 if auth.uid() is null then raise exception 'Entre para responder.' using errcode='42501'; end if;
 if accept_request is null then raise exception 'Selecione uma resposta.' using errcode='22023'; end if;
 select * into relation from public.social_friendships where id=request_id and receiver_id=auth.uid() for update;
 if not found then raise exception 'Pedido indisponível.' using errcode='42501'; end if;
 if relation.status<>'pending' then return; end if;
 update public.social_friendships set status=case when accept_request then 'accepted' else 'declined' end,updated_at=now() where id=request_id;
 if accept_request then insert into public.social_notifications(user_id,kind,message) values(relation.sender_id,'friend_accepted','Seu pedido de amizade foi aceito.'); end if;
end; $$;
create function public.social_remove_friend(request_id uuid) returns void
language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para continuar.' using errcode='42501'; end if;
 update public.social_friendships set status='declined',updated_at=now() where id=request_id and (sender_id=auth.uid() or receiver_id=auth.uid());
end; $$;
create function public.social_my_friends() returns table(request_id uuid,first_name text,city text,status text,incoming boolean)
language sql stable security definer set search_path='' as $$
 select f.id,split_part(trim(p.display_name),' ',1),p.city,f.status,f.receiver_id=auth.uid()
 from public.social_friendships f join public.profiles p on p.id=case when f.sender_id=auth.uid() then f.receiver_id else f.sender_id end
 where auth.uid() in (f.sender_id,f.receiver_id) and f.status in ('pending','accepted') order by f.created_at desc limit 200;
$$;
create function public.social_my_notifications() returns table(id uuid,kind text,message text,post_id uuid,read_at timestamptz,created_at timestamptz)
language sql stable security definer set search_path='' as $$
 select n.id,n.kind,n.message,n.post_id,n.read_at,n.created_at from public.social_notifications n where n.user_id=auth.uid() order by n.created_at desc limit 100;
$$;
create function public.social_read_notification(notification_id uuid) returns void
language sql security definer set search_path='' as $$
 update public.social_notifications set read_at=coalesce(read_at,now()) where id=notification_id and user_id=auth.uid();
$$;
create function public.social_notify_post_review() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.status is distinct from old.status and new.status in ('approved','rejected') then
 insert into public.social_notifications(user_id,kind,message,post_id) values(new.author_id,'post_review',case when new.status='approved' then 'Sua publicação foi aprovada.' else 'Sua publicação não foi aprovada. Consulte seus envios.' end,new.id);
 end if;
 return new;
end; $$;
create trigger social_post_review_notice after update of status on public.community_posts for each row execute function public.social_notify_post_review();

-- Por padrão funções são executáveis por PUBLIC; remover explicitamente antes dos grants.
revoke all on function public.social_list_comments(uuid),public.social_add_comment(uuid,text),public.social_comment_queue(),public.social_review_comment(uuid,text,text),public.social_set_bookmark(uuid,boolean),public.social_saved_posts(),public.social_search_members(text),public.social_request_friend(uuid),public.social_respond_friend(uuid,boolean),public.social_remove_friend(uuid),public.social_my_friends(),public.social_my_notifications(),public.social_read_notification(uuid),public.social_notify_post_review() from public,anon,authenticated;
grant execute on function public.social_list_comments(uuid) to anon,authenticated;
grant execute on function public.social_add_comment(uuid,text),public.social_comment_queue(),public.social_review_comment(uuid,text,text),public.social_set_bookmark(uuid,boolean),public.social_saved_posts(),public.social_search_members(text),public.social_request_friend(uuid),public.social_respond_friend(uuid,boolean),public.social_remove_friend(uuid),public.social_my_friends(),public.social_my_notifications(),public.social_read_notification(uuid) to authenticated;
commit;
