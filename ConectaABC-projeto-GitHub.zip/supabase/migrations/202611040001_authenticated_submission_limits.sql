-- Per-account submission throttles for authenticated user-generated content.
-- This is abuse control for normal authenticated sessions, not a DDoS shield.

create table if not exists public.submission_rate_limits (
  user_id uuid not null references auth.users(id) on delete cascade,
  submission_kind text not null,
  window_started_at timestamptz not null,
  submission_count integer not null check (submission_count > 0),
  primary key (user_id, submission_kind)
);

alter table public.submission_rate_limits enable row level security;
revoke all on public.submission_rate_limits from public, anon, authenticated;

comment on table public.submission_rate_limits is
  'Private server-side counters used to slow repeated authenticated content submissions.';

create or replace function public.enforce_submission_rate_limit()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user_id uuid := auth.uid();
  v_owner_id uuid;
  v_kind text := tg_table_name;
  v_period interval;
  v_max_count integer;
  v_window_started_at timestamptz;
  v_count integer;
  v_now timestamptz := clock_timestamp();
begin
  -- Trusted service operations without an end-user JWT are governed separately.
  if v_user_id is null then
    return new;
  end if;

  -- Official posts are moderator-only RPC writes, not member submissions.
  if v_kind = 'community_posts'
     and coalesce((to_jsonb(new) ->> 'is_official')::boolean, false) then
    return new;
  end if;

  case v_kind
    when 'community_posts' then
      v_owner_id := (to_jsonb(new) ->> 'author_id')::uuid;
      v_period := interval '1 hour';
      v_max_count := 4;
    when 'city_reports' then
      v_owner_id := (to_jsonb(new) ->> 'author_id')::uuid;
      v_period := interval '24 hours';
      v_max_count := 5;
    when 'animal_reports' then
      v_owner_id := (to_jsonb(new) ->> 'owner_id')::uuid;
      v_period := interval '24 hours';
      v_max_count := 4;
    when 'marketplace_listings' then
      v_owner_id := (to_jsonb(new) ->> 'owner_id')::uuid;
      v_period := interval '24 hours';
      v_max_count := 8;
    when 'service_requests' then
      v_owner_id := (to_jsonb(new) ->> 'author_id')::uuid;
      v_period := interval '24 hours';
      v_max_count := 3;
    else
      raise exception 'submission_rate_limit_configuration_missing'
        using errcode = 'P0001';
  end case;

  if v_owner_id is distinct from v_user_id then
    raise exception 'submission_owner_must_match_authenticated_user'
      using errcode = '42501';
  end if;

  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended(v_user_id::text || ':' || v_kind, 0)
  );

  select r.window_started_at, r.submission_count
    into v_window_started_at, v_count
    from public.submission_rate_limits r
   where r.user_id = v_user_id and r.submission_kind = v_kind
   for update;

  if not found then
    insert into public.submission_rate_limits(user_id, submission_kind, window_started_at, submission_count)
    values (v_user_id, v_kind, v_now, 1);
  elsif v_window_started_at <= v_now - v_period then
    update public.submission_rate_limits
       set window_started_at = v_now, submission_count = 1
     where user_id = v_user_id and submission_kind = v_kind;
  elsif v_count >= v_max_count then
    raise exception 'submission_rate_limited'
      using errcode = 'P0001',
            detail = 'Aguarde o fim do limite temporário antes de enviar novamente.';
  else
    update public.submission_rate_limits
       set submission_count = submission_count + 1
     where user_id = v_user_id and submission_kind = v_kind;
  end if;

  return new;
end;
$$;

revoke all on function public.enforce_submission_rate_limit() from public, anon, authenticated;

drop trigger if exists community_posts_submission_limit on public.community_posts;
create trigger community_posts_submission_limit
before insert on public.community_posts
for each row execute function public.enforce_submission_rate_limit();

drop trigger if exists city_reports_submission_limit on public.city_reports;
create trigger city_reports_submission_limit
before insert on public.city_reports
for each row execute function public.enforce_submission_rate_limit();

drop trigger if exists animal_reports_submission_limit on public.animal_reports;
create trigger animal_reports_submission_limit
before insert on public.animal_reports
for each row execute function public.enforce_submission_rate_limit();

drop trigger if exists marketplace_listings_submission_limit on public.marketplace_listings;
create trigger marketplace_listings_submission_limit
before insert on public.marketplace_listings
for each row execute function public.enforce_submission_rate_limit();

drop trigger if exists service_requests_submission_limit on public.service_requests;
create trigger service_requests_submission_limit
before insert on public.service_requests
for each row execute function public.enforce_submission_rate_limit();
