begin;
create table public.social_hub_settings(id boolean primary key default true check(id),community_min_points integer not null default 1500 check(community_min_points>=0));
insert into public.social_hub_settings(id) values(true);
create table public.social_polls(id uuid primary key default gen_random_uuid(),author_id uuid not null references public.profiles(id) on delete cascade,question text not null check(char_length(question) between 10 and 160),city text not null,closes_at timestamptz not null,status text not null default 'pending' check(status in ('pending','approved','rejected','hidden')),created_at timestamptz not null default now());
create table public.social_poll_options(id uuid primary key default gen_random_uuid(),poll_id uuid not null references public.social_polls(id) on delete cascade,label text not null check(char_length(label) between 1 and 80),position integer not null,unique(poll_id,id),unique(poll_id,position));
create table public.social_poll_votes(poll_id uuid not null references public.social_polls(id) on delete cascade,user_id uuid not null references public.profiles(id) on delete cascade,option_id uuid not null,created_at timestamptz not null default now(),primary key(poll_id,user_id),foreign key(poll_id,option_id) references public.social_poll_options(poll_id,id) on delete cascade);
create table public.social_groups(id uuid primary key default gen_random_uuid(),owner_id uuid not null references public.profiles(id) on delete cascade,name text not null check(char_length(name) between 3 and 80),description text not null check(char_length(description) between 20 and 1500),category text not null,city text not null,status text not null default 'pending' check(status in ('pending','approved','rejected','hidden')),created_at timestamptz not null default now());
create table public.social_group_members(group_id uuid not null references public.social_groups(id) on delete cascade,user_id uuid not null references public.profiles(id) on delete cascade,created_at timestamptz not null default now(),primary key(group_id,user_id));
create table public.social_group_posts(id uuid primary key default gen_random_uuid(),group_id uuid not null references public.social_groups(id) on delete cascade,author_id uuid not null references public.profiles(id) on delete cascade,body text not null check(char_length(body) between 10 and 2000),status text not null default 'pending' check(status in ('pending','approved','rejected','hidden')),created_at timestamptz not null default now());
create table public.social_hub_reports(kind text not null check(kind in ('poll','group','group_post')),target_id uuid not null,user_id uuid not null references public.profiles(id) on delete cascade,reason text not null check(char_length(reason) between 3 and 500),created_at timestamptz not null default now(),reviewed_at timestamptz,primary key(kind,target_id,user_id));
create table public.social_hub_audit(id bigint generated always as identity primary key,kind text not null,target_id uuid not null,moderator_id uuid not null references auth.users(id),decision text not null,reason text not null,created_at timestamptz not null default now());
create index social_polls_author_idx on public.social_polls(author_id,created_at);
create index social_groups_owner_idx on public.social_groups(owner_id,created_at);
create index social_group_posts_idx on public.social_group_posts(group_id,created_at);
create index social_group_posts_author_idx on public.social_group_posts(author_id,created_at);
alter table public.social_hub_settings enable row level security;
alter table public.social_polls enable row level security;
alter table public.social_poll_options enable row level security;
alter table public.social_poll_votes enable row level security;
alter table public.social_groups enable row level security;
alter table public.social_group_members enable row level security;
alter table public.social_group_posts enable row level security;
alter table public.social_hub_reports enable row level security;
alter table public.social_hub_audit enable row level security;
revoke all on public.social_hub_settings,public.social_polls,public.social_poll_options,public.social_poll_votes,public.social_groups,public.social_group_members,public.social_group_posts,public.social_hub_reports,public.social_hub_audit from public,anon,authenticated;
create function public.social_valid_city(city_name text) returns boolean language sql immutable set search_path='' as $$ select coalesce(city_name=any(array['Santo André','São Bernardo do Campo','São Caetano do Sul','Diadema','Mauá','Ribeirão Pires','Rio Grande da Serra']),false) $$;
create function public.social_create_poll(question_text text,poll_city text,option_labels text[],closing_at timestamptz) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid; actor uuid:=auth.uid(); label text; position_number integer:=0;
begin
 if actor is null then raise exception 'Entre para criar uma enquete.' using errcode='42501'; end if;
 if question_text is null or char_length(trim(question_text)) not between 10 and 160 or not public.social_valid_city(poll_city) or closing_at is null or closing_at<now()+interval '30 minutes' or closing_at>now()+interval '30 days' then raise exception 'Confira pergunta, cidade e prazo (30 minutos a 30 dias).' using errcode='22023'; end if;
 if option_labels is null or coalesce(cardinality(option_labels),0) not between 2 and 6 or array_ndims(option_labels)<>1 then raise exception 'Informe de 2 a 6 opções.' using errcode='22023'; end if;
 if exists(select 1 from unnest(option_labels) v where v is null or char_length(trim(v)) not between 1 and 80) or (select count(distinct lower(trim(v))) from unnest(option_labels) v)<>cardinality(option_labels) then raise exception 'As opções devem ser distintas e ter até 80 caracteres.' using errcode='22023'; end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,420));
 if (select count(*) from public.social_polls where author_id=actor and created_at>now()-interval '24 hours')>=3 then raise exception 'Limite de três enquetes por dia atingido.' using errcode='P0001'; end if;
 insert into public.social_polls(author_id,question,city,closes_at) values(actor,trim(question_text),poll_city,closing_at) returning id into result;
 foreach label in array option_labels loop
 insert into public.social_poll_options(poll_id,label,position) values(result,trim(label),position_number); position_number:=position_number+1;
 end loop;
 return result;
end; $$;
create function public.social_vote_poll(target_poll uuid,target_option uuid) returns void language plpgsql security definer set search_path='' as $$
declare item public.social_polls;
begin
 if auth.uid() is null then raise exception 'Entre para votar.' using errcode='42501'; end if;
 select * into item from public.social_polls where id=target_poll for update;
 if not found or item.status<>'approved' or item.closes_at<=now() then raise exception 'A enquete não está aberta para votação.' using errcode='P0002'; end if;
 if not exists(select 1 from public.social_poll_options where id=target_option and poll_id=target_poll) then raise exception 'Opção inválida.' using errcode='22023'; end if;
 insert into public.social_poll_votes(poll_id,user_id,option_id) values(target_poll,auth.uid(),target_option) on conflict(poll_id,user_id) do nothing;
end; $$;
create function public.social_list_polls() returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(item order by created_at desc),'[]'::jsonb) from (
 select p.created_at,jsonb_build_object('id',p.id,'question',p.question,'city',p.city,'closes_at',p.closes_at,'status',p.status,'is_own',coalesce(p.author_id=auth.uid(),false),'my_vote',(select v.option_id from public.social_poll_votes v where v.poll_id=p.id and v.user_id=auth.uid()),'options',(select jsonb_agg(jsonb_build_object('id',o.id,'label',o.label,'votes',(select count(*) from public.social_poll_votes v where v.option_id=o.id)) order by o.position) from public.social_poll_options o where o.poll_id=p.id)) item
 from public.social_polls p where p.status='approved' or p.author_id=auth.uid() order by p.created_at desc limit 100) rows;
$$;
create function public.social_create_group(group_name text,group_description text,group_category text,group_city text) returns uuid language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); result uuid; min_points integer;
begin
 if actor is null then raise exception 'Entre para criar uma comunidade.' using errcode='42501'; end if;
 if group_name is null or char_length(trim(group_name)) not between 3 and 80 or group_description is null or char_length(trim(group_description)) not between 20 and 1500 or not public.social_valid_city(group_city) or group_category is null or group_category not in ('Bairro','Esporte','Pets','Família','Cultura','Negócios','Games','Fé','Outros') then raise exception 'Confira nome, descrição, categoria e cidade.' using errcode='22023'; end if;
 select community_min_points into min_points from public.social_hub_settings where id=true;
 if not exists(select 1 from public.community_moderators where user_id=actor) and (select coalesce(sum(points),0) from public.points_ledger where user_id=actor)<min_points then raise exception 'Você precisa de % pontos confirmados para criar uma comunidade.',min_points using errcode='P0001'; end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,421));
 if (select count(*) from public.social_groups where owner_id=actor and created_at>now()-interval '7 days')>=1 then raise exception 'Você já criou uma comunidade nos últimos sete dias.' using errcode='P0001'; end if;
 insert into public.social_groups(owner_id,name,description,category,city) values(actor,trim(group_name),trim(group_description),group_category,group_city) returning id into result;
 insert into public.social_group_members(group_id,user_id) values(result,actor);
 return result;
end; $$;
create function public.social_list_groups() returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('minimum_points',(select community_min_points from public.social_hub_settings where id=true),'groups',coalesce((select jsonb_agg(item order by created_at desc) from (
 select g.created_at,jsonb_build_object('id',g.id,'name',g.name,'description',g.description,'category',g.category,'city',g.city,'status',g.status,'is_own',coalesce(g.owner_id=auth.uid(),false),'joined',exists(select 1 from public.social_group_members m where m.group_id=g.id and m.user_id=auth.uid()),'members',(select count(*) from public.social_group_members m where m.group_id=g.id)) item
 from public.social_groups g where g.status='approved' or g.owner_id=auth.uid() order by g.created_at desc limit 100) rows),'[]'::jsonb));
$$;
create function public.social_join_group(target_group uuid,joining boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para participar.' using errcode='42501'; end if;
 if joining is null then raise exception 'Selecione a ação.' using errcode='22023'; end if;
 if not joining then delete from public.social_group_members where group_id=target_group and user_id=auth.uid(); return; end if;
 if not exists(select 1 from public.social_groups where id=target_group and status='approved') then raise exception 'Comunidade indisponível.' using errcode='P0002'; end if;
 insert into public.social_group_members(group_id,user_id) values(target_group,auth.uid()) on conflict do nothing;
end; $$;
create function public.social_add_group_post(target_group uuid,post_body text) returns uuid language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); result uuid;
begin
 if actor is null or not exists(select 1 from public.social_groups g join public.social_group_members m on m.group_id=g.id where g.id=target_group and g.status='approved' and m.user_id=actor) then raise exception 'Entre e participe da comunidade para publicar.' using errcode='42501'; end if;
 if post_body is null or char_length(trim(post_body)) not between 10 and 2000 then raise exception 'Escreva de 10 a 2.000 caracteres.' using errcode='22023'; end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,422));
 if (select count(*) from public.social_group_posts where author_id=actor and created_at>now()-interval '24 hours')>=10 then raise exception 'Limite diário de publicações em comunidades atingido.' using errcode='P0001'; end if;
 insert into public.social_group_posts(group_id,author_id,body) values(target_group,actor,trim(post_body)) returning id into result;
 return result;
end; $$;
create function public.social_group_feed(target_group uuid) returns table(id uuid,body text,first_name text,is_own boolean,status text,created_at timestamptz) language sql stable security definer set search_path='' as $$
 select p.id,p.body,split_part(trim(pr.display_name),' ',1),coalesce(p.author_id=auth.uid(),false),p.status,p.created_at
 from public.social_group_posts p join public.social_groups g on g.id=p.group_id join public.profiles pr on pr.id=p.author_id
 where p.group_id=target_group and g.status='approved' and (p.status='approved' or p.author_id=auth.uid()) order by p.created_at desc limit 100;
$$;
create function public.social_hub_queue() returns table(id uuid,kind text,body text,city text,status text) language plpgsql stable security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à moderação.' using errcode='42501'; end if;
 return query select x.id,x.kind,x.body||coalesce((select E'\nDenúncias:\n'||string_agg(r.reason,E'\n') from public.social_hub_reports r where r.target_id=x.id and r.kind=x.kind and r.reviewed_at is null),''),x.city,x.status from (
 select p.id,'poll'::text kind,p.question||E'\n'||(select string_agg(o.label,E'\n' order by o.position) from public.social_poll_options o where o.poll_id=p.id) body,p.city,p.status,p.created_at from public.social_polls p where p.status in ('pending','hidden')
 union all select g.id,'group',g.name||E'\n'||g.description,g.city,g.status,g.created_at from public.social_groups g where g.status in ('pending','hidden')
 union all select p.id,'group_post',p.body,g.city,p.status,p.created_at from public.social_group_posts p join public.social_groups g on g.id=p.group_id where p.status in ('pending','hidden')) x order by x.created_at limit 100;
end; $$;
create function public.social_review_hub(target_kind text,target_id uuid,decision text,reason text) returns void language plpgsql security definer set search_path='' as $$
declare affected integer;
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à moderação.' using errcode='42501'; end if;
 if decision is null or decision not in ('approved','rejected') or reason is null or char_length(trim(reason)) not between 3 and 500 then raise exception 'Informe decisão e motivo (3 a 500 caracteres).' using errcode='22023'; end if;
 if target_kind='poll' then update public.social_polls set status=decision where id=target_id;
 elsif target_kind='group' then update public.social_groups set status=decision where id=target_id;
 elsif target_kind='group_post' then update public.social_group_posts set status=decision where id=target_id;
 else raise exception 'Tipo inválido.' using errcode='22023'; end if;
 get diagnostics affected=row_count;
 if affected=0 then raise exception 'Conteúdo não encontrado.' using errcode='P0002'; end if;
 update public.social_hub_reports r set reviewed_at=now() where r.target_id=social_review_hub.target_id and r.kind=target_kind and r.reviewed_at is null;
 insert into public.social_hub_audit(kind,target_id,moderator_id,decision,reason) values(target_kind,target_id,auth.uid(),decision,trim(reason));
end; $$;
create function public.social_report_hub(target_kind text,target_id uuid,report_reason text) returns void language plpgsql security definer set search_path='' as $$
declare available boolean;
begin
 if auth.uid() is null then raise exception 'Entre para denunciar.' using errcode='42501'; end if;
 if report_reason is null or char_length(trim(report_reason)) not between 3 and 500 then raise exception 'Informe o motivo (3 a 500 caracteres).' using errcode='22023'; end if;
 perform pg_advisory_xact_lock(hashtextextended(target_id::text,423));
 if target_kind='poll' then select status='approved' into available from public.social_polls where id=target_id;
 elsif target_kind='group' then select status='approved' into available from public.social_groups where id=target_id;
 elsif target_kind='group_post' then select status='approved' into available from public.social_group_posts where id=target_id;
 else raise exception 'Tipo inválido.' using errcode='22023'; end if;
 if not coalesce(available,false) then raise exception 'Conteúdo indisponível.' using errcode='P0002'; end if;
 insert into public.social_hub_reports(kind,target_id,user_id,reason) values(target_kind,target_id,auth.uid(),trim(report_reason)) on conflict do nothing;
 if (select count(*) from public.social_hub_reports r where r.kind=target_kind and r.target_id=social_report_hub.target_id and r.reviewed_at is null)>=3 then
 if target_kind='poll' then update public.social_polls set status='hidden' where id=target_id;
 elsif target_kind='group' then update public.social_groups set status='hidden' where id=target_id;
 else update public.social_group_posts set status='hidden' where id=target_id; end if;
 end if;
end; $$;
revoke all on function public.social_valid_city(text),public.social_create_poll(text,text,text[],timestamptz),public.social_vote_poll(uuid,uuid),public.social_list_polls(),public.social_create_group(text,text,text,text),public.social_list_groups(),public.social_join_group(uuid,boolean),public.social_add_group_post(uuid,text),public.social_group_feed(uuid),public.social_hub_queue(),public.social_review_hub(text,uuid,text,text),public.social_report_hub(text,uuid,text) from public,anon,authenticated;
grant execute on function public.social_list_polls(),public.social_list_groups(),public.social_group_feed(uuid) to anon,authenticated;
grant execute on function public.social_create_poll(text,text,text[],timestamptz),public.social_vote_poll(uuid,uuid),public.social_create_group(text,text,text,text),public.social_join_group(uuid,boolean),public.social_add_group_post(uuid,text),public.social_hub_queue(),public.social_review_hub(text,uuid,text,text),public.social_report_hub(text,uuid,text) to authenticated;
commit;
