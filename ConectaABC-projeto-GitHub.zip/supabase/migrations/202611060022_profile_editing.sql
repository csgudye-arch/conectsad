begin;
create function public.social_save_full_profile(member_name text,member_city text,member_handle text,member_bio text,member_neighborhood text,member_cover text,make_public boolean,presence_public boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para editar seu perfil.' using errcode='42501';end if;
 if member_name is null or char_length(trim(member_name)) not between 2 and 80 or not public.social_valid_city(member_city) then raise exception 'Informe seu nome (2 a 80 caracteres) e uma cidade do Grande ABC.' using errcode='22023';end if;
 perform public.social_save_details(member_handle,member_bio,member_neighborhood,member_cover,make_public,presence_public);
 update public.profiles set display_name=trim(member_name),city=member_city,updated_at=now() where id=auth.uid();
end; $$;
revoke all on function public.social_save_full_profile(text,text,text,text,text,text,boolean,boolean) from public,anon,authenticated;
grant execute on function public.social_save_full_profile(text,text,text,text,text,text,boolean,boolean) to authenticated;
commit;
