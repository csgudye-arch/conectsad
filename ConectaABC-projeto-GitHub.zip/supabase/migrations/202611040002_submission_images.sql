-- Imagens privadas para anúncios, avisos de animais e relatos urbanos.
begin;

alter table public.marketplace_listings add column if not exists media_path text;
alter table public.animal_reports add column if not exists media_path text;
alter table public.city_reports add column if not exists media_path text;

alter table public.marketplace_listings drop constraint if exists marketplace_listings_media_owner_folder_check;
alter table public.marketplace_listings add constraint marketplace_listings_media_owner_folder_check
  check (media_path is null or media_path like owner_id::text || '/%');
alter table public.animal_reports drop constraint if exists animal_reports_media_owner_folder_check;
alter table public.animal_reports add constraint animal_reports_media_owner_folder_check
  check (media_path is null or media_path like owner_id::text || '/%');
alter table public.city_reports drop constraint if exists city_reports_media_owner_folder_check;
alter table public.city_reports add constraint city_reports_media_owner_folder_check
  check (media_path is null or media_path like author_id::text || '/%');

grant select (media_path) on public.marketplace_listings to anon, authenticated;
grant insert (media_path) on public.marketplace_listings to authenticated;
grant select (media_path) on public.animal_reports to anon, authenticated;
grant insert (media_path) on public.animal_reports to authenticated;
grant select (media_path) on public.city_reports to anon, authenticated;
grant insert (media_path) on public.city_reports to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('submission-media', 'submission-media', false, 8388608, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set
  public = false,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create or replace function public.can_access_submission_media(object_name text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select
    (select auth.uid())::text = (storage.foldername(object_name))[1]
    or exists (
      select 1 from public.marketplace_listings l
      where l.media_path = object_name
        and (l.status = 'active' or l.owner_id = (select auth.uid()))
    )
    or exists (
      select 1 from public.animal_reports a
      where a.media_path = object_name
        and (a.status = 'active' or a.owner_id = (select auth.uid()))
    )
    or exists (
      select 1 from public.city_reports r
      where r.media_path = object_name
        and (r.status in ('review','in_progress','resolved') or r.author_id = (select auth.uid()))
    )
    or (
      (select auth.uid()) is not null
      and (
        exists (select 1 from public.community_moderators m where m.user_id = (select auth.uid()))
        or exists (select 1 from public.city_report_moderators m where m.user_id = (select auth.uid()))
      )
      and (
        exists (select 1 from public.marketplace_listings l where l.media_path = object_name and l.status = 'pending')
        or exists (select 1 from public.animal_reports a where a.media_path = object_name and a.status = 'pending')
        or exists (select 1 from public.city_reports r where r.media_path = object_name and r.status = 'pending')
      )
    );
$$;
revoke all on function public.can_access_submission_media(text) from public;
grant execute on function public.can_access_submission_media(text) to anon, authenticated;

drop policy if exists "Members upload submission images to own folder" on storage.objects;
create policy "Members upload submission images to own folder"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'submission-media' and (storage.foldername(name))[1] = (select auth.uid())::text);

drop policy if exists "Members view approved submission images" on storage.objects;
create policy "Members view approved submission images"
  on storage.objects for select to anon, authenticated
  using (bucket_id = 'submission-media' and public.can_access_submission_media(name));

drop policy if exists "Members remove own submission images" on storage.objects;
create policy "Members remove own submission images"
  on storage.objects for delete to authenticated
  using (bucket_id = 'submission-media' and (storage.foldername(name))[1] = (select auth.uid())::text);

drop function if exists public.list_pending_marketplace_listings();
create function public.list_pending_marketplace_listings()
returns table(id uuid,title text,category text,city text,description text,created_at timestamptz,media_path text)
language plpgsql security definer set search_path = '' stable as $$
begin
  if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id=auth.uid()) then
    raise exception 'Not authorized' using errcode = '42501';
  end if;
  return query select l.id,l.title,l.category,l.city,l.description,l.created_at,l.media_path
    from public.marketplace_listings l where l.status='pending' order by l.created_at limit 100;
end;
$$;
revoke all on function public.list_pending_marketplace_listings() from public, anon;
grant execute on function public.list_pending_marketplace_listings() to authenticated;

drop function if exists public.list_pending_animal_reports();
create function public.list_pending_animal_reports()
returns table(id uuid,report_type text,animal_name text,species text,city text,neighborhood text,description text,created_at timestamptz,media_path text)
language plpgsql security definer set search_path = '' stable as $$
begin
  if auth.uid() is null or not exists(select 1 from public.community_moderators where user_id=auth.uid()) then
    raise exception 'Not authorized' using errcode = '42501';
  end if;
  return query select a.id,a.report_type,a.animal_name,a.species,a.city,a.neighborhood,a.description,a.created_at,a.media_path
    from public.animal_reports a where a.status='pending' order by a.created_at limit 100;
end;
$$;
revoke all on function public.list_pending_animal_reports() from public, anon;
grant execute on function public.list_pending_animal_reports() to authenticated;

drop function if exists public.list_city_reports_for_moderation();
create function public.list_city_reports_for_moderation()
returns table(id uuid,category text,city text,neighborhood text,description text,status text,created_at timestamptz,media_path text)
language plpgsql security definer set search_path = '' stable as $$
begin
  if not exists(select 1 from public.city_report_moderators where user_id=(select auth.uid())) then
    raise exception 'city report moderator access required' using errcode = '42501';
  end if;
  return query select r.id,r.category,r.city,r.neighborhood,r.description,r.status,r.created_at,r.media_path
    from public.city_reports r where r.status in ('pending','review','in_progress') order by r.created_at asc limit 100;
end;
$$;
revoke all on function public.list_city_reports_for_moderation() from public, anon;
grant execute on function public.list_city_reports_for_moderation() to authenticated;

commit;
