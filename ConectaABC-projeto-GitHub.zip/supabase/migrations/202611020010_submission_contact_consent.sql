-- Reforça o consentimento para compartilhar contatos de anúncios e avisos de animais.
-- Registros antigos não recebem consentimento retroativo; seus contatos seguem ocultos.

alter table public.marketplace_listings
  add column if not exists contact_consent_at timestamptz;
alter table public.animal_reports
  add column if not exists contact_consent_at timestamptz;

grant insert (contact_consent_at)
  on public.marketplace_listings to authenticated;
grant insert (contact_consent_at)
  on public.animal_reports to authenticated;

drop policy if exists "Members submit own marketplace listings"
  on public.marketplace_listings;
create policy "Members submit own marketplace listings"
  on public.marketplace_listings for insert to authenticated
  with check (
    owner_id = (select auth.uid())
    and status = 'pending'
    and contact_consent_at is not null
  );

drop policy if exists "Members submit own animal reports"
  on public.animal_reports;
create policy "Members submit own animal reports"
  on public.animal_reports for insert to authenticated
  with check (
    owner_id = (select auth.uid())
    and status = 'pending'
    and contact_consent_at is not null
  );

create or replace function public.get_listing_contact(listing_id uuid)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare v text;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  select contact into v
  from public.marketplace_listings
  where id = listing_id and status = 'active' and contact_consent_at is not null;
  return v;
end;
$$;
revoke all on function public.get_listing_contact(uuid) from public, anon;
grant execute on function public.get_listing_contact(uuid) to authenticated;

create or replace function public.get_animal_contact(report_id uuid)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare v text;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  select contact into v
  from public.animal_reports
  where id = report_id and status = 'active' and contact_consent_at is not null;
  return v;
end;
$$;
revoke all on function public.get_animal_contact(uuid) from public, anon;
grant execute on function public.get_animal_contact(uuid) to authenticated;

notify pgrst, 'reload schema';
