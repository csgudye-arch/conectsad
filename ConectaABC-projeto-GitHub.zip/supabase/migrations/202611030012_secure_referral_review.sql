-- Private staff review for referral CPF checks. Raw CPF is never stored.
alter table public.referral_attributions
  add column if not exists cpf_fingerprint text,
  add column if not exists cpf_verified_by uuid references auth.users(id) on delete set null;

create unique index if not exists referral_attributions_cpf_fingerprint_unique
  on public.referral_attributions (cpf_fingerprint)
  where cpf_fingerprint is not null;

-- Keep the HMAC key in Supabase Vault; it is never returned to the browser.
do $$
begin
  if not exists (select 1 from vault.secrets where name = 'conecta_referral_cpf_hmac') then
    perform vault.create_secret(
      encode(extensions.gen_random_bytes(32), 'hex'),
      'conecta_referral_cpf_hmac',
      'HMAC key used only to prevent a CPF from earning multiple referral rewards'
    );
  end if;
end;
$$;

create or replace function public.can_verify_referrals()
returns boolean
language sql stable security definer set search_path = ''
as $$
  select auth.uid() is not null and (
    exists(select 1 from public.referral_verifiers v where v.user_id = auth.uid())
    or exists(select 1 from public.community_moderators m where m.user_id = auth.uid())
  );
$$;
revoke all on function public.can_verify_referrals() from public, anon;
grant execute on function public.can_verify_referrals() to authenticated;

create or replace function public.list_referrals_pending_cpf()
returns table(referred_id uuid, member_name text, city text, registered_at timestamptz, email_confirmed_at timestamptz)
language plpgsql stable security definer set search_path = ''
as $$
begin
  if not public.can_verify_referrals() then
    raise exception 'Not authorized' using errcode = '42501';
  end if;
  return query
    select r.referred_user_id, p.display_name, p.city, r.created_at, r.email_confirmed_at
    from public.referral_attributions r
    join public.profiles p on p.id = r.referred_user_id
    where r.email_confirmed_at is not null
      and r.cpf_verified_at is null
    order by r.created_at asc
    limit 100;
end;
$$;
revoke all on function public.list_referrals_pending_cpf() from public, anon;
grant execute on function public.list_referrals_pending_cpf() to authenticated;

drop function if exists public.verify_referral_cpf(uuid);
create or replace function public.verify_referral_cpf(referred_id uuid, cpf_input text)
returns boolean
language plpgsql security definer set search_path = ''
as $$
declare
  normalized_cpf text := regexp_replace(coalesce(cpf_input, ''), '[^0-9]', '', 'g');
  secret_value text;
  fingerprint_value text;
  total integer;
  digit integer;
  position integer;
  changed integer;
begin
  if auth.uid() is null or not public.can_verify_referrals() then
    raise exception 'Not authorized' using errcode = '42501';
  end if;
  if normalized_cpf !~ '^[0-9]{11}$'
     or length(replace(normalized_cpf, substr(normalized_cpf, 1, 1), '')) = 0 then
    raise exception 'CPF inválido' using errcode = '22023';
  end if;

  total := 0;
  for position in 1..9 loop
    total := total + substr(normalized_cpf, position, 1)::integer * (11 - position);
  end loop;
  digit := case when total % 11 < 2 then 0 else 11 - (total % 11) end;
  if digit <> substr(normalized_cpf, 10, 1)::integer then
    raise exception 'CPF inválido' using errcode = '22023';
  end if;

  total := 0;
  for position in 1..10 loop
    total := total + substr(normalized_cpf, position, 1)::integer * (12 - position);
  end loop;
  digit := case when total % 11 < 2 then 0 else 11 - (total % 11) end;
  if digit <> substr(normalized_cpf, 11, 1)::integer then
    raise exception 'CPF inválido' using errcode = '22023';
  end if;

  select v.decrypted_secret into secret_value
    from vault.decrypted_secrets v
    where v.name = 'conecta_referral_cpf_hmac';
  if secret_value is null then
    raise exception 'Secure CPF fingerprint key is unavailable' using errcode = '55000';
  end if;
  fingerprint_value := encode(
    extensions.hmac(convert_to(normalized_cpf, 'UTF8'), convert_to(secret_value, 'UTF8'), 'sha256'),
    'hex'
  );

  update public.referral_attributions
    set cpf_fingerprint = fingerprint_value,
        cpf_verified_at = now(),
        cpf_verified_by = auth.uid()
    where referred_user_id = verify_referral_cpf.referred_id
      and email_confirmed_at is not null
      and cpf_verified_at is null;
  get diagnostics changed = row_count;
  return changed = 1;
exception
  when unique_violation then
    raise exception 'Este CPF já foi usado para validar outra indicação.' using errcode = '23505';
end;
$$;
revoke all on function public.verify_referral_cpf(uuid, text) from public, anon;
grant execute on function public.verify_referral_cpf(uuid, text) to authenticated;
