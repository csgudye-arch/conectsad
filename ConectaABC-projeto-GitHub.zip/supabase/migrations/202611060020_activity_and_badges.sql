begin;
create function public.social_my_activity_summary() returns jsonb language plpgsql stable security definer set search_path='' as $$
declare actor uuid:=auth.uid();
begin
 if actor is null then raise exception 'Entre para consultar sua atividade.' using errcode='42501';end if;
 return jsonb_build_object('posts',(select count(*) from public.community_posts where author_id=actor),'approved_posts',(select count(*) from public.community_posts where author_id=actor and status='approved'),'city_reports',(select count(*) from public.city_reports where author_id=actor),'solved_reports',(select count(*) from public.city_reports where author_id=actor and status='resolved'),'marketplace',(select count(*) from public.marketplace_listings where owner_id=actor),'animals',(select count(*) from public.animal_reports where owner_id=actor),'services',(select count(*) from public.service_requests where author_id=actor),'comments',(select count(*) from public.social_comments where author_id=actor),'classifieds',(select count(*) from public.social_classifieds where owner_id=actor),'stories',(select count(*) from public.social_stories where author_id=actor),'visits',(select count(distinct place_id) from public.social_place_visits where user_id=actor),'friends',(select count(*) from public.social_friendships where status='accepted' and actor in (sender_id,receiver_id)));
end; $$;
create function public.social_member_badges(member_id uuid) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare badges jsonb:='[]'::jsonb;
begin
 if member_id is distinct from auth.uid() and not exists(select 1 from public.social_member_details where user_id=member_id and public_enabled and not moderation_hidden) then return badges;end if;
 if (select count(*) from public.city_reports where author_id=member_id and status='resolved')>=3 then badges:=badges||jsonb_build_array(jsonb_build_object('name','Agente da cidade','detail','Três ou mais relatos com solução confirmada pela equipe.'));end if;
 if (select count(*) from public.animal_reports where owner_id=member_id and status='reunido')>=3 then badges:=badges||jsonb_build_array(jsonb_build_object('name','Protetor dos animais','detail','Três ou mais ocorrências com reencontro confirmado.'));end if;
 if (select count(*) from public.referral_attributions where referrer_user_id=member_id and email_confirmed_at is not null and cpf_verified_at is not null and points_awarded_at is not null)>=10 then badges:=badges||jsonb_build_array(jsonb_build_object('name','Embaixador do ABC','detail','Dez ou mais indicações validadas.'));end if;
 if (select coalesce(sum(points),0) from public.points_ledger where user_id=member_id)>=(select minimum_points from public.social_levels where level=10) then badges:=badges||jsonb_build_array(jsonb_build_object('name','Lenda do ABC','detail','Nível máximo de participação alcançado.'));end if;
 return badges;
end; $$;
revoke all on function public.social_my_activity_summary(),public.social_member_badges(uuid) from public,anon,authenticated;
grant execute on function public.social_my_activity_summary() to authenticated;
grant execute on function public.social_member_badges(uuid) to anon,authenticated;
commit;
