begin;
alter table public.social_businesses add column logo_path text check(logo_path is null or logo_path like owner_id::text||'/%'),add column gallery_paths text[] not null default array[]::text[] check(cardinality(gallery_paths)<=6);
create function public.social_set_business_photos(target_business uuid,business_logo text,business_gallery text[]) returns void language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid();paths text[];
begin
 if actor is null or not exists(select 1 from public.social_businesses where id=target_business and owner_id=actor and status<>'hidden') then raise exception 'Somente o responsável pode editar fotos de um negócio disponível.' using errcode='42501';end if;
 if business_gallery is null or cardinality(business_gallery)>6 or coalesce(array_ndims(business_gallery),1)<>1 or exists(select 1 from unnest(business_gallery) v where v is null) or (select count(distinct v) from unnest(business_gallery) v)<>cardinality(business_gallery) then raise exception 'Escolha até seis fotos distintas para a galeria.' using errcode='22023';end if;
 paths:=business_gallery||case when business_logo is null then array[]::text[] else array[business_logo] end;
 if exists(select 1 from unnest(paths) p where p not like actor::text||'/%' or not exists(select 1 from storage.objects where bucket_id='submission-media' and name=p and metadata->>'mimetype' in ('image/jpeg','image/png','image/webp') and coalesce((metadata->>'size')::bigint,0)<=5242880)) then raise exception 'Foto inválida ou maior que 5 MB.' using errcode='22023';end if;
 update public.social_businesses set logo_path=business_logo,gallery_paths=business_gallery,status='pending',updated_at=now() where id=target_business and owner_id=actor and status<>'hidden';
end; $$;
create function public.social_business_media_readable(object_name text) returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.social_businesses where (logo_path=object_name or object_name=any(gallery_paths)) and (status='approved' or owner_id=auth.uid() or exists(select 1 from public.community_moderators where user_id=auth.uid()))) $$;
create policy "Read available business photos" on storage.objects for select to anon,authenticated using(bucket_id='submission-media' and public.social_business_media_readable(name));
revoke all on function public.social_set_business_photos(uuid,text,text[]),public.social_business_media_readable(text) from public,anon,authenticated;
grant execute on function public.social_set_business_photos(uuid,text,text[]) to authenticated;
grant execute on function public.social_business_media_readable(text) to anon,authenticated;
create or replace function public.social_list_businesses(target_business uuid default null,page_number integer default 0) returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(item order by name),'[]'::jsonb) from (select b.name,jsonb_build_object('id',b.id,'name',b.name,'logo_path',b.logo_path,'gallery_paths',b.gallery_paths,'category',b.category,'city',b.city,'description',b.description,'address',b.address,'hours',b.hours,'phone',b.phone,'instagram',b.instagram,'status',b.status,'is_own',coalesce(b.owner_id=auth.uid(),false),'following',exists(select 1 from public.social_business_followers f where f.business_id=b.id and f.user_id=auth.uid()),'followers',(select count(*) from public.social_business_followers f where f.business_id=b.id)) item from public.social_businesses b where (target_business is null or b.id=target_business) and (b.status='approved' or b.owner_id=auth.uid()) order by b.name,b.id limit 24 offset least(greatest(coalesce(page_number,0),0),1000)*24) rows;
$$;
commit;
