begin;
create table public.social_member_blocks(user_id uuid not null references public.profiles(id) on delete cascade,blocked_id uuid not null references public.profiles(id) on delete cascade,created_at timestamptz not null default now(),primary key(user_id,blocked_id),check(user_id<>blocked_id));
alter table public.social_member_blocks enable row level security;revoke all on public.social_member_blocks from public,anon,authenticated;
create function public.social_block_member(target_member uuid,blocking boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para gerenciar contatos.' using errcode='42501';end if;
 if target_member is null or target_member=auth.uid() or blocking is null or not exists(select 1 from public.profiles where id=target_member) then raise exception 'Contato inválido.' using errcode='22023';end if;
 if blocking then insert into public.social_member_blocks(user_id,blocked_id) values(auth.uid(),target_member) on conflict do nothing;update public.social_friendships set status='declined',updated_at=now() where (sender_id=auth.uid() and receiver_id=target_member) or (sender_id=target_member and receiver_id=auth.uid());else delete from public.social_member_blocks where user_id=auth.uid() and blocked_id=target_member;end if;
end; $$;
create function public.social_block_friend(target_request uuid) returns void language plpgsql security definer set search_path='' as $$
declare target uuid;
begin
 if auth.uid() is null then raise exception 'Entre para gerenciar contatos.' using errcode='42501';end if;
 select case when sender_id=auth.uid() then receiver_id else sender_id end into target from public.social_friendships where id=target_request and auth.uid() in (sender_id,receiver_id);if target is null then raise exception 'Pedido indisponível.' using errcode='42501';end if;
 perform public.social_block_member(target,true);
end; $$;
create function public.social_my_blocks() returns jsonb language plpgsql stable security definer set search_path='' as $$ begin if auth.uid() is null then raise exception 'Entre para ver contatos bloqueados.' using errcode='42501';end if;return(select coalesce(jsonb_agg(jsonb_build_object('member_id',b.blocked_id,'first_name',split_part(trim(p.display_name),' ',1),'city',p.city)),'[]'::jsonb) from public.social_member_blocks b join public.profiles p on p.id=b.blocked_id where b.user_id=auth.uid());end; $$;
create function public.social_suggest_members() returns jsonb language plpgsql stable security definer set search_path='' as $$ begin if auth.uid() is null then raise exception 'Entre para conhecer membros.' using errcode='42501';end if;return(select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb) from (select p.id member_id,split_part(trim(p.display_name),' ',1) first_name,p.city,d.handle,coalesce(d.show_presence and d.last_seen_at>now()-interval '2 minutes',false) recently_active from public.profiles p join public.social_member_details d on d.user_id=p.id where d.public_enabled and not d.moderation_hidden and p.id<>auth.uid() and p.city=(select city from public.profiles where id=auth.uid()) and not exists(select 1 from public.social_member_blocks b where b.user_id=auth.uid() and b.blocked_id=p.id or b.blocked_id=auth.uid() and b.user_id=p.id) and not exists(select 1 from public.social_friendships f where f.sender_id=auth.uid() and f.receiver_id=p.id or f.receiver_id=auth.uid() and f.sender_id=p.id) order by d.updated_at desc limit 20) x);end; $$;
revoke all on function public.social_block_member(uuid,boolean),public.social_block_friend(uuid),public.social_my_blocks(),public.social_suggest_members() from public,anon,authenticated;
grant execute on function public.social_block_member(uuid,boolean),public.social_block_friend(uuid),public.social_my_blocks(),public.social_suggest_members() to authenticated;
create or replace function public.social_request_friend(target_member uuid) returns void
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); relation public.social_friendships;
begin
 if exists(select 1 from public.social_member_blocks where user_id=auth.uid() and blocked_id=target_member or blocked_id=auth.uid() and user_id=target_member) then raise exception 'Interação indisponível.' using errcode='42501';end if;
 if actor is null then raise exception 'Entre para adicionar amigos.' using errcode='42501'; end if;
 if target_member=actor or target_member is null then raise exception 'Selecione outro membro.' using errcode='22023'; end if;
 if not exists(select 1 from public.profiles where id=target_member) then raise exception 'Membro não encontrado.' using errcode='P0002'; end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,411));
 perform pg_advisory_xact_lock(hashtextextended(least(actor,target_member)::text||greatest(actor,target_member)::text,412));
 select * into relation from public.social_friendships where least(sender_id,receiver_id)=least(actor,target_member) and greatest(sender_id,receiver_id)=greatest(actor,target_member) for update;
 if found then
 if relation.status in ('pending','accepted') then return; end if;
 raise exception 'Este pedido já foi encerrado.' using errcode='P0001';
 end if;
 if (select count(*) from public.social_friendships where sender_id=actor and created_at>now()-interval '24 hours')>=20 then raise exception 'Você atingiu o limite diário de convites.' using errcode='P0001'; end if;
 insert into public.social_friendships(sender_id,receiver_id) values(actor,target_member);
 insert into public.social_notifications(user_id,kind,message) values(target_member,'friend_request','Você recebeu um pedido de amizade.');
end; $$;
create or replace function public.social_add_comment(target_post uuid,comment_body text) returns uuid
language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); result uuid;
begin
 if exists(select 1 from public.social_member_blocks b join public.community_posts p on p.id=target_post and not p.is_anonymous where b.user_id=auth.uid() and b.blocked_id=p.author_id or b.blocked_id=auth.uid() and b.user_id=p.author_id) then raise exception 'Interação indisponível.' using errcode='42501';end if;
 if actor is null then raise exception 'Entre para comentar.' using errcode='42501'; end if;
 if comment_body is null or char_length(trim(comment_body)) not between 2 and 1000 then raise exception 'Escreva de 2 a 1.000 caracteres.' using errcode='22023'; end if;
 if not exists(select 1 from public.community_posts where id=target_post and status='approved') then raise exception 'Publicação indisponível.' using errcode='P0002'; end if;
 perform pg_advisory_xact_lock(hashtextextended(actor::text,410));
 if (select count(*) from public.social_comments where author_id=actor and created_at>now()-interval '1 minute')>=5
 or (select count(*) from public.social_comments where author_id=actor and created_at>now()-interval '24 hours')>=30 then
 raise exception 'Limite de comentários atingido. Tente novamente mais tarde.' using errcode='P0001'; end if;
 insert into public.social_comments(post_id,author_id,body) values(target_post,actor,trim(comment_body)) returning id into result;
 return result;
end; $$;

commit;
