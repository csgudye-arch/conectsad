begin;
alter table public.marketplace_listings add column condition_name text not null default 'Usado' check(condition_name in ('Novo','Seminovo','Usado')),add column accepts_trade boolean not null default false,add column deal_type text not null default 'venda' check(deal_type in ('venda','troca','doacao')),add column previous_price numeric(10,2) check(previous_price is null or previous_price>=0);
alter table public.marketplace_listings add constraint marketplace_donation_zero check(deal_type<>'doacao' or price=0 and price is not null);
grant select(condition_name,accepts_trade,deal_type,previous_price) on public.marketplace_listings to anon,authenticated;
grant insert(condition_name,accepts_trade,deal_type) on public.marketplace_listings to authenticated;
create function public.social_my_listings() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para gerenciar seus anúncios.' using errcode='42501';end if;
 return (select coalesce(jsonb_agg(to_jsonb(l)-'contact' order by l.created_at desc),'[]'::jsonb) from public.marketplace_listings l where l.owner_id=auth.uid());
end; $$;
create function public.social_change_listing_price(target_listing uuid,new_price numeric) returns void language plpgsql security definer set search_path='' as $$
declare item public.marketplace_listings;
begin
 if auth.uid() is null then raise exception 'Entre para editar o anúncio.' using errcode='42501';end if;
 if new_price is null or new_price<0 or new_price>99999999.99 or new_price<>round(new_price,2) then raise exception 'Informe um valor válido com até duas casas decimais.' using errcode='22023';end if;
 select * into item from public.marketplace_listings where id=target_listing for update;
 if not found or item.owner_id<>auth.uid() or item.status not in ('pending','active') then raise exception 'Somente o responsável pode alterar o preço de um anúncio disponível.' using errcode='42501';end if;
 if item.deal_type='doacao' and new_price<>0 then raise exception 'Uma doação deve permanecer gratuita. Cadastre outro anúncio para vender.' using errcode='22023';end if;
 if item.price is not distinct from new_price then return;end if;
 update public.marketplace_listings set previous_price=case when price>new_price then price else null end,price=new_price where id=target_listing;
end; $$;
create function public.social_close_listing(target_listing uuid,closed_as text) returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para gerenciar o anúncio.' using errcode='42501';end if;
 if closed_as is null or closed_as not in ('sold','hidden') then raise exception 'Selecione vendido ou retirar anúncio.' using errcode='22023';end if;
 update public.marketplace_listings set status=closed_as where id=target_listing and owner_id=auth.uid() and status in ('pending','active');
 if not found then raise exception 'Anúncio indisponível ou de outro responsável.' using errcode='42501';end if;
end; $$;
revoke all on function public.social_my_listings(),public.social_change_listing_price(uuid,numeric),public.social_close_listing(uuid,text) from public,anon,authenticated;
grant execute on function public.social_my_listings(),public.social_change_listing_price(uuid,numeric),public.social_close_listing(uuid,text) to authenticated;
commit;
