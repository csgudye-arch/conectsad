-- Anexos privados para o Feed comunitário e opção de exibição anônima.
begin;
alter table public.community_posts
  add column if not exists is_anonymous boolean not null default false,
  add column if not exists media_path text,
  add column if not exists media_kind text;

alter table public.community_posts
  drop constraint if exists community_posts_media_kind_check;
alter table public.community_posts
  add constraint community_posts_media_kind_check
  check (media_kind is null or media_kind in ('image', 'video'));
alter table public.community_posts
  drop constraint if exists community_posts_media_pair_check;
alter table public.community_posts
  add constraint community_posts_media_pair_check
  check ((media_path is null) = (media_kind is null));
alter table public.community_posts
  drop constraint if exists community_posts_media_owner_folder_check;
alter table public.community_posts
  add constraint community_posts_media_owner_folder_check
  check (media_path is null or media_path like author_id::text || '/%');

grant insert (author_id, category, city, body, is_anonymous, media_path, media_kind)
  on public.community_posts to authenticated;
revoke select on public.community_posts from anon, authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('feed-media', 'feed-media', false, 20971520,
  array['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm', 'video/quicktime'])
on conflict (id) do update set
  public = false,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create policy "Members upload feed media to their own folder"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'feed-media'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

create policy "Members view feed media they may access"
  on storage.objects for select to anon, authenticated
  using (
    bucket_id = 'feed-media'
    and (
      (select auth.uid())::text = (storage.foldername(name))[1]
      or exists (
        select 1 from public.community_posts p
        where p.media_path = name
          and (p.status = 'approved' or p.author_id = (select auth.uid()))
      )
      or (
        (select auth.uid()) is not null
        and exists (select 1 from public.community_moderators m where m.user_id = (select auth.uid()))
        and exists (select 1 from public.community_posts p where p.media_path = name and p.status = 'pending')
      )
    )
  );

create policy "Members replace their own feed media"
  on storage.objects for update to authenticated
  using (bucket_id = 'feed-media' and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'feed-media' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "Members remove their own feed media"
  on storage.objects for delete to authenticated
  using (bucket_id = 'feed-media' and (storage.foldername(name))[1] = (select auth.uid())::text);

create or replace function public.list_public_community_posts()
returns table (
  id uuid,
  author_id uuid,
  category text,
  city text,
  body text,
  status text,
  created_at timestamptz,
  title text,
  source text,
  sensitive boolean,
  is_official boolean,
  is_anonymous boolean,
  media_path text,
  media_kind text
)
language sql
stable
security definer
set search_path = ''
as $$
  select p.id,
    case when p.is_anonymous then null else p.author_id end,
    p.category, p.city, p.body, p.status, p.created_at, p.title, p.source,
    p.sensitive, p.is_official, p.is_anonymous, p.media_path, p.media_kind
  from public.community_posts p
  where p.status = 'approved' or p.author_id = (select auth.uid())
  order by p.created_at desc
  limit 50;
$$;

revoke all on function public.list_public_community_posts() from public;
grant execute on function public.list_public_community_posts() to anon, authenticated;

drop function if exists public.list_pending_community_posts();
create function public.list_pending_community_posts()
returns table (
  id uuid,
  author_name text,
  city text,
  category text,
  body text,
  created_at timestamptz,
  media_path text,
  media_kind text
)
language plpgsql
security definer
set search_path = ''
stable
as $$
begin
  if not exists (
    select 1 from public.community_moderators m
    where m.user_id = (select auth.uid())
  ) then
    raise exception 'moderator access required' using errcode = '42501';
  end if;

  return query
    select p.id, coalesce(pr.display_name, 'Membro da comunidade'), p.city,
      p.category, p.body, p.created_at, p.media_path, p.media_kind
    from public.community_posts p
    left join public.profiles pr on pr.id = p.author_id
    where p.status = 'pending'
    order by p.created_at asc
    limit 100;
end;
$$;

revoke all on function public.list_pending_community_posts() from public, anon;
grant execute on function public.list_pending_community_posts() to authenticated;

commit;
