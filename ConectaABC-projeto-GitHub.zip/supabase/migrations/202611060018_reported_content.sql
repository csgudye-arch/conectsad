begin;
alter table public.social_member_details add column moderation_hidden boolean not null default false;
create table public.social_content_reports(kind text not null check(kind in ('business','story','comment','profile','review')),target_id uuid not null,reporter_id uuid not null references public.profiles(id) on delete cascade,reason text not null check(char_length(reason) between 3 and 500),reviewed_at timestamptz,created_at timestamptz not null default now(),primary key(kind,target_id,reporter_id));
create table public.social_content_audit(id bigint generated always as identity primary key,kind text not null,target_id uuid not null,moderator_id uuid not null references auth.users(id),decision text not null,reason text not null,created_at timestamptz not null default now());
alter table public.social_content_reports enable row level security;alter table public.social_content_audit enable row level security;
revoke all on public.social_content_reports,public.social_content_audit from public,anon,authenticated;
create function public.social_report_content(target_kind text,target_id uuid,report_reason text) returns void language plpgsql security definer set search_path='' as $$
declare available boolean:=false;
begin
 if auth.uid() is null then raise exception 'Entre para enviar uma denúncia.' using errcode='42501';end if;
 if report_reason is null or char_length(trim(report_reason)) not between 3 and 500 then raise exception 'Descreva o motivo em 3 a 500 caracteres.' using errcode='22023';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text,501));
 if (select count(*) from public.social_content_reports where reporter_id=auth.uid() and created_at>now()-interval '24 hours')>=30 then raise exception 'Limite diário de denúncias atingido.' using errcode='P0001';end if;
 perform pg_advisory_xact_lock(hashtextextended(target_kind||':'||target_id::text,500));
 case target_kind
 when 'business' then select status='approved' into available from public.social_businesses where id=target_id;
 when 'story' then select status='approved' and expires_at>now() into available from public.social_stories where id=target_id;
 when 'comment' then select c.status='approved' and p.status='approved' into available from public.social_comments c join public.community_posts p on p.id=c.post_id where c.id=target_id;
 when 'profile' then select public_enabled and not moderation_hidden into available from public.social_member_details where user_id=target_id;
 when 'review' then select r.status='approved' and p.status='approved' into available from public.social_place_reviews r join public.community_places p on p.id=r.place_id where r.id=target_id;
 else raise exception 'Tipo inválido.' using errcode='22023';end case;
 if not coalesce(available,false) then raise exception 'Conteúdo indisponível.' using errcode='P0002';end if;
 insert into public.social_content_reports(kind,target_id,reporter_id,reason) values(target_kind,target_id,auth.uid(),trim(report_reason)) on conflict do nothing;
 if (select count(*) from public.social_content_reports r where r.kind=target_kind and r.target_id=social_report_content.target_id and r.reviewed_at is null)>=3 then
 case target_kind when 'business' then update public.social_businesses set status='hidden' where id=target_id;
 when 'story' then update public.social_stories set status='hidden' where id=target_id;
 when 'comment' then update public.social_comments set status='rejected' where id=target_id;
 when 'profile' then update public.social_member_details set moderation_hidden=true where user_id=target_id;
 when 'review' then update public.social_place_reviews set status='rejected' where id=target_id;end case;
 end if;
end; $$;
create function public.social_content_report_queue() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 return(select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb) from (select r.kind,r.target_id,count(*) reports,string_agg(r.reason,E'\n') reasons,case r.kind when 'business' then (select name||E'\n'||description from public.social_businesses where id=r.target_id) when 'story' then (select caption from public.social_stories where id=r.target_id) when 'comment' then (select body from public.social_comments where id=r.target_id) when 'profile' then (select '@'||handle||E'\n'||bio from public.social_member_details where user_id=r.target_id) when 'review' then (select body from public.social_place_reviews where id=r.target_id) end body from public.social_content_reports r where r.reviewed_at is null group by r.kind,r.target_id order by min(r.created_at) limit 100) x);
end; $$;
create function public.social_review_reported_content(target_kind text,target_id uuid,decision text,reason text) returns void language plpgsql security definer set search_path='' as $$
declare target_exists boolean;
begin
 if not exists(select 1 from public.community_moderators where user_id=auth.uid()) then raise exception 'Acesso restrito à equipe.' using errcode='42501';end if;
 if decision is null or decision not in ('approved','rejected') or reason is null or char_length(trim(reason)) not between 3 and 500 then raise exception 'Informe decisão e motivo.' using errcode='22023';end if;
 perform pg_advisory_xact_lock(hashtextextended(target_kind||':'||target_id::text,500));
 select case target_kind when 'business' then exists(select 1 from public.social_businesses where id=target_id) when 'story' then exists(select 1 from public.social_stories where id=target_id) when 'comment' then exists(select 1 from public.social_comments where id=target_id) when 'profile' then exists(select 1 from public.social_member_details where user_id=target_id) when 'review' then exists(select 1 from public.social_place_reviews where id=target_id) else false end into target_exists;
 if not target_exists then update public.social_content_reports r set reviewed_at=now() where r.kind=target_kind and r.target_id=social_review_reported_content.target_id;insert into public.social_content_audit(kind,target_id,moderator_id,decision,reason) values(target_kind,target_id,auth.uid(),decision,trim(reason));return;end if;
 case target_kind
 when 'business' then perform public.social_review_business(target_id,decision,reason);
 when 'story' then if decision='approved' and exists(select 1 from public.social_stories where id=target_id and expires_at<=now()) then raise exception 'Story expirado. Escolha encerrar a análise sem restaurar.' using errcode='P0002';end if;update public.social_stories set status=decision where id=target_id;
 when 'comment' then perform public.social_review_comment(target_id,decision,reason);
 when 'profile' then update public.social_member_details set moderation_hidden=(decision='rejected') where user_id=target_id;
 when 'review' then perform public.social_review_place_rating(target_id,decision,reason);
 else raise exception 'Tipo inválido.' using errcode='22023';end case;
 update public.social_content_reports r set reviewed_at=now() where r.kind=target_kind and r.target_id=social_review_reported_content.target_id and r.reviewed_at is null;
 insert into public.social_content_audit(kind,target_id,moderator_id,decision,reason) values(target_kind,target_id,auth.uid(),decision,trim(reason));
end; $$;
revoke all on function public.social_report_content(text,uuid,text),public.social_content_report_queue(),public.social_review_reported_content(text,uuid,text,text) from public,anon,authenticated;
grant execute on function public.social_report_content(text,uuid,text),public.social_content_report_queue(),public.social_review_reported_content(text,uuid,text,text) to authenticated;
create or replace function public.social_public_profile(member_handle text) returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('member_id',p.id,'first_name',split_part(trim(p.display_name),' ',1),'handle',d.handle,'bio',d.bio,'neighborhood',d.neighborhood,'city',p.city,'cover_path',d.cover_path,'avatar_path',case when p.avatar_public then p.avatar_path else null end,'recently_active',coalesce(d.show_presence and d.last_seen_at>now()-interval '2 minutes',false),'is_moderator',exists(select 1 from public.community_moderators where user_id=p.id),'points',(select coalesce(sum(points),0) from public.points_ledger where user_id=p.id),'posts',(select count(*) from public.community_posts where author_id=p.id and status='approved' and not is_anonymous)) from public.social_member_details d join public.profiles p on p.id=d.user_id where d.handle=lower(member_handle) and (d.public_enabled and not d.moderation_hidden or d.user_id=auth.uid());
$$;
create or replace function public.social_member_posts(member_handle text,page_number integer default 0) returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(to_jsonb(x)),'[]'::jsonb) from (select c.id,c.title,c.body,c.city,c.created_at,c.media_path,c.media_kind from public.community_posts c join public.social_member_details d on d.user_id=c.author_id where d.handle=lower(member_handle) and (d.public_enabled and not d.moderation_hidden or d.user_id=auth.uid()) and c.status='approved' and not c.is_anonymous order by c.created_at desc limit 24 offset least(greatest(coalesce(page_number,0),0),1000)*24) x;
$$;
create or replace function public.social_cover_readable(object_name text) returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.social_member_details where cover_path=object_name and (public_enabled and not moderation_hidden or user_id=auth.uid())) $$;

create or replace function public.social_my_details() returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Entre para acessar o perfil.' using errcode='42501'; end if;
 return (select jsonb_build_object('handle',d.handle,'bio',d.bio,'neighborhood',d.neighborhood,'cover_path',d.cover_path,'public_enabled',d.public_enabled,'show_presence',d.show_presence,'moderation_hidden',d.moderation_hidden) from public.social_member_details d where d.user_id=auth.uid());
end; $$;
commit;
