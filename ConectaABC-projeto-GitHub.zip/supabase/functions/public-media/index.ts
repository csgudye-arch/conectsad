import { createClient } from 'npm:@supabase/supabase-js@2';

// Public bytes only: never redirect to a Storage URL containing the author's UUID.
Deno.serve(async(request:Request)=>{
 const headers:Record<string,string>={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET, HEAD, OPTIONS','Access-Control-Allow-Headers':'range','Access-Control-Expose-Headers':'Content-Range, Accept-Ranges, Content-Length','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
 const fail=(status:number)=>new Response(null,{status,headers});
 if(request.method==='OPTIONS')return fail(204);
 if(!['GET','HEAD'].includes(request.method))return fail(405);
 const id=new URL(request.url).searchParams.get('post');
 if(!id||!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id))return fail(400);
 const range=request.headers.get('range');
 if(range&&!/^bytes=(?:\d+-\d*|-\d+)$/.test(range))return fail(416);
 const url=Deno.env.get('SUPABASE_URL'),key=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
 if(!url||!key)return fail(503);
 try{
  const client=createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
  const result=await client.from('community_posts').select('media_path,media_kind').eq('id',id).eq('status','approved').eq('is_anonymous',true).maybeSingle();
  if(result.error)return fail(503);
  const post=result.data;
  if(!post?.media_path||!['image','video'].includes(post.media_kind))return fail(404);
  const path=post.media_path.split('/').map(encodeURIComponent).join('/');
  const upstream=await fetch(`${url}/storage/v1/object/authenticated/feed-media/${path}`,{method:request.method,headers:{authorization:`Bearer ${key}`,apikey:key,...(range?{range}:{})},redirect:'error'});
  if(upstream.status===416){const value=upstream.headers.get('content-range');if(value)headers['Content-Range']=value;return fail(416);}
  if(![200,206].includes(upstream.status))return fail(upstream.status===404?404:503);
  const type=upstream.headers.get('content-type')||'';
  if(!/^(image\/(jpeg|png|webp)|video\/(mp4|webm|quicktime))(;|$)/i.test(type)){await upstream.body?.cancel();return fail(415);}
  for(const name of ['content-type','content-length','content-range','accept-ranges']){const value=upstream.headers.get(name);if(value)headers[name]=value;}
  return new Response(request.method==='HEAD'?null:upstream.body,{status:upstream.status,headers});
 }catch{return fail(503);}
});
