import { createClient } from 'npm:@supabase/supabase-js@2';
const allowedOrigins=new Set(['https://conectaabc.com','https://www.conectaabc.com','https://conecta-abc.netlify.app','http://localhost:3000','http://localhost:3100','capacitor://localhost','http://localhost']);
Deno.serve(async(request:Request)=>{
 const origin=request.headers.get('origin');
 const headers:Record<string,string>={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin'};
 if(origin&&allowedOrigins.has(origin)){headers['Access-Control-Allow-Origin']=origin;headers['Access-Control-Allow-Headers']='authorization, x-client-info, apikey, content-type';headers['Access-Control-Allow-Methods']='POST, OPTIONS';}
 const reply=(status:number,data:unknown)=>new Response(JSON.stringify(data),{status,headers});
 if(origin&&!allowedOrigins.has(origin))return reply(403,{error:'Origem não autorizada.'});
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(request.method!=='POST')return reply(405,{error:'Método não permitido.'});
 const bearer=request.headers.get('authorization')||'';
 if(!bearer.startsWith('Bearer '))return reply(401,{error:'Entre novamente para continuar.'});
 const url=Deno.env.get('SUPABASE_URL'),key=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
 if(!url||!key)return reply(503,{error:'Serviço de exclusão aguarda configuração.'});
 const admin=createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
 const {data:auth,error:authError}=await admin.auth.getUser(bearer.slice(7));
 if(authError||!auth.user)return reply(401,{error:'Sua sessão expirou. Entre novamente.'});
 const signedIn=Date.parse(auth.user.last_sign_in_at||'');
 if(!Number.isFinite(signedIn)||signedIn<Date.now()-15*60*1000)return reply(409,{error:'Por segurança, saia e entre novamente antes de excluir sua conta.'});
 let input:{action?:string;confirmation?:string};try{input=await request.json();}catch{return reply(400,{error:'Solicitação inválida.'});}
 if(input.action!=='check'&&input.action!=='delete')return reply(400,{error:'Ação inválida.'});
 const prepared=await admin.rpc('social_prepare_account_delete',{target_user:auth.user.id});
 if(prepared.error)return reply(409,{error:prepared.error.message});
 if(input.action==='check')return reply(200,{ready:true,file_count:prepared.data?.files?.length||0});
 if(input.confirmation!=='EXCLUIR MINHA CONTA')return reply(400,{error:'Confirmação inválida.'});
 const files=(prepared.data?.files||[]) as {bucket:string;path:string}[];
 const buckets=new Map<string,string[]>();
 for(const file of files){if(!file.path.startsWith(auth.user.id+'/'))return reply(500,{error:'Falha ao validar arquivos da conta.'});buckets.set(file.bucket,[...(buckets.get(file.bucket)||[]),file.path]);}
 for(const [bucket,paths] of buckets)for(let index=0;index<paths.length;index+=100){const result=await admin.storage.from(bucket).remove(paths.slice(index,index+100));if(result.error)return reply(503,{error:'Não foi possível remover todos os arquivos. A conta foi mantida. Tente novamente ou procure a equipe.'});}
 const result=await admin.auth.admin.deleteUser(auth.user.id);
 if(result.error)return reply(409,{error:'Não foi possível excluir a conta. Procure a equipe para concluir o atendimento.'});
 return reply(200,{deleted:true});
});
