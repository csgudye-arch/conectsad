# Confirmação de e-mail por código (OTP)

O app já tem uma tela para receber e validar o código de confirmação usando `auth.verifyOtp`. A configuração do provedor é separada: enquanto o projeto Supabase usar o modelo padrão com link, o usuário deve abrir o link recebido. O app informa os dois caminhos.

## Modelo para o Supabase

Depois de configurar um servidor SMTP em **Authentication → SMTP Settings** e salvar, vá a **Authentication → Emails → Confirm signup** e use:

**Assunto**

```text
Seu código de confirmação do Conecta ABC
```

**Corpo HTML**

```html
<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:32px;color:#f4f4f5;background:#111113;border-radius:16px">
  <p style="color:#facc15;font-weight:700;letter-spacing:.08em">CONECTA ABC</p>
  <h1 style="font-size:24px">Confirme seu e-mail</h1>
  <p style="color:#d4d4d8">Digite este código no aplicativo para ativar sua conta:</p>
  <p style="font-size:32px;font-weight:800;letter-spacing:.25em;color:#facc15">{{ .Token }}</p>
  <p style="color:#a1a1aa">Se você não criou uma conta no Conecta ABC, ignore esta mensagem.</p>
  <p style="font-size:12px;color:#71717a">O Grande ABC conectado · Uma plataforma da SAD</p>
</div>
```

Não remova `{{ .Token }}`. É essa variável que faz o Supabase enviar o código que o app valida. Salve o modelo e faça um cadastro com um e-mail de teste para confirmar o recebimento, a entrega e a validação do código.

## Antes de habilitar para o público

- Configure um SMTP com credenciais próprias e remetente verificado. Não use credenciais SMTP no frontend nem as adicione ao repositório.
- Confira limites, custo e política do provedor de e-mail escolhido; não é preciso mudar o plano do Supabase para aplicar a alteração no código do app.
- A confirmação cria uma sessão no navegador que conclui o fluxo. O link padrão continua sendo aceito pelo redirecionamento do Supabase.
- Se o template padrão estiver ativo, o formulário OTP não valida o link: abra o link recebido. A tela informa essa instrução.
