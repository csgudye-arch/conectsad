# Preparação do Supabase

O projeto contém o esquema e as funções de moderação descritos abaixo. A aplicação real depende de confirmar que essas migrações foram executadas no Supabase conectado ao site público.

## Compatibilidade atual

O Next.js está configurado com `output: "export"`; o app web e o app Capacitor são exportações estáticas. Por isso, a interface pode usar apenas a URL do projeto e a chave publicável do Supabase, com RLS ativa. Operações privilegiadas devem ficar em Edge Functions ou funções RPC SQL com autorização explícita; uma chave secreta nunca deve entrar no app.

## Criar o projeto e aplicar o esquema

1. Crie um projeto Supabase e guarde a URL e a chave publicável do projeto.
2. No painel do Supabase, abra **SQL Editor** e execute `supabase/migrations/202610260001_initial_core.sql` em um projeto novo.
3. Execute `supabase/migrations/202611020001_community_moderation.sql` para criar a fila de moderação do Feed.
4. Execute `supabase/migrations/202611020002_city_report_moderation.sql` para criar a fila protegida de relatos urbanos.
5. Execute `supabase/migrations/202611020003_auth_signup_profile.sql` para gravar nome e cidade enviados pelo cadastro e preencher o nome de contas Google no perfil.
6. Execute `supabase/migrations/202611020004_daily_checkin.sql` para habilitar o check-in diário de 5 pontos, limitado no banco a uma vez por conta e por dia.
7. Execute `supabase/migrations/202611020005_referrals_leaderboard.sql` para vincular indicações no cadastro, validar indicação por confirmação de e-mail/CPF e habilitar ranking opt-in.
8. Execute `supabase/migrations/202611020006_marketplace_animals.sql` para criar anúncios e avisos de animais com contatos protegidos e fila de aprovação.
9. Execute `supabase/migrations/202611020007_google_referral_attribution.sql` para também associar indicações durante o cadastro com Google.
10. Execute `supabase/migrations/202611020008_official_feed_service_moderation.sql` para publicação oficial do Plantão ABC e fila de pedidos do projeto social.
11. Execute `supabase/migrations/202611020009_feed_interactions.sql` para habilitar curtidas persistentes e privadas no Feed.
12. Execute `supabase/migrations/202611020010_submission_contact_consent.sql` para exigir que o consentimento de contato de anúncios e avisos de animais também seja validado no banco.
13. Confira em **Table Editor** se as tabelas `profiles`, `community_posts`, `community_post_reactions`, `city_reports`, `service_requests`, `points_ledger`, `daily_mission_claims`, `referral_attributions`, `marketplace_listings`, `animal_reports`, `community_moderators` e `city_report_moderators` foram criadas e se RLS está habilitada em todas.
Depois das migrações, autorize moderadores pelo SQL Editor, substituindo o e-mail. A conta precisa existir em **Authentication → Users**:

   ```sql
   insert into public.community_moderators (user_id)
   select id from auth.users where email = 'moderador@exemplo.com'
   on conflict (user_id) do nothing;
   ```

   Para remover o acesso, exclua a linha da conta em `community_moderators`.

   Para liberar também a fila de relatos, insira a mesma conta em `city_report_moderators`:

   ```sql
   insert into public.city_report_moderators (user_id)
   select id from auth.users where email = 'moderador@exemplo.com'
   on conflict (user_id) do nothing;
   ```

   Para remover o acesso aos relatos, exclua a linha correspondente em `city_report_moderators`.
14. Em desenvolvimento local, `.env.local` contém a URL e a chave publicável do projeto. Esse arquivo é ignorado pelo Git. Em outra máquina, copie `.env.example` para `.env.local` e preencha essas duas variáveis.
15. Em **Authentication → URL Configuration**, permita `http://localhost:3000/**` em Redirect URLs para confirmação de e-mail e redefinição de senha durante o desenvolvimento web. Para Capacitor, configure os endereços/deep links próprios antes de publicar nas lojas.
16. Para habilitar Google, crie um OAuth Client ID do tipo Web no Google Cloud. Em **Supabase → Authentication → Sign In / Providers → Google**, habilite-o e informe o Client ID e Client Secret. No Google Cloud, adicione a URL pública do app e `http://localhost:3000` como origens permitidas e cadastre como URI de redirecionamento o callback exibido pelo painel Supabase (`https://<project-ref>.supabase.co/auth/v1/callback`). Nunca copie o Client Secret para este projeto.
17. Em **Authentication → URL Configuration**, use a URL principal do site como Site URL e permita a URL pública com `/**` em Redirect URLs.
18. Reinicie `pnpm dev` depois de alterar variáveis de ambiente. Para Capacitor, os valores públicos entram no bundle no momento de `pnpm build:mobile`; sincronize e gere novo build nativo após alterar esses valores.
19. Depois de confirmar que as migrações anteriores até `202611030018` estão aplicadas, execute `supabase/migrations/202611040001_authenticated_submission_limits.sql` para ativar limites por conta nos envios do Feed, relatos, animais, anúncios e solicitações. Essa migração é idempotente; ela não ativa sala de espera nem fila de tarefas.

Consulte a [documentação oficial do Supabase para Google OAuth](https://supabase.com/docs/guides/auth/social-login/auth-google) e [Redirect URLs](https://supabase.com/docs/guides/auth/redirect-urls). Google continua inativo até inserir credenciais válidas no painel do projeto e testar o retorno OAuth.

## Segurança e escopo desta migração

- A chave publicável vai para o cliente e não é um segredo. Ela não protege dados por si só; as políticas RLS são a barreira obrigatória.
- `SUPABASE_SERVICE_ROLE_KEY` não deve ser preenchida no frontend, no `.env.local` usado para o build estático, nem em código `NEXT_PUBLIC_*`. Só deve existir como segredo de uma função confiável quando essas funções forem implementadas.
- Perfil contém apenas nome público, cidade e código de indicação. CPF, e-mail, telefone de contato público e documentos não são armazenados nessa tabela.
- Pedidos de serviço e contato ficam privados ao dono. Relatos começam pendentes e publicações de comunidade só podem ser criadas como pendentes.
- O cliente comum não consegue aprovar uma publicação. As funções SQL verificam `community_moderators` antes de revelar pendências ou alterar o status; a interface não concede acesso por conta própria.
- Relatos urbanos são inseridos como `pending`; o usuário não escolhe nem altera esse status. A política permite leitura pública para `review`, `in_progress` e `resolved`, e leitura dos estados privado/pending somente pelo autor. A fila urbana exige a migração `202611020002_city_report_moderation.sql` e cadastro explícito em `city_report_moderators`; a função SQL não retorna itens da fila a contas comuns, só permite transições sequenciais e registra moderador e horário em cada mudança.
- O cliente não pode alterar estados nem inserir pontos diretamente. O check-in diário usa `claim_daily_checkin()` e grava 5 pontos uma vez por dia. Indicações registram o link, confirmação de e-mail e CPF verificado pela equipe; só então a função protegida concede 10 pontos.
- A migração `202611040001` aplica limites por conta em envios repetidos. Isso ajuda contra spam de contas autenticadas, mas não substitui captcha, mitigação DDoS do provedor, monitoramento nem RLS e pode ser contornado por abuso distribuído com várias contas.
- A migração não cria o bucket de fotos, pois as políticas de armazenamento e retenção precisam ser definidas antes de receber imagens de usuários.
- O cadastro por e-mail usa nome, cidade e confirmação por e-mail do Supabase Auth; a senha tem pelo menos oito caracteres e confirmação. A tela Google pede cidade no primeiro acesso. CPF ainda não é solicitado ou validado.

## Envios disponíveis e limites

| Área | O usuário consegue enviar | O que acontece |
| --- | --- | --- |
| Feed da comunidade | Texto, categoria e cidade | Grava como pendente; moderador aprova ou rejeita. |
| Problemas da cidade | Categoria, cidade, bairro aproximado e descrição | Fica privado enquanto pendente; moderador atualiza o andamento. |
| Animais Perdidos | Tipo, espécie, cidade, bairro, descrição e contato com aceite | Fica pendente; contato só pode ser solicitado após aprovação. |
| Mercadão e empregos | Título, categoria, cidade, descrição, preço e contato com aceite | Fica pendente; contato só pode ser solicitado após aprovação. |
| Serviços sociais | Tipo de apoio, cidade, bairro, descrição e contato autorizado | Pedido privado; a equipe atualiza o status. |
| Parceiros e Portal | Negócio, cidade, contato e descrição autorizados | Solicitação privada de análise/acesso; não publica automaticamente ofertas. |

Todos estes envios exigem uma conta autenticada e as migrações correspondentes. O envio é confirmado na interface apenas depois da resposta de sucesso do Supabase.

## Ainda não implementado

Cadastro/login, Feed moderado, check-in, indicação, ranking opt-in, carteirinha, solicitações privadas, relatos urbanos, anúncios, avisos de animais, fila de parceiros e publicação oficial dependem das migrações indicadas acima e da autorização de moderadores. Denúncias abrem um e-mail para a equipe; fotos, publicação autônoma de ofertas por parceiros, pagamentos/benefícios, validação automatizada de CPF, prêmio de R$ 500 e exclusão completa da conta ainda não estão ativos. O Clube permanece fechado conforme decisão do produto.
