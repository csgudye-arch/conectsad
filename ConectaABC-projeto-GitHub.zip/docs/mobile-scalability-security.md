# Mobile, segurança e escala

## O que o repositório prepara

- O mesmo projeto web é empacotado em Android e iOS pelo Capacitor (`pnpm build:mobile`). Android é compilado no Android Studio; iOS precisa de macOS e Xcode.
- O app agora declara viewport para dispositivos, cores escuras, nome e status bar para instalação na tela inicial do iPhone, e ícones PNG em tamanhos próprios para PWA/iOS. `pnpm assets:generate` atualiza os ícones web e nativos a partir de `public/conecta-abc-mark.svg`.
- Em telas pequenas, os controles de formulário usam fonte de 16 px para evitar zoom involuntário no Safari iOS, os alvos de toque principais ficam maiores, as áreas respeitam recortes de tela e usuários que reduzem animações recebem transições mínimas.
- O Netlify serve assets do Next com cache longo e imutável e aplica cabeçalhos básicos contra MIME incorreto, framing e vazamento desnecessário de referer.

## Proteção de tráfego

O site estático publicado no Netlify recebe a proteção DDoS automática da plataforma. Isso ajuda a manter a entrega das páginas, mas não é uma garantia de disponibilidade nem de capacidade ilimitada. Regras adicionais de rate limit no Netlify cobrem requisições que passam pelo domínio do site; hoje o navegador chama o Supabase diretamente, então essas regras não limitam os pedidos ao banco/Auth.

Mantenha RLS ativa e valide autorização, tamanho e frequência de cada operação no banco. Configure limites de autenticação no Supabase e acompanhe erros, conexões, uso de banco e armazenamento nos painéis dos provedores. O app não contém segredo privilegiado; a chave publicável do Supabase não substitui RLS.

A migração `supabase/migrations/202611040001_authenticated_submission_limits.sql` acrescenta limites por conta no próprio banco: 4 publicações no Feed por hora, 5 relatos da cidade por 24 horas, 4 avisos de animais por 24 horas, 8 anúncios por 24 horas e 3 pedidos sociais/parceiros por 24 horas. Ela impede repetições rápidas feitas pela mesma conta e devolve uma mensagem amigável no app. Não impede ataques distribuídos nem criação de várias contas; a proteção de login, os alertas do provedor e a mitigação DDoS continuam necessários. A migração precisa ser aplicada ao Supabase para entrar em vigor.

## Fila de alta demanda

Ainda não há uma fila de espera para visitantes nem fila de processamento ligada aos envios. Uma fila durável de tarefas e uma sala de espera de visitantes resolvem problemas diferentes:

1. Para tarefas demoradas (notificações, processamento de mídia e integrações), a arquitetura recomendada é validar o envio em uma função confiável, gravar o registro e enfileirar o trabalho na mesma transação; um worker consome a fila com idempotência e tentativas limitadas. Supabase Queues/PGMQ pode atender esse padrão, mas requer ativação, permissões/RLS, consumidores e monitoramento. Não exponha operações de leitura/remoção da fila aos usuários do app.
2. Para controlar quantas pessoas entram durante um pico, use uma sala de espera/controle de tráfego na borda ou um provedor de waiting room. O app atual não tem essa camada.
3. Para crescimento sustentado, revise o plano e os limites de Netlify/Supabase, paginação, consultas e mídia. Faça teste de carga com limites autorizados antes de campanhas públicas; não teste contra produção sem janela e autorização definidas.

O app hoje envia algumas operações diretamente ao Supabase com RLS e as publicações passam por moderação. Migrar operações para fila exige uma etapa de backend/Edge Functions e migrações coordenadas; não basta pôr mensagens na fila pelo navegador. Assim, as melhorias de cliente e entrega incluídas aqui não significam que uma fila de tráfego esteja ativa.

## Publicação das alterações

1. Rode `pnpm assets:generate` para produzir os ícones.
2. Rode `pnpm build` e confira o deploy log do Netlify para os cabeçalhos.
3. Para app nativo, rode `pnpm build:mobile`; abra Android Studio no Windows para Android e Xcode no Mac para iOS.
4. Antes de anunciar grande volume, configurar monitoramento, testar login/envios em aparelhos reais e decidir o serviço de waiting room e os workers de tarefas.

## Verificação de carga segura

O script `scripts/smoke-load.mjs` só aceita localhost ou Netlify Deploy Preview/branch deploy, limita a 20 conexões e 30 segundos e faz apenas GET da página e do manifest. Exemplo local: `pnpm load:smoke -- http://localhost:3000/ 8 15`. Ele não cria contas, não envia publicações e não testa capacidade do banco. Para carga de Supabase, use um ambiente separado com plano, usuários de teste, limite de requisições e janela aprovados; não aponte ferramentas de carga ao site público.

## Rotina de monitoramento

- No Netlify, consulte **Usage & billing** para créditos, requests e banda; revise logs do deploy para confirmar que os cabeçalhos desta configuração foram aceitos. Defina uma pessoa responsável pelos alertas de 50%, 75% e limite mensal.
- No Supabase, revise relatórios de Database, API, Auth e Storage: uso de CPU/memória, conexões, egress, erros 4xx/5xx, cadastros e volume de arquivos. Investigue picos e pausas antes de impulsionar divulgação.
- Faça primeiro a verificação de leitura neste preview; para envios e autenticação, valide manualmente com poucas contas de teste num projeto Supabase de staging. Guarde a hora, plano, duração, conexões e métricas para estabelecer uma capacidade real.
- Não existe um limite confiável de “usuários simultâneos” medido neste repositório. A capacidade depende da carga por usuário e dos planos/recursos atuais das contas.
