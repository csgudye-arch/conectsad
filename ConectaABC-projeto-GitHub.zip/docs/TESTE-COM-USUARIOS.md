# Conecta ABC — rodada inicial de testes

Endereço: https://conectaabc.com/. Aplicação hospedada no Netlify; autenticação, banco e arquivos no Supabase. O computador do proprietário não precisa permanecer ligado para o app público funcionar. Plano gratuito preservado.

## Orientação aos participantes

Estamos testando o Conecta ABC. Exemplos fictícios estão identificados e não são ofertas, vagas ou ocorrências reais. Publique apenas informações verdadeiras. Publicações podem aguardar análise; pedidos de serviço são privados. Acompanhe em Meus envios. Para avisar sobre um problema, use Ajuda e relatar problema no rodapé. O botão prepara um e-mail; é necessário enviá-lo no aplicativo de e-mail.

Clube de benefícios, cupons e campanhas de prêmio permanecem fechados. Pontos e indicações seguem as regras do servidor; confirmar um e-mail não substitui a validação de CPF pela equipe.

## Roteiro da equipe e dos primeiros participantes

Começar com um grupo pequeno de voluntários reais. Usar duas contas distintas, uma comum e outra de moderação. Não atribuir permissões de equipe a participantes comuns e não publicar registros falsos em produção.

1. Criar conta com e-mail, confirmar a mensagem e completar nome/cidade. Testar Google separadamente; verificar retorno a conectaabc.com. Testar recuperação de senha com o próprio titular.
2. Adicionar foto, escolher se é pública, abrir carteirinha e ler o QR em outro aparelho. Conferir a tela pública de validação.
3. Enviar uma publicação verdadeira com foto e, separadamente, vídeo compatível. Conferir estado em análise, aprovação pela equipe e leitura por outra conta. Conferir anonimato quando selecionado.
4. Publicar story verdadeiro; conferir miniatura, visualizador e desaparecimento da listagem após 24 horas. Testar vídeo em Android e iPhone.
5. Se houver necessidade real, testar anúncio/vaga, aviso de animal, relato da cidade, serviço e cadastro de empresa. Conferir aprovação, andamento, contato protegido e Meus envios.
6. Testar apoio, comentários, denúncia, salvar, compartilhar link externo e acesso pelo destinatário. Conferir que repetição de apoio não duplica pontos.
7. Conferir ranking, check-in e link próprio de indicação. Só validar uma indicação real após cadastro, e-mail confirmado e verificação pela equipe; não aprovar dados inventados.
8. A equipe deve revisar diariamente as filas e responder aos relatos recebidos em santoandredepressao@gmail.com. Anotar aparelho, tela, ação esperada e resultado, sem senhas ou documentos.

Registrar para cada etapa: data, aparelho/navegador, resultado, responsável e eventual problema. O percurso autenticado completo com duas contas é um teste de aceitação pendente, não substituído pelos testes automatizados.

## Teste integrado do banco — 09/11/2026

`node scripts/test-acceptance-db.mjs` usa a mesma instalação isolada de PGlite em `tmp/social-db-test` que o teste social. Aplica todas as migrações a um PostgreSQL vazio em memória, com estruturas mínimas para simular Auth, Storage e Vault.

Passaram os fluxos de criação de perfil e QR, envio e aprovação de feed e stories, privacidade de anexos, acompanhamento de serviços, consentimento para contato no Mercadão e em avisos de animais, etapas de relatos urbanos, pontuação, ranking e indicação. A reprodução da fila de relatos detectou que a migração de anexos retirou a leitura da fila para moderadores gerais. A migração `202611090001_restore_city_report_queue_access.sql` restaurou essa permissão no teste e manteve a fila restrita aos perfis de moderação.

O diagnóstico no Supabase de produção confirmou a diferença entre o acesso à fila e o acesso à ação de moderar. A aplicação da correção nesse ambiente depende de confirmação. Ainda falta executar o percurso pela interface com duas contas, receber e usar os links de e-mail e reproduzir vídeos em aparelhos reais.

## Verificações desta revisão — 06/11/2026

- 21 testes Vitest, 216 verificações PostgreSQL em memória, 10 testes de exclusão e 8 de mídia anônima passaram. Sem alterações em dados de produção.
- 12 consultas públicas reais ao Supabase passaram.
- TypeScript, lint dos arquivos alterados e exportação estática conferidos. Não equivale ao lint integral do legado.
- Ajuda mobile abriu, copiou relato e fechou; sem transbordamento a 390 px. Nenhum e-mail foi enviado pelo teste.
- Formulário de serviços vazio apresentou validação em português; atalhos de criação abriram. Nenhum pedido foi inserido.

## Operação durante o piloto

Monitorar uso de armazenamento, tráfego e limites no Supabase/Netlify. Stories expirados deixam de aparecer, mas seus arquivos ainda precisam de política de retenção e rotina de limpeza pela Storage API. Não há transcodificação de vídeos. Não divulgar como serviço finalizado ou prometer disponibilidade ilimitada. Antes de divulgação ampla, concluir o roteiro acima e corrigir os problemas encontrados.

Para desenvolver: `pnpm install`, `pnpm dev`. Para verificar: `pnpm typecheck`, `pnpm test`, `node scripts/test-social-db.mjs`, `node scripts/test-account-function.mjs`, `node scripts/test-public-media.mjs`, `pnpm build`. O build estático está em `out/`; nunca distribuir `.env.local`, credenciais, dumps ou dependências no ZIP de publicação.
