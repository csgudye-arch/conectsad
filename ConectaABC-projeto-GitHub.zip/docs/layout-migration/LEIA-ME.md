# Conecta ABC: migração passo a passo

Este pacote leva o visual e as novidades do protótipo **Conecta ABC** para o **app que você já tem**, sem perder o que já funciona lá.

A regra de todos os prompts é a mesma:

| Situação no seu app | O que fazer |
|---|---|
| Já existe uma página, recurso ou ideia **igual ou parecida** | **Manter a lógica e os dados**, trocar o visual pelo modelo novo e melhorar com o que o protótipo tem a mais |
| **Não existe** | **Criar**, no modelo novo |
| Existe algo que o protótipo **não tem** | **Manter**, só aplicar o visual novo |

Nada é apagado sem você confirmar.

---

## Como usar

1. **Abra o protótipo** `00-referencia/prototipo-conecta-abc.html` no navegador (dois cliques). É o alvo visual. Navegue por ele antes de começar.
2. **Anexe os arquivos de referência** na ferramenta de IA que mexe no seu app (Lovable, Cursor, Claude Code, Bolt, v0 etc.). No mínimo:
   - `00-referencia/design-tokens.md`
   - `00-referencia/mapa-de-telas.md`
   - `00-referencia/regras-de-negocio.md`
   - `00-referencia/prototipo-codigo-fonte.jsx` (código do protótipo, para a IA copiar o visual exato)
   Se a ferramenta não aceitar arquivo grande, cole só o trecho que o prompt indicar (cada prompt diz quais componentes do código-fonte usar).
3. **Rode os prompts em ordem**, de `01` a `18`, um de cada vez. Cada um está em `01-prompts/`.
4. **Ao final de cada prompt**, confira o item correspondente em `02-checklists/checklist-por-fase.md`. Só passe para o próximo quando estiver tudo certo.
5. Se algo quebrar, peça à IA: *"Desfaça a última alteração e refaça o prompt NN mantendo X funcionando"*.

> Dica: faça um backup ou um commit/versão do app antes do prompt 01 e depois de cada fase. No Lovable, cada mensagem já gera uma versão que dá pra restaurar.

---

## Ordem dos prompts

| # | Prompt | O que entrega |
|---|---|---|
| 01 | Auditoria e mapa | Inventário do seu app e tabela "existe / parecido / não existe" |
| 02 | Tokens e tema | Cores, fontes, raios e espaçamentos do modelo novo |
| 03 | Layout e navegação | Barra lateral, topo com CONECTA ABC centralizado, abas do celular |
| 04 | Componentes base | Botões, abas, cards, avatar, selos, busca, toast, página |
| 05 | Início (feed) | Stories com online, painel do dia, destaques deslizando, abas Cidade/Amigos/Meu bairro, blocos no meio da rolagem |
| 06 | Posts | Reações, comentários, salvar, denunciar, ocultar, toque duplo |
| 07 | Em alta (vídeos) | Vídeos verticais estilo TikTok, só administrador publica |
| 08 | Perfil, amigos e convites | Perfil estilo rede social, amizades, link de convite, selo Embaixador |
| 09 | Gamificação | 10 níveis, metas únicas, limites diários, histórico, ranking, placar dos bairros, selo Fundador |
| 10 | Carteirinha | Frente e verso, QR de verificação, cor por nível |
| 11 | Parceiros, empresas e cupons | Guia por categoria, seguir, QR do balcão, cupons por nível com estoque |
| 12 | Classificados | Mercadão (baixou, troca, doação), imóveis (antifraude), vagas, achados (finais felizes), animais |
| 13 | Cidade e comunidade | Agenda (período, lembrete), notícias, enquetes, comunidades, Voz do Bairro |
| 14 | Explorar e engajamento | Mapa com check-in e nota, SAD Indica, sorteios, Melhores do ABC, top da semana |
| 15 | Moderação, notificações e busca | Fila de denúncias, ocultação automática, notificações, busca global |
| 16 | Utilidades, institucional e PWA | Telefones, plantão, coleta, termos, LGPD, app instalável |
| 17 | Backend e segurança | Tabelas, permissões (RLS), regras no servidor |
| 18 | Revisão final | Testes de ponta a ponta, acessibilidade, desempenho |

Se o seu app **não usa Supabase**, o prompt 17 se adapta ao banco que você usa. Se usa, recomendo rodar o 17 **logo depois do 09**, para que pontos, níveis e permissões já fiquem gravados no servidor.

---

## O que tem em cada pasta

- `00-referencia/`: protótipo, código-fonte, tokens, mapa de telas, regras de negócio e modelo de dados
- `01-prompts/`: os 18 prompts, prontos para copiar e colar
- `02-checklists/`: o que conferir ao fim de cada fase
