# Prompt 15: Moderação, notificações e busca

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: CONTROLE E DESCOBERTA

Referência no código-fonte: `TelaModeracao`, `TelaNotificacoes`, `TelaBusca`.

1. **Moderação** (só moderador/admin): números (na fila, ocultos, decididos), fila de denúncias com o conteúdo, contagem e motivo; ações **restaurar, advertir, suspender, banir, remover** e **estornar pontos**, sempre com motivo; histórico de decisões.
2. **Ocultação automática** com N denúncias de pessoas diferentes (padrão 3, configurável).
3. **Notificações**: in-app e push (Web Push). Eventos: comentário ou reação recebida, pedido de amizade, subida de nível, lembrete de evento, cupom novo de empresa seguida, resposta no SAD Indica, alertas da cidade. Ícone por tipo, lidas/não lidas, bolinha no menu.
4. **Busca global**: pessoas, empresas, comunidades, lugares, posts e anúncios, com filtros por tipo e bairro, e sugestões quando vazia.
5. **Modo administrador**: menu Mais mostra Moderação só para quem tem permissão.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Fila de moderação lista o que foi denunciado
- [ ] Restaurar devolve o conteúdo ao feed
- [ ] Notificação chega quando alguém comenta
