# Prompt 16: Utilidades, institucional, LGPD e PWA

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: SERVIÇOS E CONFORMIDADE

Referência no código-fonte: `TelaUtilidades`, `TelaInstitucional`, `TelaMais`, `TelaServicos`, `TelaProblemas`.

1. **Utilidades**: telefones de emergência com **ligar em um toque**, farmácias de plantão do dia, coleta de lixo por bairro (destacando o bairro do usuário).
2. **Mais**: grade com todos os módulos (título + descrição curta), modo administrador, reiniciar e sair.
3. **Institucional**: Sobre, Regras da comunidade, Termos de uso, Política de privacidade (LGPD) e Anuncie.
4. **LGPD**: consentimento no cadastro, **exportar meus dados** (arquivo JSON) e **excluir minha conta** (com confirmação na própria tela).
5. **PWA**: manifest com nome "Conecta ABC", ícones, cor `#000000`, tela cheia; service worker para abrir offline o básico; botão "Instalar o app" (meta +50 pontos).
6. Mantenha **Serviços** e **Problemas da cidade** do app atual, só no visual novo.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] App instala no celular com o nome Conecta ABC
- [ ] Exportar dados baixa o arquivo
- [ ] Excluir conta pede confirmação e funciona
