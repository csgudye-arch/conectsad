# Prompt 17: Backend, banco e segurança

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: SERVIDOR

Referência: `modelo-de-dados.sql` (PostgreSQL/Supabase) e `regras-de-negocio.md`.

1. **Compare** o `modelo-de-dados.sql` com as tabelas que o app já tem. Para cada tabela: já existe (só acrescentar colunas que faltam), parecida (adaptar sem perder dados) ou não existe (criar). **Me mostre o plano antes de rodar qualquer migração.**
2. Crie as migrações **sem apagar dados**. Colunas novas com valor padrão. Use soft delete (`deleted_at`).
3. **Regras no servidor**, não só na tela:
   - Pontos só entram por função do servidor, respeitando limite diário e meta única (`award_points`, `claim_goal`).
   - **Vídeos: só admin grava** (RLS).
   - Cupom confere nível mínimo e estoque e gera código único (`redeem_coupon`).
   - Ocultação automática por denúncias (trigger).
   - Relato anônimo: o autor nunca vai pro cliente (view pública sem o autor).
   - Uma denúncia, um voto e uma reação por pessoa (chaves únicas).
4. **Permissões (RLS)** em todas as tabelas novas: cada um mexe no que é seu; moderação vê ocultos; admin configura.
5. **Presença online** (Supabase Realtime Presence ou equivalente) para a bolinha verde.
6. **Uploads** com verificação de tipo e tamanho; **rate limiting** em postar, comentar e denunciar.
7. Se o app **não usa Supabase**, traduza o modelo para o banco e o backend que ele usa, mantendo as mesmas regras.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Plano de migração revisado por mim antes de rodar
- [ ] Nenhum dado antigo perdido
- [ ] Usuário comum não consegue: publicar vídeo, dar pontos a si mesmo, pegar cupom acima do nível
