# Prompt 11: Parceiros, empresas e cupons

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: ECONOMIA LOCAL

Referência no código-fonte: `TelaParceiros`, `TelaParceiro`, `QrBalcao`, `TelaEmpresas`, `TelaCupons`, constantes `CUPONS`, `EMP_CATS`.

1. **Guia de empresas** com 18 categorias (alimentação, bares e restaurantes, mercado, beleza, saúde, jurídico, contabilidade, construção, imóveis, educação, esporte, moda, pets, automotivo, tecnologia, eventos, música, serviços gerais) e botão **Seguir**.
2. **Página da empresa** estilo perfil: avatar com anel, nota, seguidores, distância, descrição, botões Seguir / Salvar / QR, benefício do associado, grade de fotos, endereço, horário, WhatsApp e Instagram. URL pública amigável e indexável (`/e/{slug}`).
3. **QR do balcão**: cartaz com a marca e o QR que leva a seguir a empresa.
4. **Empresa posta como empresa** no feed, cria cupons e vagas.
5. **Cupons**: tipo, regras, validade, estoque com "restam X" e "já pegaram", **nível mínimo** (bloqueado com cadeado e barra "faltam X pontos"), filtros Acabando / Meus cupons / categoria, **código único por usuário** com QR para o caixa validar.

Se o app já tem parceiros e cupons, **mantenha os cadastros**, acrescente `nível mínimo` (padrão configurável), estoque e código único, e troque o visual.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Cupom bloqueado mostra quanto falta
- [ ] Resgate gera código único e respeita estoque
- [ ] Parceiros antigos aparecem no guia novo
