# Prompt 07: Em alta: vídeos verticais (só admin publica)

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: VÍDEOS ESTILO TIKTOK

Referência no código-fonte: `TelaEmAlta`, `Clip`, `EmAltaCarrossel`, opção `video` dentro de `Criar`.

1. **Tela Em alta**: vídeos em tela cheia, rolagem vertical que **encaixa** um por vez (`scroll-snap`). No topo, "Em alta no ABC". O vídeo visível toca; os outros pausam.
2. **Ações na lateral direita** (no computador, ao lado do vídeo): avatar da conta oficial com selo, curtir (vermelho `#FE2C55`, toque duplo também curte), comentários, salvar, enviar e disco de música girando.
3. **Embaixo**: `@conectaabc` + selo verificado + etiqueta "Oficial", "com @parceiro" quando houver menção, legenda, "som original", **botão de destino** (Ver evento, Pegar cupom, Ajudar, Ler notícia...) e barra de progresso.
4. **Carrossel "Em alta no ABC"** no feed (cards 9:16 com visualizações).
5. **Só administrador publica.** No Criar, a opção "Vídeo no Em alta" aparece com cadeado pra quem não é admin. Para admin: formulário com envio do arquivo de vídeo, legenda, etiqueta, destino do botão e prévia 9:16, publicando como @conectaabc.
6. Armazene o arquivo de vídeo no storage que o app usa (Supabase Storage, S3...), com limite de tamanho e tipo (mp4/webm).
7. **A permissão tem que valer no servidor** (regra de acesso / RLS: só `role = admin` grava na tabela de vídeos). Ver `modelo-de-dados.sql`, tabela `videos`.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Rolagem vertical encaixando vídeo por vídeo
- [ ] Usuário comum não consegue publicar vídeo (nem pela tela, nem chamando a API)
- [ ] Admin publica e o vídeo aparece primeiro
