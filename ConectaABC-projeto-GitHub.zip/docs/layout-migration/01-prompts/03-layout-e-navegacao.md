# Prompt 03: Layout, topo CONECTA ABC e navegação

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: ESTRUTURA DA TELA E NAVEGAÇÃO

Referência no código-fonte: componentes `App` (parte do `return`), `Wordmark`, `ConectaMarca`, constante `SIDE`.

1. **Marca:** nome **CONECTA ABC** (20px, peso 800, espaçamento .06em, "ABC" em amarelo) e o símbolo de dois anéis num quadrado amarelo (`ConectaMarca`). Atualize o `<title>` e o ícone do app.
2. **Celular (< 768px):**
   - Topo de 52px, preto, borda inferior: **Criar** à esquerda, **CONECTA ABC centralizado**, **Notificações** (com bolinha vermelha de não lidas) e **Menu** à direita.
   - Barra inferior de 50px: **Início, Explorar, Criar (+), Em alta, Perfil** (o perfil é o avatar). Ícone ativo mais grosso/preenchido.
   - Respeite as áreas seguras do aparelho (`env(safe-area-inset-*)`).
3. **Tablet (768–1279px):** barra lateral fixa de 72px só com ícones.
4. **Computador (≥ 1280px):** barra lateral de 244px com ícone + nome dos itens: Página inicial, Pesquisa, Explorar, Em alta, Amigos, Cupons, Parceiros, Mercadão, Agenda, Animais, Notificações, Criar, Perfil e, embaixo, Mais. No topo da área de conteúdo, faixa fina de 56px com **CONECTA ABC centralizado**.
5. **Coluna direita** (só no início, ≥ 1280px): perfil resumido, card SAD Pontua com check-in, próximos eventos, comunidades sugeridas, disputa dos bairros, rodapé com links. (Pode deixar os dados de exemplo e ligar de verdade nos prompts seguintes.)
6. **Mapeie as rotas que o app já tem** para esses itens. Se uma rota do app tem outro nome, mantenha a rota e só aponte o item de menu para ela. Páginas do app que não cabem no menu principal vão para a tela **Mais**.
7. Na área **Em alta**, o topo do celular some (tela cheia).

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] CONECTA ABC centralizado no topo no celular e no computador
- [ ] Barra inferior com 5 itens no celular
- [ ] Barra lateral no tablet (ícones) e no computador (ícones + nomes)
- [ ] Todas as páginas antigas continuam acessíveis (pelo menu ou pela tela Mais)
