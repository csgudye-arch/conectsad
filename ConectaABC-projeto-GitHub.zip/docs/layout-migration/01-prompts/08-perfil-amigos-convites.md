# Prompt 08: Perfil, amigos e convites

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: PERFIL E REDE

Referência no código-fonte: `TelaPerfil`, `TelaAmigos`, `TelaConvidar`, `TelaEntrar`.

1. **Perfil** estilo rede social: avatar grande com anel, @usuário + verificado + selo ADM (se admin), contadores (posts, pontos, nível), nome, bairro, bio **editável**, selos (Fundador, Embaixador), barra de progresso do nível, botões Editar perfil e Carteirinha, **destaques** (Carteirinha, Meu nível, Amigos, Convidar, Salvos, Cupons, Menu) e abas **Posts / Salvos / Cupons** em grade.
2. **Perfil público** em `/u/{usuario}` (só leitura, com botão Adicionar).
3. **Amigos**: abas Sugestões ("talvez você conheça", priorizando o mesmo bairro e amigos em comum), Pedidos (aceitar/recusar) e Meus amigos; busca de pessoas; bolinha verde de online.
4. **Convidar amigos**: link único `/c/{usuario}`, copiar, botão de WhatsApp com mensagem pronta, **imagem para story** (carteirinha + QR do convite), regras (+100 pra quem convida e +30 pro convidado, só conta com perfil completo e foto), progresso até o selo **Embaixador** (10) e ranking mensal de convites.
5. Se o app já tem perfil, **mantenha os campos atuais** e acrescente os que faltam (bio, capa, bairro).

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Perfil com contadores, selos, destaques e abas
- [ ] Pedido de amizade: enviar, aceitar, recusar
- [ ] Link de convite copia e abre o WhatsApp
