# Prompt 14: Mapa, SAD Indica, sorteios, Melhores do ABC e top da semana

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: EXPLORAR E ENGAJAR

Referência no código-fonte: `MapaBloco`, `TelaMapa`, `TelaExplorar`, `TelaIndica`, `TelaSorteios`, `SorteioBloco`, `TelaPremio`, `TelaTop`, `TopSemanaBloco`.

1. **Mapa**: use um mapa real (Leaflet/OpenStreetMap ou Google Maps) com pinos por tipo (comer e beber, comércios, praças e parques, esporte, cultura, saúde e serviços, religião), filtros "perto de mim" e "abertos agora"; ao tocar num lugar: **check-in** (+10, limite diário) e **nota de 1 a 5** com comentário (+15, limite diário); **título de explorador** por lugares visitados; **sugerir lugar** (vai para moderação).
2. **Explorar**: grade de imagens de tudo (parceiros, eventos, produtos, animais, notícias) e atalhos por área.
3. **SAD Indica**: pedir indicação com categoria; vizinhos indicam empresas cadastradas; **o dono não pode indicar a própria empresa**; quem pediu marca **"essa resolveu"**; abas Pedidos e Ranking.
4. **Sorteios**: prêmio, parceiro, regras, prazo, participar grátis, estado vazio "Nenhum sorteio no momento".
5. **Melhores do ABC** (prêmio anual): fases indicação → votação → apuração → resultado; um voto por categoria.
6. **Top da semana**: 5 posts com mais reações + comentários nos últimos 7 dias.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Check-in e nota pontuam e respeitam o limite diário
- [ ] Dono não consegue indicar a própria empresa
- [ ] Top da semana atualiza sozinho
