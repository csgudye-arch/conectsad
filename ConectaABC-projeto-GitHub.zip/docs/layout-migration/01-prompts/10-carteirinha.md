# Prompt 10: Carteirinha digital

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: CARTEIRINHA

Referência no código-fonte: `TelaCarteirinha`, `faixaCarteirinha`, CSS `.flip-cena`, `.flip-carta`, `.flip-face`, `.flip-verso`.

1. **Frente**: marca, faixa (Ouro, Prata, Ouro negro ou Lenda conforme o nível), foto ou iniciais, nome, @usuário, número sequencial, bairro, nível, pontos, "membro desde", validade e selos.
2. **Verso**: QR que abre uma **página pública de verificação de autenticidade** (`/v/{numero}`, mostra nome, nível e se está ativo).
3. **Vira com um toque** (animação 3D de 600ms; sem animação com movimento reduzido).
4. **A cor muda por faixa de nível**: 1–3 ouro, 4–6 prata, 7–9 ouro negro, 10 lenda.
5. Compartilhar como imagem.
6. Abaixo: assinatura, nível e metas, cupons resgatados, histórico de pagamentos.

Se a carteirinha já existe no app, **mantenha número, QR e regras atuais** e acrescente verso, faixas e animação.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Carteirinha vira e o verso tem o QR
- [ ] A página de verificação abre pelo QR
- [ ] A cor muda quando o nível muda
