# Prompt 05: Página inicial (feed)

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: INÍCIO

Referência no código-fonte: `TelaFeed`, `StoriesRow`, `StoryViewer`, `PainelDoDia`, `CampanhaFundador`, `DestaquesRotativos`, `ItemFeed`, `EmAltaCarrossel`, `ExploreBloco`, `SugestoesAmigos`, `RankingBloco`, `TopSemanaBloco`, `PlacarBloco`, `SorteioBloco`, `ComunidadesBloco`, `VozBloco`, `EnqueteBloco`. Ordem dos blocos em `mapa-de-telas.md`.

Se o app já tem uma página inicial/dashboard, **transforme ela neste feed**, levando junto o que ela já mostra (em forma de bloco).

De cima pra baixo:
1. **Stories**: "Seu story" (avatar com +) e bolinhas com anel dourado. **Quem está online tem uma bolinha verde pequena.** Tocar abre o visualizador: barras de progresso, passa sozinho a cada 5s, pausar, tocar nos lados pra voltar/avançar, botão de ação (ex.: "Ver evento").
2. **Painel do dia**: "Bom dia/Boa tarde/Boa noite, {nome}", data por extenso, clima; botões **Postar algo** e **Meu bairro · {bairro}**; resumo "X posts novos · Y eventos nos próximos 30 dias".
3. **Campanha Fundador** (enquanto não tiver o selo): checklist de 5 passos, barra de progresso, contagem de dias.
4. **Destaques que deslizam pro lado sozinhos** a cada 4s: alternam notícias da cidade, evento, animal perdido, cupom e alerta. Bolinhas embaixo, arrastar com o dedo no celular, setas no computador, pausa com o mouse em cima.
5. Caixa **"No que você está pensando, {nome}?"** que abre o Criar.
6. **Abas fixas** ao rolar: **Cidade · Amigos · Meu bairro**. Amigos = só posts de amigos. Meu bairro = tudo do bairro do usuário.
7. **Feed misto** que se reveza entre post, notícia, evento, animal, parceiro, produto e vaga (ciclo em `mapa-de-telas.md`), cada tipo com o card e o botão de ação dele.
8. **Blocos no meio da rolagem** (só na aba Cidade): Em alta, Explore Santo André, Talvez você conheça, enquete, Ranking dos membros, Top da semana, Placar dos bairros, Sorteio, Comunidades, Voz do Bairro.
9. Fim: "Você está em dia".

Use os dados reais do app onde existirem (posts, eventos, parceiros...). Blocos de recursos que ainda não existem podem ficar com dados de exemplo até o prompt correspondente.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Stories com bolinha verde em quem está online
- [ ] Destaques deslizando sozinhos e com o dedo
- [ ] Abas Cidade / Amigos / Meu bairro filtrando
- [ ] Feed alternando os tipos de conteúdo, com os blocos no meio
- [ ] O que a página inicial antiga mostrava continua aparecendo
