# Prompt 04: Componentes base

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: BIBLIOTECA DE COMPONENTES

Referência no código-fonte: `Btn`, `Tabs`, `Busca`, `Pill`, `Avatar`, `Verificado`, `Campo`, `inputCls`, `Vazio`, `Pagina`, `Linha`, `Ph`, `PostCabecalho`, `CardFeed`, `BlocoBox`.

Crie (ou adapte os equivalentes que o app já tem) estes componentes no visual novo, e passe a usá-los nas telas existentes:

| Componente | Como é |
|---|---|
| Botão | variantes: principal (amarelo), secundário (cinza `#262626`), sucesso, WhatsApp, link; altura 36px; raio 8px; estado desabilitado |
| Abas/filtros | pílulas `#1A1A1A`; a ativa fica branca com texto preto |
| Busca | campo `#1A1A1A` com lupa e botão de limpar |
| Selo (pill) | 11px, raio 6px; cores neutro, amarelo, sucesso, perigo, info |
| Avatar | iniciais ou foto; variante com **anel de story** (degradê dourado; cinza se visto); variante com **bolinha verde de online** (11px, borda preta, canto inferior direito) |
| Verificado | selo amarelo ao lado do nome |
| Campo | 44px, fundo `#121212`, borda `#262626`, foco amarelo, rótulo acima |
| Estado vazio | ícone em círculo + texto curto + ação opcional |
| Página | cabeçalho com voltar ou ícone amarelo, título 22–24px, subtítulo e ação à direita; larguras 630px (comum) e 935px (grade) |
| Linha de lista | ícone, título, subtítulo, valor à direita, seta |
| Card de feed | sem borda no celular (separado por linha), com borda e raio no computador |
| Bloco do feed | card com título + ícone amarelo + link "Ver todos" |
| Toast | barra clara no rodapé, some em 2,4s |

Substitua, nas telas que já existem, botões, abas, campos e listas antigos por esses componentes. Não mude o que cada tela faz.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Os componentes existem num lugar só e são reaproveitados
- [ ] As telas antigas já usam os botões, campos e abas novos
- [ ] Avatar com anel e com bolinha de online funcionando
