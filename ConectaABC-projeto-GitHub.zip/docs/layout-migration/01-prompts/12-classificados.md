# Prompt 12: Mercadão, imóveis, vagas, achados e animais

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: CLASSIFICADOS

Referência no código-fonte: `TelaMercadao`, `TelaProduto`, `Baixou`, `TelaImoveis`, `TelaVagas`, `TelaAchados`, `TelaAnimais`, `TelaAnimal`, `TelaCadastrarAnimal`.

1. **Mercadão** (classificados de usados): grade de fotos quadradas, preço, selo **"Baixou X%"** com preço antigo riscado, **"Aceita troca"**, **doação** (preço "Grátis"), estado (novo/seminovo/usado), filtros de categoria e bairro, ordenação, página do anúncio com botão de WhatsApp e vendedor.
2. **Imóveis**: aviso fixo **"Nunca pague sinal antes de visitar o imóvel. O Conecta ABC não intermedeia pagamentos."**; tipo, preço, condomínio, área, quartos, banheiros, vagas; filtros aluguel/venda, tipo, quartos, preço; ordenação.
3. **Vagas**: cargo, empresa, contrato (CLT, PJ, estágio, temporário, freelancer, meio período, aprendiz), modelo (presencial, híbrido, remoto), salário, bairro, candidatar.
4. **Achados e perdidos**: Perdi/Achei, categorias (documento, carteira, chave, celular, pet, bolsa, óculos, bicicleta, outro), local, bairro, data, foto, contato, botão **Resolvido** e seção **Finais felizes**.
5. **Animais perdidos**: grade com status (Perdido, Encontrado, Buscando tutor), página do animal, cadastro em 3 passos.

Mantenha os anúncios que já existem. Só acrescente os campos novos (`preço antigo`, `aceita troca`, `doação`, `resolvido`...).

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Baixar o preço de um anúncio mostra o selo "Baixou"
- [ ] Aviso antifraude fixo em imóveis
- [ ] Item marcado como resolvido vai para Finais felizes
