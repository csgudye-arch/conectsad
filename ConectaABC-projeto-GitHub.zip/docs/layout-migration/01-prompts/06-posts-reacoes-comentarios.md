# Prompt 06: Posts, reações, comentários e denúncia

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: INTERAÇÃO NOS POSTS

Referência no código-fonte: `PostFeed`, `Comentarios`, `Criar`, constante `REACOES`.

1. **Cabeçalho do post**: avatar (com anel se for parceiro), nome, selo verificado para empresa, bairro e tempo, botão "…".
2. **Conteúdo**: imagem quadrada (4:3 no computador) ou, se for só texto, cartão com texto grande sobre fundo escuro com degradê dourado.
3. **Toque duplo** curte e mostra um coração grande animado.
4. **Ações**: curtir (coração vermelho `#ED4956`), **escolher reação** (👍 💛 🔥 😂 😮 😢, configurável), comentar, compartilhar, salvar.
5. Linha de resumo: as reações mais usadas + total, "Ver todos os N comentários".
6. **Comentários** em folha que sobe de baixo (celular) ou janela (computador), com campo pra comentar como @usuário.
7. **Menu "…"**: Denunciar, Não quero ver isso, Copiar link.
8. **Denúncia**: uma por pessoa. Com **3 denúncias de pessoas diferentes**, o post vira "Publicação ocultada após denúncias. Em análise pela moderação." até o moderador decidir (fila no prompt 15).
9. **Criar (+)**: folha com Publicação, Anúncio no Mercadão, Enquete, Animal perdido/achado, Problema da cidade e Vídeo (com cadeado para quem não é admin; prompt 07).
10. Selo de nível ao lado do nome do autor (ex.: "Nv 4").

Se o app já tem curtidas e comentários, **mantenha os dados** e migre curtida para "reação 👍/coração" sem perder contagem.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Reações escolhidas ficam salvas e aparecem no resumo
- [ ] Comentários abrem e salvam
- [ ] Denunciar 3 vezes (contas diferentes) oculta o post
- [ ] Curtidas antigas continuam contando
