# Prompt 18: Revisão final

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: REVISÃO

1. **Percorra todas as telas** do `mapa-de-telas.md` e as que só existem no app, no celular (390px) e no computador (1440px). Liste o que estiver quebrado, cortado, ilegível ou fora do visual novo, e corrija.
2. **Fluxos de ponta a ponta**:
   - cadastro → completar perfil → primeiro post → ganhar pontos → subir de nível
   - convidar amigo → amigo completa perfil → +100 / +30
   - pegar cupom → código único → validar
   - denunciar 3 vezes → oculta → moderador restaura
   - admin publica vídeo → aparece no Em alta; usuário comum não consegue
3. **Acessibilidade (WCAG AA)**: contraste, navegação por teclado com foco visível, textos alternativos, rótulos em botões de ícone.
4. **Desempenho**: imagens otimizadas, paginação por cursor no feed, cache de ranking e placar.
5. **SEO**: páginas públicas de empresas, lugares, notícias e anúncios com URL amigável e metadados (título, descrição, imagem de compartilhamento).
6. Atualize o `MIGRACAO-CONECTA-ABC.md` com o resultado final: o que foi adaptado, criado, mantido e o que ficou pendente.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Todos os fluxos de ponta a ponta passaram
- [ ] Nenhuma tela quebrada no celular nem no computador
- [ ] Relatório final atualizado
