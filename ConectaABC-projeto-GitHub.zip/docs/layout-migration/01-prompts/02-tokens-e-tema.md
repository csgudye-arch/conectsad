# Prompt 02: Tokens de design e tema escuro

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: TEMA

Aplique os tokens de `design-tokens.md` no app inteiro:

1. Crie (ou adapte, se já existir um arquivo de tema) as variáveis de cor, fonte, raio e espaçamento. Se o app usa Tailwind, estenda o `tailwind.config` com os nomes do arquivo de tokens. Se usa CSS, crie as variáveis em `:root`.
2. Fundo preto `#000000`, texto `#F5F5F5`, destaque amarelo `#FFC107` com texto escuro por cima. Bordas finas `#262626` no lugar de sombras pesadas.
3. Fonte **Inter** (400 a 800) com fallback de sistema. Números com `tabular-nums` em contadores, preços e pontos.
4. Se o app tinha tema claro ou outras cores: troque as cores **fixas** espalhadas pelo código por referências aos tokens. Não troque cores que fazem parte de imagens ou logos de parceiros.
5. Acrescente `prefers-reduced-motion` desligando animações.
6. Ainda **não** mude layout nem componentes: só cores, fonte e formas.

Liste os arquivos que tinham cores fixas e foram trocados.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] App inteiro no fundo preto com destaque amarelo
- [ ] Fonte Inter carregando
- [ ] Nenhuma tela ficou com texto ilegível (preto no preto, branco no amarelo)
- [ ] Nada mudou de lugar
