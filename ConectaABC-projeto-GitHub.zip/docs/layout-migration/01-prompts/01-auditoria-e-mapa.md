# Prompt 01: Auditoria do app e mapa da migração

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: AUDITORIA (não altere nenhum arquivo ainda)

Analise o meu app inteiro e me entregue:

1. **Stack e estrutura:** framework, roteamento, estilização (Tailwind? CSS? biblioteca de componentes?), banco de dados e autenticação.
2. **Inventário:** lista de todas as páginas/rotas, componentes principais, tabelas do banco e recursos (login, pontos, cupons etc.).
3. **Tabela de mapeamento**, uma linha para cada tela de `mapa-de-telas.md`:

| Tela do Conecta ABC | O que existe no meu app | Situação | Ação |
|---|---|---|---|
| ex.: Carteirinha | `/minha-carteirinha` com QR | Parecido | Adaptar visual + frente/verso + cor por nível |

   Situação deve ser **Igual**, **Parecido** ou **Não existe**. Inclua também, no fim, as páginas do meu app que **não têm** equivalente no protótipo (situação: **Só no app**, ação: manter e aplicar visual).
4. **Riscos:** o que pode quebrar (rotas que mudam de nome, dados que precisam de migração, permissões).
5. **Plano:** confirme a ordem dos próximos prompts (02 a 18) ou sugira ajustes pro meu caso.

Salve essa análise num arquivo `MIGRACAO-CONECTA-ABC.md` na raiz do projeto, para usarmos como guia nas próximas etapas. Atualize esse arquivo ao fim de cada etapa.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Recebi a tabela com todas as telas do protótipo classificadas
- [ ] Recebi a lista do que só existe no meu app
- [ ] O arquivo `MIGRACAO-CONECTA-ABC.md` foi criado
- [ ] Nenhum arquivo do app foi alterado
