# Prompt 13: Agenda, notícias, enquetes, comunidades e Voz do Bairro

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: CIDADE E COMUNIDADE

Referência no código-fonte: `TelaAgenda`, `TelaEvento`, `TelaNoticias`, `TelaNoticia`, `TelaEnquetes`, `EnqueteBloco`, `TelaComunidades`, `TelaComunidade`, `TelaVoz`.

1. **Agenda**: filtros de **período** (hoje, fim de semana, 7 dias, 30 dias), categoria e bairro; card com data em destaque; **Eu vou** com contagem; **lembrete** (sino) com notificação 1 dia antes; usuários podem sugerir evento (vai para moderação).
2. **Notícias**: lista com fonte e data, filtros (cidade, eventos, comércio, esporte, cultura, serviço, curiosidades, oficial, alerta). Preparar importação por RSS/API com curadoria no admin.
3. **Enquetes**: qualquer usuário cria (pergunta, 2+ opções, data de encerramento); um voto por pessoa; resultado na hora com barras; abas Ativas / Encerradas / Minhas.
4. **Comunidades**: categorias (bairro, esporte, pets, família, cultura, negócios, games, fé, outros); entrar é livre; **criar exige nível 3** (configurável); feed próprio.
5. **Voz do Bairro** (relatos): tipos história, elogio, reclamação e denúncia; **publicar como anônimo** (o autor fica oculto pros usuários e visível pra moderação); apoiar, comentar, denunciar.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Filtro "Fim de semana" e lembrete funcionando
- [ ] Um voto por pessoa nas enquetes
- [ ] Relato anônimo não mostra o autor (só a moderação vê)
