# Prompt 09: Gamificação: níveis, metas, ranking e placar

> **Como usar:** copie tudo a partir de "PROMPT" e cole na sua ferramenta de IA. Anexe (ou já tenha anexado) os arquivos de `00-referencia/`. Rode só depois de terminar o prompt anterior.

---

## PROMPT

Estou migrando o meu app para o novo modelo visual e de recursos chamado **Conecta ABC**. Anexei os arquivos de referência: `design-tokens.md`, `mapa-de-telas.md`, `regras-de-negocio.md`, `prototipo-codigo-fonte.jsx` e o protótipo `prototipo-conecta-abc.html`.

**Regras desta migração (valem para tudo abaixo):**
1. O que já existe no meu app e é **igual ou parecido** com o protótipo: **mantenha a lógica, os dados e as rotas**, troque o visual pelo modelo novo e acrescente o que o protótipo tem a mais.
2. O que **não existe**: crie no modelo novo.
3. O que existe no meu app e o protótipo **não tem**: mantenha, só aplique o visual novo.
4. **Não apague** páginas, tabelas, campos ou dados sem me perguntar antes.
5. Use a stack, o roteamento, o banco e os componentes que o app **já usa**. O protótipo é referência de visual e comportamento, não código pra colar inteiro.
6. Os dados do protótipo são de exemplo. Onde o meu app já tem dados reais, use os reais.
7. Ao terminar, me mostre: o que foi **adaptado**, o que foi **criado**, o que ficou **igual**, e qualquer coisa que você **não conseguiu** fazer.

### Tarefa desta etapa: PONTOS

Referência no código-fonte: `TelaNivel`, `TelaPontua`, `RankingBloco`, `PlacarBloco`, `TelaPlacar`, `CampanhaFundador`, constantes `NIVEIS`, `METAS_UNICAS`, `LIMITES`, `FUNDADOR`. Regras completas em `regras-de-negocio.md`.

1. **Livro de pontos** como fonte única: toda pontuação vira um registro (quem, quanto, ação, quando). Nível, ranking e placar são **calculados**, nunca editados à mão.
2. **10 níveis** (Novato → Lenda do ABC). Subir de nível dispara aviso na tela e notificação.
3. **Metas únicas** (pagam uma vez) com botão Resgatar quando cumpridas e Fazer quando não.
4. **Ações com limite diário**; passou do limite, a ação funciona mas não pontua, e o usuário vê o aviso.
5. **Tela Meu nível**: nível atual e quanto falta, atalhos (carteirinha, cupons, ranking, convidar), metas, "Pontos de hoje" com limite de cada ação, histórico "Últimos pontos".
6. **Ranking da temporada** com pódio dos 3 primeiros e a posição do usuário.
7. **Placar dos bairros**: posição, moradores, posts no mês, pontos; botões **Chamar vizinhos** (WhatsApp) e **Postar no story**.
8. **Selo Fundador** por campanha com data-limite configurável; **Embaixador** com 10 convites.
9. **Temporadas**: ranking e placar zeram por temporada; nível e selos não.

**Se o app já tem um sistema de pontos/XP (ex.: SAD Pontua):** não crie outro. Migre o saldo atual de cada usuário para o livro de pontos como um lançamento inicial ("saldo anterior"), mapeie os níveis antigos para os 10 novos e me mostre a tabela de conversão antes de aplicar.

Recomendo rodar o **prompt 17 logo depois deste**, para levar essas regras ao servidor.

**Critérios de aceite desta etapa** (me confirme cada um ao terminar):
- [ ] Saldo de pontos antigo preservado
- [ ] Limite diário bloqueando pontos extras
- [ ] Meta só paga uma vez
- [ ] Ranking e placar calculados a partir dos pontos
