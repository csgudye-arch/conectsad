-- =====================================================================
-- Conecta ABC: modelo de dados de referência (PostgreSQL / Supabase)
-- ---------------------------------------------------------------------
-- É um PONTO DE PARTIDA. O prompt 17 pede pra IA comparar com as tabelas
-- que você já tem e só criar o que falta, sem apagar dados.
-- Não rode este arquivo inteiro num banco que já tem tabelas com esses nomes.
-- =====================================================================

-- ---------- Bairros e configurações ----------
create table if not exists neighborhoods (
  id serial primary key,
  name text not null unique,
  city text not null default 'Santo André',
  active boolean not null default true
);

create table if not exists admin_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
-- exemplos: ('fundador_deadline','"2026-11-30"'), ('report_threshold','3'), ('coupon_default_min_level','10')

-- ---------- Perfis ----------
create type user_role as enum ('morador', 'moderador', 'admin');

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  full_name text not null,
  bio text,
  avatar_url text,
  cover_url text,
  neighborhood_id int references neighborhoods(id),
  role user_role not null default 'morador',
  member_number bigserial unique,
  invited_by uuid references profiles(id),
  pwa_installed boolean not null default false,
  push_enabled boolean not null default false,
  created_at timestamptz not null default now(),
  deleted_at timestamptz
);

-- ---------- Gamificação: o livro de pontos é a fonte da verdade ----------
create table if not exists levels (
  level int primary key,            -- 1 a 10
  title text not null,
  min_points int not null
);
insert into levels values
 (1,'Novato',0),(2,'Vizinho',100),(3,'Participante',250),(4,'Ativo',500),(5,'Destaque',800),
 (6,'Referência',1200),(7,'Influente',1700),(8,'Líder',2300),(9,'Embaixador',3000),(10,'Lenda do ABC',4000)
on conflict do nothing;

create table if not exists point_rules (      -- ações recorrentes com limite diário
  action text primary key,                    -- 'post','comment','checkin','review','recommend','recommend_solved','friendship','invite',...
  points int not null,
  daily_cap int not null
);

create table if not exists goals (             -- metas únicas
  id text primary key,                         -- 'perfil','foto','capa','post1',...
  title text not null,
  points int not null,
  active boolean not null default true
);

create table if not exists user_goals (
  user_id uuid references profiles(id) on delete cascade,
  goal_id text references goals(id),
  claimed_at timestamptz not null default now(),
  primary key (user_id, goal_id)
);

create table if not exists seasons (
  id serial primary key,
  name text not null,                          -- 'Novembro 2026'
  starts_at date not null,
  ends_at date not null,
  closed boolean not null default false
);

create table if not exists points_ledger (     -- log imutável (sem update/delete pelo app)
  id bigserial primary key,
  user_id uuid not null references profiles(id),
  points int not null,                         -- pode ser negativo (estorno da moderação)
  action text not null,                        -- regra ou meta que gerou
  ref_id text,                                 -- id do post, lugar, etc.
  season_id int references seasons(id),
  created_at timestamptz not null default now()
);
create index on points_ledger (user_id, created_at);

-- Pontos e nível são VIEWS, nunca colunas editáveis
create or replace view user_points as
  select p.id as user_id, coalesce(sum(l.points),0)::int as points
  from profiles p left join points_ledger l on l.user_id = p.id
  group by p.id;

create or replace view user_levels as
  select up.user_id, up.points,
    (select max(level) from levels where min_points <= up.points) as level
  from user_points up;

create table if not exists badges (id text primary key, title text not null);          -- 'fundador','embaixador','nivel_max'
create table if not exists user_badges (
  user_id uuid references profiles(id) on delete cascade,
  badge_id text references badges(id),
  granted_at timestamptz not null default now(),
  primary key (user_id, badge_id)
);

-- ---------- Social ----------
create table if not exists friendships (
  requester uuid references profiles(id) on delete cascade,
  addressee uuid references profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined')),
  created_at timestamptz not null default now(),
  primary key (requester, addressee)
);

create table if not exists invites (
  inviter uuid references profiles(id),
  invitee uuid references profiles(id) unique,
  counted boolean not null default false,       -- vira true quando o convidado completa perfil com foto
  created_at timestamptz not null default now()
);

create table if not exists businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id),
  slug text unique not null,
  name text not null,
  category text not null,
  neighborhood_id int references neighborhoods(id),
  description text, address text, hours text, whatsapp text, instagram text, logo_url text,
  verified boolean not null default false,
  created_at timestamptz not null default now(),
  deleted_at timestamptz
);
create table if not exists business_followers (
  business_id uuid references businesses(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (business_id, user_id)
);

create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references profiles(id),
  business_id uuid references businesses(id),     -- preenchido quando posta como empresa
  community_id uuid,                               -- post dentro de comunidade
  neighborhood_id int references neighborhoods(id),
  body text not null,
  images text[] not null default '{}',
  hidden boolean not null default false,          -- ocultação automática por denúncias
  created_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists reactions (            -- 👍 💛 🔥 😂 😮 😢 (configurável)
  post_id uuid references posts(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  emoji text not null,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references posts(id) on delete cascade,
  author_id uuid not null references profiles(id),
  body text not null,
  hidden boolean not null default false,
  created_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists saved_items (
  user_id uuid references profiles(id) on delete cascade,
  item_type text not null,                         -- 'post','business','marketplace','pet',...
  item_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, item_type, item_id)
);

-- ---------- Em alta (vídeos): só admin publica ----------
create table if not exists videos (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references profiles(id),  -- sempre um admin
  video_url text not null,
  caption text not null,
  tag text not null,                                -- Evento, Parceiro, Notícia, ...
  mention text,                                     -- @parceiro mencionado
  cta_label text, cta_route text,
  created_at timestamptz not null default now(),
  deleted_at timestamptz
);
create table if not exists video_likes (
  video_id uuid references videos(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (video_id, user_id)
);

-- ---------- Comunidade e cidade ----------
create table if not exists communities (
  id uuid primary key default gen_random_uuid(),
  name text not null, category text not null, description text,
  created_by uuid references profiles(id), created_at timestamptz not null default now(), deleted_at timestamptz
);
create table if not exists community_members (
  community_id uuid references communities(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (community_id, user_id)
);

create table if not exists polls (
  id uuid primary key default gen_random_uuid(),
  author_id uuid references profiles(id), question text not null, closes_at timestamptz not null,
  created_at timestamptz not null default now()
);
create table if not exists poll_options (id serial primary key, poll_id uuid references polls(id) on delete cascade, label text not null);
create table if not exists poll_votes (
  poll_id uuid references polls(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  option_id int references poll_options(id),
  primary key (poll_id, user_id)                   -- um voto por pessoa
);

create table if not exists voice_reports (         -- Voz do Bairro
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references profiles(id), -- sempre gravado; anonimato é só na exibição
  kind text not null check (kind in ('historia','elogio','reclamacao','denuncia')),
  anonymous boolean not null default false,
  body text not null, neighborhood_id int references neighborhoods(id),
  hidden boolean not null default false, created_at timestamptz not null default now(), deleted_at timestamptz
);

create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  title text not null, kind text not null, starts_at timestamptz not null, place text not null,
  neighborhood_id int references neighborhoods(id), price numeric, image_url text,
  created_by uuid references profiles(id), approved boolean not null default false, created_at timestamptz not null default now()
);
create table if not exists event_attendees (
  event_id uuid references events(id) on delete cascade, user_id uuid references profiles(id) on delete cascade,
  remind boolean not null default false, primary key (event_id, user_id)
);

create table if not exists news_items (
  id uuid primary key default gen_random_uuid(), source text not null, url text, title text not null, summary text,
  category text not null, published_at timestamptz not null, approved boolean not null default true
);

create table if not exists places (
  id uuid primary key default gen_random_uuid(), name text not null, category text not null,
  lat double precision, lng double precision, neighborhood_id int references neighborhoods(id), approved boolean not null default false
);
create table if not exists place_reviews (place_id uuid references places(id), user_id uuid references profiles(id), stars int check (stars between 1 and 5), body text, created_at timestamptz default now(), primary key (place_id, user_id));
create table if not exists place_checkins (id bigserial primary key, place_id uuid references places(id), user_id uuid references profiles(id), created_at timestamptz default now());

-- ---------- Economia local ----------
create table if not exists coupons (
  id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses(id),
  title text not null, kind text not null, rules text, valid_until date not null,
  stock int,                                        -- null = ilimitado
  min_level int not null default 10,
  created_at timestamptz not null default now()
);
create table if not exists coupon_redemptions (
  coupon_id uuid references coupons(id), user_id uuid references profiles(id),
  code text unique not null,                        -- código único por usuário
  validated_at timestamptz, created_at timestamptz not null default now(),
  primary key (coupon_id, user_id)
);

create table if not exists jobs (
  id uuid primary key default gen_random_uuid(), title text not null, company text not null, business_id uuid references businesses(id),
  contract text not null, mode text not null, salary text, neighborhood_id int references neighborhoods(id), contact text,
  created_by uuid references profiles(id), created_at timestamptz default now(), deleted_at timestamptz
);
create table if not exists real_estate_listings (
  id uuid primary key default gen_random_uuid(), deal text check (deal in ('aluguel','venda')), kind text not null,
  price numeric not null, condo_fee numeric, area_m2 int, bedrooms int, bathrooms int, parking int,
  neighborhood_id int references neighborhoods(id), photos text[] default '{}', contact text,
  created_by uuid references profiles(id), business_id uuid references businesses(id), created_at timestamptz default now(), deleted_at timestamptz
);
create table if not exists marketplace_items (
  id uuid primary key default gen_random_uuid(), title text not null, price numeric not null default 0,
  previous_price numeric,                           -- para o selo "Baixou X%"
  condition text check (condition in ('novo','seminovo','usado')), category text not null,
  accepts_trade boolean default false, is_donation boolean default false,
  neighborhood_id int references neighborhoods(id), photos text[] default '{}',
  seller_id uuid references profiles(id), created_at timestamptz default now(), deleted_at timestamptz
);
create table if not exists lost_found_items (
  id uuid primary key default gen_random_uuid(), kind text check (kind in ('perdi','achei')), category text not null,
  title text not null, place text, neighborhood_id int references neighborhoods(id), happened_on date, description text,
  photo_url text, contact text, resolved boolean not null default false,
  created_by uuid references profiles(id), created_at timestamptz default now()
);
create table if not exists recommendation_requests (
  id uuid primary key default gen_random_uuid(), author_id uuid references profiles(id), question text not null,
  category text not null, solved_by uuid, created_at timestamptz default now()
);
create table if not exists recommendations (
  id uuid primary key default gen_random_uuid(), request_id uuid references recommendation_requests(id) on delete cascade,
  recommender_id uuid references profiles(id), business_id uuid references businesses(id), created_at timestamptz default now(),
  unique (request_id, recommender_id)
);
create table if not exists giveaways (id uuid primary key default gen_random_uuid(), title text not null, sponsor text, rules text, ends_at timestamptz not null, winner_id uuid references profiles(id));
create table if not exists giveaway_entries (giveaway_id uuid references giveaways(id), user_id uuid references profiles(id), primary key (giveaway_id, user_id));
create table if not exists awards (id uuid primary key default gen_random_uuid(), edition int not null, category text not null, phase text not null default 'indicacao');
create table if not exists award_options (id serial primary key, award_id uuid references awards(id), label text not null);
create table if not exists award_votes (award_id uuid references awards(id), user_id uuid references profiles(id), option_id int references award_options(id), primary key (award_id, user_id));

-- ---------- Moderação e notificações ----------
create table if not exists reports (
  id bigserial primary key, reporter_id uuid not null references profiles(id),
  item_type text not null, item_id text not null, reason text not null,
  created_at timestamptz not null default now(),
  unique (reporter_id, item_type, item_id)          -- uma denúncia por pessoa por item
);
create table if not exists moderation_actions (
  id bigserial primary key, moderator_id uuid references profiles(id), item_type text, item_id text,
  action text check (action in ('remover','restaurar','advertir','suspender','banir','estornar_pontos')),
  reason text not null, created_at timestamptz not null default now()
);
create table if not exists notifications (
  id bigserial primary key, user_id uuid references profiles(id) on delete cascade,
  kind text not null, payload jsonb not null default '{}', read_at timestamptz, created_at timestamptz default now()
);

-- =====================================================================
-- SEGURANÇA (RLS): exemplos das regras mais importantes
-- =====================================================================
create or replace function is_admin() returns boolean language sql stable as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;
create or replace function is_mod() returns boolean language sql stable as
$$ select exists (select 1 from profiles where id = auth.uid() and role in ('moderador','admin')) $$;

-- Vídeos: todos leem, SÓ ADMIN publica/edita/apaga
alter table videos enable row level security;
create policy videos_ler on videos for select using (deleted_at is null);
create policy videos_admin_insere on videos for insert with check (is_admin() and author_id = auth.uid());
create policy videos_admin_altera on videos for update using (is_admin());
create policy videos_admin_apaga on videos for delete using (is_admin());

-- Livro de pontos: usuário só LÊ os próprios; ninguém escreve pelo app (só funções no servidor)
alter table points_ledger enable row level security;
create policy pontos_ler_proprios on points_ledger for select using (user_id = auth.uid() or is_mod());
-- (sem policy de insert/update/delete: gravação só via função security definer abaixo)

-- Posts: todos leem os não ocultos; autor e moderação veem os ocultos; autor edita os próprios
alter table posts enable row level security;
create policy posts_ler on posts for select using ((not hidden and deleted_at is null) or author_id = auth.uid() or is_mod());
create policy posts_criar on posts for insert with check (author_id = auth.uid());
create policy posts_editar on posts for update using (author_id = auth.uid() or is_mod());

-- Voz do Bairro: autor real só aparece pra moderação (exponha uma VIEW pública sem author_id quando anonymous = true)
alter table voice_reports enable row level security;
create policy voz_ler on voice_reports for select using (not hidden or is_mod());
create policy voz_criar on voice_reports for insert with check (author_id = auth.uid());
create or replace view voice_reports_public as
  select id, kind, anonymous, body, neighborhood_id, created_at,
         case when anonymous then null else author_id end as author_id
  from voice_reports where not hidden and deleted_at is null;

-- Denúncias: cada um cria as suas; só moderação lê
alter table reports enable row level security;
create policy denuncia_criar on reports for insert with check (reporter_id = auth.uid());
create policy denuncia_ler on reports for select using (is_mod());

-- =====================================================================
-- FUNÇÕES NO SERVIDOR (regras que não podem ficar só na tela)
-- =====================================================================

-- Dá pontos respeitando o limite diário da regra
create or replace function award_points(p_action text, p_ref text default null)
returns int language plpgsql security definer set search_path = public as $$
declare r point_rules; feitos int; temporada int;
begin
  select * into r from point_rules where action = p_action;
  if not found then raise exception 'regra % não existe', p_action; end if;
  select count(*) into feitos from points_ledger
   where user_id = auth.uid() and action = p_action and created_at::date = now()::date;
  if feitos >= r.daily_cap then return 0; end if;          -- passou do limite: não pontua
  select id into temporada from seasons where not closed and now()::date between starts_at and ends_at limit 1;
  insert into points_ledger (user_id, points, action, ref_id, season_id) values (auth.uid(), r.points, p_action, p_ref, temporada);
  return r.points;
end $$;

-- Resgata meta única (verifica que não foi resgatada antes)
create or replace function claim_goal(p_goal text)
returns int language plpgsql security definer set search_path = public as $$
declare g goals;
begin
  select * into g from goals where id = p_goal and active;
  if not found then raise exception 'meta inválida'; end if;
  insert into user_goals (user_id, goal_id) values (auth.uid(), p_goal);   -- falha se já existe
  insert into points_ledger (user_id, points, action, ref_id) values (auth.uid(), g.points, 'goal', p_goal);
  -- a verificação de que a meta foi cumprida (perfil completo, 3 amigos...) deve ser feita aqui, conforme cada meta
  return g.points;
end $$;

-- Oculta automaticamente com N denúncias de pessoas diferentes
create or replace function auto_hide_on_reports() returns trigger language plpgsql security definer as $$
declare n int; limite int := coalesce((select (value)::int from admin_settings where key = 'report_threshold'), 3);
begin
  select count(distinct reporter_id) into n from reports where item_type = new.item_type and item_id = new.item_id;
  if n >= limite then
    if new.item_type = 'post' then update posts set hidden = true where id::text = new.item_id; end if;
    if new.item_type = 'comment' then update comments set hidden = true where id::text = new.item_id; end if;
    if new.item_type = 'voice' then update voice_reports set hidden = true where id::text = new.item_id; end if;
  end if;
  return new;
end $$;
create trigger trg_auto_hide after insert on reports for each row execute function auto_hide_on_reports();

-- Cupom: confere nível mínimo e estoque, e gera código único
create or replace function redeem_coupon(p_coupon uuid)
returns text language plpgsql security definer set search_path = public as $$
declare c coupons; nivel int; usados int; codigo text;
begin
  select * into c from coupons where id = p_coupon and valid_until >= now()::date;
  if not found then raise exception 'cupom inválido ou vencido'; end if;
  select level into nivel from user_levels where user_id = auth.uid();
  if nivel < c.min_level then raise exception 'nível insuficiente'; end if;
  select count(*) into usados from coupon_redemptions where coupon_id = p_coupon;
  if c.stock is not null and usados >= c.stock then raise exception 'esgotado'; end if;
  codigo := upper(substr(md5(p_coupon::text || auth.uid()::text), 1, 8));
  insert into coupon_redemptions (coupon_id, user_id, code) values (p_coupon, auth.uid(), codigo);
  return codigo;
end $$;
