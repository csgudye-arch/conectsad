// Código-fonte legível do protótipo Conecta ABC (React + Tailwind, arquivo único).
// É REFERÊNCIA de visual e comportamento. Não é pra colar inteiro no app: cada prompt diz o que portar.

const { useState, useEffect, useRef } = React;

/* ====== ÍCONES (lucide) ====== */
const camel = (k) => k.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
function Icon({ name, size = 22, className = '', strokeWidth = 2, fill = 'none' }) {
  const node = (window.lucide && window.lucide.icons && window.lucide.icons[name]) || null;
  const kids = node ? (node[0] === 'svg' ? node[2] : node) : [];
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" className={'shrink-0 ' + className} aria-hidden="true">
      {kids.map(([tag, attrs], i) => { const p = {}; Object.keys(attrs || {}).forEach((k) => { if (k !== 'key') p[camel(k)] = attrs[k]; }); return React.createElement(tag, { key: i, ...p }); })}
    </svg>
  );
}

/* ====== MARCA ====== */
const SadLogo = ({ size = 32, dark = false }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" className="shrink-0" aria-hidden="true">
    <path d="M24 4L4 42H15.5L24 24.5L28.5 33.5H19.5L16.5 42H44L24 4Z" fill={dark ? '#0A0A0A' : '#FFC107'} />
    <path d="M24 14L11 39H15L24 21.5L24 14Z" fill={dark ? '#FFC107' : '#0A0A0A'} opacity="0.35" />
  </svg>
);
const ConectaMarca = ({ size = 30 }) => (
  <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden="true" className="shrink-0">
    <rect width="40" height="40" rx="11" fill="#FFC107" />
    <circle cx="16" cy="20" r="7.5" fill="none" stroke="#0A0A0A" strokeWidth="3.4" />
    <circle cx="24" cy="20" r="7.5" fill="none" stroke="#0A0A0A" strokeWidth="3.4" strokeDasharray="30 17" strokeDashoffset="-8" />
  </svg>
);
const Wordmark = ({ marca = true }) => (<span className="flex items-center gap-2">{marca && <ConectaMarca size={28} />}<span className="text-[20px] font-extrabold tracking-[.06em] leading-none">CONECTA <span className="text-[#FFC107]">ABC</span></span></span>);
const Medalha = ({ size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className="shrink-0" aria-hidden="true">
    <path d="M28 65L18 94L32 88L40 96L45 68" fill="#D97706" /><path d="M72 65L82 94L68 88L60 96L55 68" fill="#B45309" />
    <circle cx="50" cy="46" r="36" fill="#D97706" /><circle cx="50" cy="46" r="31" fill="#F59E0B" stroke="#FDE047" strokeWidth="2.5" /><circle cx="50" cy="46" r="24" fill="#B45309" />
    <path d="M50 27L55.3 37.8L67.2 39.5L58.6 47.9L60.6 59.8L50 54.2L39.4 59.8L41.4 47.9L32.8 39.5L44.7 37.8L50 27Z" fill="#FEF08A" />
  </svg>
);
const QR = () => (
  <svg viewBox="0 0 100 100" className="w-full h-full p-1.5 bg-white rounded-[10px]" aria-label="QR code">
    <path d="M8,8 h26 v26 h-26 z M13,13 v16 h16 v-16 z M17,17 h8 v8 h-8 z M66,8 h26 v26 h-26 z M71,13 v16 h16 v-16 z M75,17 h8 v8 h-8 z M8,66 h26 v26 h-26 z M13,71 v16 h16 v-16 z M17,75 h8 v8 h-8 z" fill="#0A0A0A" fillRule="evenodd" />
    {[[38,8,6,6],[50,8,6,12],[38,20,12,6],[56,22,6,12],[8,38,12,6],[26,38,6,12],[38,32,14,14],[58,38,12,6],[76,38,16,6],[8,50,6,10],[18,52,14,6],[38,52,6,14],[50,50,14,8],[70,48,6,14],[82,50,10,10],[38,72,12,6],[44,82,12,10],[56,64,10,12],[72,68,12,12],[62,84,16,8],[84,78,8,14]].map(([x,y,w,h],i)=>(<rect key={i} x={x} y={y} width={w} height={h} fill="#0A0A0A" />))}
  </svg>
);

/* ====== DADOS (os mesmos do app) ====== */
const TONES = { ouro: 'from-[#3A2E05] to-[#1A1503]', verde: 'from-[#0F2A1E] to-[#0B1712]', azul: 'from-[#0E1D33] to-[#0A1220]', vinho: 'from-[#33101A] to-[#1A0A0E]', lar: 'from-[#3A1D08] to-[#1C0F05]', cinza: 'from-[#262629] to-[#151517]', roxo: 'from-[#22143A] to-[#120B1F]' };
const BAIRROS = ['Centro', 'Vila Assunção', 'Jardim', 'Casa Branca', 'Campestre', 'Vila Luzita', 'Parque das Nações', 'Utinga'];
const EVENTOS = [
  { id: 'e1', wd: 'sáb', dia: '07', mes: 'nov', titulo: 'Feira Cultural do Paço', local: 'Paço Municipal', bairro: 'Centro', hora: '10h às 18h', cat: 'Cultura', gratis: true, vao: 214, icon: 'Sparkles', tone: 'ouro', desc: 'Artesanato, comida de rua e apresentações de grupos de dança do ABC. Tem troca de livros na tenda da biblioteca.' },
  { id: 'e2', wd: 'sáb', dia: '07', mes: 'nov', titulo: 'Batalha de rima no Parque Celso Daniel', local: 'Parque Celso Daniel', bairro: 'Jardim', hora: '16h', cat: 'Música', gratis: true, vao: 389, icon: 'Megaphone', tone: 'roxo', desc: 'Roda aberta de freestyle com inscrição na hora. DJ convidado a partir das 18h.' },
  { id: 'e3', wd: 'dom', dia: '08', mes: 'nov', titulo: 'Corrida 5K do ABC', local: 'Av. Industrial', bairro: 'Campestre', hora: '7h', cat: 'Esporte', gratis: false, vao: 132, icon: 'Flame', tone: 'lar', desc: 'Percurso plano de 5 km. Associados do Clube têm 20% de desconto na inscrição.' },
  { id: 'e4', wd: 'qua', dia: '11', mes: 'nov', titulo: 'Mutirão de adoção de pets', local: 'Praça do Carmo', bairro: 'Centro', hora: '9h às 15h', cat: 'Animais', gratis: true, vao: 97, icon: 'PawPrint', tone: 'verde', desc: 'ONGs parceiras com cães e gatos vacinados e castrados. Traga documento com foto.' },
  { id: 'e5', wd: 'sex', dia: '13', mes: 'nov', titulo: 'Noite do pagode na Vila', local: 'Clube Atlético Vila Luzita', bairro: 'Vila Luzita', hora: '20h', cat: 'Música', gratis: false, vao: 276, icon: 'Music', tone: 'vinho', desc: 'Três grupos da região. Entrada com 1 kg de alimento não perecível.' },
  { id: 'e6', wd: 'sáb', dia: '14', mes: 'nov', titulo: 'Oficina de currículo e entrevista', local: 'Biblioteca Nair Lacerda', bairro: 'Centro', hora: '14h', cat: 'Carreira', gratis: true, vao: 58, icon: 'Briefcase', tone: 'azul', desc: 'Voluntários de RH revisam seu currículo e simulam entrevistas. Vagas limitadas.' },
];
const PARCEIROS = [
  { id: 'p1', nome: 'Pizzaria Da Vila', user: 'pizzariadavila', cat: 'Alimentação', beneficio: '15% de desconto', cupom: 'SAD15PIZZA', bairro: 'Vila Alzira', dist: '1,2 km', icon: 'Pizza', tone: 'lar', nota: 4.8, desc: 'Forno a lenha, entrega no ABC inteiro. Desconto no salão e no delivery.' },
  { id: 'p2', nome: 'Posto ABC', user: 'postoabc', cat: 'Auto', beneficio: 'Desconto no combustível', cupom: 'SADFUEL20', bairro: 'Centro', dist: '3,5 km', icon: 'Fuel', tone: 'vinho', nota: 4.5, desc: 'Gasolina, etanol e diesel. Mostre a carteirinha no caixa.' },
  { id: 'p3', nome: 'Farmácia Saúde+', user: 'farmaciasaudemais', cat: 'Saúde', beneficio: 'Até 15% de desconto', cupom: 'SADSAUDE', bairro: 'Jardim', dist: '5,1 km', icon: 'Pill', tone: 'verde', nota: 4.7, desc: 'Aberta 24h. Desconto em genéricos e perfumaria.' },
  { id: 'p4', nome: 'Academia FitABC', user: 'fitabc', cat: 'Saúde', beneficio: 'Plano especial', cupom: 'SADFIT0', bairro: 'Casa Branca', dist: '4,6 km', icon: 'Dumbbell', tone: 'azul', nota: 4.6, desc: 'Musculação, funcional e lutas. Matrícula isenta para associados.' },
  { id: 'p5', nome: 'Barbearia Navalha', user: 'barbearianavalha', cat: 'Beleza', beneficio: 'Corte + barba R$ 45', cupom: 'SADNAVALHA', bairro: 'Utinga', dist: '6,0 km', icon: 'Scissors', tone: 'cinza', nota: 4.9, desc: 'Atendimento com hora marcada de terça a sábado.' },
  { id: 'p6', nome: 'Bike & Cia', user: 'bikeecia', cat: 'Auto', beneficio: 'Revisão com 10% off', cupom: 'SADBIKE10', bairro: 'Campestre', dist: '2,8 km', icon: 'Bike', tone: 'ouro', nota: 4.7, desc: 'Oficina e peças para bicicletas urbanas e MTB.' },
];
const PRODUTOS0 = [
  { id: 'prod1', nome: 'iPhone 14 128GB', preco: 3500, precoAntigo: 3800, troca: true, cond: 'Usado - Bom estado', cat: 'Eletrônicos', bairro: 'Santo André', vend: 'Rafael Mendes', icon: 'Smartphone', tone: 'azul', dias: 1, desc: 'Bateria em 88%, com caixa e capinha. Sem marcas na tela.' },
  { id: 'prod2', nome: 'Sofá 3 lugares', preco: 1200, precoAntigo: 1500, cond: 'Usado - Ótimo estado', cat: 'Móveis', bairro: 'Santo André', vend: 'Patrícia Lima', icon: 'Sofa', tone: 'cinza', dias: 3, desc: 'Tecido suede cinza, 2,10 m. Retirada no local.' },
  { id: 'prod3', nome: 'PlayStation 5', preco: 3500, cond: 'Usado - Bom estado', cat: 'Eletrônicos', bairro: 'Santo André', vend: 'João Vitor', icon: 'Gamepad2', tone: 'roxo', dias: 2, desc: 'Console PS5 com 1 controle, cabos e caixa. Tudo funcionando perfeitamente.' },
  { id: 'prod4', nome: 'Bicicleta MTB', preco: 1500, cond: 'Usado - Revisada', cat: 'Esporte', bairro: 'Santo André', vend: 'Diego Santos', icon: 'Bike', tone: 'verde', dias: 5, desc: 'Quadro alumínio aro 29, 21 marchas, freio a disco.' },
  { id: 'prod5', nome: 'Cama de casal', preco: 900, cond: 'Usado', cat: 'Móveis', bairro: 'Vila Luzita', vend: 'Ana Paula', icon: 'BedDouble', tone: 'ouro', dias: 6, desc: 'Madeira maciça e colchão de molas com 2 anos de uso.' },
  { id: 'prod7', nome: 'Carrinho de bebê', preco: 0, doacao: true, cond: 'Usado', cat: 'Infantil', bairro: 'Parque das Nações', vend: 'Bruna Carvalho', icon: 'Baby', tone: 'vinho', dias: 1, desc: 'Doação. Reclinável, com capa de chuva. Retirar no local.' },
  { id: 'prod6', nome: 'Jaqueta jeans', preco: 80, troca: true, cond: 'Novo', cat: 'Moda', bairro: 'Utinga', vend: 'Lucas Rocha', icon: 'Shirt', tone: 'azul', dias: 1, desc: 'Tamanho M, nunca usada, com etiqueta.' },
];
const PETS0 = [
  { id: 'pet1', nome: 'Max', status: 'Perdido', especie: 'Cachorro', raca: 'Golden retriever', bairro: 'Vila Assunção', icon: 'Dog', tone: 'ouro', quando: 'há 2 dias', desc: 'Coleira vermelha, muito dócil. Fugiu perto da Av. Portugal.' },
  { id: 'pet2', nome: 'Sem nome', status: 'Encontrado', especie: 'Gato', raca: 'Rajado cinza', bairro: 'Jardim', icon: 'Cat', tone: 'cinza', quando: 'ontem', desc: 'Encontrado no estacionamento do mercado. Está abrigado com uma moradora.' },
  { id: 'pet3', nome: 'Luna', status: 'Perdido', especie: 'Cachorro', raca: 'Border collie', bairro: 'Casa Branca', icon: 'Dog', tone: 'azul', quando: 'há 4 dias', desc: 'Preta e branca, tem chip. Recompensa para quem encontrar.' },
  { id: 'pet4', nome: 'Sem nome', status: 'Em busca do tutor', especie: 'Gato', raca: 'Laranja e branco', bairro: 'Centro', icon: 'Cat', tone: 'lar', quando: 'há 1 dia', desc: 'Filhote resgatado na Rua Senador Fláquer. Muito manso.' },
];
const ACHADOS = [
  { id: 'o1', tipo: 'Achado', cat: 'Carteira', titulo: 'Carteira marrom com documentos', bairro: 'Centro', local: 'Terminal Oeste', quando: 'hoje', icon: 'Wallet', tone: 'lar' },
  { id: 'o2', tipo: 'Perdido', cat: 'Chave', titulo: 'Chave de carro com chaveiro do Ramalhão', bairro: 'Jardim', local: 'Rua das Figueiras', quando: 'ontem', icon: 'KeyRound', tone: 'ouro' },
  { id: 'o3', tipo: 'Achado', cat: 'Documento', titulo: 'Cartão do SUS', bairro: 'Vila Luzita', local: 'UBS Vila Luzita', quando: 'há 2 dias', icon: 'IdCard', tone: 'azul' },
  { id: 'o4', tipo: 'Perdido', cat: 'Celular', titulo: 'Celular com capinha azul', bairro: 'Campestre', local: 'Parque Central', quando: 'há 3 dias', icon: 'Smartphone', tone: 'cinza' },
  { id: 'o5', tipo: 'Perdido', cat: 'Óculos', titulo: 'Óculos de grau com armação preta', bairro: 'Casa Branca', local: 'Padaria da praça', quando: 'há 4 dias', icon: 'Glasses', tone: 'roxo' },
  { id: 'o6', tipo: 'Achado', cat: 'Bicicleta', titulo: 'Bicicleta infantil vermelha', bairro: 'Jardim', local: 'Parque Celso Daniel', quando: 'há 5 dias', icon: 'Bike', tone: 'vinho', resolvido: true },
  { id: 'o7', tipo: 'Perdido', cat: 'Documento', titulo: 'RG e CNH num envelope', bairro: 'Centro', local: 'Rua Coronel Oliveira Lima', quando: 'semana passada', icon: 'IdCard', tone: 'azul', resolvido: true },
];
const NOTICIAS = [
  { id: 'n1', fonte: 'Prefeitura de Santo André', data: '5 nov', cat: 'Cidade', titulo: 'Nova ciclofaixa liga o Centro ao Parque Celso Daniel', resumo: 'São 4,2 km de pista sinalizada pela Av. Dom Pedro II. A obra termina em dezembro.', icon: 'Bike', tone: 'verde' },
  { id: 'n2', fonte: 'Clube da SAD', data: '5 nov', cat: 'Clube', titulo: 'Clube da SAD passa de 12 mil associados no ABC', resumo: 'O número dobrou em seis meses. Nova leva de parceiros entra na rede em novembro.', icon: 'Users', tone: 'ouro' },
  { id: 'n3', fonte: 'Semasa', data: '4 nov', cat: 'Serviços', titulo: 'Coleta seletiva muda de horário em cinco bairros', resumo: 'Jardim, Casa Branca, Campestre, Vila Assunção e Centro passam a ter coleta às terças e sextas.', icon: 'Recycle', tone: 'azul' },
  { id: 'n4', fonte: 'Secretaria de Cultura', data: '3 nov', cat: 'Cultura', titulo: 'Oficinas gratuitas de música urbana abrem inscrições', resumo: 'Produção musical, DJ e beatmaking para jovens de 15 a 29 anos.', icon: 'Music', tone: 'roxo' },
  { id: 'n5', fonte: 'Defesa Civil', data: '3 nov', cat: 'Alerta', titulo: 'Previsão de chuva forte na quinta à tarde', resumo: 'Evite áreas de alagamento como a Av. dos Estados entre 15h e 19h.', icon: 'CloudRain', tone: 'cinza' },
];
const POSTS0 = [
  { id: 'f1', autor: 'Pizzaria Da Vila', user: 'pizzariadavila', tipo: 'Parceiro', bairro: 'Vila Alzira', tempo: '40 min', texto: 'Sexta tem rodízio com 15% pra quem mostrar a carteirinha do Clube. Reserva pelo WhatsApp da loja.', likes: 48, coms: 7, icon: 'Pizza', tone: 'lar' },
  { id: 'f2', autor: 'Mariana Souza', user: 'mari.souza', tipo: 'Morador', bairro: 'Jardim', tempo: '1 h', texto: 'Alguém indica eletricista de confiança aqui no Jardim? Preciso trocar o quadro de luz.', likes: 12, coms: 15 },
  { id: 'f3', autor: 'Infinita 3D', user: 'infinita3d', tipo: 'Parceiro', bairro: 'Campestre', tempo: '3 h', texto: 'Catálogo de Natal no ar: enfeites e bonecos personalizados impressos em 3D. Encomendas até 10/12.', likes: 63, coms: 9, icon: 'Gift', tone: 'vinho' },
  { id: 'f4', autor: 'Coletivo Rima ABC', user: 'rimaabc', tipo: 'Comunidade', bairro: 'Centro', tempo: '5 h', texto: 'Sábado tem batalha no Parque Celso Daniel. Inscrições na hora, começa 16h. Chega junto!', likes: 121, coms: 22, icon: 'Megaphone', tone: 'roxo' },
];
const COMENTARIOS0 = {
  f1: [['jvitor', 'Já reservei pra sexta!'], ['ana.paula', 'Vale pro delivery também?']],
  f2: [['fernanda.c', 'Fernando Elétrica, super recomendo.'], ['marcos.o', 'Chama o Tião da Rua 7, trabalho caprichado']],
  f3: [['bruna.c', 'Faz boneco de pet?']], f4: [['rafa.mc', 'Tô dentro!'], ['juliana.s', 'Que horas acaba?']],
};
const ENQUETES0 = [
  { id: 'q1', pergunta: 'Qual a prioridade pra sua rua em 2027?', autor: 'Conecta ABC', opcoes: [['Asfalto', 182], ['Iluminação', 141], ['Mais árvores', 96], ['Segurança', 210]], dias: 3 },
  { id: 'q2', pergunta: 'Você usaria uma ciclofaixa até o trabalho?', autor: 'Mariana Souza', opcoes: [['Sim, todo dia', 88], ['Às vezes', 71], ['Não', 43]], dias: 5 },
];
const COMUNIDADES = [
  { id: 'c1', nome: 'Mães e pais do ABC', membros: 1840, desc: 'Escolas, pediatras, festas e trocas de roupa infantil.', icon: 'Baby', tone: 'vinho', ativo: 'agora' },
  { id: 'c2', nome: 'Empreendedores de Santo André', membros: 1215, desc: 'Networking, dicas de MEI e parcerias entre negócios locais.', icon: 'Briefcase', tone: 'azul', ativo: 'há 10 min' },
  { id: 'c3', nome: 'Pedal ABC', membros: 960, desc: 'Rotas, pedais noturnos e mecânica básica.', icon: 'Bike', tone: 'verde', ativo: 'há 1 h' },
  { id: 'c4', nome: 'Música urbana do ABC', membros: 2310, desc: 'Rap, funk, trap e pagode. Divulgue seu som e ache parceria.', icon: 'Mic', tone: 'roxo', ativo: 'agora' },
  { id: 'c5', nome: 'Protetores de animais', membros: 1430, desc: 'Resgates, lares temporários e campanhas de castração.', icon: 'PawPrint', tone: 'lar', ativo: 'há 25 min' },
];
const IMOVEIS = [
  { id: 'i1', tipo: 'Aluguel', cat: 'Apartamento', titulo: 'Apartamento 2 dormitórios', preco: 'R$ 1.800/mês', valor: 1800, cond: 'R$ 420', area: '58 m²', quartos: 2, banheiros: 1, vagas: '1 vaga', bairro: 'Jardim', icon: 'Building2', tone: 'azul' },
  { id: 'i2', tipo: 'Venda', cat: 'Casa', titulo: 'Casa térrea com quintal', preco: 'R$ 520 mil', valor: 520000, cond: '', area: '120 m²', quartos: 3, banheiros: 2, vagas: '2 vagas', bairro: 'Vila Assunção', icon: 'House', tone: 'verde' },
  { id: 'i3', tipo: 'Aluguel', cat: 'Sala comercial', titulo: 'Salão comercial de esquina', preco: 'R$ 3.200/mês', valor: 3200, cond: '', area: '85 m²', quartos: 0, banheiros: 1, vagas: 'sem vaga', bairro: 'Centro', icon: 'Store', tone: 'ouro' },
  { id: 'i4', tipo: 'Aluguel', cat: 'Kitnet', titulo: 'Kitnet mobiliada', preco: 'R$ 1.100/mês', valor: 1100, cond: 'R$ 150', area: '28 m²', quartos: 1, banheiros: 1, vagas: 'sem vaga', bairro: 'Campestre', icon: 'BedDouble', tone: 'roxo' },
  { id: 'i5', tipo: 'Venda', cat: 'Apartamento', titulo: 'Apartamento com varanda gourmet', preco: 'R$ 410 mil', valor: 410000, cond: 'R$ 560', area: '72 m²', quartos: 3, banheiros: 2, vagas: '1 vaga', bairro: 'Casa Branca', icon: 'Building', tone: 'vinho' },
];
const VAGAS = [
  { id: 'v1', cargo: 'Atendente de loja', empresa: 'Farmácia Saúde+', regime: 'CLT', modo: 'Presencial', salario: 'R$ 1.950 + VR', bairro: 'Jardim' },
  { id: 'v2', cargo: 'Auxiliar de cozinha', empresa: 'Pizzaria Da Vila', regime: 'CLT', modo: 'Presencial', salario: 'R$ 1.800 + refeição', bairro: 'Vila Alzira' },
  { id: 'v3', cargo: 'Social media', empresa: 'Escola Ponte', regime: 'PJ', modo: 'Híbrido', salario: 'R$ 2.800', bairro: 'Jardim' },
  { id: 'v4', cargo: 'Frentista', empresa: 'Posto ABC', regime: 'CLT', modo: 'Presencial', salario: 'R$ 2.100', bairro: 'Centro' },
  { id: 'v5', cargo: 'Instrutor de musculação', empresa: 'Academia FitABC', regime: 'Temporário', modo: 'Presencial', salario: 'R$ 2.400', bairro: 'Casa Branca' },
];
const PROBLEMAS0 = [
  { id: 'r1', cat: 'Buracos', status: 'Em análise', titulo: 'Buraco na via', end: 'Rua das Figueiras, 125', bairro: 'Jardim', data: '10/11', apoios: 24, icon: 'Construction', tone: 'cinza' },
  { id: 'r2', cat: 'Lixo', status: 'Encaminhado', titulo: 'Descarte irregular', end: 'Av. Dom Pedro I', bairro: 'Vila Assunção', data: '09/11', apoios: 16, icon: 'Trash2', tone: 'verde' },
  { id: 'r3', cat: 'Iluminação', status: 'Resolvido', titulo: 'Poste sem luz', end: 'Rua das Palmeiras', bairro: 'Casa Branca', data: '02/11', apoios: 42, icon: 'Lightbulb', tone: 'ouro' },
];
const INDICA = [
  { id: 'k1', pergunta: 'Eletricista de confiança no Jardim?', autor: 'Mariana S.', respostas: 15, top: 'Fernando Elétrica (8 votos)' },
  { id: 'k2', pergunta: 'Melhor pastel do Centro?', autor: 'Paulo R.', respostas: 31, top: 'Lanchonete do Tião (19 votos)' },
  { id: 'k3', pergunta: 'Veterinário que atende sábado?', autor: 'Camila T.', respostas: 9, top: 'Clínica Amigo Fiel (5 votos)' },
];
const RANKING = [
  { nome: 'Fernanda Costa', bairro: 'Jardim', xp: 1420, nivel: 'Embaixadora' }, { nome: 'Marcos Oliveira', bairro: 'Centro', xp: 890, nivel: 'Destaque' },
  { nome: 'Juliana Santos', bairro: 'Vila Luzita', xp: 610, nivel: 'Destaque' }, { nome: 'Rafael Mendes', bairro: 'Campestre', xp: 198, nivel: 'Iniciante' },
];
const PLACAR = [['Jardim', 48210], ['Centro', 41380], ['Vila Assunção', 36940], ['Casa Branca', 29870], ['Vila Luzita', 24410], ['Campestre', 21050]];
const LUGARES = [
  { id: 'l1', nome: 'Parque Celso Daniel', cat: 'Lazer', x: 22, y: 30, nota: 4.8 }, { id: 'l2', nome: 'Paço Municipal', cat: 'Cultura', x: 50, y: 50, nota: 4.6 },
  { id: 'l3', nome: 'Pizzaria Da Vila', cat: 'Comer', x: 70, y: 26, nota: 4.8 }, { id: 'l4', nome: 'Farmácia Saúde+', cat: 'Saúde', x: 34, y: 72, nota: 4.7 },
  { id: 'l5', nome: 'Feira de quinta', cat: 'Comer', x: 80, y: 66, nota: 4.5 }, { id: 'l6', nome: 'Biblioteca Nair Lacerda', cat: 'Cultura', x: 58, y: 82, nota: 4.9 },
  { id: 'l7', nome: 'Academia FitABC', cat: 'Saúde', x: 88, y: 40, nota: 4.6 }, { id: 'l8', nome: 'Parque Central', cat: 'Lazer', x: 12, y: 76, nota: 4.7 },
];
const PIN_COR = { Lazer: '#22C55E', Cultura: '#A78BFA', Comer: '#F97316', Saúde: '#3B82F6' };
const UTILIDADES = [['Emergência (SAMU)', '192'], ['Bombeiros', '193'], ['Polícia Militar', '190'], ['Defesa Civil', '199'], ['Guarda Civil Municipal', '153'], ['Prefeitura', '156']];
const MISSOES = [
  { id: 'm-checkin', icon: 'CalendarCheck', titulo: 'Check-in diário', xp: 3 }, { id: 'm-problema', icon: 'Camera', titulo: 'Enviar problema da cidade', xp: 35, rota: 'problemas' },
  { id: 'm-post', icon: 'MessageCircle', titulo: 'Publicar no feed', xp: 10, rota: 'criar' }, { id: 'm-evento', icon: 'CalendarDays', titulo: 'Confirmar presença num evento', xp: 5, rota: 'agenda' },
  { id: 'm-cupom', icon: 'TicketPercent', titulo: 'Usar cupom de parceiro', xp: 15, rota: 'parceiros' }, { id: 'm-voto', icon: 'Vote', titulo: 'Votar numa enquete', xp: 5, rota: 'enquetes' },
];
const NIVEIS = [['Novato', 0], ['Vizinho', 100], ['Participante', 250], ['Ativo', 500], ['Destaque', 800], ['Referência', 1200], ['Influente', 1700], ['Líder', 2300], ['Embaixador', 3000], ['Lenda do ABC', 4000]];
const nivelDe = (xp) => { let i = 0; NIVEIS.forEach(([, m], k) => { if (xp >= m) i = k; }); return i; };
const STORIES = [
  { id: 's1', autor: 'Conecta ABC', icon: 'Sparkles', tone: 'ouro', titulo: '186 parceiros com desconto', texto: 'Mostre a carteirinha ou use o cupom do app.', cta: 'Ver parceiros', rota: 'parceiros' },
  { id: 's2', autor: 'Pizzaria Da Vila', online: true, icon: 'Pizza', tone: 'lar', titulo: 'Rodízio de sexta com 15%', texto: 'Válido no salão e no delivery pra associados.', cta: 'Pegar cupom', rota: 'parceiro-p1' },
  { id: 's3', autor: 'Batalha de rima', online: true, icon: 'Megaphone', tone: 'roxo', titulo: 'Sábado, 16h, Parque Celso Daniel', texto: '389 pessoas já confirmaram.', cta: 'Ver evento', rota: 'evento-e2' },
  { id: 's4', autor: 'Animais', icon: 'Dog', tone: 'azul', titulo: 'Luna está perdida', texto: 'Border collie preta e branca, Casa Branca.', cta: 'Ajudar', rota: 'animal-pet3' },
  { id: 's5', autor: 'Defesa Civil', icon: 'CloudRain', tone: 'cinza', titulo: 'Chuva forte na quinta', texto: 'Evite a Av. dos Estados entre 15h e 19h.', cta: 'Ler alerta', rota: 'noticia-n5' },
  { id: 's7', autor: 'Fernanda Costa', pessoa: true, online: true, icon: 'Sprout', tone: 'verde', titulo: 'Mutirão na horta da Vila', texto: 'Sábado de manhã, quem vem?', cta: 'Ver comunidades', rota: 'comunidades' },
  { id: 's8', autor: 'Marcos Oliveira', pessoa: true, online: false, icon: 'Bike', tone: 'azul', titulo: 'Pedal de quarta à noite', texto: 'Saída 20h do Paço.', cta: 'Pedal ABC', rota: 'comunidade-c3' },
  { id: 's9', autor: 'Juliana Santos', pessoa: true, online: true, icon: 'Music', tone: 'roxo', titulo: 'Ensaio aberto hoje', texto: 'Grupo de pagode da Vila Luzita.', cta: 'Ver agenda', rota: 'agenda' },
  { id: 's6', autor: 'SAD Pontua', icon: 'Trophy', tone: 'verde', titulo: 'Sorteio de novembro', texto: 'Bicicleta MTB entre associados nível 2+.', cta: 'Ver prêmios', rota: 'pontua' },
];
const NOTIFS = [
  ['Heart', 'pizzariadavila', 'curtiu sua publicação.', '5 min'], ['UserPlus', 'fernanda.c', 'começou a seguir você.', '1 h'], ['TicketPercent', 'Conecta ABC', 'liberou um cupom novo da Barbearia Navalha.', '2 h'],
  ['CalendarDays', 'Agenda', 'Batalha de rima começa amanhã às 16h.', '3 h'], ['ThumbsUp', 'Prefeitura', 'marcou como encaminhado o aviso "Descarte irregular".', 'ontem'], ['Trophy', 'SAD Pontua', 'você está a 280 XP do nível Destaque.', 'ontem'],
];

/* ====== ESTADO ====== */
const KEY = 'conecta-abc-v2';
const INICIAL = { admin: false, clips: [], amigos: ['mari.souza', 'fernanda.c'], pedidos: ['ana.paula', 'tiago.m'], enviados: [], reacoes: {}, denuncias: [], ocultos: [], removidos: [], escondidos: [], moderados: [], metas: [], historico: [], sorteios: [], votosPremio: {}, convites: 2, falas: [], indicados: {}, resolvidos: [], pedidosIndica: [], checkins: [], avaliacoes: {}, lembretes: [], foto: false, capa: false, appInstalado: false, notifAtivas: false, selos: [], logado: true, nome: 'Carlos Silva', user: 'carlos.silva', bairro: 'Jardim', bio: 'Associado do Clube desde 2024. Santo André de coração.', xp: 220, streak: 4, ultimoCheckin: '', salvos: ['p1'], presencas: [], votos: {}, extraVotos: {}, curtidas: [], posts: [], problemas: [], pets: [], produtos: [], enquetes: [], cupons: [], missoes: [], apoios: [], comunidades: [], comentarios: {}, vistos: [], seguindo: [] };
function load() { try { const s = JSON.parse(localStorage.getItem(KEY) || 'null'); return s ? { ...INICIAL, ...s } : INICIAL; } catch (e) { return INICIAL; } }
function save(s) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {} }
const hoje = () => new Date().toISOString().slice(0, 10);
const brl = (n) => (n === 0 ? 'Grátis' : 'R$ ' + n.toLocaleString('pt-BR'));
const Baixou = ({ p }) => (p.precoAntigo ? <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-[#16A34A] text-white rounded px-1.5 py-0.5"><Icon name="TrendingDown" size={12} />Baixou {Math.round((1 - p.preco / p.precoAntigo) * 100)}%</span> : p.doacao ? <span className="text-[11px] font-bold bg-[#2563EB] text-white rounded px-1.5 py-0.5">Doação</span> : p.troca ? <span className="text-[11px] font-bold bg-[#262626] text-white rounded px-1.5 py-0.5">Aceita troca</span> : null);
const fmt = (n) => n.toLocaleString('pt-BR');

/* ====== PEÇAS ====== */
const Ph = ({ tone = 'cinza', icon = 'Image', size = 32, className = '' }) => (<div className={`ph bg-gradient-to-br ${TONES[tone] || TONES.cinza} ${className}`}><Icon name={icon} size={size} className="text-white/80" strokeWidth={1.5} /></div>);
const iniciais = (n) => n.replace(/\(.*\)/, '').trim().split(/[\s.]+/).map((p) => p[0]).slice(0, 2).join('').toUpperCase();
const Avatar = ({ nome, size = 32, ouro = false, anel = false, visto = false }) => {
  const inner = <span style={{ width: size, height: size, fontSize: Math.max(10, size * 0.36) }} className={`rounded-full grid place-items-center font-bold shrink-0 ${ouro ? 'bg-[#FFC107] text-[#0A0A0A]' : 'bg-[#262626] text-white'}`}>{iniciais(nome)}</span>;
  if (!anel) return inner;
  return <span className={`rounded-full p-[2.5px] shrink-0 ${visto ? 'bg-[#363636]' : 'anel'}`}><span className="block rounded-full p-[2px] bg-black">{inner}</span></span>;
};
const Verificado = () => <Icon name="BadgeCheck" size={14} className="text-[#FFC107]" fill="#FFC107" strokeWidth={2.4} />;
const Pill = ({ children, cor = 'neutro', className = '' }) => {
  const c = { neutro: 'bg-[#262626] text-white', ouro: 'bg-[#FFC107] text-[#0A0A0A]', ok: 'bg-[#16A34A] text-white', bad: 'bg-[#DC2626] text-white', info: 'bg-[#2563EB] text-white' }[cor];
  return <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md whitespace-nowrap ${c} ${className}`}>{children}</span>;
};
const Tabs = ({ opcoes, valor, set }) => (
  <div className="flex gap-2 overflow-x-auto no-scrollbar">
    {opcoes.map((o) => <button key={o} onClick={() => set(o)} className={`px-3.5 h-8 rounded-lg text-[13px] font-semibold shrink-0 transition-colors ${valor === o ? 'bg-[#F5F5F5] text-black' : 'bg-[#1A1A1A] text-[#F5F5F5] hover:bg-[#262626]'}`}>{o}</button>)}
  </div>
);
const Busca = ({ id, valor, set, ph }) => (
  <div className="h-10 bg-[#1A1A1A] rounded-lg px-3 flex items-center gap-2 focus-within:ring-1 focus-within:ring-[#FFC107]"><Icon name="Search" size={17} className="text-[#A8A8A8]" /><input id={id} value={valor} onChange={(e) => set(e.target.value)} placeholder={ph} className="bg-transparent text-[14px] w-full focus:outline-none placeholder-[#A8A8A8]" />{valor && <button onClick={() => set('')} aria-label="Limpar"><Icon name="CircleX" size={16} className="text-[#A8A8A8]" fill="#363636" /></button>}</div>
);
const Btn = ({ children, onClick, tipo = 'ouro', className = '', type = 'button', disabled }) => {
  const c = { ouro: 'bg-[#FFC107] text-[#0A0A0A] hover:bg-[#FFCA2C]', sec: 'bg-[#262626] text-white hover:bg-[#333]', ok: 'bg-[#16A34A] text-white', zap: 'bg-[#25D366] text-white', ghost: 'text-[#FFC107] hover:text-[#FFD54F]' }[tipo];
  return <button type={type} disabled={disabled} onClick={onClick} className={`inline-flex items-center justify-center gap-2 h-9 px-4 rounded-lg text-[14px] font-semibold transition-colors active:scale-[.98] disabled:opacity-40 ${c} ${className}`}>{children}</button>;
};
const Campo = ({ label, children }) => (<label className="block"><span className="block text-[13px] font-semibold text-[#A8A8A8] mb-1.5">{label}</span>{children}</label>);
const inputCls = 'w-full h-11 bg-[#121212] border border-[#262626] rounded-lg px-3 text-[14px] placeholder-[#737373] focus:outline-none focus:border-[#FFC107]';
const Vazio = ({ icon = 'Inbox', texto }) => (<div className="py-14 text-center"><span className="w-16 h-16 rounded-full border-2 border-[#F5F5F5] grid place-items-center mx-auto"><Icon name={icon} size={28} /></span><p className="text-[#A8A8A8] text-[14px] mt-3">{texto}</p></div>);
const Pagina = ({ titulo, sub, icon, voltar, go, acao, children, larga }) => (
  <div className={`mx-auto w-full ${larga ? 'max-w-[935px]' : 'max-w-[630px]'} px-4 md:px-6 pt-4 md:pt-8 pb-24 md:pb-12`}>
    <div className="flex items-center gap-3 mb-5">
      {voltar && <button onClick={() => go(voltar)} className="w-9 h-9 -ml-2 rounded-full grid place-items-center hover:bg-[#1A1A1A]" aria-label="Voltar"><Icon name="ChevronLeft" size={26} /></button>}
      {icon && !voltar && <span className="w-10 h-10 rounded-xl bg-[#FFC107] text-[#0A0A0A] grid place-items-center"><Icon name={icon} size={21} /></span>}
      <div className="min-w-0 flex-1"><h1 className="text-[22px] md:text-[24px] font-bold leading-tight truncate">{titulo}</h1>{sub && <p className="text-[13px] text-[#A8A8A8]">{sub}</p>}</div>
      {acao}
    </div>
    {children}
  </div>
);
const Linha = ({ icon, titulo, sub, dir, onClick, perigo }) => (
  <button onClick={onClick} className="w-full flex items-center gap-3 px-1 py-3 text-left hover:bg-[#121212] rounded-lg">
    <Icon name={icon} size={22} className={perigo ? 'text-[#ED4956]' : ''} /><span className="flex-1 min-w-0"><span className={`block text-[15px] ${perigo ? 'text-[#ED4956]' : ''}`}>{titulo}</span>{sub && <span className="block text-[12px] text-[#A8A8A8]">{sub}</span>}</span>{dir}{!perigo && <Icon name="ChevronRight" size={18} className="text-[#737373]" />}
  </button>
);

/* ====== POST (estilo feed) ====== */
function PostCabecalho({ nome, sub, ouro, verificado, direita, onNome }) {
  return (
    <div className="flex items-center gap-2.5 px-3 md:px-0 py-2.5">
      <Avatar nome={nome} size={34} ouro={ouro} anel={ouro} />
      <button onClick={onNome} className="min-w-0 text-left flex-1"><span className="text-[14px] font-semibold flex items-center gap-1">{nome}{verificado && <Verificado />}</span>{sub && <span className="block text-[12px] text-[#A8A8A8] -mt-0.5 truncate">{sub}</span>}</button>
      {direita}
    </div>
  );
}
function Acoes({ curtido, onCurtir, onComentar, onCompartilhar, salvo, onSalvar }) {
  return (
    <div className="flex items-center gap-3.5 px-3 md:px-0 pt-2.5">
      <button onClick={onCurtir} aria-label="Curtir" className="active:scale-90 transition-transform"><Icon name="Heart" size={25} className={curtido ? 'text-[#ED4956]' : ''} fill={curtido ? '#ED4956' : 'none'} /></button>
      <button onClick={onComentar} aria-label="Comentar"><Icon name="MessageCircle" size={24} /></button>
      <button onClick={onCompartilhar} aria-label="Compartilhar"><Icon name="Send" size={23} /></button>
      {onSalvar && <button onClick={onSalvar} aria-label="Salvar" className="ml-auto"><Icon name="Bookmark" size={24} fill={salvo ? '#F5F5F5' : 'none'} /></button>}
    </div>
  );
}
function CardFeed({ cab, midia, children, rodape }) {
  return (<article className="border-b border-[#262626] md:border md:rounded-lg md:mb-4 md:px-4 md:pb-4 bg-black pb-3 fade">{cab}{midia}<div className="px-3 md:px-0">{children}</div>{rodape}</article>);
}
function EnqueteBloco({ q, voto, votar, extra = {} }) {
  const cont = q.opcoes.map(([t, n]) => n + (extra[t] || 0)); const total = cont.reduce((a, b) => a + b, 0);
  return (
    <div>
      <p className="text-[16px] font-semibold leading-snug">{q.pergunta}</p>
      <div className="mt-3 space-y-2">{q.opcoes.map(([t], i) => { const pct = Math.round((cont[i] / total) * 100); const meu = voto === t; return (
        <button key={t} onClick={() => votar(q.id, t)} className={`relative w-full h-11 rounded-lg border overflow-hidden text-left px-3.5 text-[14px] font-medium ${meu ? 'border-[#FFC107]' : 'border-[#363636]'}`}>
          {voto && <span className={`absolute inset-y-0 left-0 ${meu ? 'bg-[#FFC107]/25' : 'bg-white/[.06]'}`} style={{ width: pct + '%' }} />}
          <span className="relative flex justify-between"><span className="flex items-center gap-1.5">{meu && <Icon name="CircleCheck" size={16} className="text-[#FFC107]" />}{t}</span>{voto && <span className="tabnum text-[#A8A8A8]">{pct}%</span>}</span>
        </button>); })}</div>
      <p className="text-[12px] text-[#A8A8A8] mt-2 tabnum">{fmt(total)} votos · encerra em {q.dias} dias</p>
    </div>
  );
}

/* ====== STORIES ====== */
function StoriesRow({ ctx }) {
  const { s, abrirStory, go } = ctx;
  return (
    <div className="flex gap-4 overflow-x-auto no-scrollbar px-3 md:px-0 py-3 md:py-4 border-b border-[#262626] md:border-0">
      <button onClick={() => go('criar')} className="flex flex-col items-center gap-1.5 w-[66px] shrink-0">
        <span className="relative"><Avatar nome={s.nome} size={62} ouro /><span className="absolute -bottom-0.5 -right-0.5 w-[22px] h-[22px] rounded-full bg-[#FFC107] text-[#0A0A0A] border-[3px] border-black grid place-items-center"><Icon name="Plus" size={12} strokeWidth={3.5} /></span></span>
        <span className="text-[12px] text-[#A8A8A8] truncate w-full text-center">Seu story</span>
      </button>
      {STORIES.map((st, i) => (
        <button key={st.id} onClick={() => abrirStory(i)} className="flex flex-col items-center gap-1.5 w-[66px] shrink-0">
          <span className="relative">
            <span className={`block rounded-full p-[2.5px] ${s.vistos.includes(st.id) ? 'bg-[#363636]' : 'anel'}`}><span className="block rounded-full p-[2px] bg-black">{st.pessoa ? <Avatar nome={st.autor} size={58} /> : <Ph tone={st.tone} icon={st.icon} className="w-[58px] h-[58px] rounded-full" size={24} />}</span></span>
            {st.online && <span className="absolute bottom-[3px] right-[3px] w-[11px] h-[11px] rounded-full bg-[#22C55E] border-2 border-black" title="Online agora" aria-label="online" />}
          </span>
          <span className="text-[12px] truncate w-full text-center">{st.autor}</span>
        </button>
      ))}
    </div>
  );
}
function StoryViewer({ idx, setIdx, ctx }) {
  const { go, marcarVisto } = ctx; const st = STORIES[idx]; const [pausa, setPausa] = useState(false);
  useEffect(() => { marcarVisto(st.id); }, [idx]);
  useEffect(() => { if (pausa) return; const t = setTimeout(() => (idx < STORIES.length - 1 ? setIdx(idx + 1) : setIdx(null)), 5000); return () => clearTimeout(t); }, [idx, pausa]);
  useEffect(() => { const k = (e) => { if (e.key === 'Escape') setIdx(null); if (e.key === 'ArrowRight') idx < STORIES.length - 1 ? setIdx(idx + 1) : setIdx(null); if (e.key === 'ArrowLeft' && idx > 0) setIdx(idx - 1); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [idx]);
  return (
    <div className="fixed inset-0 z-[100] bg-[#0A0A0A]/95 grid place-items-center" onClick={() => setIdx(null)}>
      <div onClick={(e) => e.stopPropagation()} className="relative w-full h-full sm:w-[400px] sm:h-[min(92vh,720px)] sm:rounded-xl overflow-hidden">
        <Ph tone={st.tone} icon={st.icon} className="absolute inset-0" size={120} />
        <div className="absolute inset-x-0 top-0 p-3 bg-gradient-to-b from-black/60 to-transparent" style={{ paddingTop: 'calc(env(safe-area-inset-top,0px) + 12px)' }}>
          <div className="flex gap-1">{STORIES.map((x, i) => <span key={x.id} className="h-[2.5px] flex-1 rounded-full bg-white/30 overflow-hidden">{i < idx ? <span className="block h-full w-full bg-white" /> : i === idx ? <span key={idx + '-' + pausa} className="barra block h-full bg-white" style={{ animationDuration: '5s', animationPlayState: pausa ? 'paused' : 'running' }} /> : null}</span>)}</div>
          <div className="flex items-center gap-2 mt-3"><Avatar nome={st.autor} size={30} ouro /><span className="text-[14px] font-semibold">{st.autor}</span><span className="text-[13px] text-white/70">2 h</span>
            <button onClick={() => setPausa(!pausa)} className="ml-auto p-1" aria-label={pausa ? 'Continuar' : 'Pausar'}><Icon name={pausa ? 'Play' : 'Pause'} size={20} fill="#fff" /></button>
            <button onClick={() => setIdx(null)} className="p-1" aria-label="Fechar"><Icon name="X" size={26} /></button></div>
        </div>
        <button className="absolute left-0 top-20 bottom-28 w-1/3" aria-label="Anterior" onClick={() => idx > 0 && setIdx(idx - 1)} />
        <button className="absolute right-0 top-20 bottom-28 w-1/3" aria-label="Próximo" onClick={() => (idx < STORIES.length - 1 ? setIdx(idx + 1) : setIdx(null))} />
        <div className="absolute inset-x-0 bottom-0 p-5 bg-gradient-to-t from-black/80 to-transparent" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom,0px) + 20px)' }}>
          <h2 className="text-[26px] font-extrabold leading-tight">{st.titulo}</h2><p className="text-[15px] text-white/85 mt-1">{st.texto}</p>
          <button onClick={() => { setIdx(null); go(st.rota); }} className="mt-4 w-full h-11 rounded-full bg-white text-black font-semibold flex items-center justify-center gap-1.5">{st.cta}<Icon name="ChevronRight" size={18} /></button>
        </div>
      </div>
    </div>
  );
}

/* ====== COMENTÁRIOS (folha) ====== */
function Comentarios({ post, fechar, ctx }) {
  const { s, up, toast } = ctx; const [t, setT] = useState(''); const fim = useRef(null);
  const lista = [...(COMENTARIOS0[post.id] || []), ...(s.comentarios[post.id] || [])];
  const enviar = (e) => { e.preventDefault(); if (!t.trim()) return; up((p) => ({ comentarios: { ...p.comentarios, [post.id]: [...(p.comentarios[post.id] || []), [p.user, t.trim()]] } })); setT(''); ctx.pontuar('comentario', 'Comentário publicado'); setTimeout(() => fim.current && fim.current.scrollIntoView({ behavior: 'smooth' }), 50); };
  return (
    <div className="fixed inset-0 z-[90] bg-black/70 flex items-end sm:items-center justify-center" onClick={fechar}>
      <div onClick={(e) => e.stopPropagation()} className="fade w-full sm:w-[480px] max-h-[80vh] bg-[#121212] rounded-t-2xl sm:rounded-xl flex flex-col" style={{ paddingBottom: 'env(safe-area-inset-bottom,0px)' }}>
        <div className="relative h-12 grid place-items-center border-b border-[#262626] shrink-0"><span className="absolute top-1.5 w-10 h-1 rounded-full bg-[#363636] sm:hidden" /><b className="text-[15px]">Comentários</b><button onClick={fechar} className="absolute right-3 top-3" aria-label="Fechar"><Icon name="X" size={22} /></button></div>
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
          <div className="flex gap-3 pb-3 border-b border-[#262626]"><Avatar nome={post.autor} size={32} ouro={post.tipo === 'Parceiro'} /><p className="text-[14px]"><b className="mr-1.5">{post.user || post.autor}</b>{post.texto}</p></div>
          {lista.length === 0 && <p className="text-[#A8A8A8] text-[14px] text-center py-6">Ainda sem comentários. Seja o primeiro.</p>}
          {lista.map(([u, c], i) => (<div key={i} className="flex gap-3"><Avatar nome={u} size={32} ouro={u === s.user} /><div className="flex-1"><p className="text-[14px]"><b className="mr-1.5">{u}</b>{c}</p><p className="text-[12px] text-[#A8A8A8] mt-0.5">{u === s.user ? 'agora' : (i + 1) * 12 + ' min'} · Responder</p></div><Icon name="Heart" size={13} className="text-[#A8A8A8] mt-1.5" /></div>))}
          <div ref={fim} />
        </div>
        <form onSubmit={enviar} className="flex items-center gap-3 px-4 py-3 border-t border-[#262626] shrink-0"><Avatar nome={s.nome} size={32} ouro /><input id="novo-comentario" autoFocus value={t} onChange={(e) => setT(e.target.value)} placeholder={`Comente como ${s.user}...`} className="flex-1 bg-transparent text-[14px] focus:outline-none placeholder-[#737373]" /><button type="submit" disabled={!t.trim()} className="text-[14px] font-semibold text-[#FFC107] disabled:opacity-40">Publicar</button></form>
      </div>
    </div>
  );
}

/* ====== CRIAR ====== */
function Criar({ fechar, ctx, inicial }) {
  const { s, up, go, ganharXP, toast } = ctx;
  const [tipo, setTipo] = useState(inicial && inicial !== true ? inicial : null);
  const [vid, setVid] = useState({ legenda: '', tag: 'Aviso', destino: 'agenda', tone: 'ouro' });
  const [texto, setTexto] = useState(''); const [prod, setProd] = useState({ nome: '', preco: '', cat: 'Eletrônicos', desc: '' }); const [enq, setEnq] = useState({ pergunta: '', a: '', b: '', c: '' });
  const opcoes = [['post', 'Publicação', 'Aviso, foto ou pergunta pro bairro', 'SquarePen'], ['produto', 'Anúncio no Mercadão', 'Venda algo pra outros associados', 'ShoppingBag'], ['enquete', 'Enquete', 'Pergunte a opinião da vizinhança', 'Vote'], ['animal', 'Animal perdido ou achado', 'Cadastro em 3 passos', 'PawPrint'], ['problema', 'Problema da cidade', 'Buraco, poste, lixo', 'Megaphone'], ['video', 'Vídeo no Em alta', s.admin ? 'Publicar como Conecta ABC' : 'Só a equipe do Conecta ABC publica vídeos', 'Clapperboard']];
  const escolher = (t) => { if (t === 'video' && !s.admin) { toast('Vídeos no Em alta são publicados só pela equipe do Conecta ABC'); return; } if (t === 'animal') { fechar(); go('cadastrar-animal'); return; } if (t === 'problema') { fechar(); go('problemas'); return; } setTipo(t); };
  const pubPost = (e) => { e.preventDefault(); if (!texto.trim()) return; up((p) => ({ posts: [{ id: 'u' + Date.now(), autor: p.nome, user: p.user, tipo: 'Morador', bairro: p.bairro, tempo: 'agora', texto: texto.trim(), likes: 0, coms: 0 }, ...p.posts] })); ganharXP(10, 'm-post', 'Publicado'); fechar(); go('inicio'); };
  const pubProd = (e) => { e.preventDefault(); const preco = parseInt(String(prod.preco).replace(/\D/g, ''), 10); if (!prod.nome.trim() || !preco) return; up((p) => ({ produtos: [{ id: 'u' + Date.now(), nome: prod.nome.trim(), preco, cond: 'Usado', cat: prod.cat, bairro: p.bairro, vend: p.nome, icon: { Eletrônicos: 'Smartphone', Móveis: 'Sofa', Moda: 'Shirt', Esporte: 'Bike' }[prod.cat] || 'Package', tone: 'ouro', dias: 0, desc: prod.desc || 'Sem descrição.' }, ...p.produtos] })); toast('Anúncio publicado no Mercadão'); fechar(); go('mercadao'); };
  const DESTINOS = [['agenda', 'Agenda', 'Ver evento'], ['parceiros', 'Parceiros', 'Ver parceiros'], ['noticias', 'Notícias', 'Ler notícia'], ['animais', 'Animais perdidos', 'Ajudar'], ['mercadao', 'Mercadão', 'Ver anúncios'], ['pontua', 'SAD Pontua', 'Ver prêmios']];
  const ICONE_TAG = { Aviso: 'Megaphone', Evento: 'CalendarDays', Parceiro: 'Store', Notícia: 'Newspaper', 'Animal perdido': 'PawPrint', Mercadão: 'ShoppingBag' };
  const pubVid = (e) => { e.preventDefault(); if (!s.admin || !vid.legenda.trim()) return; const d = DESTINOS.find((x) => x[0] === vid.destino); up((p) => ({ clips: [{ id: 'cv' + Date.now(), user: 'conectaabc', nome: 'Conecta ABC', icon: ICONE_TAG[vid.tag] || 'Clapperboard', tone: vid.tone, legenda: vid.legenda.trim(), som: 'som original · Conecta ABC', likes: 0, coms: 0, views: '0', cta: [d[2], d[0]], tag: vid.tag }, ...p.clips] })); toast('Vídeo publicado no Em alta'); fechar(); ctx.abrirClip(0); };
  const pubEnq = (e) => { e.preventDefault(); const ops = [enq.a, enq.b, enq.c].map((x) => x.trim()).filter(Boolean); if (!enq.pergunta.trim() || ops.length < 2) return; up((p) => ({ enquetes: [{ id: 'u' + Date.now(), pergunta: enq.pergunta.trim(), autor: p.nome, opcoes: ops.map((o) => [o, 0]), dias: 7 }, ...p.enquetes] })); toast('Enquete publicada'); fechar(); go('enquetes'); };
  return (
    <div className="fixed inset-0 z-[90] bg-black/70 flex items-end sm:items-center justify-center" onClick={fechar}>
      <div onClick={(e) => e.stopPropagation()} className="fade w-full sm:w-[480px] max-h-[88vh] overflow-y-auto bg-[#121212] rounded-t-2xl sm:rounded-xl" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom,0px) + 8px)' }}>
        <div className="relative h-12 grid place-items-center border-b border-[#262626]">{tipo && <button onClick={() => setTipo(null)} className="absolute left-3 top-3" aria-label="Voltar"><Icon name="ArrowLeft" size={22} /></button>}<b className="text-[15px]">{tipo ? { post: 'Nova publicação', produto: 'Novo anúncio', enquete: 'Nova enquete', video: 'Novo vídeo · Em alta' }[tipo] : 'Criar'}</b><button onClick={fechar} className="absolute right-3 top-3" aria-label="Fechar"><Icon name="X" size={22} /></button></div>
        {!tipo && <div className="p-2">{opcoes.map(([id, t, d, ic]) => (<button key={id} onClick={() => escolher(id)} aria-disabled={id === 'video' && !s.admin} className={`w-full flex items-center gap-3.5 p-3 rounded-lg text-left ${id === 'video' && !s.admin ? 'opacity-50 cursor-not-allowed' : 'hover:bg-[#1A1A1A]'}`}><span className="w-11 h-11 rounded-full bg-[#262626] grid place-items-center"><Icon name={ic} size={21} className="text-[#FFC107]" /></span><span className="flex-1"><b className="block text-[15px] font-semibold">{t}</b><span className="text-[13px] text-[#A8A8A8]">{d}</span></span>{id === 'video' && (s.admin ? <Pill cor="ouro">ADM</Pill> : <Icon name="Lock" size={18} className="text-[#A8A8A8]" />)}</button>))}</div>}
        {tipo === 'post' && <form onSubmit={pubPost} className="p-4"><div className="flex gap-3"><Avatar nome={s.nome} size={38} ouro /><div className="flex-1"><b className="text-[14px]">{s.nome}</b><p className="text-[12px] text-[#A8A8A8]">Publicando em {s.bairro}</p></div></div><textarea id="criar-post" autoFocus rows={5} value={texto} onChange={(e) => setTexto(e.target.value)} placeholder={`No que você está pensando, ${s.nome.split(' ')[0]}?`} className="w-full mt-3 bg-transparent text-[17px] resize-none focus:outline-none placeholder-[#737373]" /><Btn type="submit" disabled={!texto.trim()} className="w-full h-10">Publicar (+10 XP)</Btn></form>}
        {tipo === 'produto' && <form onSubmit={pubProd} className="p-4 space-y-3"><Campo label="O que você está vendendo?"><input id="prod-nome" className={inputCls} value={prod.nome} onChange={(e) => setProd({ ...prod, nome: e.target.value })} placeholder="Ex: Bicicleta aro 26" /></Campo><div className="grid grid-cols-2 gap-3"><Campo label="Preço (R$)"><input id="prod-preco" inputMode="numeric" className={inputCls} value={prod.preco} onChange={(e) => setProd({ ...prod, preco: e.target.value })} placeholder="350" /></Campo><Campo label="Categoria"><select id="prod-cat" className={inputCls} value={prod.cat} onChange={(e) => setProd({ ...prod, cat: e.target.value })}>{['Eletrônicos', 'Móveis', 'Moda', 'Esporte', 'Outros'].map((c) => <option key={c}>{c}</option>)}</select></Campo></div><Campo label="Descrição"><textarea id="prod-desc" rows={3} className={inputCls + ' h-auto py-2.5'} value={prod.desc} onChange={(e) => setProd({ ...prod, desc: e.target.value })} placeholder="Estado, tamanho, retirada..." /></Campo><Btn type="submit" disabled={!prod.nome.trim() || !prod.preco} className="w-full h-10">Publicar anúncio</Btn></form>}
        {tipo === 'video' && s.admin && <form onSubmit={pubVid} className="p-4 space-y-3">
          <div className="flex items-center gap-2.5 rounded-lg bg-[#1A1503] border border-[#FFC107]/40 px-3 py-2.5 text-[13px]"><Icon name="ShieldCheck" size={18} className="text-[#FFC107]" />Publicando como <b>@conectaabc</b> (conta oficial)</div>
          <div className={`relative aspect-[9/16] max-h-[220px] mx-auto rounded-lg overflow-hidden bg-gradient-to-br ${TONES[vid.tone]}`}><span className="absolute inset-0 grid place-items-center"><Icon name={ICONE_TAG[vid.tag] || 'Clapperboard'} size={48} className="text-white/80" /></span><span className="absolute bottom-2 inset-x-2 text-[11px] font-semibold line-clamp-2">{vid.legenda || 'Prévia do vídeo'}</span></div>
          <button type="button" onClick={() => toast('Envio do arquivo de vídeo entra quando o app tiver servidor')} className="w-full h-11 rounded-lg border border-dashed border-[#363636] text-[13px] text-[#A8A8A8] flex items-center justify-center gap-2"><Icon name="Upload" size={17} />Selecionar arquivo de vídeo</button>
          <Campo label="Legenda"><textarea id="vid-legenda" rows={2} className={inputCls + ' h-auto py-2.5'} value={vid.legenda} onChange={(e) => setVid({ ...vid, legenda: e.target.value })} placeholder="Ex: Hoje tem feira no Paço, chega junto!" /></Campo>
          <div className="grid grid-cols-2 gap-3"><Campo label="Etiqueta"><select id="vid-tag" className={inputCls} value={vid.tag} onChange={(e) => setVid({ ...vid, tag: e.target.value })}>{Object.keys(ICONE_TAG).map((t) => <option key={t}>{t}</option>)}</select></Campo>
            <Campo label="Botão leva para"><select id="vid-destino" className={inputCls} value={vid.destino} onChange={(e) => setVid({ ...vid, destino: e.target.value })}>{DESTINOS.map(([r, l]) => <option key={r} value={r}>{l}</option>)}</select></Campo></div>
          <Campo label="Cor do fundo"><div className="flex gap-2">{Object.keys(TONES).map((t) => <button key={t} type="button" onClick={() => setVid({ ...vid, tone: t })} aria-label={t} className={`w-9 h-9 rounded-full bg-gradient-to-br ${TONES[t]} ${vid.tone === t ? 'ring-2 ring-[#FFC107] ring-offset-2 ring-offset-[#121212]' : ''}`} />)}</div></Campo>
          <Btn type="submit" disabled={!vid.legenda.trim()} className="w-full h-10">Publicar vídeo</Btn>
        </form>}
        {tipo === 'enquete' && <form onSubmit={pubEnq} className="p-4 space-y-3"><Campo label="Pergunta"><input id="enq-p" className={inputCls} value={enq.pergunta} onChange={(e) => setEnq({ ...enq, pergunta: e.target.value })} placeholder="Ex: Feira de domingo ou sábado?" /></Campo>{['a', 'b', 'c'].map((k, i) => <Campo key={k} label={`Opção ${i + 1}${i === 2 ? ' (opcional)' : ''}`}><input id={'enq-' + k} className={inputCls} value={enq[k]} onChange={(e) => setEnq({ ...enq, [k]: e.target.value })} /></Campo>)}<Btn type="submit" disabled={!enq.pergunta.trim() || !enq.a.trim() || !enq.b.trim()} className="w-full h-10">Publicar enquete</Btn></form>}
      </div>
    </div>
  );
}

/* ====== MAPA ====== */
/* ====== TELAS ====== */
/* ====== CLIPES (Em alta, estilo vídeo vertical) ====== */
const CLIPS = [
  { id: 'c-e2', user: 'conectaabc', nome: 'Conecta ABC', com: 'rimaabc', icon: 'Mic', tone: 'roxo', legenda: 'Aquecimento pra batalha de sábado no Parque Celso Daniel 🔥 #rimaABC #santoandre', som: 'som original · Conecta ABC', likes: 12400, coms: 318, views: '98 mil', cta: ['Ver evento', 'evento-e2'], tag: 'Evento' },
  { id: 'c-p1', user: 'conectaabc', nome: 'Conecta ABC', com: 'pizzariadavila', icon: 'Pizza', tone: 'lar', legenda: 'Saindo do forno a lenha agora. Associado do Clube tem 15% 🍕', som: 'som original · Conecta ABC', likes: 3820, coms: 96, views: '41 mil', cta: ['Pegar cupom', 'parceiro-p1'], tag: 'Parceiro' },
  { id: 'c-pet3', user: 'conectaabc', nome: 'Conecta ABC', com: 'protetores.abc', icon: 'Dog', tone: 'azul', legenda: 'A Luna sumiu na Casa Branca. Compartilha pra ajudar ela a voltar pra casa 🙏', som: 'som original · Conecta ABC', likes: 8710, coms: 540, views: '120 mil', cta: ['Ajudar a Luna', 'animal-pet3'], tag: 'Animal perdido' },
  { id: 'c-n1', user: 'conectaabc', nome: 'Conecta ABC', com: 'prefeitura.sa', icon: 'Bike', tone: 'verde', legenda: 'Primeira volta na nova ciclofaixa do Centro até o Parque Celso Daniel 🚲', som: 'som original · Conecta ABC', likes: 2140, coms: 211, views: '33 mil', cta: ['Ler notícia', 'noticia-n1'], tag: 'Notícia' },
  { id: 'c-e3', user: 'conectaabc', nome: 'Conecta ABC', com: 'corrida5kabc', icon: 'Flame', tone: 'lar', legenda: 'Treino de domingo pra Corrida 5K. Associado tem 20% na inscrição. Bora?', som: 'som original · Conecta ABC', likes: 1590, coms: 44, views: '18 mil', cta: ['Ver evento', 'evento-e3'], tag: 'Evento' },
  { id: 'c-prod3', user: 'conectaabc', nome: 'Conecta ABC', com: 'jvitor', icon: 'Gamepad2', tone: 'roxo', legenda: 'Vendendo meu PS5 completinho, tudo funcionando. Chama no Mercadão 🎮', som: 'som original · Conecta ABC', likes: 640, coms: 37, views: '9 mil', cta: ['Ver anúncio', 'produto-prod3'], tag: 'Mercadão' },
  { id: 'c-e5', user: 'conectaabc', nome: 'Conecta ABC', com: 'pagodedavila', icon: 'Music', tone: 'vinho', legenda: 'Sexta tem pagode na Vila Luzita. Entrada com 1 kg de alimento 🎶', som: 'som original · Conecta ABC', likes: 5230, coms: 188, views: '62 mil', cta: ['Ver evento', 'evento-e5'], tag: 'Evento' },
];
const kfmt = (n) => (n >= 1000 ? (n / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mil' : String(n));

function EmAltaCarrossel({ ctx }) {
  const { abrirClip, go } = ctx;
  return (
    <section className="border-b border-[#262626] md:border md:rounded-lg md:mb-4 py-3">
      <div className="flex items-center justify-between px-3 md:px-4 mb-2.5"><b className="text-[15px] flex items-center gap-1.5"><Icon name="Flame" size={18} className="text-[#FE2C55]" />Em alta no ABC</b><button onClick={() => go('agora')} className="text-[13px] font-semibold text-[#FFC107]">Ver tudo</button></div>
      <div className="flex gap-2 overflow-x-auto no-scrollbar px-3 md:px-4">
        {ctx.clips.map((c, i) => (
          <button key={c.id} onClick={() => abrirClip(i)} className="relative w-[118px] shrink-0 aspect-[9/16] rounded-lg overflow-hidden text-left">
            <div className={`absolute inset-0 bg-gradient-to-br ${TONES[c.tone]} clipbg`} />
            <span className="absolute inset-0 grid place-items-center"><Icon name={c.icon} size={40} className="text-white/80 flutua" strokeWidth={1.5} /></span>
            <span className="absolute top-1.5 left-1.5"><span className="text-[10px] font-bold bg-black/50 rounded px-1.5 py-0.5">{c.tag}</span></span>
            <span className="absolute inset-x-0 bottom-0 p-2 bg-gradient-to-t from-black/80 to-transparent"><span className="flex items-center gap-1 text-[12px] font-semibold"><Icon name="Play" size={12} fill="#fff" />{c.views}</span><span className="block text-[11px] text-white/80 truncate">@conectaabc</span></span>
          </button>
        ))}
      </div>
    </section>
  );
}

function Clip({ c, ativo, ctx }) {
  const { s, up, curtir, abrirComentarios, go, toast, toggleSalvo } = ctx;
  const [coracao, setCoracao] = useState(0);
  const curtido = s.curtidas.includes(c.id); const salvo = s.salvos.includes(c.id); const seg = s.seguindo.includes(c.user);
  const nComs = c.coms + (s.comentarios[c.id] || []).length;
  const dbl = () => { if (!curtido) curtir(c.id); setCoracao((x) => x + 1); };
  const Acao = ({ icon, n, on, cor, onClick, label, fill }) => (
    <button onClick={onClick} className="flex flex-col items-center gap-1" aria-label={label}>
      <span className="w-12 h-12 rounded-full bg-black/25 md:bg-[#1A1A1A] grid place-items-center"><Icon name={icon} size={28} className={on ? cor : 'text-white'} fill={on ? fill : 'none'} /></span>
      <span className="text-[12px] font-semibold tabnum drop-shadow">{n}</span>
    </button>
  );
  const acoes = (
    <>
      <div className="relative mb-2">
        <span className="block rounded-full border-2 border-white"><span className="w-[44px] h-[44px] rounded-full bg-[#FFC107] grid place-items-center"><SadLogo size={26} dark /></span></span>
        <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full grid place-items-center bg-black" title="Conta oficial"><Verificado /></span>
      </div>
      <Acao icon="Heart" n={kfmt(c.likes + (curtido ? 1 : 0))} on={curtido} cor="text-[#FE2C55]" fill="#FE2C55" onClick={() => curtir(c.id)} label="Curtir" />
      <Acao icon="MessageCircle" n={kfmt(nComs)} onClick={() => abrirComentarios({ id: c.id, autor: 'Conecta ABC', user: 'conectaabc', texto: c.legenda, tipo: 'Parceiro' })} label="Comentários" />
      <Acao icon="Bookmark" n={salvo ? 'Salvo' : 'Salvar'} on={salvo} cor="text-[#FFC107]" fill="#FFC107" onClick={() => toggleSalvo(c.id)} label="Salvar" />
      <Acao icon="Share" n="Enviar" onClick={() => toast('Link do vídeo copiado')} label="Compartilhar" />
      <span className={`mt-1 w-11 h-11 rounded-full bg-gradient-to-br from-[#2A2A2A] to-black border-[6px] border-[#1A1A1A] grid place-items-center ${ativo ? 'gira' : ''}`}><Icon name="Music" size={14} /></span>
    </>
  );
  return (
    <div className="h-full w-full flex items-end justify-center md:gap-4 snap-start snap-always md:py-4">
      <div className="relative h-full w-full md:w-auto md:aspect-[9/16] md:rounded-xl overflow-hidden select-none" onDoubleClick={dbl}>
        <div className={`absolute inset-0 bg-gradient-to-br ${TONES[c.tone]} clipbg`} />
        <span className="absolute inset-0 grid place-items-center"><Icon name={c.icon} size={150} className={`text-white/75 ${ativo ? 'flutua' : ''}`} strokeWidth={1.2} /></span>
        {coracao > 0 && <span key={coracao} className="pop absolute inset-0 grid place-items-center pointer-events-none"><Icon name="Heart" size={120} fill="#FE2C55" className="text-[#FE2C55] drop-shadow-xl" /></span>}
        <div className="md:hidden absolute right-2 bottom-24 flex flex-col items-center gap-3.5">{acoes}</div>
        <div className="absolute inset-x-0 bottom-0 p-4 pr-20 md:pr-4 pb-5 bg-gradient-to-t from-black/85 via-black/40 to-transparent">
          <p className="text-[16px] font-bold flex items-center gap-1.5">@conectaabc<Verificado /><span className="text-[11px] font-semibold bg-white/15 rounded px-1.5 py-0.5">Oficial</span></p>
          {c.com && <p className="text-[13px] text-white/80">com @{c.com}</p>}
          <p className="text-[14px] mt-1 leading-snug">{c.legenda}</p>
          <p className="text-[13px] mt-2 flex items-center gap-1.5 text-white/90"><Icon name="Music" size={13} /><span className="truncate">{c.som}</span></p>
          <button onClick={() => go(c.cta[1])} className="mt-3 h-9 px-3.5 rounded-md bg-[#FFC107] text-[#0A0A0A] text-[13px] font-bold flex items-center gap-1">{c.cta[0]}<Icon name="ChevronRight" size={16} /></button>
        </div>
        <div className="absolute inset-x-0 bottom-0 h-[3px] bg-white/20">{ativo && <span key={c.id + ativo} className="barra block h-full bg-white" style={{ animationDuration: '9s' }} />}</div>
      </div>
      <div className="hidden md:flex flex-col items-center gap-4 pb-6">{acoes}</div>
    </div>
  );
}

function TelaEmAlta(ctx) {
  const { clipInicial } = ctx;
  const [ativo, setAtivo] = useState(clipInicial || 0); const [aba, setAba] = useState('Para você');
  const ref = useRef(null);
  useEffect(() => { const el = ref.current; if (el && clipInicial) el.scrollTop = clipInicial * el.clientHeight; }, []);
  const onScroll = () => { const el = ref.current; if (!el) return; const i = Math.round(el.scrollTop / el.clientHeight); if (i !== ativo) setAtivo(i); };
  const lista = ctx.clips;
  return (
    <div className="relative bg-black h-[calc(100dvh-50px-env(safe-area-inset-bottom,0px))] md:h-screen">
      <div className="absolute top-0 inset-x-0 z-10 flex justify-center gap-6 pt-3 pointer-events-none" style={{ paddingTop: 'calc(env(safe-area-inset-top,0px) + 12px)' }}>
        <span className="text-[16px] font-bold pb-1 border-b-2 border-white drop-shadow">Em alta no ABC</span>
        {ctx.s.admin && <button onClick={() => ctx.abrirCriar('video')} className="pointer-events-auto absolute right-3 h-8 px-3 rounded-full bg-[#FFC107] text-black text-[12px] font-bold flex items-center gap-1" style={{ top: 'calc(env(safe-area-inset-top,0px) + 8px)' }}><Icon name="Plus" size={14} strokeWidth={3} />Vídeo</button>}
      </div>
      <div ref={ref} onScroll={onScroll} className="h-full overflow-y-scroll snap-y snap-mandatory no-scrollbar">
        {lista.length ? lista.map((c, i) => <div key={c.id} className="h-full"><Clip c={c} ativo={i === ativo} ctx={ctx} /></div>)
          : <div className="h-full grid place-items-center text-center px-8"><div><Icon name="UserPlus" size={40} className="mx-auto" /><p className="text-[16px] font-semibold mt-3">Você ainda não segue ninguém</p><p className="text-[14px] text-[#A8A8A8] mt-1">Toque no + do avatar nos vídeos de "Para você".</p></div></div>}
      </div>
    </div>
  );
}

/* ====== BLOCOS DA PÁGINA INICIAL ====== */
function DestaquesRotativos({ go }) {
  const N = (k) => NOTICIAS.find((n) => n.id === k);
  const itens = [
    { tag: 'Notícia', cor: 'bg-[#2563EB]', icon: N('n1').icon, tone: N('n1').tone, titulo: N('n1').titulo, sub: N('n1').fonte + ' · ' + N('n1').data, rota: 'noticia-n1' },
    { tag: 'Evento', cor: 'bg-[#FFC107] text-black', icon: EVENTOS[1].icon, tone: EVENTOS[1].tone, titulo: EVENTOS[1].titulo, sub: `${EVENTOS[1].wd}, ${EVENTOS[1].dia} ${EVENTOS[1].mes} · ${EVENTOS[1].hora}`, rota: 'evento-e2' },
    { tag: 'Notícia', cor: 'bg-[#2563EB]', icon: N('n3').icon, tone: N('n3').tone, titulo: N('n3').titulo, sub: N('n3').fonte + ' · ' + N('n3').data, rota: 'noticia-n3' },
    { tag: 'Animal perdido', cor: 'bg-[#DC2626]', icon: PETS0[2].icon, tone: PETS0[2].tone, titulo: `${PETS0[2].nome} sumiu na ${PETS0[2].bairro}`, sub: PETS0[2].raca + ' · ' + PETS0[2].quando, rota: 'animal-pet3' },
    { tag: 'Notícia', cor: 'bg-[#2563EB]', icon: N('n4').icon, tone: N('n4').tone, titulo: N('n4').titulo, sub: N('n4').fonte + ' · ' + N('n4').data, rota: 'noticia-n4' },
    { tag: 'Parceiro', cor: 'bg-[#16A34A]', icon: PARCEIROS[0].icon, tone: PARCEIROS[0].tone, titulo: `${PARCEIROS[0].nome}: ${PARCEIROS[0].beneficio}`, sub: 'Cupom pra associados', rota: 'parceiro-p1' },
    { tag: 'Alerta', cor: 'bg-[#F97316]', icon: N('n5').icon, tone: N('n5').tone, titulo: N('n5').titulo, sub: N('n5').fonte + ' · ' + N('n5').data, rota: 'noticia-n5' },
  ];
  const [i, setI] = useState(0); const [pausa, setPausa] = useState(false); const toque = useRef(null);
  useEffect(() => { if (pausa || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return; const t = setInterval(() => setI((x) => (x + 1) % itens.length), 4000); return () => clearInterval(t); }, [pausa, i]);
  const mover = (d) => setI((x) => (x + d + itens.length) % itens.length);
  return (
    <section className="px-3 md:px-0 py-3 md:pt-0 border-b border-[#262626] md:border-0 md:mb-4" onMouseEnter={() => setPausa(true)} onMouseLeave={() => setPausa(false)}>
      <div className="relative overflow-hidden rounded-xl" onTouchStart={(e) => { toque.current = e.touches[0].clientX; setPausa(true); }} onTouchEnd={(e) => { const dx = e.changedTouches[0].clientX - (toque.current || 0); if (Math.abs(dx) > 40) mover(dx < 0 ? 1 : -1); setPausa(false); }}>
        <div className="flex transition-transform duration-500 ease-out" style={{ transform: `translateX(-${i * 100}%)` }}>
          {itens.map((it, k) => (
            <button key={k} onClick={() => go(it.rota)} tabIndex={k === i ? 0 : -1} aria-hidden={k !== i} className="relative w-full shrink-0 h-[150px] text-left">
              <Ph tone={it.tone} icon={it.icon} className="absolute inset-0" size={84} />
              <span className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/45 to-transparent" />
              <span className="absolute left-4 top-3.5 right-16"><span className={`inline-block text-[11px] font-bold px-2 py-0.5 rounded ${it.cor}`}>{it.tag}</span><b className="block text-[18px] leading-snug mt-2 line-clamp-2">{it.titulo}</b><span className="block text-[13px] text-white/75 mt-1">{it.sub}</span></span>
            </button>
          ))}
        </div>
        <button onClick={() => mover(-1)} aria-label="Anterior" className="hidden md:grid absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 place-items-center"><Icon name="ChevronLeft" size={18} /></button>
        <button onClick={() => mover(1)} aria-label="Próximo" className="hidden md:grid absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 place-items-center"><Icon name="ChevronRight" size={18} /></button>
      </div>
      <div className="flex justify-center gap-1.5 mt-2.5">{itens.map((_, k) => <button key={k} onClick={() => setI(k)} aria-label={'Destaque ' + (k + 1)} className={`h-1.5 rounded-full transition-all ${k === i ? 'w-5 bg-[#FFC107]' : 'w-1.5 bg-[#363636]'}`} />)}</div>
    </section>
  );
}
const BlocoBox = ({ titulo, icon, acao, children }) => (
  <section className="border-b border-[#262626] md:border md:rounded-lg md:mb-4 px-3 md:px-4 py-4 fade">
    <div className="flex items-center justify-between mb-3"><b className="text-[15px] flex items-center gap-2">{icon && <Icon name={icon} size={18} className="text-[#FFC107]" />}{titulo}</b>{acao}</div>
    {children}
  </section>
);
function RankingBloco({ s, go, nv }) {
  const lista = [...RANKING, { nome: s.nome, bairro: s.bairro, xp: s.xp, nivel: NIVEIS[nv][0], me: true }].sort((a, b) => b.xp - a.xp);
  const medalha = ['#FFC107', '#C0C0C0', '#CD7F32'];
  return (
    <BlocoBox titulo="Ranking dos membros" icon="Trophy" acao={<button onClick={() => go('pontua')} className="text-[13px] font-semibold text-[#FFC107]">Ver ranking</button>}>
      <p className="text-[12px] text-[#A8A8A8] -mt-2 mb-2">Temporada de novembro · zera dia 30</p>
      <div className="space-y-1">{lista.map((u, i) => (
        <div key={u.nome} className={`flex items-center gap-3 py-2 ${u.me ? 'bg-[#FFC107]/10 rounded-lg -mx-2 px-2' : ''}`}>
          <span className="w-6 text-center font-extrabold tabnum" style={{ color: medalha[i] || '#A8A8A8' }}>{i + 1}</span>
          <Avatar nome={u.nome} size={36} ouro={u.me} anel={i === 0} />
          <span className="flex-1 min-w-0"><b className="text-[14px] block truncate">{u.nome}{u.me && ' (você)'}</b><span className="text-[12px] text-[#A8A8A8]">{u.nivel} · {u.bairro}</span></span>
          <span className="text-[14px] font-bold tabnum">{fmt(u.xp)} <span className="text-[#A8A8A8] font-normal text-[12px]">XP</span></span>
        </div>))}</div>
    </BlocoBox>
  );
}
function ComunidadesBloco({ s, go, toggleComunidade }) {
  return (
    <BlocoBox titulo="Comunidades pra você" icon="Users" acao={<button onClick={() => go('comunidades')} className="text-[13px] font-semibold text-[#FFC107]">Ver todas</button>}>
      <div className="flex gap-2.5 overflow-x-auto no-scrollbar -mx-3 md:-mx-4 px-3 md:px-4">{COMUNIDADES.map((c) => { const m = s.comunidades.includes(c.id); return (
        <div key={c.id} className="w-[150px] shrink-0 border border-[#262626] rounded-lg p-3 text-center"><Ph tone={c.tone} icon={c.icon} className="w-16 h-16 rounded-full mx-auto" size={26} /><b className="block text-[13px] mt-2 truncate">{c.nome}</b><p className="text-[11px] text-[#A8A8A8] tabnum">{fmt(c.membros + (m ? 1 : 0))} membros</p>
          <button onClick={() => toggleComunidade(c.id)} className={`mt-2.5 w-full h-8 rounded-lg text-[13px] font-semibold ${m ? 'bg-[#262626]' : 'bg-[#FFC107] text-[#0A0A0A]'}`}>{m ? 'Participando' : 'Participar'}</button></div>); })}</div>
    </BlocoBox>
  );
}

/* Itens do feed, um por tipo */
function ItemFeed({ it, ctx }) {
  const { s, go, toggleSalvo, presenca, toast } = ctx; const d = it.d;
  if (it.k === 'post') return <PostFeed p={d} ctx={ctx} />;
  if (it.k === 'parceiro') return (
    <CardFeed cab={<PostCabecalho nome={d.nome} sub="Parceiro do Clube · Patrocinado" ouro verificado onNome={() => go('parceiro-' + d.id)} direita={<Btn tipo="ghost" className="!px-0 h-auto" onClick={() => go('parceiro-' + d.id)}>Ver</Btn>} />}
      midia={<button onClick={() => go('parceiro-' + d.id)} className="block w-full"><Ph tone={d.tone} icon={d.icon} className="aspect-[4/3] md:rounded-md w-full" size={72} /></button>}
      rodape={<button onClick={() => go('parceiro-' + d.id)} className="mx-3 md:mx-0 mt-3 w-[calc(100%-24px)] md:w-full h-10 rounded-lg bg-[#FFC107] text-[#0A0A0A] text-[14px] font-semibold flex items-center justify-between px-4">Pegar cupom: {d.beneficio}<Icon name="ChevronRight" size={18} /></button>}>
      <p className="text-[14px] pt-3"><b className="mr-1.5">{d.user}</b>{d.desc}</p>
    </CardFeed>);
  if (it.k === 'evento') { const vou = s.presencas.includes(d.id); return (
    <CardFeed cab={<PostCabecalho nome="Agenda do ABC" sub={`${d.local} · ${d.wd}, ${d.dia} ${d.mes}`} ouro onNome={() => go('agenda')} />}
      midia={<button onClick={() => go('evento-' + d.id)} className="relative block w-full"><Ph tone={d.tone} icon={d.icon} className="aspect-[16/9] md:rounded-md w-full" size={64} /><span className="absolute top-3 left-3 bg-white text-black rounded-lg px-2.5 py-1 text-center leading-none"><span className="block text-[10px] font-bold uppercase text-[#DC2626]">{d.mes}</span><span className="block text-[22px] font-extrabold tabnum">{d.dia}</span></span></button>}>
      <p className="text-[16px] font-semibold pt-3">{d.titulo}</p><p className="text-[13px] text-[#A8A8A8] tabnum">{d.hora} · {fmt(d.vao + (vou ? 1 : 0))} pessoas vão</p>
      <div className="flex gap-2 mt-3"><Btn tipo={vou ? 'ok' : 'ouro'} onClick={() => presenca(d.id)} className="flex-1"><Icon name={vou ? 'CircleCheck' : 'Star'} size={16} />{vou ? 'Vou' : 'Tenho interesse'}</Btn><Btn tipo="sec" onClick={() => toast('Convite copiado')}><Icon name="Share2" size={16} /></Btn></div>
    </CardFeed>); }
  if (it.k === 'produto') return (
    <CardFeed cab={<PostCabecalho nome={d.vend} sub={`Mercadão da SAD · ${d.bairro}`} onNome={() => go('mercadao')} direita={<button onClick={() => toggleSalvo(d.id)} aria-label="Salvar"><Icon name="Bookmark" size={22} fill={s.salvos.includes(d.id) ? '#F5F5F5' : 'none'} /></button>} />}
      midia={<button onClick={() => go('produto-' + d.id)} className="block w-full"><Ph tone={d.tone} icon={d.icon} className="aspect-square md:rounded-md w-full" size={80} /></button>}>
      <div className="flex items-end justify-between pt-3 gap-3"><div className="min-w-0"><p className="text-[20px] font-bold tabnum flex items-center gap-2">{brl(d.preco)}<Baixou p={d} /></p><p className="text-[14px] truncate">{d.nome}</p><p className="text-[12px] text-[#A8A8A8]">{d.cond}</p></div><Btn tipo="zap" onClick={() => go('produto-' + d.id)}><Icon name="MessageCircle" size={16} />Chamar</Btn></div>
    </CardFeed>);
  if (it.k === 'animal') return (
    <CardFeed cab={<PostCabecalho nome="Animais perdidos" sub={`${d.bairro} · ${d.quando}`} ouro onNome={() => go('animais')} />}
      midia={<button onClick={() => go('animal-' + d.id)} className="relative block w-full"><Ph tone={d.tone} icon={d.icon} className="aspect-[4/3] md:rounded-md w-full" size={80} /><span className="absolute top-3 left-3"><Pill cor={corPet(d.status)}>{d.status.toUpperCase()}</Pill></span></button>}
      rodape={<div className="flex gap-2 px-3 md:px-0 mt-3"><Btn onClick={() => toast('Avisamos o tutor. Obrigado!')} className="flex-1"><Icon name="Eye" size={16} />{d.status === 'Perdido' ? 'Vi esse animal' : 'Sou o tutor'}</Btn><Btn tipo="sec" onClick={() => toast('Compartilhado nos seus stories')} className="flex-1"><Icon name="Repeat2" size={16} />Compartilhar</Btn></div>}>
      <p className="text-[14px] pt-3"><b className="mr-1.5">{d.nome}</b>{d.raca}. {d.desc}</p>
    </CardFeed>);
  if (it.k === 'noticia') return (
    <CardFeed cab={<PostCabecalho nome={d.fonte} sub={`Notícias da cidade · ${d.data}`} verificado onNome={() => go('noticias')} />}
      midia={<button onClick={() => go('noticia-' + d.id)} className="block w-full text-left md:border md:border-[#262626] md:rounded-md overflow-hidden"><Ph tone={d.tone} icon={d.icon} className="aspect-[16/9] w-full" size={60} /><div className="bg-[#121212] px-3 py-2.5"><p className="text-[11px] uppercase tracking-wide text-[#A8A8A8]">{d.cat} · conectaabc.com.br</p><p className="text-[15px] font-semibold leading-snug">{d.titulo}</p><p className="text-[13px] text-[#A8A8A8] mt-0.5 line-clamp-2">{d.resumo}</p></div></button>} />);
  if (it.k === 'vaga') return (
    <CardFeed cab={<PostCabecalho nome={d.empresa} sub={`Vaga · ${d.bairro}`} onNome={() => go('vagas')} />}>
      <div className="border border-[#262626] rounded-lg p-3.5"><p className="text-[16px] font-semibold">{d.cargo}</p><p className="text-[13px] text-[#A8A8A8]">{d.regime} · {d.modo} · {d.salario}</p><div className="flex gap-2 mt-3"><Btn onClick={() => toast('Candidatura enviada!')} className="flex-1">Candidatar-se</Btn><Btn tipo="sec" onClick={() => go('vagas')}>Mais vagas</Btn></div></div>
    </CardFeed>);
  return null;
}

function TelaExplorar({ go, produtos }) {
  const blocos = [
    ...PARCEIROS.map((p) => ['parceiro-' + p.id, p.icon, p.tone, p.nome, 'TicketPercent']), ...EVENTOS.slice(0, 4).map((e) => ['evento-' + e.id, e.icon, e.tone, e.titulo, 'CalendarDays']),
    ...produtos.slice(0, 5).map((p) => ['produto-' + p.id, p.icon, p.tone, p.nome, 'ShoppingBag']), ...PETS0.map((a) => ['animal-' + a.id, a.icon, a.tone, a.nome, 'PawPrint']), ...NOTICIAS.slice(0, 3).map((n) => ['noticia-' + n.id, n.icon, n.tone, n.titulo, 'Newspaper']),
  ];
  const [q, setQ] = useState('');
  return (
    <div className="mx-auto w-full max-w-[935px] md:px-6 pt-3 md:pt-8 pb-24 md:pb-12">
      <div className="px-3 md:px-0 mb-3"><button onClick={() => go('busca')} className="w-full"><div className="h-10 bg-[#1A1A1A] rounded-lg px-3 flex items-center gap-2 text-[#A8A8A8] text-[14px]"><Icon name="Search" size={17} />Pesquisar parceiros, eventos, produtos...</div></button></div>
      <div className="flex gap-2 overflow-x-auto no-scrollbar px-3 md:px-0 mb-3">{[['mapa', 'Mapa', 'MapPin'], ['agenda', 'Agenda', 'CalendarDays'], ['parceiros', 'Parceiros', 'Store'], ['mercadao', 'Mercadão', 'ShoppingBag'], ['animais', 'Animais', 'PawPrint'], ['noticias', 'Notícias', 'Newspaper'], ['vagas', 'Vagas', 'Briefcase'], ['imoveis', 'Imóveis', 'Building2']].map(([r, l, ic]) => <button key={r} onClick={() => go(r)} className="h-8 px-3 rounded-lg bg-[#1A1A1A] hover:bg-[#262626] text-[13px] font-semibold flex items-center gap-1.5 shrink-0"><Icon name={ic} size={15} />{l}</button>)}</div>
      <div className="grid grid-cols-3 gap-[2px] md:gap-1">{blocos.map(([r, ic, tone, t, tipo], i) => (
        <button key={r} onClick={() => go(r)} className={`group relative ${i % 10 === 2 ? 'row-span-2' : ''}`}><Ph tone={tone} icon={ic} className={`w-full h-full ${i % 10 === 2 ? 'min-h-[100%]' : 'aspect-square'}`} size={i % 10 === 2 ? 56 : 36} />
          <span className="absolute top-2 right-2"><Icon name={tipo} size={16} className="text-white drop-shadow" /></span>
          <span className="absolute inset-0 bg-black/55 opacity-0 group-hover:opacity-100 transition-opacity grid place-items-center p-2 text-[13px] font-semibold text-center">{t}</span></button>))}</div>
    </div>
  );
}

function TelaBusca({ go, produtos, q, setQ }) {
  const t = q.trim().toLowerCase();
  const res = t.length < 2 ? [] : [
    ...PARCEIROS.filter((p) => (p.nome + p.beneficio + p.bairro).toLowerCase().includes(t)).map((p) => [p.nome, 'Parceiro · ' + p.beneficio, 'parceiro-' + p.id, p.icon, p.tone]),
    ...EVENTOS.filter((e) => (e.titulo + e.local).toLowerCase().includes(t)).map((e) => [e.titulo, `Evento · ${e.dia} ${e.mes}`, 'evento-' + e.id, e.icon, e.tone]),
    ...produtos.filter((p) => (p.nome + p.cat).toLowerCase().includes(t)).map((p) => [p.nome, 'Mercadão · ' + brl(p.preco), 'produto-' + p.id, p.icon, p.tone]),
    ...COMUNIDADES.filter((c) => c.nome.toLowerCase().includes(t)).map((c) => [c.nome, 'Comunidade · ' + fmt(c.membros) + ' membros', 'comunidade-' + c.id, c.icon, c.tone]),
    ...NOTICIAS.filter((n) => n.titulo.toLowerCase().includes(t)).map((n) => [n.titulo, 'Notícia · ' + n.fonte, 'noticia-' + n.id, n.icon, n.tone]),
  ];
  return (
    <Pagina titulo="Pesquisa" voltar="explorar" go={go}>
      <Busca id="busca-global" valor={q} set={setQ} ph="Pesquisar" />
      {t.length < 2 && <div className="mt-5"><b className="text-[15px]">Sugestões</b><div className="flex flex-wrap gap-2 mt-3">{['pizza', 'bike', 'samba', 'farmácia', 'adoção', 'Jardim'].map((x) => <button key={x} onClick={() => setQ(x)} className="h-8 px-3 rounded-lg bg-[#1A1A1A] text-[13px]">{x}</button>)}</div></div>}
      {t.length >= 2 && !res.length && <Vazio icon="Search" texto={`Nenhum resultado para "${q}".`} />}
      <div className="mt-3">{res.map(([a, b, r, ic, tone]) => (<button key={r} onClick={() => go(r)} className="w-full flex items-center gap-3 py-2 text-left hover:bg-[#121212] rounded-lg px-1"><Ph tone={tone} icon={ic} className="w-11 h-11 rounded-full shrink-0" size={18} /><span className="min-w-0"><b className="block text-[14px] font-semibold truncate">{a}</b><span className="text-[13px] text-[#A8A8A8] truncate block">{b}</span></span></button>))}</div>
    </Pagina>
  );
}

function TelaNotificacoes({ go, toast }) {
  return (
    <Pagina titulo="Notificações" voltar="inicio" go={go}>
      <b className="text-[15px]">Hoje</b>
      <div className="mt-2">{NOTIFS.map(([ic, u, t, q], i) => (
        <div key={i} className="flex items-center gap-3 py-2.5"><span className="relative"><Avatar nome={u} size={44} ouro={u === 'Conecta ABC' || u === 'SAD Pontua'} /><span className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full bg-[#FFC107] text-[#0A0A0A] grid place-items-center border-2 border-black"><Icon name={ic} size={10} strokeWidth={3} /></span></span>
          <p className="flex-1 text-[14px] leading-snug"><b>{u}</b> {t} <span className="text-[#A8A8A8]">{q}</span></p>
          {ic === 'UserPlus' ? <Btn onClick={() => toast('Seguindo fernanda.c')} className="h-8 px-3 text-[13px]">Seguir</Btn> : <button onClick={() => go(ic === 'TicketPercent' ? 'parceiro-p5' : ic === 'CalendarDays' ? 'evento-e2' : ic === 'ThumbsUp' ? 'problemas' : ic === 'Trophy' ? 'pontua' : 'perfil')} className="text-[13px] font-semibold text-[#FFC107]">Ver</button>}
        </div>))}</div>
    </Pagina>
  );
}

function TelaPerfil(ctx) {
  const { s, up, go, nv, prox, pct, toast, produtos } = ctx;
  const [aba, setAba] = useState('posts'); const [edit, setEdit] = useState(false); const [bio, setBio] = useState(s.bio);
  if (!s.logado) return <TelaEntrar {...ctx} />;
  const meusPosts = s.posts;
  const salvos = [...PARCEIROS.filter((p) => s.salvos.includes(p.id)).map((p) => ['parceiro-' + p.id, p.icon, p.tone, p.nome]), ...produtos.filter((p) => s.salvos.includes(p.id)).map((p) => ['produto-' + p.id, p.icon, p.tone, p.nome]), ...PETS0.filter((a) => s.salvos.includes(a.id)).map((a) => ['animal-' + a.id, a.icon, a.tone, a.nome])];
  const destaques = [['carteirinha', 'Carteirinha', 'IdCard'], ['nivel', 'Meu nível', 'Trophy'], ['amigos', 'Amigos', 'Users'], ['convidar', 'Convidar', 'Send'], ['salvos', 'Salvos', 'Bookmark'], ['cupons', 'Cupons', 'TicketPercent'], ['mais', 'Menu', 'Menu']];
  return (
    <div className="mx-auto w-full max-w-[935px] px-4 md:px-6 pt-4 md:pt-8 pb-24 md:pb-12">
      <div className="flex items-center gap-5 md:gap-16 md:px-10">
        <Avatar nome={s.nome} size={86} ouro anel />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap"><h1 className="text-[20px] font-normal">{s.user}</h1><Verificado />{s.admin && <Pill cor="ouro">ADM</Pill>}<div className="hidden md:flex gap-2 ml-4"><Btn tipo="sec" onClick={() => setEdit(!edit)}>Editar perfil</Btn><Btn tipo="sec" onClick={() => go('carteirinha')}>Carteirinha</Btn></div></div>
          <div className="flex gap-6 md:gap-10 mt-3 text-[14px] tabnum"><span><b>{meusPosts.length}</b> posts</span><span><b>{s.xp}</b> XP</span><span><b>{NIVEIS[nv][0]}</b></span></div>
          <div className="hidden md:block mt-3 text-[14px]"><b>{s.nome}</b><p className="text-[#A8A8A8]">{s.bairro} · Santo André</p><p>{s.bio}</p></div>
          {s.selos.length > 0 && <div className="flex gap-1.5 mt-2 flex-wrap">{s.selos.map((x) => <Pill key={x} cor="ouro"><Icon name="Award" size={12} />{x}</Pill>)}</div>}
        </div>
      </div>
      <div className="md:hidden mt-3 text-[14px]"><b>{s.nome}</b><p className="text-[#A8A8A8]">{s.bairro} · Santo André</p><p>{s.bio}</p></div>
      <div className="mt-3 md:px-10"><div className="h-1.5 rounded-full bg-[#262626] overflow-hidden max-w-sm"><div className="h-full bg-[#FFC107]" style={{ width: pct + '%' }} /></div><p className="text-[12px] text-[#A8A8A8] mt-1 tabnum">{prox ? `${prox[1] - s.xp} XP para ${prox[0]}` : 'Nível máximo'} · {s.streak} dias de check-in</p></div>
      <div className="flex gap-2 mt-4 md:hidden"><Btn tipo="sec" onClick={() => setEdit(!edit)} className="flex-1">Editar perfil</Btn><Btn tipo="sec" onClick={() => go('carteirinha')} className="flex-1">Carteirinha</Btn></div>
      {edit && <div className="mt-4 border border-[#262626] rounded-lg p-4 fade"><Campo label="Bio"><textarea id="perfil-bio" rows={2} className={inputCls + ' h-auto py-2.5'} value={bio} onChange={(e) => setBio(e.target.value)} /></Campo><div className="flex gap-2 mt-3"><Btn onClick={() => { up({ bio }); setEdit(false); toast('Perfil atualizado'); }}>Salvar</Btn><Btn tipo="sec" onClick={() => setEdit(false)}>Cancelar</Btn></div></div>}
      <div className="flex gap-5 overflow-x-auto no-scrollbar mt-6 md:px-10">{destaques.map(([r, l, ic]) => (<button key={r} onClick={() => go(r)} className="flex flex-col items-center gap-1.5 shrink-0 w-[66px]"><span className="w-[64px] h-[64px] rounded-full border border-[#363636] p-[3px]"><span className="w-full h-full rounded-full bg-[#121212] grid place-items-center"><Icon name={ic} size={24} className="text-[#FFC107]" /></span></span><span className="text-[12px]">{l}</span></button>))}</div>
      <div className="flex justify-center gap-12 border-t border-[#262626] mt-6">{[['posts', 'Grid3x3', 'Posts'], ['salvos', 'Bookmark', 'Salvos'], ['cupons', 'TicketPercent', 'Cupons']].map(([id, ic, l]) => (<button key={id} onClick={() => setAba(id)} className={`h-12 flex items-center gap-1.5 text-[12px] font-semibold uppercase tracking-wide border-t ${aba === id ? 'border-white text-white' : 'border-transparent text-[#A8A8A8]'}`}><Icon name={ic} size={16} /><span className="hidden sm:inline">{l}</span></button>))}</div>
      {aba === 'posts' && (meusPosts.length ? <div className="grid grid-cols-3 gap-1">{meusPosts.map((p) => (<div key={p.id} className="aspect-square bg-gradient-to-br from-[#1A1503] to-[#0A0A0A] border border-[#262626] p-2 text-[12px] overflow-hidden">{p.texto}</div>))}</div> : <Vazio icon="Camera" texto="Compartilhe sua primeira publicação com o bairro." />)}
      {aba === 'salvos' && (salvos.length ? <div className="grid grid-cols-3 gap-1">{salvos.map(([r, ic, tone, t]) => (<button key={r} onClick={() => go(r)} className="relative group"><Ph tone={tone} icon={ic} className="aspect-square w-full" size={32} /><span className="absolute inset-0 bg-black/55 opacity-0 group-hover:opacity-100 grid place-items-center text-[12px] font-semibold p-1 text-center">{t}</span></button>))}</div> : <Vazio icon="Bookmark" texto="Salve parceiros, anúncios e animais pra ver aqui." />)}
      {aba === 'cupons' && (s.cupons.length ? <div className="space-y-2 mt-2">{PARCEIROS.filter((p) => s.cupons.includes(p.id)).map((p) => (<button key={p.id} onClick={() => go('parceiro-' + p.id)} className="w-full flex items-center gap-3 border border-[#262626] rounded-lg p-3 text-left"><Ph tone={p.tone} icon={p.icon} className="w-11 h-11 rounded-lg" size={20} /><span className="flex-1"><b className="text-[14px] block">{p.nome}</b><span className="text-[13px] text-[#A8A8A8]">{p.beneficio}</span></span><code className="text-[13px] font-bold text-[#FFC107]">{p.cupom}</code></button>))}</div> : <Vazio icon="TicketPercent" texto="Resgate cupons nos parceiros pra ver aqui." />)}
    </div>
  );
}
function TelaEntrar({ s, up, go, toast }) {
  const [nome, setNome] = useState(s.nome); const [bairro, setBairro] = useState(s.bairro);
  const entrar = (e) => { e.preventDefault(); if (!nome.trim()) return; const user = nome.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '.').replace(/^\.|\.$/g, ''); up({ logado: true, nome: nome.trim(), user, bairro }); toast('Bem-vindo, ' + nome.trim().split(' ')[0] + '!'); go('inicio'); };
  return (
    <div className="mx-auto w-full max-w-[350px] px-4 pt-14 pb-24">
      <div className="border border-[#262626] rounded-lg px-8 py-10 text-center"><div className="flex justify-center"><Wordmark /></div><p className="text-[#A8A8A8] text-[15px] font-semibold mt-4">Entre pra ver os descontos e o que rola no seu bairro.</p>
        <form onSubmit={entrar} className="space-y-2 mt-6 text-left"><input id="login-nome" className={inputCls + ' h-10 text-[13px]'} value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Seu nome" /><select id="login-bairro" className={inputCls + ' h-10 text-[13px]'} value={bairro} onChange={(e) => setBairro(e.target.value)}>{BAIRROS.map((b) => <option key={b}>{b}</option>)}</select><Btn type="submit" disabled={!nome.trim()} className="w-full h-9 mt-2">Entrar</Btn></form>
        <p className="text-[12px] text-[#737373] mt-5">Versão de demonstração: nenhuma senha é pedida.</p></div>
    </div>
  );
}
function TelaPontua({ s, nv, prox, pct, checkin, go }) {
  const [aba, setAba] = useState('Missões');
  const feita = (id) => s.missoes.includes(id + ':' + hoje());
  return (
    <Pagina titulo="SAD Pontua" sub="Ações viram XP, XP vira benefício." icon="Trophy" go={go}>
      <div className="border border-[#262626] rounded-xl p-4 flex items-center gap-4"><Medalha size={80} /><div className="flex-1"><p className="text-[22px] font-bold">Nível {nv + 1} · {NIVEIS[nv][0]}</p><div className="h-2 rounded-full bg-[#262626] overflow-hidden mt-2"><div className="h-full bg-[#FFC107]" style={{ width: pct + '%' }} /></div><p className="text-[13px] text-[#A8A8A8] mt-1.5 tabnum">{s.xp} / {prox ? prox[1] : s.xp} XP · {s.streak} dias seguidos</p></div></div>
      <div className="mt-4"><Tabs opcoes={['Missões', 'Ranking', 'Bairros', 'Prêmios']} valor={aba} set={setAba} /></div>
      <div className="mt-3">
        {aba === 'Missões' && <div className="divide-y divide-[#262626]">{MISSOES.map((m) => { const ok = feita(m.id); return (
          <div key={m.id} className="flex items-center gap-3 py-3"><span className="w-11 h-11 rounded-full bg-[#1A1A1A] grid place-items-center"><Icon name={m.icon} size={20} className="text-[#FFC107]" /></span><div className="flex-1"><p className="text-[14px] font-semibold">{m.titulo}</p><p className="text-[13px] text-[#FFC107]">+{m.xp} XP</p></div>
            <Btn tipo={ok ? 'ok' : 'ouro'} onClick={() => ok ? null : m.rota ? go(m.rota) : checkin()} className="h-8 px-3 text-[13px]">{ok ? 'Feita' : m.rota ? 'Ir' : 'Fazer'}</Btn></div>); })}</div>}
        {aba === 'Ranking' && <div className="divide-y divide-[#262626]">{[...RANKING, { nome: s.nome, bairro: s.bairro, xp: s.xp, nivel: NIVEIS[nv][0], me: true }].sort((a, b) => b.xp - a.xp).map((u, i) => (
          <div key={u.nome} className={`flex items-center gap-3 py-3 ${u.me ? 'bg-[#FFC107]/10 -mx-2 px-2 rounded-lg' : ''}`}><span className="w-6 text-center font-bold text-[#FFC107] tabnum">{i + 1}</span><Avatar nome={u.nome} size={40} ouro={u.me} /><div className="flex-1"><b className="text-[14px] block">{u.nome}{u.me && ' (você)'}</b><span className="text-[12px] text-[#A8A8A8]">{u.nivel} · {u.bairro}</span></div><span className="text-[14px] font-semibold tabnum">{fmt(u.xp)} XP</span></div>))}</div>}
        {aba === 'Bairros' && <div className="space-y-3.5 pt-1">{PLACAR.map(([b, pts], i) => (<div key={b}><div className="flex justify-between text-[14px]"><span>{i + 1}. {b}{b === s.bairro && <span className="text-[#FFC107]"> · seu bairro</span>}</span><span className="tabnum text-[#A8A8A8]">{fmt(pts)} XP</span></div><div className="h-2 rounded-full bg-[#262626] mt-1.5 overflow-hidden"><div className={`h-full ${i === 0 ? 'bg-[#FFC107]' : 'bg-white/30'}`} style={{ width: (pts / PLACAR[0][1]) * 100 + '%' }} /></div></div>))}</div>}
        {aba === 'Prêmios' && <div className="grid sm:grid-cols-3 gap-3">{[['Gift', 'Sorteio de novembro', 'Bicicleta MTB entre associados nível 2+', 'Sorteio dia 30/11'], ['TicketPercent', 'Cupom turbinado', 'Nível Destaque libera 25% em 40 parceiros', 'A partir de 500 XP'], ['Crown', 'Embaixador do bairro', 'Selo no perfil e convite pra eventos do Clube', 'A partir de 1.000 XP']].map(([ic, t, d, r]) => (<div key={t} className="border border-[#262626] rounded-xl p-4"><Icon name={ic} size={28} className="text-[#FFC107]" /><b className="block text-[15px] mt-2">{t}</b><p className="text-[13px] text-[#A8A8A8] mt-0.5">{d}</p><p className="text-[12px] text-[#FFC107] font-semibold mt-2">{r}</p></div>))}</div>}
      </div>
    </Pagina>
  );
}
function TelaParceiros({ s, go, toggleSalvo }) {
  const [cat, setCat] = useState('Todos'); const [q, setQ] = useState('');
  const lista = PARCEIROS.filter((p) => (cat === 'Todos' || p.cat === cat) && (p.nome + p.bairro + p.beneficio).toLowerCase().includes(q.toLowerCase()));
  return (
    <Pagina titulo="Parceiros" sub="Descontos exclusivos para associados." icon="Store" go={go}>
      <Busca id="busca-parceiros" valor={q} set={setQ} ph="Buscar parceiro, categoria ou bairro" />
      <div className="mt-3"><Tabs opcoes={['Todos', 'Alimentação', 'Saúde', 'Auto', 'Beleza']} valor={cat} set={setCat} /></div>
      <div className="mt-2 divide-y divide-[#262626]">{lista.map((p) => { const sv = s.salvos.includes(p.id); return (
        <div key={p.id} className="flex items-center gap-3 py-3"><button onClick={() => go('parceiro-' + p.id)} className="flex items-center gap-3 flex-1 min-w-0 text-left"><Ph tone={p.tone} icon={p.icon} className="w-14 h-14 rounded-full shrink-0" size={22} /><span className="min-w-0"><b className="text-[14px] flex items-center gap-1 truncate">{p.nome}<Verificado /></b><span className="block text-[13px] text-[#FFC107] truncate">{p.beneficio}</span><span className="block text-[12px] text-[#A8A8A8]">{p.bairro} · {p.dist} · ★ {p.nota.toLocaleString('pt-BR')}</span></span></button>
          <button onClick={() => toggleSalvo(p.id)} aria-label="Salvar" className="p-1"><Icon name="Bookmark" size={22} fill={sv ? '#F5F5F5' : 'none'} /></button></div>); })}</div>
      {!lista.length && <Vazio icon="Store" texto="Nenhum parceiro com esse filtro." />}
    </Pagina>
  );
}
function TelaParceiro({ id, s, up, go, toast, ganharXP, toggleSalvo }) {
  const [qr, setQr] = useState(false);
  const p = PARCEIROS.find((x) => x.id === id); if (!p) return <Pagina titulo="Parceiro" voltar="parceiros" go={go}><Vazio texto="Parceiro não encontrado." /></Pagina>;
  const resg = s.cupons.includes(p.id); const sv = s.salvos.includes(p.id); const seg = s.seguindo.includes(p.id);
  const copiar = () => { try { navigator.clipboard.writeText(p.cupom).then(() => toast('Código copiado'), () => toast('Segure o código pra copiar')); } catch (e) { toast('Segure o código pra copiar'); } };
  return (
    <Pagina titulo={p.user} voltar="parceiros" go={go}>
      <div className="flex items-center gap-5"><Avatar nome={p.nome} size={80} ouro anel /><div className="flex gap-6 text-center text-[14px] tabnum"><span><b className="block text-[17px]">{p.nota.toLocaleString('pt-BR')}</b>nota</span><span><b className="block text-[17px]">{fmt(1240 + (seg ? 1 : 0))}</b>seguidores</span><span><b className="block text-[17px]">{p.dist}</b>de você</span></div></div>
      <div className="mt-3 text-[14px]"><b className="flex items-center gap-1">{p.nome}<Verificado /></b><p className="text-[#A8A8A8]">{p.cat} · {p.bairro}</p><p>{p.desc}</p></div>
      <div className="grid grid-cols-3 gap-2 mt-4"><Btn tipo={seg ? 'sec' : 'ouro'} onClick={() => up((x) => ({ seguindo: seg ? x.seguindo.filter((y) => y !== p.id) : [...x.seguindo, p.id] }))}>{seg ? 'Seguindo' : 'Seguir'}</Btn><Btn tipo="sec" onClick={() => toggleSalvo(p.id)}>{sv ? 'Salvo' : 'Salvar'}</Btn><Btn tipo="sec" onClick={() => setQr(true)}><Icon name="QrCode" size={15} />QR</Btn></div>{qr && <QrBalcao p={p} fechar={() => setQr(false)} />}
      <div className="mt-5 rounded-xl border-2 border-dashed border-[#FFC107]/60 bg-[#120F02] p-4">
        <p className="text-[11px] font-bold uppercase tracking-[.14em] text-[#FFC107]">Benefício do associado</p><p className="text-[22px] font-bold mt-1">{p.beneficio}</p>
        {resg ? <div className="flex gap-2 mt-3"><code className="flex-1 h-11 grid place-items-center text-[18px] font-extrabold tracking-[.2em] bg-black border border-[#262626] rounded-lg select-all">{p.cupom}</code><Btn tipo="sec" onClick={copiar} className="h-11"><Icon name="Copy" size={16} />Copiar</Btn></div>
          : <Btn onClick={() => { up((x) => ({ cupons: [...x.cupons, p.id] })); ganharXP(15, 'm-cupom', 'Cupom liberado'); }} className="w-full h-11 mt-3"><Icon name="TicketPercent" size={18} />Resgatar cupom (+15 XP)</Btn>}
      </div>
      <div className="grid grid-cols-3 gap-1 mt-5">{[0, 1, 2, 3, 4, 5].map((i) => <Ph key={i} tone={['lar', 'ouro', 'vinho', 'cinza', 'verde', 'azul'][i]} icon={p.icon} className="aspect-square" size={28} />)}</div>
    </Pagina>
  );
}
function TelaMercadao({ s, go, toggleSalvo, produtos }) {
  const [q, setQ] = useState(''); const [ord, setOrd] = useState('Mais recentes'); const [cat, setCat] = useState('Todos');
  let lista = produtos.filter((p) => (cat === 'Todos' || p.cat === cat) && p.nome.toLowerCase().includes(q.toLowerCase()));
  lista = [...lista].sort((a, b) => (ord === 'Menor preço' ? a.preco - b.preco : ord === 'Maior preço' ? b.preco - a.preco : a.dias - b.dias));
  return (
    <Pagina titulo="Mercadão da SAD" sub="Compre, venda e negocie com associados." icon="ShoppingBag" go={go} larga acao={<Btn onClick={() => go('criar')} className="h-9"><Icon name="Plus" size={16} /><span className="hidden sm:inline">Vender</span></Btn>}>
      <Busca id="busca-mercadao" valor={q} set={setQ} ph="Buscar no Mercadão" />
      <div className="mt-3 space-y-2"><Tabs opcoes={['Todos', 'Eletrônicos', 'Móveis', 'Moda', 'Esporte']} valor={cat} set={setCat} /><Tabs opcoes={['Mais recentes', 'Menor preço', 'Maior preço']} valor={ord} set={setOrd} /></div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-x-3 gap-y-5 mt-4">{lista.map((p) => { const sv = s.salvos.includes(p.id); return (
        <button key={p.id} onClick={() => go('produto-' + p.id)} className="text-left group"><div className="relative"><Ph tone={p.tone} icon={p.icon} className="aspect-square rounded-lg w-full" size={44} /><span role="button" tabIndex={0} aria-label="Salvar" onClick={(e) => { e.stopPropagation(); toggleSalvo(p.id); }} onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); toggleSalvo(p.id); } }} className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/60 grid place-items-center"><Icon name="Heart" size={16} className={sv ? 'text-[#ED4956]' : ''} fill={sv ? '#ED4956' : 'none'} /></span></div>
          <p className="text-[16px] font-bold mt-2 tabnum flex items-center gap-1.5 flex-wrap">{brl(p.preco)}{p.precoAntigo && <s className="text-[12px] font-normal text-[#A8A8A8]">{brl(p.precoAntigo)}</s>}</p><Baixou p={p} /><p className="text-[14px] truncate">{p.nome}</p><p className="text-[12px] text-[#A8A8A8]">{p.bairro}</p></button>); })}</div>
      {!lista.length && <Vazio icon="ShoppingBag" texto="Nada encontrado com esses filtros." />}
    </Pagina>
  );
}
function TelaProduto({ id, s, go, toggleSalvo, toast, produtos }) {
  const p = produtos.find((x) => x.id === id); if (!p) return <Pagina titulo="Anúncio" voltar="mercadao" go={go}><Vazio texto="Anúncio não encontrado." /></Pagina>;
  const sv = s.salvos.includes(p.id);
  return (
    <Pagina titulo="Mercadão" voltar="mercadao" go={go} larga>
      <div className="grid md:grid-cols-[1.2fr_1fr] gap-6">
        <Ph tone={p.tone} icon={p.icon} className="aspect-square rounded-xl w-full" size={110} />
        <div>
          <h1 className="text-[24px] font-bold leading-tight">{p.nome}</h1><p className="text-[28px] font-bold text-[#FFC107] tabnum flex items-baseline gap-2">{brl(p.preco)}{p.precoAntigo && <s className="text-[16px] font-normal text-[#A8A8A8]">{brl(p.precoAntigo)}</s>}</p><Baixou p={p} />
          <p className="text-[13px] text-[#A8A8A8] mt-1">{p.bairro} - SP · {p.dias === 0 ? 'agora' : `há ${p.dias} ${p.dias > 1 ? 'dias' : 'dia'}`}</p>
          <div className="flex gap-2 mt-4"><a href={'https://wa.me/5511999999999?text=' + encodeURIComponent('Olá! Vi seu anúncio "' + p.nome + '" no Conecta ABC.')} target="_blank" rel="noopener" className="flex-1 h-10 rounded-lg bg-[#25D366] text-white text-[14px] font-semibold flex items-center justify-center gap-2"><Icon name="MessageCircle" size={17} />Conversar no WhatsApp</a><Btn tipo="sec" onClick={() => toggleSalvo(p.id)} className="h-10"><Icon name="Bookmark" size={18} fill={sv ? '#F5F5F5' : 'none'} /></Btn><Btn tipo="sec" onClick={() => toast('Link copiado')} className="h-10"><Icon name="Send" size={17} /></Btn></div>
          <div className="mt-5 border-t border-[#262626] pt-4"><b className="text-[16px]">Detalhes</b><div className="grid grid-cols-2 gap-y-2 mt-2 text-[14px]"><span className="text-[#A8A8A8]">Condição</span><span>{p.cond}</span><span className="text-[#A8A8A8]">Categoria</span><span>{p.cat}</span></div><p className="text-[14px] mt-3 leading-relaxed">{p.desc}</p></div>
          <div className="mt-5 border-t border-[#262626] pt-4 flex items-center gap-3"><Avatar nome={p.vend} size={44} /><div className="flex-1"><b className="text-[14px] block">{p.vend}</b><span className="text-[12px] text-[#A8A8A8]">Associado desde 2024 · ★ 5,0</span></div><Btn tipo="sec" onClick={() => toast('Perfil do vendedor')} className="h-8 text-[13px]">Ver perfil</Btn></div>
        </div>
      </div>
    </Pagina>
  );
}
const corPet = (st) => (st === 'Perdido' ? 'bad' : st === 'Encontrado' ? 'ok' : 'info');
function TelaAnimais({ s, go, pets, toggleSalvo }) {
  const [f, setF] = useState('Todos'); const [q, setQ] = useState('');
  const lista = pets.filter((a) => (f === 'Todos' || (f === 'Perdidos' ? a.status === 'Perdido' : f === 'Encontrados' ? a.status === 'Encontrado' : a.status === 'Em busca do tutor')) && (a.nome + a.raca + a.bairro).toLowerCase().includes(q.toLowerCase()));
  return (
    <Pagina titulo="Animais perdidos" sub="Ajude a encontrar e cuidar de quem ama." icon="PawPrint" go={go} larga acao={<Btn onClick={() => go('cadastrar-animal')} className="h-9"><Icon name="Plus" size={16} /><span className="hidden sm:inline">Cadastrar</span></Btn>}>
      <Busca id="busca-pets" valor={q} set={setQ} ph="Buscar por nome, raça ou bairro" />
      <div className="mt-3"><Tabs opcoes={['Todos', 'Perdidos', 'Encontrados', 'Buscando tutor']} valor={f} set={setF} /></div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-x-3 gap-y-5 mt-4">{lista.map((a) => (<button key={a.id} onClick={() => go('animal-' + a.id)} className="text-left"><div className="relative"><Ph tone={a.tone} icon={a.icon} className="aspect-square rounded-lg w-full" size={48} /><span className="absolute top-2 left-2"><Pill cor={corPet(a.status)}>{a.status}</Pill></span></div><p className="text-[15px] font-bold mt-2">{a.nome}</p><p className="text-[12px] text-[#A8A8A8]">{a.bairro} · {a.quando}</p></button>))}</div>
      {!lista.length && <Vazio icon="PawPrint" texto="Nenhum animal com esse filtro." />}
    </Pagina>
  );
}
function TelaAnimal({ id, s, go, pets, toast, toggleSalvo }) {
  const a = pets.find((x) => x.id === id); if (!a) return <Pagina titulo="Animal" voltar="animais" go={go}><Vazio texto="Animal não encontrado." /></Pagina>;
  return (
    <Pagina titulo={a.nome} voltar="animais" go={go}>
      <div className="relative"><Ph tone={a.tone} icon={a.icon} className="aspect-[4/3] rounded-xl w-full" size={96} /><span className="absolute top-3 left-3"><Pill cor={corPet(a.status)}>{a.status}</Pill></span></div>
      <p className="text-[15px] font-semibold mt-4">{a.especie} · {a.raca}</p><p className="text-[13px] text-[#A8A8A8]">{a.bairro} · Santo André · {a.quando}</p><p className="text-[14px] mt-3 leading-relaxed">{a.desc}</p>
      <div className="grid grid-cols-2 gap-2 mt-5"><Btn onClick={() => toast('Avisamos o tutor. Obrigado!')}><Icon name="Eye" size={16} />{a.status === 'Perdido' ? 'Vi esse animal' : 'Sou o tutor'}</Btn><Btn tipo="sec" onClick={() => toast('Compartilhado')}><Icon name="Repeat2" size={16} />Compartilhar</Btn></div>
      <Btn tipo="sec" onClick={() => toggleSalvo(a.id)} className="w-full mt-2"><Icon name="Bookmark" size={16} fill={s.salvos.includes(a.id) ? '#F5F5F5' : 'none'} />{s.salvos.includes(a.id) ? 'Salvo' : 'Salvar'}</Btn>
    </Pagina>
  );
}
function TelaCadastrarAnimal({ up, go, ganharXP }) {
  const [passo, setPasso] = useState(1);
  const [f, setF] = useState({ tipo: 'Perdido', nome: '', especie: 'Cachorro', raca: '', porte: 'Médio', cor: '', bairro: 'Jardim', desc: '' });
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  const publicar = () => { up((p) => ({ pets: [{ id: 'u' + Date.now(), nome: f.nome || 'Sem nome', status: f.tipo, especie: f.especie, raca: f.raca || f.especie, bairro: f.bairro, icon: f.especie === 'Gato' ? 'Cat' : 'Dog', tone: 'ouro', quando: 'agora', desc: [f.cor && 'Cor: ' + f.cor + '.', 'Porte ' + f.porte.toLowerCase() + '.', f.desc].filter(Boolean).join(' ') }, ...p.pets] })); ganharXP(20, null, 'Animal publicado'); go('animais'); };
  return (
    <Pagina titulo="Cadastrar animal" voltar="animais" go={go}>
      <div className="flex gap-1.5 mb-5">{[1, 2, 3].map((n) => <span key={n} className={`h-1 flex-1 rounded-full ${passo >= n ? 'bg-[#FFC107]' : 'bg-[#262626]'}`} />)}</div>
      <p className="text-[13px] text-[#A8A8A8] mb-4">Passo {passo} de 3 · {['Informações', 'Detalhes', 'Revisão'][passo - 1]}</p>
      {passo === 1 && <div className="space-y-4"><Campo label="Tipo de publicação"><div className="grid grid-cols-3 gap-2">{['Perdido', 'Encontrado', 'Em busca do tutor'].map((t) => <button key={t} onClick={() => set('tipo', t)} className={`h-10 rounded-lg text-[13px] font-semibold ${f.tipo === t ? 'bg-[#FFC107] text-[#0A0A0A]' : 'bg-[#1A1A1A]'}`}>{t}</button>)}</div></Campo><Campo label="Nome do animal"><input id="pet-nome" className={inputCls} value={f.nome} onChange={(e) => set('nome', e.target.value)} placeholder="Ex: Max" /></Campo><Campo label="Espécie"><select id="pet-especie" className={inputCls} value={f.especie} onChange={(e) => set('especie', e.target.value)}><option>Cachorro</option><option>Gato</option><option>Outro</option></select></Campo><Campo label="Raça (opcional)"><input id="pet-raca" className={inputCls} value={f.raca} onChange={(e) => set('raca', e.target.value)} placeholder="Ex: Labrador" /></Campo><Btn onClick={() => setPasso(2)} className="w-full h-11">Próximo</Btn></div>}
      {passo === 2 && <div className="space-y-4"><Campo label="Porte"><div className="grid grid-cols-3 gap-2">{['Pequeno', 'Médio', 'Grande'].map((t) => <button key={t} onClick={() => set('porte', t)} className={`h-10 rounded-lg text-[13px] font-semibold ${f.porte === t ? 'bg-[#FFC107] text-[#0A0A0A]' : 'bg-[#1A1A1A]'}`}>{t}</button>)}</div></Campo><Campo label="Cor"><input id="pet-cor" className={inputCls} value={f.cor} onChange={(e) => set('cor', e.target.value)} placeholder="Ex: Caramelo" /></Campo><Campo label="Bairro"><select id="pet-bairro" className={inputCls} value={f.bairro} onChange={(e) => set('bairro', e.target.value)}>{BAIRROS.map((b) => <option key={b}>{b}</option>)}</select></Campo><Campo label="Descrição"><textarea id="pet-desc" rows={3} className={inputCls + ' h-auto py-2.5'} value={f.desc} onChange={(e) => set('desc', e.target.value)} placeholder="Coleira, comportamento, onde foi visto..." /></Campo><div className="flex gap-2"><Btn tipo="sec" onClick={() => setPasso(1)} className="h-11">Voltar</Btn><Btn onClick={() => setPasso(3)} className="flex-1 h-11">Próximo</Btn></div></div>}
      {passo === 3 && <div><div className="border border-[#262626] rounded-xl overflow-hidden"><div className="relative"><Ph tone="ouro" icon={f.especie === 'Gato' ? 'Cat' : 'Dog'} className="aspect-[16/9] w-full" size={64} /><span className="absolute top-3 left-3"><Pill cor={corPet(f.tipo)}>{f.tipo}</Pill></span></div><div className="p-4"><b className="text-[16px]">{f.nome || 'Sem nome'}</b><p className="text-[13px] text-[#A8A8A8]">{f.raca || f.especie} · {f.bairro} · porte {f.porte.toLowerCase()}{f.cor && ' · ' + f.cor}</p>{f.desc && <p className="text-[14px] mt-2">{f.desc}</p>}</div></div><div className="flex gap-2 mt-4"><Btn tipo="sec" onClick={() => setPasso(2)} className="h-11">Voltar</Btn><Btn onClick={publicar} className="flex-1 h-11">Publicar (+20 XP)</Btn></div></div>}
    </Pagina>
  );
}
function TelaProblemas({ s, up, go, problemas, apoiar, ganharXP }) {
  const [f, setF] = useState('Todos'); const [aberto, setAberto] = useState(false);
  const [n, setN] = useState({ cat: 'Buracos', titulo: '', end: '', bairro: 'Jardim' });
  const lista = problemas.filter((r) => f === 'Todos' || r.cat === f);
  const enviar = (e) => { e.preventDefault(); if (!n.titulo.trim() || !n.end.trim()) return; const icons = { Buracos: 'Construction', Iluminação: 'Lightbulb', Lixo: 'Trash2', Outros: 'TriangleAlert' }; up((p) => ({ problemas: [{ id: 'u' + Date.now(), ...n, status: 'Em análise', data: 'hoje', apoios: 0, icon: icons[n.cat], tone: 'cinza' }, ...p.problemas] })); setAberto(false); setN({ cat: 'Buracos', titulo: '', end: '', bairro: 'Jardim' }); ganharXP(35, 'm-problema', 'Problema enviado'); };
  return (
    <Pagina titulo="Problemas da cidade" sub="Ajude a melhorar Santo André." icon="Megaphone" go={go} acao={<Btn onClick={() => setAberto(!aberto)} className="h-9"><Icon name={aberto ? 'X' : 'Plus'} size={16} /><span className="hidden sm:inline">{aberto ? 'Fechar' : 'Avisar'}</span></Btn>}>
      {aberto && <form onSubmit={enviar} className="border border-[#FFC107]/50 rounded-xl p-4 mb-4 space-y-3 fade"><div className="grid grid-cols-2 gap-3"><Campo label="Categoria"><select id="prob-cat" className={inputCls} value={n.cat} onChange={(e) => setN({ ...n, cat: e.target.value })}>{['Buracos', 'Iluminação', 'Lixo', 'Outros'].map((x) => <option key={x}>{x}</option>)}</select></Campo><Campo label="Bairro"><select id="prob-bairro" className={inputCls} value={n.bairro} onChange={(e) => setN({ ...n, bairro: e.target.value })}>{BAIRROS.map((b) => <option key={b}>{b}</option>)}</select></Campo></div><Campo label="O que está acontecendo?"><input id="prob-titulo" className={inputCls} value={n.titulo} onChange={(e) => setN({ ...n, titulo: e.target.value })} placeholder="Ex: bueiro entupido" /></Campo><Campo label="Endereço"><input id="prob-end" className={inputCls} value={n.end} onChange={(e) => setN({ ...n, end: e.target.value })} placeholder="Rua e número aproximado" /></Campo><Btn type="submit" disabled={!n.titulo.trim() || !n.end.trim()} className="w-full h-10">Enviar (+35 XP)</Btn></form>}
      <Tabs opcoes={['Todos', 'Buracos', 'Iluminação', 'Lixo', 'Outros']} valor={f} set={setF} />
      <div className="mt-3 space-y-3">{lista.map((r) => { const ap = s.apoios.includes(r.id); const cor = r.status === 'Resolvido' ? 'ok' : r.status === 'Encaminhado' ? 'info' : 'neutro'; return (
        <div key={r.id} className="border border-[#262626] rounded-xl overflow-hidden"><div className="flex gap-3 p-3"><Ph tone={r.tone} icon={r.icon} className="w-20 h-20 rounded-lg shrink-0" size={28} /><div className="flex-1 min-w-0"><div className="flex gap-1.5"><Pill>{r.cat}</Pill><Pill cor={cor}>{r.status}</Pill></div><p className="text-[15px] font-semibold mt-1.5">{r.titulo}</p><p className="text-[12px] text-[#A8A8A8] truncate">{r.end} · {r.bairro} · {r.data}</p></div></div>
          <div className="flex border-t border-[#262626]"><button onClick={() => apoiar(r.id)} className={`flex-1 h-10 text-[13px] font-semibold flex items-center justify-center gap-1.5 ${ap ? 'text-[#FFC107]' : ''}`}><Icon name="ThumbsUp" size={16} fill={ap ? '#FFC107' : 'none'} />Apoiar · {r.apoios + (ap ? 1 : 0)}</button><button onClick={() => go('mapa')} className="flex-1 h-10 text-[13px] font-semibold flex items-center justify-center gap-1.5 border-l border-[#262626]"><Icon name="MapPin" size={16} />Ver no mapa</button></div></div>); })}</div>
      {!lista.length && <Vazio icon="Megaphone" texto="Nenhum problema nessa categoria." />}
    </Pagina>
  );
}
function TelaServicos({ go, toast }) {
  const sv = [['Scale', 'Atendimento Jurídico', 'Orientação e advogados parceiros.'], ['PawPrint', 'Atendimento Veterinário', 'Clínicas parceiras com preço de associado.'], ['Landmark', 'Solicitações Prefeitura', 'Como solicitar serviços municipais.'], ['Phone', 'Telefones úteis', 'Emergência, Defesa Civil, Guarda Municipal.', 'utilidades']];
  return (
    <Pagina titulo="Serviços" sub="Apoio para você e para sua família." icon="HandHelping" go={go}>
      <div className="divide-y divide-[#262626]">{sv.map(([ic, t, d, r]) => <Linha key={t} icon={ic} titulo={t} sub={d} onClick={() => (r ? go(r) : toast(`Acessando ${t}...`))} />)}</div>
      <a href="https://wa.me/5511999999999" target="_blank" rel="noopener" className="mt-5 flex items-center gap-4 rounded-xl bg-[#FFC107] text-[#0A0A0A] p-4"><Icon name="Headphones" size={34} /><span className="flex-1"><b className="text-[16px] block">Dúvidas?</b><span className="text-[13px]">Fale com a equipe da SAD.</span></span><Icon name="ChevronRight" size={20} /></a>
    </Pagina>
  );
}
function TelaEvento({ id, s, go, presenca, toast }) {
  const e = EVENTOS.find((x) => x.id === id); if (!e) return <Pagina titulo="Evento" voltar="agenda" go={go}><Vazio texto="Evento não encontrado." /></Pagina>;
  const vou = s.presencas.includes(e.id);
  return (
    <Pagina titulo="Evento" voltar="agenda" go={go}>
      <Ph tone={e.tone} icon={e.icon} className="aspect-[16/9] rounded-xl w-full" size={80} />
      <p className="text-[13px] text-[#FFC107] font-semibold uppercase mt-4">{e.wd}, {e.dia} de {e.mes} · {e.hora}</p><h1 className="text-[24px] font-bold leading-tight">{e.titulo}</h1>
      <p className="text-[14px] text-[#A8A8A8] mt-1">{e.local} · {e.bairro}</p>
      <div className="grid grid-cols-[1fr_auto] gap-2 mt-4"><Btn tipo={vou ? 'ok' : 'ouro'} onClick={() => presenca(e.id)} className="h-10"><Icon name={vou ? 'CircleCheck' : 'Star'} size={17} />{vou ? 'Presença confirmada' : 'Vou! (+5 XP)'}</Btn><Btn tipo="sec" onClick={() => toast('Convite copiado')} className="h-10"><Icon name="Send" size={17} /></Btn></div>
      <div className="mt-5 divide-y divide-[#262626] border-y border-[#262626]">{[['Users', `${fmt(e.vao + (vou ? 1 : 0))} pessoas vão`], ['Tag', e.gratis ? 'Grátis' : 'Desconto para associados'], ['MapPin', `${e.local}, ${e.bairro}`]].map(([ic, t]) => <div key={t} className="flex items-center gap-3 py-3 text-[14px]"><Icon name={ic} size={20} />{t}</div>)}</div>
      <p className="text-[14px] mt-4 leading-relaxed">{e.desc}</p>
    </Pagina>
  );
}
function TelaNoticias({ go }) {
  const [cat, setCat] = useState('Todas'); const cats = ['Todas', ...Array.from(new Set(NOTICIAS.map((n) => n.cat)))]; const lista = NOTICIAS.filter((n) => cat === 'Todas' || n.cat === cat);
  return (
    <Pagina titulo="Notícias do ABC" sub="Prefeitura, serviços, cultura e alertas." icon="Newspaper" go={go}>
      <Tabs opcoes={cats} valor={cat} set={setCat} />
      <div className="mt-3 divide-y divide-[#262626]">{lista.map((n) => (<button key={n.id} onClick={() => go('noticia-' + n.id)} className="w-full flex gap-3 py-3 text-left"><div className="flex-1 min-w-0"><p className="text-[12px] text-[#A8A8A8]">{n.fonte} · {n.data}</p><p className="text-[15px] font-semibold leading-snug mt-0.5">{n.titulo}</p><p className="text-[13px] text-[#A8A8A8] mt-1 line-clamp-2">{n.resumo}</p></div><Ph tone={n.tone} icon={n.icon} className="w-24 h-24 rounded-lg shrink-0" size={30} /></button>))}</div>
    </Pagina>
  );
}
function TelaNoticia({ id, go, toast }) {
  const n = NOTICIAS.find((x) => x.id === id); if (!n) return <Pagina titulo="Notícia" voltar="noticias" go={go}><Vazio texto="Notícia não encontrada." /></Pagina>;
  return (
    <Pagina titulo="Notícias" voltar="noticias" go={go}>
      <PostCabecalho nome={n.fonte} sub={`${n.cat} · ${n.data}`} verificado />
      <h1 className="text-[26px] font-bold leading-tight mt-1">{n.titulo}</h1><p className="text-[16px] text-[#A8A8A8] mt-2">{n.resumo}</p>
      <Ph tone={n.tone} icon={n.icon} className="aspect-[16/9] rounded-xl w-full mt-4" size={72} />
      <p className="text-[15px] leading-relaxed mt-4">Texto de exemplo da matéria. Na versão final, esta tela traz o conteúdo completo, com link para a fonte original.</p>
      <Btn tipo="sec" onClick={() => toast('Link copiado')} className="mt-5"><Icon name="Send" size={16} />Compartilhar</Btn>
    </Pagina>
  );
}
function TelaComunidades({ s, go, toggleComunidade }) {
  const [q, setQ] = useState(''); const lista = COMUNIDADES.filter((c) => (c.nome + c.desc).toLowerCase().includes(q.toLowerCase()));
  return (
    <Pagina titulo="Comunidades" sub="Grupos de associados por interesse e bairro." icon="Users" go={go}>
      <Busca id="busca-com" valor={q} set={setQ} ph="Buscar comunidade" />
      <div className="mt-2 divide-y divide-[#262626]">{lista.map((c) => { const m = s.comunidades.includes(c.id); return (
        <div key={c.id} className="flex items-center gap-3 py-3"><button onClick={() => go('comunidade-' + c.id)} className="flex items-center gap-3 flex-1 min-w-0 text-left"><Ph tone={c.tone} icon={c.icon} className="w-14 h-14 rounded-xl shrink-0" size={22} /><span className="min-w-0"><b className="text-[14px] block truncate">{c.nome}</b><span className="block text-[12px] text-[#A8A8A8] tabnum">{fmt(c.membros + (m ? 1 : 0))} membros · ativo {c.ativo}</span></span></button>
          <Btn tipo={m ? 'sec' : 'ouro'} onClick={() => toggleComunidade(c.id)} className="h-8 px-3 text-[13px]">{m ? 'Participando' : 'Participar'}</Btn></div>); })}</div>
    </Pagina>
  );
}
function TelaComunidade(ctx) {
  const { id, s, go, toggleComunidade } = ctx;
  const c = COMUNIDADES.find((x) => x.id === id); if (!c) return <Pagina titulo="Comunidade" voltar="comunidades" go={go}><Vazio texto="Comunidade não encontrada." /></Pagina>;
  const m = s.comunidades.includes(c.id);
  return (
    <div>
      <div className="mx-auto max-w-[630px]"><Ph tone={c.tone} icon={c.icon} className="h-40 md:h-52 md:rounded-b-xl w-full" size={64} /></div>
      <Pagina titulo={c.nome} voltar="comunidades" go={go}>
        <p className="text-[13px] text-[#A8A8A8] -mt-3 tabnum">Grupo público · {fmt(c.membros + (m ? 1 : 0))} membros · ativo {c.ativo}</p>
        <p className="text-[14px] mt-3">{c.desc}</p>
        <div className="flex gap-2 mt-4"><Btn tipo={m ? 'sec' : 'ouro'} onClick={() => toggleComunidade(c.id)} className="flex-1"><Icon name={m ? 'Check' : 'UserPlus'} size={16} />{m ? 'Participando' : 'Participar do grupo'}</Btn><Btn tipo="sec" onClick={() => ctx.toast('Convite copiado')}><Icon name="Send" size={16} /></Btn></div>
        <div className="mt-6 -mx-4 md:mx-0">{POSTS0.slice(2, 4).map((p) => <PostFeed key={p.id} p={p} ctx={ctx} />)}</div>
      </Pagina>
    </div>
  );
}
function TelaVagas({ go, toast }) {
  const [f, setF] = useState('Todas'); const [q, setQ] = useState('');
  const lista = VAGAS.filter((v) => (f === 'Todas' || v.regime === f) && (v.cargo + v.empresa + v.bairro).toLowerCase().includes(q.toLowerCase()));
  return (
    <Pagina titulo="Vagas no ABC" sub="Empregos nos parceiros e empresas da região." icon="Briefcase" go={go}>
      <Busca id="busca-vagas" valor={q} set={setQ} ph="Cargo, empresa ou bairro" />
      <div className="mt-3"><Tabs opcoes={['Todas', 'CLT', 'PJ', 'Temporário']} valor={f} set={setF} /></div>
      <div className="mt-2 divide-y divide-[#262626]">{lista.map((v) => (<div key={v.id} className="flex gap-3 py-3.5"><span className="w-12 h-12 rounded-lg bg-[#1A1A1A] grid place-items-center text-[18px] font-extrabold text-[#FFC107] shrink-0">{v.empresa[0]}</span><div className="flex-1 min-w-0"><b className="text-[15px] block">{v.cargo}</b><p className="text-[13px]">{v.empresa}</p><p className="text-[12px] text-[#A8A8A8]">{v.bairro} · {v.regime} · {v.modo} · {v.salario}</p><Btn onClick={() => toast('Candidatura enviada!')} className="h-8 px-3 text-[13px] mt-2">Candidatar-se</Btn></div></div>))}</div>
      {!lista.length && <Vazio icon="Briefcase" texto="Nenhuma vaga com esse filtro." />}
    </Pagina>
  );
}
function TelaEnquetes({ s, go, votar, enquetes }) {
  return (<Pagina titulo="Enquetes" sub="Opine sobre o que importa na cidade." icon="Vote" go={go} acao={<Btn onClick={() => go('criar')} className="h-9"><Icon name="Plus" size={16} /><span className="hidden sm:inline">Criar</span></Btn>}><div className="space-y-4">{enquetes.map((q) => (<div key={q.id} className="border border-[#262626] rounded-xl p-4"><PostCabecalho nome={q.autor} sub={`Enquete · ${q.dias} dias restantes`} ouro={q.autor === 'Conecta ABC'} /><EnqueteBloco q={q} voto={s.votos[q.id]} votar={votar} extra={s.extraVotos[q.id]} /></div>))}</div></Pagina>);
}
function TelaSalvos({ go }) { useEffect(() => { go('perfil'); }, []); return null; }
/* ====================================================================
   NOVOS MÓDULOS — ideias do documento, adaptadas ao Conecta ABC
   ==================================================================== */
const PESSOAS = [
  { user: 'fernanda.c', nome: 'Fernanda Costa', bairro: 'Jardim', mutuos: 6, online: true },
  { user: 'mari.souza', nome: 'Mariana Souza', bairro: 'Jardim', mutuos: 8, online: false },
  { user: 'ana.paula', nome: 'Ana Paula Reis', bairro: 'Jardim', mutuos: 4, online: true },
  { user: 'tiago.m', nome: 'Tiago Martins', bairro: 'Jardim', mutuos: 3, online: false },
  { user: 'marcos.o', nome: 'Marcos Oliveira', bairro: 'Centro', mutuos: 3, online: false },
  { user: 'juliana.s', nome: 'Juliana Santos', bairro: 'Vila Luzita', mutuos: 2, online: true },
  { user: 'jvitor', nome: 'João Vitor', bairro: 'Vila Assunção', mutuos: 5, online: true },
  { user: 'rafa.mc', nome: 'Rafael Mendes', bairro: 'Campestre', mutuos: 1, online: false },
  { user: 'bruna.c', nome: 'Bruna Carvalho', bairro: 'Parque das Nações', mutuos: 2, online: false },
];
const REACOES = [['👍', 'Curti'], ['💛', 'Amei'], ['🔥', 'Brabo'], ['😂', 'Kkk'], ['😮', 'Uau'], ['😢', 'Triste']];
const BASE_DEN = { f2: 2, v2: 2 };
const LIMITES = {
  post: { n: 10, max: 3, label: 'Posts' }, comentario: { n: 5, max: 10, label: 'Comentários' }, checkin: { n: 10, max: 5, label: 'Check-ins' },
  avaliacao: { n: 15, max: 5, label: 'Avaliações de lugares' }, indicacao: { n: 5, max: 5, label: 'Indicações' }, amizade: { n: 5, max: 10, label: 'Amizades novas' },
  convite: { n: 100, max: 5, label: 'Amigos convidados' }, resolveu: { n: 15, max: 5, label: 'Indicações que resolveram' },
};
const CUPONS = [
  { id: 'k1', p: 'p1', titulo: '15% em qualquer pizza', tipo: '% off', nivel: 1, estoque: 60, pegaram: 51, validade: '30/11', regras: 'Salão ou delivery. Um por pessoa.' },
  { id: 'k2', p: 'p3', titulo: 'R$ 10 off acima de R$ 60', tipo: 'R$ off', nivel: 2, estoque: 40, pegaram: 12, validade: '15/12', regras: 'Não vale para medicamentos controlados.' },
  { id: 'k3', p: 'p5', titulo: 'Corte + barba por R$ 45', tipo: 'Preço especial', nivel: 3, estoque: null, pegaram: 233, validade: '31/12', regras: 'Com hora marcada, de terça a sábado.' },
  { id: 'k4', p: 'p4', titulo: 'Matrícula grátis + 50% na 1ª mensalidade', tipo: '% off', nivel: 4, estoque: 30, pegaram: 9, validade: '30/11', regras: 'Planos mensais e trimestrais.' },
  { id: 'k5', p: 'p6', titulo: 'Revisão completa com 25% off', tipo: '% off', nivel: 5, estoque: 20, pegaram: 17, validade: '20/11', regras: 'Bicicletas urbanas e MTB.' },
  { id: 'k6', p: 'p2', titulo: 'Lavagem grátis no abastecimento', tipo: 'Brinde', nivel: 10, estoque: 10, pegaram: 2, validade: '31/12', regras: 'Abastecimento acima de 30 litros.' },
];
const SORTEIOS = [
  { id: 'g1', titulo: 'Bicicleta MTB aro 29', parceiro: 'Bike & Cia', icon: 'Bike', tone: 'verde', fim: '30/11', inscritos: 812, regras: 'Para associados com conta ativa. Sorteio ao vivo no dia 30/11 às 19h.' },
  { id: 'g2', titulo: 'Rodízio de pizza para 4 pessoas', parceiro: 'Pizzaria Da Vila', icon: 'Pizza', tone: 'lar', fim: '15/11', inscritos: 1290, regras: 'Válido de segunda a quinta. Retirada em até 30 dias.' },
  { id: 'g3', titulo: '3 meses de academia', parceiro: 'Academia FitABC', icon: 'Dumbbell', tone: 'azul', fim: '22/11', inscritos: 431, regras: 'Plano completo, sem taxa de matrícula.' },
];
const PREMIO = [
  { id: 'pz1', cat: 'Melhor pizzaria', opcoes: ['Pizzaria Da Vila', 'Forno do Bairro', 'Bella Massa'] },
  { id: 'pz2', cat: 'Melhor barbearia', opcoes: ['Barbearia Navalha', 'Corte Fino', 'Barba & Cia'] },
  { id: 'pz3', cat: 'Melhor evento do ano', opcoes: ['Feira Cultural do Paço', 'Batalha de rima', 'Corrida 5K do ABC'] },
  { id: 'pz4', cat: 'Melhor lugar pra passear', opcoes: ['Parque Celso Daniel', 'Parque Central', 'Paço Municipal'] },
];
const VOZ0 = [
  { id: 'v1', tipo: 'Elogio', anon: false, autor: 'Ana Paula Reis', bairro: 'Jardim', tempo: '2 h', texto: 'Quero agradecer o motorista da linha 214 que esperou minha mãe atravessar com calma hoje cedo. Gentileza ainda existe.', reacoes: 87 },
  { id: 'v2', tipo: 'Reclamação', anon: true, autor: 'Anônimo', bairro: 'Centro', tempo: '4 h', texto: 'Calçada da Rua Senador Fláquer está toda quebrada perto do ponto. Já vi idoso tropeçar duas vezes essa semana.', reacoes: 142 },
  { id: 'v3', tipo: 'História', anon: false, autor: 'Tiago Martins', bairro: 'Jardim', tempo: 'ontem', texto: 'Meu avô abriu a primeira mercearia da rua em 1968. Hoje passei lá e o prédio virou uma padaria linda. Bateu saudade boa.', reacoes: 203 },
  { id: 'v4', tipo: 'Denúncia', anon: true, autor: 'Anônimo', bairro: 'Vila Luzita', tempo: 'ontem', texto: 'Tem gente descartando entulho toda madrugada no terreno da esquina com a Av. Queirós. Já avisei a prefeitura pelo 156.', reacoes: 98 },
];
const COR_VOZ = { Elogio: 'ok', Reclamação: 'bad', História: 'info', Denúncia: 'ouro' };
const METAS_UNICAS = [
  { id: 'perfil', titulo: 'Completar o perfil', d: 'Nome, @, bairro e bio', n: 50, ok: (s) => !!(s.bio && s.bio.length > 10), ir: 'perfil' },
  { id: 'foto', titulo: 'Foto de rosto', d: 'Ajuda os vizinhos a te reconhecer', n: 50, ok: (s) => s.foto, acao: 'foto' },
  { id: 'capa', titulo: 'Escolher capa', d: 'Imagem do topo do perfil', n: 30, ok: (s) => s.capa, acao: 'capa' },
  { id: 'post1', titulo: 'Primeiro post', d: 'Publique algo no feed', n: 50, ok: (s) => s.posts.length > 0, ir: 'criar' },
  { id: 'convite1', titulo: 'Convidar um amigo', d: 'Conta quando ele completa o perfil', n: 100, ok: (s) => s.convites > 0, ir: 'convidar' },
  { id: 'amigos3', titulo: 'Ter 3 amigos', d: 'Aceite pedidos ou adicione vizinhos', n: 60, ok: (s) => s.amigos.length >= 3, ir: 'amigos' },
  { id: 'seguir3', titulo: 'Seguir 3 empresas', d: 'Siga parceiros do bairro', n: 30, ok: (s) => s.seguindo.filter((x) => x.startsWith('p')).length >= 3, ir: 'empresas' },
  { id: 'coment1', titulo: 'Comentar num post', d: 'Participe de uma conversa', n: 20, ok: (s) => Object.keys(s.comentarios).length > 0, ir: 'inicio' },
  { id: 'reagir5', titulo: 'Reagir a 5 posts', d: 'Curtidas e reações contam', n: 20, ok: (s) => new Set([...s.curtidas, ...Object.keys(s.reacoes)]).size >= 5, ir: 'inicio' },
  { id: 'voto1', titulo: 'Votar numa enquete', d: 'Dê sua opinião', n: 20, ok: (s) => Object.keys(s.votos).length > 0, ir: 'enquetes' },
  { id: 'sorteio1', titulo: 'Participar de um sorteio', d: 'É grátis', n: 20, ok: (s) => s.sorteios.length > 0, ir: 'sorteios' },
  { id: 'app', titulo: 'Instalar o app', d: 'Adicione à tela inicial', n: 50, ok: (s) => s.appInstalado, acao: 'app' },
  { id: 'notif', titulo: 'Ativar notificações', d: 'Saiba de eventos e cupons', n: 30, ok: (s) => s.notifAtivas, acao: 'notif' },
];
const FUNDADOR = [['perfil', 'Completar o perfil'], ['foto', 'Colocar foto de rosto'], ['post1', 'Fazer o primeiro post'], ['amigos3', 'Ter 3 amigos'], ['convite1', 'Convidar um amigo']];
const FARMACIAS = [['Farmácia Saúde+', 'Av. Portugal, 820 · Jardim', '24 horas'], ['Drogaria Central', 'Rua Coronel Oliveira Lima, 300 · Centro', 'até 23h'], ['Farma Luzita', 'Av. Queirós, 1450 · Vila Luzita', 'até 22h']];
const COLETA = { Centro: 'Seg, qua e sex · noite', 'Vila Assunção': 'Ter, qui e sáb · manhã', Jardim: 'Seg, qua e sex · manhã', 'Casa Branca': 'Ter, qui e sáb · tarde', Campestre: 'Seg, qua e sex · tarde', 'Vila Luzita': 'Ter, qui e sáb · manhã', 'Parque das Nações': 'Seg, qua e sex · noite', Utinga: 'Ter, qui e sáb · noite' };
const EMP_CATS = [['Alimentação', 'Utensils', 48], ['Bares e restaurantes', 'Beer', 31], ['Mercado', 'ShoppingCart', 12], ['Beleza', 'Scissors', 27], ['Saúde', 'HeartPulse', 22], ['Jurídico', 'Scale', 9], ['Contabilidade', 'Calculator', 7], ['Construção', 'Hammer', 15], ['Imóveis', 'Building2', 11], ['Educação', 'GraduationCap', 14], ['Esporte', 'Dumbbell', 10], ['Moda', 'Shirt', 19], ['Pets', 'PawPrint', 8], ['Automotivo', 'Car', 16], ['Tecnologia', 'Laptop', 6], ['Eventos', 'PartyPopper', 5], ['Música', 'Music', 9], ['Serviços gerais', 'Wrench', 23]];
const CAT_PARCEIRO = { Alimentação: 'Alimentação', Saúde: 'Saúde', Auto: 'Automotivo', Beleza: 'Beleza' };
const ACHADOS_CATS = ['Documento', 'Carteira', 'Chave', 'Celular', 'Pet', 'Bolsa', 'Óculos', 'Bicicleta', 'Outro'];
const diasAte = (iso) => Math.max(0, Math.ceil((new Date(iso + 'T23:59:59') - new Date()) / 86400000));
const codigoUnico = (base, user) => base + '-' + (user || 'x').split('').reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 46656, 7).toString(36).toUpperCase().padStart(3, '0');
const faixaCarteirinha = (nv) => (nv >= 9 ? { nome: 'Lenda', bg: 'linear-gradient(135deg,#FFE07A,#FFC107 35%,#FF8A00 70%,#FFE07A)', fg: '#0A0A0A' } : nv >= 6 ? { nome: 'Ouro negro', bg: 'linear-gradient(135deg,#1A1A1A,#0A0A0A 60%,#3A2E05)', fg: '#FFC107' } : nv >= 3 ? { nome: 'Prata', bg: 'linear-gradient(135deg,#E5E7EB,#9CA3AF)', fg: '#0A0A0A' } : { nome: 'Ouro', bg: '#FFC107', fg: '#0A0A0A' });

/* ---------- Post com reações, denúncia e moderação ---------- */
function PostFeed({ p, ctx }) {
  const { s, up, curtir, toast, abrirComentarios, toggleSalvo, denunciar } = ctx;
  const [coracao, setCoracao] = useState(0); const [picker, setPicker] = useState(false); const [menu, setMenu] = useState(false);
  if (s.removidos.includes(p.id) || s.escondidos.includes(p.id)) return null;
  if (s.ocultos.includes(p.id)) return (
    <div className="border-b border-[#262626] md:border md:rounded-lg md:mb-4 px-4 py-5 flex items-center gap-3 text-[13px] text-[#A8A8A8]"><Icon name="EyeOff" size={20} />Publicação ocultada após denúncias. Está em análise pela moderação.</div>
  );
  const minha = s.reacoes[p.id]; const curtido = s.curtidas.includes(p.id) || !!minha;
  const coms = (COMENTARIOS0[p.id] || []).length + (s.comentarios[p.id] || []).length + Math.max(0, (p.coms || 0) - (COMENTARIOS0[p.id] || []).length);
  const reagir = (e) => { up((x) => ({ reacoes: { ...x.reacoes, [p.id]: e }, curtidas: x.curtidas.filter((y) => y !== p.id) })); setPicker(false); };
  const tirar = () => up((x) => { const r = { ...x.reacoes }; delete r[p.id]; return { reacoes: r, curtidas: x.curtidas.filter((y) => y !== p.id) }; });
  const clique = () => (curtido ? tirar() : curtir(p.id));
  const dbl = () => { if (!curtido) curtir(p.id); setCoracao((x) => x + 1); };
  const resumo = ['🔥', '💛', '😂'].slice(0, 2 + (p.likes > 50 ? 1 : 0));
  return (
    <article className="relative border-b border-[#262626] md:border md:rounded-lg md:mb-4 md:px-4 md:pb-3 bg-black fade">
      <PostCabecalho nome={p.autor} sub={`${p.bairro} · ${p.tempo}`} ouro={p.tipo === 'Parceiro'} verificado={p.tipo === 'Parceiro'} direita={<button onClick={() => setMenu(!menu)} aria-label="Mais opções"><Icon name="Ellipsis" size={20} /></button>} />
      {menu && <div className="fade absolute right-3 md:right-4 top-11 z-20 w-52 rounded-lg bg-[#1A1A1A] border border-[#262626] shadow-2xl overflow-hidden text-[14px]">
        <button onClick={() => { setMenu(false); denunciar(p.id); }} className="w-full px-3.5 py-2.5 text-left text-[#ED4956] font-semibold flex items-center gap-2 hover:bg-[#262626]"><Icon name="Flag" size={16} />Denunciar</button>
        <button onClick={() => { setMenu(false); up((x) => ({ escondidos: [...x.escondidos, p.id] })); toast('Você não vai mais ver essa publicação'); }} className="w-full px-3.5 py-2.5 text-left flex items-center gap-2 hover:bg-[#262626]"><Icon name="EyeOff" size={16} />Não quero ver isso</button>
        <button onClick={() => { setMenu(false); toast('Link copiado'); }} className="w-full px-3.5 py-2.5 text-left flex items-center gap-2 hover:bg-[#262626]"><Icon name="Link" size={16} />Copiar link</button>
      </div>}
      {p.icon ? (
        <div className="relative select-none" onDoubleClick={dbl}><Ph tone={p.tone} icon={p.icon} className="aspect-square md:aspect-[4/3] md:rounded-md w-full" size={72} />{coracao > 0 && <span key={coracao} className="pop absolute inset-0 grid place-items-center pointer-events-none"><Icon name="Heart" size={110} fill="#fff" className="text-white drop-shadow-xl" /></span>}</div>
      ) : (
        <div onDoubleClick={dbl} className="relative mx-3 md:mx-0 rounded-md bg-gradient-to-br from-[#1A1503] to-[#0A0A0A] border border-[#262626] px-5 py-10 text-center select-none"><p className="text-[19px] font-semibold leading-snug">{p.texto}</p>{coracao > 0 && <span key={coracao} className="pop absolute inset-0 grid place-items-center pointer-events-none"><Icon name="Heart" size={90} fill="#fff" className="text-white" /></span>}</div>
      )}
      <div className="relative flex items-center gap-3.5 px-3 md:px-0 pt-2.5">
        <button onClick={clique} aria-label={curtido ? 'Tirar reação' : 'Curtir'} className="active:scale-90 transition-transform w-[25px] h-[25px] grid place-items-center">{minha ? <span className="text-[22px] leading-none">{minha}</span> : <Icon name="Heart" size={25} className={curtido ? 'text-[#ED4956]' : ''} fill={curtido ? '#ED4956' : 'none'} />}</button>
        <button onClick={() => setPicker(!picker)} aria-label="Escolher reação" className="text-[#A8A8A8]"><Icon name="SmilePlus" size={22} /></button>
        <button onClick={() => abrirComentarios(p)} aria-label="Comentar"><Icon name="MessageCircle" size={24} /></button>
        <button onClick={() => toast('Link copiado para compartilhar')} aria-label="Compartilhar"><Icon name="Send" size={23} /></button>
        <button onClick={() => toggleSalvo(p.id)} aria-label="Salvar" className="ml-auto"><Icon name="Bookmark" size={24} fill={s.salvos.includes(p.id) ? '#F5F5F5' : 'none'} /></button>
        {picker && <div className="fade absolute left-2 md:-left-1 -top-12 z-20 flex gap-1 bg-[#1A1A1A] border border-[#262626] rounded-full px-2 py-1.5 shadow-2xl">{REACOES.map(([e, l]) => <button key={e} onClick={() => reagir(e)} title={l} aria-label={l} className={`w-9 h-9 rounded-full grid place-items-center text-[22px] hover:scale-125 transition-transform ${minha === e ? 'bg-[#FFC107]/20' : ''}`}>{e}</button>)}</div>}
      </div>
      <div className="px-3 md:px-0 pt-2 text-[14px] space-y-1">
        <p className="font-semibold tabnum flex items-center gap-1.5"><span className="text-[14px]">{(minha ? [minha, ...resumo.filter((x) => x !== minha)] : resumo).slice(0, 3).join('')}</span>{fmt(p.likes + (curtido ? 1 : 0))} reações</p>
        {p.icon && <p><span className="font-semibold mr-1.5">{p.user || p.autor}</span>{p.texto}</p>}
        {coms > 0 && <button onClick={() => abrirComentarios(p)} className="text-[#A8A8A8]">Ver todos os {coms} comentários</button>}
        <button onClick={() => abrirComentarios(p)} className="block text-[#737373] text-[13px] pb-3 md:pb-0">Adicione um comentário...</button>
      </div>
    </article>
  );
}

/* ---------- Blocos novos da página inicial ---------- */
function PainelDoDia({ s, go, posts }) {
  const d = new Date(); const data = d.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
  const h = d.getHours(); const saud = h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
  return (
    <section className="px-3 md:px-0 pt-1 pb-3 md:mb-1">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0"><p className="text-[20px] font-bold leading-tight">{saud}, {s.nome.split(' ')[0]}!</p><p className="text-[13px] text-[#A8A8A8] first-letter:uppercase">{data} · <Icon name="CloudSun" size={14} className="inline -mt-0.5 text-[#FFC107]" /> 24°, parcialmente nublado</p></div>
      </div>
      <div className="grid grid-cols-2 gap-2 mt-3">
        <button onClick={() => go('criar')} className="h-10 rounded-lg bg-[#FFC107] text-[#0A0A0A] text-[14px] font-semibold flex items-center justify-center gap-1.5"><Icon name="SquarePen" size={17} />Postar algo</button>
        <button onClick={() => go('meu-bairro')} className="h-10 rounded-lg bg-[#1A1A1A] text-[14px] font-semibold flex items-center justify-center gap-1.5"><Icon name="MapPin" size={17} />Meu bairro · {s.bairro}</button>
      </div>
      <p className="text-[12px] text-[#A8A8A8] mt-2.5 tabnum"><b className="text-[#F5F5F5]">{posts.length + s.posts.length + 14}</b> posts novos hoje · <b className="text-[#F5F5F5]">{EVENTOS.length}</b> eventos nos próximos 30 dias</p>
    </section>
  );
}
function CampanhaFundador({ s, go }) {
  if (s.selos.includes('Fundador')) return null;
  const feitos = FUNDADOR.filter(([id]) => METAS_UNICAS.find((m) => m.id === id).ok(s)).length; const dias = diasAte('2026-11-30');
  return (
    <section className="mx-3 md:mx-0 mb-3 md:mb-4 rounded-xl border border-[#FFC107]/50 bg-gradient-to-br from-[#1A1503] to-black p-4 fade">
      <div className="flex items-start gap-3"><span className="w-11 h-11 rounded-xl bg-[#FFC107] text-black grid place-items-center shrink-0"><Icon name="Award" size={24} /></span>
        <div className="flex-1"><p className="text-[11px] font-bold uppercase tracking-[.14em] text-[#FFC107]">Campanha · faltam {dias} dias</p><b className="text-[16px] block leading-tight mt-0.5">Ganhe o selo Fundador do Conecta ABC</b><p className="text-[13px] text-[#A8A8A8] mt-0.5">Complete os 5 passos até 30/11. O selo fica pra sempre no seu perfil e na carteirinha.</p></div></div>
      <div className="h-1.5 rounded-full bg-[#262626] mt-3 overflow-hidden"><div className="h-full bg-[#FFC107]" style={{ width: (feitos / FUNDADOR.length) * 100 + '%' }} /></div>
      <ul className="mt-3 space-y-1.5">{FUNDADOR.map(([id, l]) => { const ok = METAS_UNICAS.find((m) => m.id === id).ok(s); return <li key={id} className="flex items-center gap-2 text-[13px]"><Icon name={ok ? 'CircleCheck' : 'Circle'} size={17} className={ok ? 'text-[#22C55E]' : 'text-[#737373]'} /><span className={ok ? 'line-through text-[#A8A8A8]' : ''}>{l}</span></li>; })}</ul>
      <button onClick={() => go('nivel')} className="mt-3 text-[13px] font-semibold text-[#FFC107] flex items-center gap-1">Ver metas e pontos<Icon name="ChevronRight" size={15} /></button>
    </section>
  );
}
function SugestoesAmigos({ s, go, pedirAmizade }) {
  const sug = PESSOAS.filter((p) => !s.amigos.includes(p.user) && !s.pedidos.includes(p.user)).sort((a, b) => (b.bairro === s.bairro) - (a.bairro === s.bairro) || b.mutuos - a.mutuos);
  if (!sug.length) return null;
  return (
    <BlocoBox titulo="Talvez você conheça" icon="UserPlus" acao={<button onClick={() => go('amigos')} className="text-[13px] font-semibold text-[#FFC107]">Ver todos</button>}>
      <div className="flex gap-2.5 overflow-x-auto no-scrollbar -mx-3 md:-mx-4 px-3 md:px-4">{sug.map((p) => { const env = s.enviados.includes(p.user); return (
        <div key={p.user} className="w-[150px] shrink-0 border border-[#262626] rounded-lg p-3 text-center"><span className="relative inline-block"><Avatar nome={p.nome} size={64} />{p.online && <span className="absolute bottom-0.5 right-0.5 w-[11px] h-[11px] rounded-full bg-[#22C55E] border-2 border-black" />}</span><b className="block text-[13px] mt-2 truncate">{p.nome}</b><p className="text-[11px] text-[#A8A8A8] truncate">{p.bairro === s.bairro ? 'Do seu bairro' : p.bairro} · {p.mutuos} em comum</p>
          <button onClick={() => pedirAmizade(p.user)} className={`mt-2.5 w-full h-8 rounded-lg text-[13px] font-semibold ${env ? 'bg-[#262626]' : 'bg-[#FFC107] text-[#0A0A0A]'}`}>{env ? 'Pedido enviado' : 'Adicionar'}</button></div>); })}</div>
    </BlocoBox>
  );
}
const scorePost = (p, s) => p.likes + (p.coms || 0) * 2 + (s.curtidas.includes(p.id) || s.reacoes[p.id] ? 1 : 0);
function TopSemanaBloco({ s, go, posts }) {
  const top = [...s.posts, ...posts].sort((a, b) => scorePost(b, s) - scorePost(a, s)).slice(0, 3);
  return (
    <BlocoBox titulo="Top da semana" icon="Flame" acao={<button onClick={() => go('top')} className="text-[13px] font-semibold text-[#FFC107]">Ver top 5</button>}>
      <ol className="space-y-2.5">{top.map((p, i) => (<li key={p.id} className="flex items-start gap-3"><span className="text-[22px] font-extrabold text-[#FFC107] w-6 tabnum leading-none mt-1">{i + 1}</span><span className="flex-1 min-w-0"><b className="text-[13px] block">{p.autor}</b><span className="text-[13px] text-[#A8A8A8] line-clamp-2">{p.texto}</span></span><span className="text-[12px] text-[#A8A8A8] tabnum shrink-0">{fmt(scorePost(p, s))} pts</span></li>))}</ol>
    </BlocoBox>
  );
}
function SorteioBloco({ s, go, participar }) {
  const g = SORTEIOS[1]; const dentro = s.sorteios.includes(g.id);
  return (
    <BlocoBox titulo="Sorteio da semana" icon="Gift" acao={<button onClick={() => go('sorteios')} className="text-[13px] font-semibold text-[#FFC107]">Todos</button>}>
      <div className="flex gap-3"><Ph tone={g.tone} icon={g.icon} className="w-20 h-20 rounded-lg shrink-0" size={32} /><div className="min-w-0 flex-1"><b className="text-[15px] block leading-snug">{g.titulo}</b><p className="text-[12px] text-[#A8A8A8]">Oferecido por {g.parceiro} · até {g.fim}</p><p className="text-[12px] text-[#A8A8A8] tabnum">{fmt(g.inscritos + (dentro ? 1 : 0))} participando</p></div></div>
      <Btn tipo={dentro ? 'ok' : 'ouro'} onClick={() => !dentro && participar(g.id)} className="w-full mt-3"><Icon name={dentro ? 'CircleCheck' : 'Ticket'} size={16} />{dentro ? 'Você está participando' : 'Participar grátis'}</Btn>
    </BlocoBox>
  );
}
function VozBloco({ go, s }) {
  const v = [...s.falas, ...VOZ0][0];
  return (
    <BlocoBox titulo="Voz do Bairro" icon="Megaphone" acao={<button onClick={() => go('voz')} className="text-[13px] font-semibold text-[#FFC107]">Ver relatos</button>}>
      <div className="flex items-center gap-2 mb-1.5"><Pill cor={COR_VOZ[v.tipo]}>{v.tipo}</Pill><span className="text-[12px] text-[#A8A8A8]">{v.anon ? 'Anônimo' : v.autor} · {v.bairro} · {v.tempo}</span></div>
      <p className="text-[14px] leading-relaxed">{v.texto}</p>
      <button onClick={() => go('voz')} className="mt-3 text-[13px] font-semibold flex items-center gap-1.5 text-[#A8A8A8]"><Icon name="SquarePen" size={15} />Contar uma história, elogiar ou reclamar</button>
    </BlocoBox>
  );
}

/* ---------- Placar dos bairros (com moradores, posts e compartilhar) ---------- */
function PlacarBloco({ s, go, toast, completo }) {
  const total = PLACAR.reduce((a, [, p]) => a + p, 0);
  const mor = { Jardim: 1840, Centro: 1620, 'Vila Assunção': 1310, 'Casa Branca': 1190, 'Vila Luzita': 980, Campestre: 870 };
  const pos = PLACAR.findIndex(([b]) => b === s.bairro) + 1;
  const txt = encodeURIComponent(`O ${s.bairro} está em ${pos || '—'}º no placar dos bairros do Conecta ABC! Bora subir: conectaabc.app/c/${s.user}`);
  return (
    <BlocoBox titulo="Placar dos bairros" icon="Flag" acao={!completo && <button onClick={() => go('placar')} className="text-[13px] font-semibold text-[#FFC107]">Ver placar</button>}>
      <p className="text-[12px] text-[#A8A8A8] -mt-2 mb-3">Soma dos pontos dos moradores · {fmt(total)} pontos no total · temporada de novembro</p>
      <div className="space-y-3">{PLACAR.map(([b, pts], i) => (
        <div key={b}>
          <div className="flex items-center justify-between text-[14px]"><span className="flex items-center gap-2"><span className={`w-6 h-6 rounded-md grid place-items-center text-[12px] font-bold ${i === 0 ? 'bg-[#FFC107] text-black' : 'bg-[#1A1A1A]'}`}>{i + 1}</span>{b}{b === s.bairro && <span className="text-[11px] font-bold text-[#FFC107] bg-[#FFC107]/15 rounded px-1.5">SEU BAIRRO</span>}</span><span className="tabnum text-[#A8A8A8]">{fmt(pts)}</span></div>
          <div className="h-2 rounded-full bg-[#1A1A1A] mt-1.5 overflow-hidden"><div className={`h-full rounded-full ${i === 0 ? 'bg-gradient-to-r from-[#FFC107] to-[#FF8A00]' : 'bg-white/25'}`} style={{ width: (pts / PLACAR[0][1]) * 100 + '%' }} /></div>
          {completo && <p className="text-[12px] text-[#A8A8A8] mt-1 tabnum">{fmt(mor[b] || 600)} moradores · {fmt(Math.round(pts / 38))} posts no mês</p>}
        </div>))}</div>
      <div className="grid grid-cols-2 gap-2 mt-4">
        <a href={'https://wa.me/?text=' + txt} target="_blank" rel="noopener" className="h-9 rounded-lg bg-[#25D366] text-white text-[13px] font-semibold flex items-center justify-center gap-1.5"><Icon name="MessageCircle" size={16} />Chamar vizinhos</a>
        <Btn tipo="sec" onClick={() => toast('Imagem do placar pronta pra postar no story')} className="text-[13px]"><Icon name="Image" size={16} />Postar no story</Btn>
      </div>
    </BlocoBox>
  );
}
function TelaPlacar(ctx) { return (<Pagina titulo="Placar dos bairros" sub="Cada ponto seu soma pro seu bairro." icon="Flag" go={ctx.go}><div className="-mx-4 md:mx-0"><PlacarBloco {...ctx} completo /></div></Pagina>); }

/* ---------- Mapa com check-in e avaliação ---------- */
function MapaBloco({ alto, ctx }) {
  const [cat, setCat] = useState('Todos'); const [sel, setSel] = useState(LUGARES[0]);
  const lista = LUGARES.filter((l) => cat === 'Todos' || l.cat === cat);
  const s = ctx && ctx.s; const visitados = s ? s.checkins.length : 0;
  const bairrosV = s ? new Set(s.checkins.map((id) => (LUGARES.find((l) => l.id === id) || {}).cat)).size : 0;
  const titulo = visitados >= 6 ? 'Desbravador do ABC' : visitados >= 3 ? 'Explorador' : 'Explorador iniciante';
  const fezCheck = s && s.checkins.includes(sel.id); const nota = s && s.avaliacoes[sel.id];
  return (
    <div>
      <div className="relative rounded-xl overflow-hidden border border-[#262626]">
        <svg viewBox="0 0 100 70" preserveAspectRatio="none" className={`w-full block ${alto ? 'h-[360px] md:h-[460px]' : 'h-[200px]'}`} aria-label="Mapa ilustrado de Santo André">
          <rect width="100" height="70" fill="#0E0E0E" /><path d="M0 46 C25 40 45 54 100 34" stroke="#222" strokeWidth="3.4" fill="none" /><path d="M30 0 L38 70 M72 0 L64 70 M0 16 L100 22" stroke="#1B1B1B" strokeWidth="1.8" /><rect x="6" y="14" width="24" height="16" rx="2" fill="#0F2A1E" /><rect x="2" y="48" width="18" height="16" rx="2" fill="#0F2A1E" />
        </svg>
        {lista.map((l) => (<button key={l.id} onClick={() => setSel(l)} style={{ left: l.x + '%', top: l.y + '%', background: PIN_COR[l.cat] }} className={`absolute -translate-x-1/2 -translate-y-full w-7 h-7 rounded-full rounded-br-none rotate-45 border-2 transition-transform ${sel && sel.id === l.id ? 'border-white scale-125' : 'border-black'}`} aria-label={l.nome}><span className="block -rotate-45 text-[10px] font-black text-white">{s && s.checkins.includes(l.id) ? '✓' : l.cat[0]}</span></button>))}
        {sel && <div className="absolute left-3 bottom-3 right-3 sm:right-auto bg-black/85 backdrop-blur border border-[#262626] rounded-lg px-3 py-2 flex items-center gap-2.5"><span className="w-2.5 h-2.5 rounded-full" style={{ background: PIN_COR[sel.cat] }} /><span><b className="text-[13px] block">{sel.nome}</b><span className="text-[12px] text-[#A8A8A8]">{sel.cat} · ★ {sel.nota.toLocaleString('pt-BR')}</span></span></div>}
      </div>
      <div className="mt-3"><Tabs opcoes={['Todos', 'Comer', 'Lazer', 'Cultura', 'Saúde']} valor={cat} set={setCat} /></div>
      {ctx && <div className="mt-3 border border-[#262626] rounded-lg p-3">
        <div className="flex items-center justify-between gap-2"><b className="text-[14px] truncate">{sel.nome}</b><Btn tipo={fezCheck ? 'ok' : 'ouro'} onClick={() => ctx.fazerCheckin(sel.id)} className="h-8 px-3 text-[13px] shrink-0"><Icon name={fezCheck ? 'CircleCheck' : 'MapPinCheck'} size={15} />{fezCheck ? 'Check-in feito' : 'Check-in'}</Btn></div>
        <div className="flex items-center gap-1 mt-2"><span className="text-[12px] text-[#A8A8A8] mr-1">Sua nota:</span>{[1, 2, 3, 4, 5].map((n) => <button key={n} onClick={() => ctx.avaliar(sel.id, n)} aria-label={n + ' estrelas'}><Icon name="Star" size={20} className="text-[#FFC107]" fill={nota >= n ? '#FFC107' : 'none'} /></button>)}</div>
        <p className="text-[12px] text-[#A8A8A8] mt-2 flex items-center gap-1.5"><Icon name="Compass" size={14} className="text-[#FFC107]" /><b className="text-[#F5F5F5]">{titulo}</b> · {visitados} lugares visitados · {bairrosV} tipos de lugar</p>
      </div>}
    </div>
  );
}
function ExploreBloco({ go, ctx }) {
  return (<BlocoBox titulo="Explore Santo André" icon="MapPin" acao={<button onClick={() => go('mapa')} className="text-[13px] font-semibold text-[#FFC107]">Abrir mapa</button>}><MapaBloco ctx={ctx} /><p className="text-[12px] text-[#A8A8A8] mt-2">Check-in vale 10 pontos e avaliação vale 15, até 5 por dia.</p></BlocoBox>);
}
function TelaMapa(ctx) { return (<Pagina titulo="Explore Santo André" sub="Faça check-in, avalie e suba seu título de explorador." icon="MapPin" go={ctx.go} larga acao={<Btn tipo="sec" onClick={() => ctx.toast('Sugestão enviada para moderação')} className="h-9"><Icon name="Plus" size={16} /><span className="hidden sm:inline">Sugerir lugar</span></Btn>}><MapaBloco alto ctx={ctx} /></Pagina>); }

/* ---------- Feed com abas Cidade / Amigos / Meu bairro ---------- */
function TelaFeed(ctx) {
  const { s, go, votar, posts, produtos, enquetes, pets, rotaBase } = ctx;
  const [aba, setAba] = useState(rotaBase === 'meu-bairro' ? 'Meu bairro' : 'Cidade');
  useEffect(() => { if (rotaBase === 'meu-bairro') setAba('Meu bairro'); }, [rotaBase]);
  const filas = {
    post: posts.map((d) => ({ k: 'post', d })), noticia: NOTICIAS.map((d) => ({ k: 'noticia', d })), evento: EVENTOS.map((d) => ({ k: 'evento', d })),
    animal: pets.map((d) => ({ k: 'animal', d })), parceiro: PARCEIROS.slice(0, 4).map((d) => ({ k: 'parceiro', d })), produto: produtos.slice(0, 5).map((d) => ({ k: 'produto', d })), vaga: VAGAS.slice(0, 3).map((d) => ({ k: 'vaga', d })),
  };
  const ordem = ['post', 'noticia', 'evento', 'animal', 'parceiro', 'post', 'produto', 'noticia', 'evento', 'vaga'];
  let seq = []; let voltas = 0;
  while (Object.values(filas).some((f) => f.length) && voltas < 30) { ordem.forEach((t) => { if (filas[t].length) seq.push(filas[t].shift()); }); voltas++; }
  if (aba === 'Amigos') seq = seq.filter((it) => it.k === 'post' && s.amigos.includes(it.d.user));
  if (aba === 'Meu bairro') seq = seq.filter((it) => (it.d.bairro || '').includes(s.bairro));
  const ESPECIAIS = aba !== 'Cidade' ? {} : {
    1: <EmAltaCarrossel key="emalta" ctx={ctx} />,
    3: <ExploreBloco key="explore" go={go} ctx={ctx} />,
    4: <SugestoesAmigos key="sug" {...ctx} />,
    5: <CardFeed key="enq1" cab={<PostCabecalho nome="Conecta ABC" sub={`Enquete · ${enquetes[0].autor}`} ouro verificado onNome={() => go('enquetes')} />}><EnqueteBloco q={enquetes[0]} voto={s.votos[enquetes[0].id]} votar={votar} extra={s.extraVotos[enquetes[0].id]} /></CardFeed>,
    7: <RankingBloco key="rank" {...ctx} />,
    9: <TopSemanaBloco key="top" {...ctx} />,
    10: <PlacarBloco key="placar" {...ctx} />,
    12: <SorteioBloco key="sorteio" {...ctx} />,
    13: <ComunidadesBloco key="com" {...ctx} />,
    15: <VozBloco key="voz" {...ctx} />,
    17: enquetes[1] && <CardFeed key="enq2" cab={<PostCabecalho nome={enquetes[1].autor} sub="Enquete" onNome={() => go('enquetes')} />}><EnqueteBloco q={enquetes[1]} voto={s.votos[enquetes[1].id]} votar={votar} extra={s.extraVotos[enquetes[1].id]} /></CardFeed>,
  };
  const corpo = []; seq.forEach((it, i) => { if (ESPECIAIS[i]) corpo.push(ESPECIAIS[i]); corpo.push(<ItemFeed key={it.k + '-' + it.d.id} it={it} ctx={ctx} />); });
  const meus = s.posts.filter((p) => aba !== 'Meu bairro' || p.bairro === s.bairro);
  return (
    <div className="mx-auto w-full max-w-[470px] md:pt-4 pb-24 md:pb-12">
      <StoriesRow ctx={ctx} />
      <PainelDoDia {...ctx} />
      <CampanhaFundador {...ctx} />
      <DestaquesRotativos go={go} />
      <button onClick={() => go('criar')} className="w-full flex items-center gap-3 px-3 md:px-4 py-3 md:mb-4 border-b border-[#262626] md:border md:rounded-lg text-left">
        <Avatar nome={s.nome} size={38} ouro /><span className="flex-1 h-10 rounded-full bg-[#1A1A1A] px-4 flex items-center text-[14px] text-[#A8A8A8]">No que você está pensando, {s.nome.split(' ')[0]}?</span><Icon name="Image" size={24} className="text-[#22C55E]" />
      </button>
      <div className="sticky top-[52px] md:top-14 z-20 bg-black/95 backdrop-blur flex border-b border-[#262626] md:mb-4">{['Cidade', 'Amigos', 'Meu bairro'].map((a) => <button key={a} onClick={() => setAba(a)} className={`flex-1 h-11 text-[14px] font-semibold border-b-2 ${aba === a ? 'border-[#FFC107] text-white' : 'border-transparent text-[#A8A8A8]'}`}>{a === 'Meu bairro' ? `Meu bairro · ${s.bairro}` : a}</button>)}</div>
      {meus.map((p) => <PostFeed key={p.id} p={p} ctx={ctx} />)}
      {corpo}
      {aba === 'Amigos' && !seq.length && !meus.length && <Vazio icon="Users" texto="Seus amigos ainda não postaram. Adicione mais vizinhos em Amigos." />}
      <div className="py-10 text-center"><span className="w-14 h-14 rounded-full border-2 border-[#FFC107] text-[#FFC107] grid place-items-center mx-auto"><Icon name="Check" size={26} strokeWidth={2.5} /></span><p className="text-[16px] font-semibold mt-3">Você está em dia</p><p className="text-[13px] text-[#A8A8A8]">Viu todas as novidades dos últimos 3 dias.</p></div>
    </div>
  );
}

/* ---------- Amigos ---------- */
function TelaAmigos(ctx) {
  const { s, up, go, toast, pedirAmizade, pontuar } = ctx;
  const [aba, setAba] = useState('Sugestões'); const [q, setQ] = useState('');
  const P = (u) => PESSOAS.find((p) => p.user === u) || { user: u, nome: u, bairro: '—', mutuos: 0 };
  const aceitar = (u) => { up((x) => ({ amigos: [...x.amigos, u], pedidos: x.pedidos.filter((y) => y !== u) })); pontuar('amizade', 'Nova amizade com ' + P(u).nome.split(' ')[0]); };
  const recusar = (u) => { up((x) => ({ pedidos: x.pedidos.filter((y) => y !== u) })); toast('Pedido recusado'); };
  const sug = PESSOAS.filter((p) => !s.amigos.includes(p.user) && !s.pedidos.includes(p.user) && (p.nome + p.bairro).toLowerCase().includes(q.toLowerCase())).sort((a, b) => (b.bairro === s.bairro) - (a.bairro === s.bairro) || b.mutuos - a.mutuos);
  const Linha2 = ({ p, children }) => (<div className="flex items-center gap-3 py-2.5"><span className="relative"><Avatar nome={p.nome} size={48} />{p.online && <span className="absolute bottom-0.5 right-0.5 w-[11px] h-[11px] rounded-full bg-[#22C55E] border-2 border-black" />}</span><span className="flex-1 min-w-0"><b className="text-[14px] block truncate">{p.nome}</b><span className="text-[12px] text-[#A8A8A8]">@{p.user} · {p.bairro === s.bairro ? 'do seu bairro' : p.bairro}{p.mutuos ? ` · ${p.mutuos} em comum` : ''}</span></span>{children}</div>);
  return (
    <Pagina titulo="Amigos" sub="Conecte-se com quem mora perto." icon="Users" go={go} acao={<Btn tipo="sec" onClick={() => go('convidar')} className="h-9"><Icon name="Send" size={16} /><span className="hidden sm:inline">Convidar</span></Btn>}>
      <Tabs opcoes={['Sugestões', `Pedidos (${s.pedidos.length})`, `Meus amigos (${s.amigos.length})`]} valor={aba.startsWith('Pedidos') ? `Pedidos (${s.pedidos.length})` : aba.startsWith('Meus') ? `Meus amigos (${s.amigos.length})` : aba} set={(v) => setAba(v.split(' (')[0])} />
      {aba === 'Sugestões' && <div className="mt-3"><Busca id="busca-pessoas" valor={q} set={setQ} ph="Buscar pessoas por nome ou bairro" /><p className="text-[13px] font-semibold text-[#A8A8A8] mt-4">Talvez você conheça</p><div className="divide-y divide-[#262626]">{sug.map((p) => { const env = s.enviados.includes(p.user); return <Linha2 key={p.user} p={p}><Btn tipo={env ? 'sec' : 'ouro'} onClick={() => pedirAmizade(p.user)} className="h-8 px-3 text-[13px]">{env ? 'Enviado' : 'Adicionar'}</Btn></Linha2>; })}</div>{!sug.length && <Vazio icon="UserCheck" texto="Você já conhece todo mundo por aqui." />}</div>}
      {aba === 'Pedidos' && <div className="mt-3 divide-y divide-[#262626]">{s.pedidos.map((u) => <Linha2 key={u} p={P(u)}><div className="flex gap-1.5"><Btn onClick={() => aceitar(u)} className="h-8 px-3 text-[13px]">Aceitar</Btn><Btn tipo="sec" onClick={() => recusar(u)} className="h-8 px-3 text-[13px]">Recusar</Btn></div></Linha2>)}{!s.pedidos.length && <Vazio icon="Inbox" texto="Nenhum pedido de amizade agora." />}</div>}
      {aba === 'Meus amigos' && <div className="mt-3 divide-y divide-[#262626]">{s.amigos.map((u) => <Linha2 key={u} p={P(u)}><Btn tipo="sec" onClick={() => toast('Perfil público: conectaabc.app/u/' + u)} className="h-8 px-3 text-[13px]">Perfil</Btn></Linha2>)}</div>}
    </Pagina>
  );
}

/* ---------- Cupons com nível mínimo e estoque ---------- */
function TelaCupons(ctx) {
  const { s, up, go, toast, nv } = ctx;
  const [f, setF] = useState('Todos'); const [aberto, setAberto] = useState(null);
  const P = (id) => PARCEIROS.find((p) => p.id === id);
  let lista = CUPONS.filter((c) => f === 'Todos' || (f === 'Acabando' ? c.estoque && c.estoque - c.pegaram <= 10 : f === 'Meus cupons' ? s.cupons.includes(c.id) : P(c.p).cat === f));
  const resgatar = (c) => {
    if (nv + 1 < c.nivel) { toast(`Esse cupom libera no nível ${c.nivel}`); return; }
    if (c.estoque && c.estoque - c.pegaram <= 0) { toast('Esgotado'); return; }
    up((x) => ({ cupons: [...x.cupons, c.id] })); ctx.ganharXP(15, 'm-cupom', 'Cupom resgatado', 'cupom'); setAberto(c.id);
  };
  return (
    <Pagina titulo="Cupons" sub="Descontos dos parceiros. Quanto maior seu nível, mais cupons liberam." icon="TicketPercent" go={go}>
      <div className="rounded-lg border border-[#262626] p-3 flex items-center gap-3 mb-3"><Medalha size={40} /><span className="flex-1 text-[13px]">Você está no <b>nível {nv + 1}</b>. {NIVEIS[nv + 1] ? <>Faltam <b className="text-[#FFC107] tabnum">{NIVEIS[nv + 1][1] - s.xp}</b> pontos para o nível {nv + 2}.</> : 'Todos os cupons liberados.'}</span><button onClick={() => go('nivel')} className="text-[13px] font-semibold text-[#FFC107]">Subir</button></div>
      <Tabs opcoes={['Todos', 'Acabando', 'Meus cupons', 'Alimentação', 'Saúde', 'Auto', 'Beleza']} valor={f} set={setF} />
      <div className="mt-3 space-y-3">{lista.map((c) => { const p = P(c.p); const meu = s.cupons.includes(c.id); const bloq = nv + 1 < c.nivel; const restam = c.estoque ? c.estoque - c.pegaram - (meu ? 1 : 0) : null; return (
        <div key={c.id} className={`border rounded-xl overflow-hidden ${meu ? 'border-[#FFC107]/60' : 'border-[#262626]'}`}>
          <div className="flex gap-3 p-3"><Ph tone={p.tone} icon={p.icon} className="w-16 h-16 rounded-lg shrink-0" size={26} />
            <div className="flex-1 min-w-0"><div className="flex items-center gap-1.5"><Pill cor="ouro">{c.tipo}</Pill>{bloq && <Pill><Icon name="Lock" size={11} />Nível {c.nivel}</Pill>}{restam !== null && restam <= 10 && <Pill cor="bad">Acabando</Pill>}</div>
              <b className="text-[15px] block mt-1 leading-snug">{c.titulo}</b><p className="text-[12px] text-[#A8A8A8]">{p.nome} · válido até {c.validade}</p>
              <p className="text-[12px] text-[#A8A8A8] tabnum mt-0.5">{restam !== null ? `Restam ${restam} de ${c.estoque}` : 'Estoque ilimitado'} · {fmt(c.pegaram + (meu ? 1 : 0))} já pegaram</p></div></div>
          {bloq && <div className="px-3 pb-3"><div className="h-1.5 rounded-full bg-[#262626] overflow-hidden"><div className="h-full bg-[#FFC107]" style={{ width: Math.min(100, (s.xp / NIVEIS[c.nivel - 1][1]) * 100) + '%' }} /></div><p className="text-[12px] text-[#A8A8A8] mt-1 tabnum">Faltam {NIVEIS[c.nivel - 1][1] - s.xp} pontos para liberar</p></div>}
          <div className="border-t border-dashed border-[#363636] px-3 py-2.5 flex items-center gap-2">
            {meu ? <><code className="flex-1 text-[15px] font-extrabold tracking-widest text-[#FFC107] select-all">{codigoUnico(p.cupom, s.user)}</code><Btn tipo="sec" onClick={() => setAberto(aberto === c.id ? null : c.id)} className="h-8 px-3 text-[13px]"><Icon name="QrCode" size={15} />Mostrar</Btn></>
              : <><span className="flex-1 text-[12px] text-[#A8A8A8]">{c.regras}</span><Btn tipo={bloq ? 'sec' : 'ouro'} onClick={() => resgatar(c)} className="h-8 px-3 text-[13px]">{bloq ? 'Bloqueado' : 'Pegar cupom'}</Btn></>}
          </div>
          {meu && aberto === c.id && <div className="fade px-3 pb-4 flex flex-col items-center"><span className="w-36 h-36"><QR /></span><p className="text-[12px] text-[#A8A8A8] mt-2 text-center">Mostre no caixa. O parceiro valida o código {codigoUnico(p.cupom, s.user)}.</p></div>}
        </div>); })}</div>
      {!lista.length && <Vazio icon="TicketPercent" texto="Nenhum cupom nesse filtro." />}
    </Pagina>
  );
}

/* ---------- Voz do Bairro (relatos, com opção anônima) ---------- */
function TelaVoz(ctx) {
  const { s, up, go, toast, denunciar } = ctx;
  const [f, setF] = useState('Todos'); const [novo, setNovo] = useState(false); const [form, setForm] = useState({ tipo: 'História', texto: '', anon: false });
  const lista = [...s.falas, ...VOZ0].filter((v) => !s.ocultos.includes(v.id) && !s.removidos.includes(v.id) && (f === 'Todos' || v.tipo === f));
  const publicar = (e) => { e.preventDefault(); if (form.texto.trim().length < 10) return; up((x) => ({ falas: [{ id: 'vz' + Date.now(), tipo: form.tipo, anon: form.anon, autor: form.anon ? 'Anônimo' : x.nome, autorReal: x.nome, bairro: x.bairro, tempo: 'agora', texto: form.texto.trim(), reacoes: 0 }, ...x.falas] })); setNovo(false); setForm({ tipo: 'História', texto: '', anon: false }); ctx.pontuar('post', 'Relato publicado'); };
  return (
    <Pagina titulo="Voz do Bairro" sub="Histórias, elogios, reclamações e denúncias da vizinhança." icon="Megaphone" go={go} acao={<Btn onClick={() => setNovo(!novo)} className="h-9"><Icon name={novo ? 'X' : 'SquarePen'} size={16} /><span className="hidden sm:inline">{novo ? 'Fechar' : 'Escrever'}</span></Btn>}>
      {novo && <form onSubmit={publicar} className="border border-[#FFC107]/50 rounded-xl p-4 mb-4 space-y-3 fade">
        <div className="grid grid-cols-4 gap-1.5">{['História', 'Elogio', 'Reclamação', 'Denúncia'].map((t) => <button key={t} type="button" onClick={() => setForm({ ...form, tipo: t })} className={`h-9 rounded-lg text-[12px] font-semibold ${form.tipo === t ? 'bg-[#FFC107] text-black' : 'bg-[#1A1A1A]'}`}>{t}</button>)}</div>
        <textarea id="voz-texto" rows={4} className={inputCls + ' h-auto py-2.5'} value={form.texto} onChange={(e) => setForm({ ...form, texto: e.target.value })} placeholder="Conte o que aconteceu. Sem expor nomes ou fotos de pessoas." />
        <label className="flex items-center gap-2.5 text-[14px]"><input id="voz-anon" type="checkbox" checked={form.anon} onChange={(e) => setForm({ ...form, anon: e.target.checked })} className="w-4 h-4 accent-[#FFC107]" />Publicar como anônimo</label>
        {form.anon && <p className="text-[12px] text-[#A8A8A8] -mt-1">Seu nome fica escondido pros vizinhos, mas a moderação consegue ver quem publicou.</p>}
        <Btn type="submit" disabled={form.texto.trim().length < 10} className="w-full h-10">Publicar relato</Btn>
      </form>}
      <Tabs opcoes={['Todos', 'História', 'Elogio', 'Reclamação', 'Denúncia']} valor={f} set={setF} />
      <div className="mt-3 divide-y divide-[#262626]">{lista.map((v) => { const r = s.reacoes[v.id]; return (
        <div key={v.id} className="py-4">
          <div className="flex items-center gap-2.5">{v.anon ? <span className="w-9 h-9 rounded-full bg-[#262626] grid place-items-center"><Icon name="VenetianMask" size={18} /></span> : <Avatar nome={v.autor} size={36} />}<span className="flex-1 min-w-0"><b className="text-[14px] block">{v.anon ? 'Anônimo' : v.autor}</b><span className="text-[12px] text-[#A8A8A8]">{v.bairro} · {v.tempo}{s.admin && v.anon && v.autorReal ? ` · (moderação: ${v.autorReal})` : ''}</span></span><Pill cor={COR_VOZ[v.tipo]}>{v.tipo}</Pill></div>
          <p className="text-[14px] leading-relaxed mt-2.5">{v.texto}</p>
          <div className="flex items-center gap-4 mt-3 text-[13px]">
            <button onClick={() => up((x) => { const n = { ...x.reacoes }; if (n[v.id]) delete n[v.id]; else n[v.id] = '💛'; return { reacoes: n }; })} className={`flex items-center gap-1.5 ${r ? 'text-[#FFC107] font-semibold' : 'text-[#A8A8A8]'}`}>{r || '🤝'} <span className="tabnum">{fmt(v.reacoes + (r ? 1 : 0))}</span> Apoiar</button>
            <button onClick={() => ctx.abrirComentarios({ id: v.id, autor: v.anon ? 'Anônimo' : v.autor, user: v.anon ? 'anonimo' : v.autor, texto: v.texto })} className="flex items-center gap-1.5 text-[#A8A8A8]"><Icon name="MessageCircle" size={16} />Comentar</button>
            <button onClick={() => denunciar(v.id)} className="flex items-center gap-1.5 text-[#A8A8A8] ml-auto"><Icon name="Flag" size={15} />Denunciar</button>
          </div>
        </div>); })}</div>
    </Pagina>
  );
}

/* ---------- Top da semana ---------- */
function TelaTop(ctx) {
  const { s, go, posts } = ctx;
  const top = [...s.posts, ...posts].sort((a, b) => scorePost(b, s) - scorePost(a, s)).slice(0, 5);
  return (
    <Pagina titulo="Top da semana" sub="Os 5 posts com mais reações e comentários nos últimos 7 dias." icon="Flame" go={go}>
      <div className="-mx-4 md:mx-0">{top.map((p, i) => (<div key={p.id} className="relative"><span className="absolute z-10 left-3 md:-left-3 top-2.5 w-7 h-7 rounded-full bg-[#FFC107] text-black text-[13px] font-extrabold grid place-items-center tabnum">{i + 1}</span><div className="pl-9 md:pl-0"><PostFeed p={p} ctx={ctx} /></div></div>))}</div>
    </Pagina>
  );
}

/* ---------- Sorteios ---------- */
function TelaSorteios(ctx) {
  const { s, go, participar } = ctx;
  return (
    <Pagina titulo="Sorteios" sub="Promovidos por parceiros. Participar é grátis." icon="Gift" go={go}>
      {!SORTEIOS.length && <Vazio icon="Gift" texto="Nenhum sorteio no momento." />}
      <div className="space-y-4">{SORTEIOS.map((g) => { const dentro = s.sorteios.includes(g.id); return (
        <div key={g.id} className="border border-[#262626] rounded-xl overflow-hidden"><Ph tone={g.tone} icon={g.icon} className="aspect-[16/7] w-full" size={64} />
          <div className="p-4"><div className="flex items-center gap-2"><Pill cor="ouro">Até {g.fim}</Pill><span className="text-[12px] text-[#A8A8A8] tabnum">{fmt(g.inscritos + (dentro ? 1 : 0))} participando</span></div>
            <b className="text-[18px] block mt-1.5">{g.titulo}</b><p className="text-[13px] text-[#A8A8A8]">Oferecido por {g.parceiro}</p><p className="text-[13px] mt-2">{g.regras}</p>
            <Btn tipo={dentro ? 'ok' : 'ouro'} onClick={() => !dentro && participar(g.id)} className="w-full h-10 mt-3"><Icon name={dentro ? 'CircleCheck' : 'Ticket'} size={17} />{dentro ? 'Você está participando. Boa sorte!' : 'Participar grátis'}</Btn></div></div>); })}</div>
    </Pagina>
  );
}

/* ---------- Melhores do ABC (prêmio anual) ---------- */
function TelaPremio(ctx) {
  const { s, up, go, toast } = ctx;
  const votados = Object.keys(s.votosPremio).length;
  return (
    <Pagina titulo="Melhores do ABC 2026" sub="Votação aberta até 15/12. Resultado no dia 20/12." icon="Trophy" go={go}>
      <div className="flex items-center gap-1.5 mb-4 text-[12px]">{['Indicações', 'Votação', 'Apuração', 'Resultado'].map((e, i) => (<React.Fragment key={e}>{i > 0 && <span className="flex-1 h-px bg-[#363636]" />}<span className={`px-2 py-1 rounded-md font-semibold ${i === 1 ? 'bg-[#FFC107] text-black' : i < 1 ? 'bg-[#262626] text-[#A8A8A8] line-through' : 'bg-[#121212] text-[#737373]'}`}>{e}</span></React.Fragment>))}</div>
      <p className="text-[13px] text-[#A8A8A8] mb-3 tabnum">Você votou em {votados} de {PREMIO.length} categorias.</p>
      <div className="space-y-4">{PREMIO.map((c) => { const voto = s.votosPremio[c.id]; return (
        <div key={c.id} className="border border-[#262626] rounded-xl p-4"><b className="text-[16px]">{c.cat}</b>
          <div className="mt-3 space-y-2">{c.opcoes.map((o) => (<button key={o} onClick={() => { up((x) => ({ votosPremio: { ...x.votosPremio, [c.id]: o } })); toast(voto ? 'Voto alterado' : 'Voto registrado em ' + c.cat); }} className={`w-full h-11 rounded-lg border px-3.5 text-left text-[14px] flex items-center justify-between ${voto === o ? 'border-[#FFC107] bg-[#FFC107]/10' : 'border-[#363636]'}`}>{o}{voto === o && <Icon name="CircleCheck" size={18} className="text-[#FFC107]" />}</button>))}</div></div>); })}</div>
    </Pagina>
  );
}

/* ---------- Convidar amigos ---------- */
function TelaConvidar(ctx) {
  const { s, go, toast, nv } = ctx; const [story, setStory] = useState(false);
  const link = 'conectaabc.app/c/' + s.user; const msg = encodeURIComponent(`Vem pro Conecta ABC, a rede de Santo André e região! Entra pelo meu link: https://${link}`);
  const copiar = () => { try { navigator.clipboard.writeText('https://' + link).then(() => toast('Link copiado'), () => toast('Selecione o link pra copiar')); } catch (e) { toast('Selecione o link pra copiar'); } };
  const RANK = [['Fernanda Costa', 14], ['Jefferson Lima', 11], ['Mariana Souza', 9], [s.nome + ' (você)', s.convites]].sort((a, b) => b[1] - a[1]);
  return (
    <Pagina titulo="Convidar amigos" sub="Cada amigo que entra vale pontos pra você e pro seu bairro." icon="Send" go={go}>
      <div className="rounded-xl border border-[#262626] p-4">
        <p className="text-[13px] text-[#A8A8A8]">Seu link de convite</p>
        <div className="flex gap-2 mt-1.5"><code className="flex-1 min-w-0 h-10 px-3 rounded-lg bg-[#121212] border border-[#262626] flex items-center text-[13px] truncate select-all">{link}</code><Btn tipo="sec" onClick={copiar} className="h-10"><Icon name="Copy" size={16} /></Btn></div>
        <div className="grid grid-cols-2 gap-2 mt-3"><a href={'https://wa.me/?text=' + msg} target="_blank" rel="noopener" className="h-10 rounded-lg bg-[#25D366] text-white text-[14px] font-semibold flex items-center justify-center gap-1.5"><Icon name="MessageCircle" size={17} />WhatsApp</a><Btn tipo="sec" onClick={() => setStory(true)} className="h-10"><Icon name="Image" size={16} />Imagem pro story</Btn></div>
      </div>
      <div className="grid grid-cols-2 gap-2 mt-3"><div className="rounded-xl bg-[#121212] p-3"><b className="text-[22px] text-[#FFC107]">+100</b><p className="text-[12px] text-[#A8A8A8]">pra você, quando o convidado completa o perfil com foto</p></div><div className="rounded-xl bg-[#121212] p-3"><b className="text-[22px] text-[#FFC107]">+30</b><p className="text-[12px] text-[#A8A8A8]">pro amigo que entrou pelo seu link</p></div></div>
      <div className="mt-4 rounded-xl border border-[#262626] p-4"><div className="flex items-center justify-between"><b className="text-[14px] flex items-center gap-1.5"><Icon name="Crown" size={17} className="text-[#FFC107]" />Selo Embaixador</b><span className="text-[13px] tabnum">{Math.min(s.convites, 10)}/10</span></div><div className="h-2 rounded-full bg-[#262626] overflow-hidden mt-2"><div className="h-full bg-[#FFC107]" style={{ width: Math.min(100, s.convites * 10) + '%' }} /></div><p className="text-[12px] text-[#A8A8A8] mt-1.5">Convide 10 amigos que completem o perfil pra ganhar o selo permanente.</p></div>
      <b className="block text-[15px] mt-5 mb-2">Quem mais convidou em novembro</b>
      <div className="divide-y divide-[#262626]">{RANK.map(([n, c], i) => (<div key={n} className="flex items-center gap-3 py-2.5"><span className="w-5 text-center font-bold text-[#FFC107] tabnum">{i + 1}</span><Avatar nome={n} size={36} ouro={n.includes('(você)')} /><span className="flex-1 text-[14px]">{n}</span><span className="text-[13px] tabnum text-[#A8A8A8]">{c} convites</span></div>))}</div>
      {story && <div className="fixed inset-0 z-[100] bg-black/85 grid place-items-center p-4" onClick={() => setStory(false)}><div onClick={(e) => e.stopPropagation()} className="fade w-[300px] aspect-[9/16] rounded-2xl overflow-hidden relative bg-gradient-to-b from-[#1A1503] via-black to-black border border-[#262626] p-5 flex flex-col">
        <Wordmark /><p className="text-[22px] font-extrabold leading-tight mt-6">Tô no <span className="text-[#FFC107]">Conecta ABC</span>. Bora?</p>
        <div className="mt-5 rounded-xl p-3" style={{ background: faixaCarteirinha(nv).bg, color: faixaCarteirinha(nv).fg }}><b className="text-[15px] block">{s.nome}</b><span className="text-[12px]">@{s.user} · {s.bairro} · nível {nv + 1}</span></div>
        <span className="mt-auto mx-auto w-28 h-28"><QR /></span><p className="text-[12px] text-center text-[#A8A8A8] mt-2">{link}</p>
        <button onClick={() => { setStory(false); toast('Imagem salva pra postar no story'); }} className="absolute top-3 right-3 h-8 px-3 rounded-full bg-white text-black text-[12px] font-semibold">Usar</button></div></div>}
    </Pagina>
  );
}

/* ---------- Meu nível, metas e pontos ---------- */
function TelaNivel(ctx) {
  const { s, up, go, nv, prox, pct, resgatarMeta, toast } = ctx;
  const agora = hoje(); const deHoje = s.historico.filter((h) => new Date(h.t).toISOString().slice(0, 10) === agora);
  const acao = (m) => { if (m.acao === 'foto') { up({ foto: true }); toast('Foto adicionada'); } if (m.acao === 'capa') { up({ capa: true }); toast('Capa escolhida'); } if (m.acao === 'app') { up({ appInstalado: true }); toast('Conecta ABC adicionado à tela inicial'); } if (m.acao === 'notif') { up({ notifAtivas: true }); toast('Notificações ativadas'); } if (m.ir) go(m.ir); };
  return (
    <Pagina titulo="Meu nível" icon="Trophy" go={go}>
      <div className="rounded-xl border border-[#262626] p-4 flex items-center gap-4"><Medalha size={72} /><div className="flex-1"><p className="text-[12px] text-[#A8A8A8] uppercase tracking-wide font-semibold">Nível {nv + 1} de {NIVEIS.length}</p><p className="text-[22px] font-bold leading-tight">{NIVEIS[nv][0]}</p><div className="h-2 rounded-full bg-[#262626] overflow-hidden mt-2"><div className="h-full bg-[#FFC107]" style={{ width: pct + '%' }} /></div><p className="text-[13px] text-[#A8A8A8] mt-1.5 tabnum">{fmt(s.xp)} pontos · {prox ? `faltam ${fmt(prox[1] - s.xp)} para ${prox[0]}` : 'nível máximo'}</p></div></div>
      <div className="grid grid-cols-4 gap-2 mt-3">{[['carteirinha', 'Carteirinha', 'IdCard'], ['cupons', 'Cupons', 'TicketPercent'], ['pontua', 'Ranking', 'Trophy'], ['convidar', 'Convidar', 'Send']].map(([r, l, ic]) => <button key={r} onClick={() => go(r)} className="rounded-xl bg-[#121212] py-3 flex flex-col items-center gap-1.5 text-[12px] font-semibold"><Icon name={ic} size={20} className="text-[#FFC107]" />{l}</button>)}</div>
      {s.selos.length > 0 && <div className="flex gap-2 mt-3 flex-wrap">{s.selos.map((x) => <Pill key={x} cor="ouro"><Icon name="Award" size={12} />{x}</Pill>)}</div>}
      <b className="block text-[16px] mt-6 mb-1">Metas únicas</b><p className="text-[12px] text-[#A8A8A8] mb-2">Pontos pagos uma vez só.</p>
      <div className="divide-y divide-[#262626]">{METAS_UNICAS.map((m) => { const pago = s.metas.includes(m.id); const ok = m.ok(s); return (
        <div key={m.id} className="flex items-center gap-3 py-2.5"><Icon name={pago ? 'CircleCheck' : ok ? 'CircleDot' : 'Circle'} size={20} className={pago ? 'text-[#22C55E]' : ok ? 'text-[#FFC107]' : 'text-[#737373]'} /><span className="flex-1 min-w-0"><b className={`text-[14px] block ${pago ? 'text-[#A8A8A8]' : ''}`}>{m.titulo}</b><span className="text-[12px] text-[#A8A8A8]">{m.d}</span></span>
          <span className="text-[13px] font-bold text-[#FFC107] tabnum w-12 text-right">+{m.n}</span>
          {pago ? <span className="w-[86px] text-[12px] text-[#A8A8A8] text-right">Recebido</span> : ok ? <Btn onClick={() => resgatarMeta(m)} className="h-8 px-3 text-[13px] w-[86px]">Resgatar</Btn> : <Btn tipo="sec" onClick={() => acao(m)} className="h-8 px-3 text-[13px] w-[86px]">Fazer</Btn>}</div>); })}</div>
      <b className="block text-[16px] mt-6 mb-1">Pontos de hoje</b><p className="text-[12px] text-[#A8A8A8] mb-2">Passou do limite, a ação continua valendo, mas só pontua amanhã.</p>
      <div className="grid grid-cols-2 gap-2">{Object.entries(LIMITES).map(([k, l]) => { const n = deHoje.filter((h) => h.cat === k).length; return (<div key={k} className="rounded-lg bg-[#121212] p-3"><p className="text-[12px] text-[#A8A8A8]">{l.label}</p><p className="text-[15px] font-bold tabnum">{n}/{l.max} <span className="text-[12px] font-normal text-[#A8A8A8]">· +{l.n} cada</span></p><div className="h-1 rounded-full bg-[#262626] mt-1.5 overflow-hidden"><div className={`h-full ${n >= l.max ? 'bg-[#ED4956]' : 'bg-[#FFC107]'}`} style={{ width: Math.min(100, (n / l.max) * 100) + '%' }} /></div></div>); })}</div>
      <b className="block text-[16px] mt-6 mb-2">Últimos pontos</b>
      {!s.historico.length && <p className="text-[13px] text-[#A8A8A8]">Seus pontos vão aparecer aqui.</p>}
      <div className="divide-y divide-[#262626]">{s.historico.slice(0, 15).map((h, i) => (<div key={i} className="flex items-center justify-between py-2.5 text-[14px]"><span className="min-w-0 truncate">{h.msg}</span><span className="flex items-center gap-3 shrink-0"><span className="text-[12px] text-[#A8A8A8]">{new Date(h.t).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span><b className="text-[#22C55E] tabnum">+{h.n}</b></span></div>))}</div>
    </Pagina>
  );
}

/* ---------- Guia de empresas + QR do balcão ---------- */
function TelaEmpresas(ctx) {
  const { s, go, toast } = ctx; const [cat, setCat] = useState(null);
  const lista = PARCEIROS.filter((p) => !cat || CAT_PARCEIRO[p.cat] === cat || p.cat === cat);
  return (
    <Pagina titulo="Guia de empresas" sub="Comércios e serviços de Santo André e região." icon="Store" go={go} larga acao={<Btn tipo="sec" onClick={() => go('institucional')} className="h-9"><Icon name="Plus" size={16} /><span className="hidden sm:inline">Cadastrar empresa</span></Btn>}>
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">{EMP_CATS.map(([c, ic, n]) => (<button key={c} onClick={() => setCat(cat === c ? null : c)} className={`rounded-xl p-2.5 flex flex-col items-center gap-1.5 text-center ${cat === c ? 'bg-[#FFC107] text-black' : 'bg-[#121212] hover:bg-[#1A1A1A]'}`}><Icon name={ic} size={22} className={cat === c ? '' : 'text-[#FFC107]'} /><span className="text-[12px] font-semibold leading-tight">{c}</span><span className={`text-[11px] tabnum ${cat === c ? 'text-black/70' : 'text-[#A8A8A8]'}`}>{n}</span></button>))}</div>
      <b className="block text-[15px] mt-5 mb-1">{cat || 'Em destaque'}</b>
      <div className="divide-y divide-[#262626]">{lista.map((p) => { const seg = s.seguindo.includes(p.id); return (<div key={p.id} className="flex items-center gap-3 py-3"><button onClick={() => go('parceiro-' + p.id)} className="flex items-center gap-3 flex-1 min-w-0 text-left"><Ph tone={p.tone} icon={p.icon} className="w-14 h-14 rounded-xl shrink-0" size={22} /><span className="min-w-0"><b className="text-[14px] flex items-center gap-1">{p.nome}<Verificado /></b><span className="block text-[12px] text-[#A8A8A8]">{p.cat} · {p.bairro} · ★ {p.nota.toLocaleString('pt-BR')}</span></span></button><Btn tipo={seg ? 'sec' : 'ouro'} onClick={() => ctx.seguirEmpresa(p.id)} className="h-8 px-3 text-[13px]">{seg ? 'Seguindo' : 'Seguir'}</Btn></div>); })}</div>
      {!lista.length && <Vazio icon="Store" texto="Ainda não há empresas parceiras nessa categoria." />}
    </Pagina>
  );
}
function QrBalcao({ p, fechar }) {
  return (
    <div className="fixed inset-0 z-[100] bg-black/85 grid place-items-center p-4" onClick={fechar}>
      <div onClick={(e) => e.stopPropagation()} className="fade w-[300px] rounded-2xl bg-[#FFC107] text-black p-6 text-center">
        <p className="text-[12px] font-bold uppercase tracking-[.14em]">Siga a gente no</p><div className="flex justify-center mt-1"><span className="flex items-center gap-2"><ConectaMarca size={26} /><b className="text-[18px] tracking-[.06em]">CONECTA ABC</b></span></div>
        <span className="block w-44 h-44 mx-auto mt-4"><QR /></span><b className="block text-[18px] mt-3">{p.nome}</b><p className="text-[12px]">conectaabc.app/e/{p.user}</p><p className="text-[12px] mt-2">Aponte a câmera e ganhe {p.beneficio.toLowerCase()}</p>
        <button onClick={fechar} className="mt-4 w-full h-9 rounded-lg bg-black text-white text-[13px] font-semibold">Fechar</button>
      </div>
    </div>
  );
}

/* ---------- Moderação (admin) ---------- */
function TelaModeracao(ctx) {
  const { s, up, go, toast, posts } = ctx;
  if (!s.admin) return <Pagina titulo="Moderação" icon="ShieldCheck" go={go}><Vazio icon="Lock" texto="Área só para moderadores. Ative o modo administrador no Menu." /></Pagina>;
  const todos = [...posts, ...s.posts.map((p) => ({ ...p })), ...VOZ0.map((v) => ({ id: v.id, autor: v.anon ? 'Anônimo (' + (v.autorReal || 'autor oculto') + ')' : v.autor, texto: v.texto, tipo: 'Voz do Bairro' })), ...s.falas.map((v) => ({ id: v.id, autor: v.anon ? 'Anônimo (' + v.autorReal + ')' : v.autor, texto: v.texto, tipo: 'Voz do Bairro' }))];
  const fila = todos.filter((p) => (s.denuncias.includes(p.id) || BASE_DEN[p.id]) && !s.removidos.includes(p.id));
  const decidir = (id, a) => { up((x) => ({ ocultos: x.ocultos.filter((y) => y !== id), denuncias: x.denuncias.filter((y) => y !== id), removidos: a === 'remover' ? [...x.removidos, id] : x.removidos, moderados: [...(x.moderados || []), { id, a, t: Date.now() }] })); toast({ remover: 'Conteúdo removido', restaurar: 'Conteúdo restaurado', advertir: 'Autor advertido' }[a]); };
  return (
    <Pagina titulo="Moderação" sub="Conteúdo é ocultado sozinho com 3 denúncias de pessoas diferentes." icon="ShieldCheck" go={go}>
      <div className="grid grid-cols-3 gap-2 mb-4">{[['Na fila', fila.length], ['Ocultos', s.ocultos.length], ['Decididos', (s.moderados || []).length]].map(([l, n]) => <div key={l} className="rounded-lg bg-[#121212] p-3 text-center"><b className="text-[20px] tabnum">{n}</b><p className="text-[12px] text-[#A8A8A8]">{l}</p></div>)}</div>
      {!fila.length && <Vazio icon="ShieldCheck" texto="Fila vazia. Nenhuma denúncia pendente." />}
      <div className="space-y-3">{fila.map((p) => { const n = (BASE_DEN[p.id] || 0) + (s.denuncias.includes(p.id) ? 1 : 0); return (
        <div key={p.id} className="border border-[#262626] rounded-xl p-3.5"><div className="flex items-center gap-2"><Pill cor={n >= 3 ? 'bad' : 'neutro'}>{n} denúncias</Pill>{s.ocultos.includes(p.id) && <Pill>Oculto</Pill>}<span className="text-[12px] text-[#A8A8A8] truncate">{p.tipo || 'Post'} · {p.autor}</span></div>
          <p className="text-[14px] mt-2 line-clamp-3">{p.texto}</p><p className="text-[12px] text-[#A8A8A8] mt-1">Motivo mais citado: informação falsa</p>
          <div className="grid grid-cols-3 gap-2 mt-3"><Btn tipo="sec" onClick={() => decidir(p.id, 'restaurar')} className="text-[13px]">Restaurar</Btn><Btn tipo="sec" onClick={() => decidir(p.id, 'advertir')} className="text-[13px]">Advertir</Btn><Btn onClick={() => decidir(p.id, 'remover')} className="text-[13px] !bg-[#ED4956] !text-white">Remover</Btn></div></div>); })}</div>
    </Pagina>
  );
}

/* ---------- Páginas institucionais (com LGPD) ---------- */
function TelaInstitucional(ctx) {
  const { s, up, go, toast } = ctx; const [aba, setAba] = useState('Sobre'); const [dados, setDados] = useState(false); const [excluir, setExcluir] = useState(false);
  const T = {
    Sobre: ['O Conecta ABC é a rede de Santo André e região: moradores, comércio local e informação da cidade num lugar só.', 'É grátis pra moradores e empresas. A gente se sustenta com parcerias: sorteios patrocinados, destaques e divulgação.'],
    Regras: ['Proibido golpe e informação falsa, discurso de ódio, expor pessoas, conteúdo adulto ou violento, qualquer coisa envolvendo menores, spam, briga política partidária e venda de itens proibidos.', 'Conteúdo com 3 denúncias de pessoas diferentes fica oculto até a moderação decidir. Quem quebra as regras pode ser advertido, suspenso ou banido, e perder pontos.'],
    Termos: ['Ao usar o Conecta ABC você concorda em publicar só o que é seu ou que tem direito de compartilhar.', 'A plataforma não intermedeia pagamentos de anúncios, imóveis ou vagas. Nunca pague sinal antes de ver o produto ou visitar o imóvel.'],
    Privacidade: ['Tratamos seus dados conforme a LGPD. Usamos nome, bairro e atividade só pra fazer o app funcionar e calcular pontos.', 'Você pode exportar seus dados ou excluir sua conta quando quiser, aqui mesmo.'],
    Anuncie: ['Empresas criam a página e postam de graça. Pra quem quer mais alcance: sorteio patrocinado, destaque no feed e banner na página inicial.', 'Fale com a equipe pelo e-mail parcerias@conectaabc.app.'],
  };
  return (
    <Pagina titulo="Sobre o Conecta ABC" icon="Info" go={go}>
      <Tabs opcoes={Object.keys(T)} valor={aba} set={setAba} />
      <div className="mt-4 space-y-3 text-[15px] leading-relaxed">{T[aba].map((t, i) => <p key={i}>{t}</p>)}</div>
      {aba === 'Privacidade' && <div className="mt-5 space-y-2">
        <Btn tipo="sec" onClick={() => setDados(!dados)} className="w-full h-10"><Icon name="FileDown" size={16} />{dados ? 'Fechar meus dados' : 'Ver e exportar meus dados'}</Btn>
        {dados && <pre className="fade text-[11px] bg-[#121212] border border-[#262626] rounded-lg p-3 max-h-60 overflow-auto select-all">{JSON.stringify({ nome: s.nome, usuario: s.user, bairro: s.bairro, pontos: s.xp, amigos: s.amigos, posts: s.posts.length, cupons: s.cupons, historico: s.historico.slice(0, 20) }, null, 2)}</pre>}
        {!excluir ? <Btn tipo="sec" onClick={() => setExcluir(true)} className="w-full h-10 !text-[#ED4956]"><Icon name="Trash2" size={16} />Excluir minha conta</Btn>
          : <div className="fade border border-[#ED4956]/60 rounded-lg p-3"><p className="text-[14px]">Isso apaga seu perfil, posts e pontos desta demonstração. Não dá pra desfazer.</p><div className="grid grid-cols-2 gap-2 mt-3"><Btn tipo="sec" onClick={() => setExcluir(false)}>Cancelar</Btn><Btn onClick={() => { try { localStorage.removeItem(KEY); } catch (e) {} up({ ...INICIAL, logado: false }); toast('Conta excluída'); go('entrar'); }} className="!bg-[#ED4956] !text-white">Excluir</Btn></div></div>}
      </div>}
    </Pagina>
  );
}

/* ---------- Versões ampliadas de telas que já existiam ---------- */
function TelaCarteirinha({ s, nv, go, toast }) {
  const [verso, setVerso] = useState(false); const fx = faixaCarteirinha(nv);
  return (
    <Pagina titulo="Minha carteirinha" voltar="perfil" go={go} acao={<button onClick={() => toast('Imagem da carteirinha pronta pra compartilhar')} aria-label="Compartilhar"><Icon name="Send" size={22} /></button>}>
      <div className="flip-cena mx-auto max-w-[400px]" onClick={() => setVerso(!verso)} role="button" tabIndex={0} aria-label="Virar carteirinha" onKeyDown={(e) => { if (e.key === 'Enter') setVerso(!verso); }}>
        <div className={`flip-carta ${verso ? 'virada' : ''}`}>
          <div className="flip-face rounded-2xl p-5 shadow-[0_24px_60px_-24px_rgba(255,193,7,.6)]" style={{ background: fx.bg, color: fx.fg }}>
            <div className="flex items-center justify-between"><span className="flex items-center gap-2"><SadLogo size={26} dark={fx.fg === '#0A0A0A'} /><b className="text-[16px] font-extrabold">CLUBE DA SAD</b></span><span className="text-[10px] font-bold px-2 py-1 rounded-full uppercase" style={{ background: fx.fg, color: fx.fg === '#0A0A0A' ? '#FFC107' : '#0A0A0A' }}>{fx.nome}</span></div>
            <div className="flex items-center gap-3 mt-4"><span className="w-[72px] h-[90px] rounded-xl bg-black/10 grid place-items-center text-[24px] font-extrabold border border-current/20">{iniciais(s.nome)}</span><div className="flex-1 min-w-0"><b className="text-[18px] block leading-tight">{s.nome}</b><p className="text-[12px] opacity-80">@{s.user}</p><p className="text-[13px] tabnum mt-1">Nº 00012245 · {s.bairro}</p><p className="text-[13px]">Nível {nv + 1} · {NIVEIS[nv][0]} · {fmt(s.xp)} pts</p></div></div>
            <div className="flex items-center justify-between mt-3 text-[12px]"><span>Membro desde 2024 · válida até 20/11/2026</span><span className="flex gap-1">{s.selos.map((x) => <Icon key={x} name="Award" size={16} />)}</span></div>
          </div>
          <div className="flip-face flip-verso rounded-2xl p-5 bg-[#0E0E0E] border border-[#262626] text-[#F5F5F5] flex items-center gap-4">
            <span className="w-32 h-32 shrink-0"><QR /></span>
            <div className="text-[13px] space-y-1"><b className="text-[15px] block">Verifique a autenticidade</b><p className="text-[#A8A8A8]">Aponte a câmera pro código. Abre a página pública de verificação.</p><p className="text-[12px] text-[#FFC107]">conectaabc.app/v/00012245</p></div>
          </div>
        </div>
      </div>
      <p className="text-[12px] text-[#A8A8A8] text-center mt-2">Toque na carteirinha pra virar. A cor muda conforme seu nível.</p>
      <div className="grid grid-cols-2 gap-2 mt-4"><Btn tipo="sec" onClick={() => toast('Carteirinha compartilhada')}>Compartilhar</Btn><Btn onClick={() => go('cupons')}>Ver cupons</Btn></div>
      <div className="mt-5 divide-y divide-[#262626]">
        <Linha icon="CalendarCheck" titulo="Minha assinatura" dir={<Pill cor="ok">Ativa</Pill>} onClick={() => toast('Assinatura mensal ativa')} />
        <Linha icon="Award" titulo="Meu nível e metas" dir={<span className="text-[14px] text-[#FFC107] font-semibold">Nível {nv + 1}</span>} onClick={() => go('nivel')} />
        <Linha icon="TicketPercent" titulo="Cupons resgatados" dir={<span className="text-[14px] font-semibold tabnum">{s.cupons.length}</span>} onClick={() => go('cupons')} />
        <Linha icon="Receipt" titulo="Histórico de pagamentos" onClick={() => toast('Histórico de pagamentos')} />
      </div>
    </Pagina>
  );
}
function TelaAgenda({ s, up, go, presenca, toast }) {
  const [cat, setCat] = useState('Todos'); const [per, setPer] = useState('30 dias');
  const cats = ['Todos', ...Array.from(new Set(EVENTOS.map((e) => e.cat)))];
  const HOJE = 6; const lim = { Hoje: [6, 6], 'Fim de semana': [7, 8], '7 dias': [6, 13], '30 dias': [6, 36] }[per];
  const lista = EVENTOS.filter((e) => (cat === 'Todos' || e.cat === cat) && +e.dia >= lim[0] && +e.dia <= lim[1]);
  return (
    <Pagina titulo="Agenda do ABC" sub="Confirme presença, ative lembretes e ganhe pontos." icon="CalendarDays" go={go} larga acao={<Btn tipo="sec" onClick={() => toast('Sugestão de evento enviada para moderação')} className="h-9"><Icon name="Plus" size={16} /><span className="hidden sm:inline">Publicar evento</span></Btn>}>
      <div className="space-y-2"><Tabs opcoes={['Hoje', 'Fim de semana', '7 dias', '30 dias']} valor={per} set={setPer} /><Tabs opcoes={cats} valor={cat} set={setCat} /></div>
      {!lista.length && <Vazio icon="CalendarX" texto={`Nenhum evento ${per === 'Hoje' ? 'hoje' : 'nesse período'}. Veja o fim de semana.`} />}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">{lista.map((e) => { const vou = s.presencas.includes(e.id); const lem = s.lembretes.includes(e.id); return (
        <div key={e.id} className="border border-[#262626] rounded-xl overflow-hidden"><button onClick={() => go('evento-' + e.id)} className="block w-full text-left"><div className="relative"><Ph tone={e.tone} icon={e.icon} className="aspect-[16/9] w-full" size={48} /><span className="absolute top-2 left-2 bg-white text-black rounded-md px-2 py-0.5 text-center leading-none"><span className="block text-[9px] font-bold uppercase text-[#DC2626]">{e.mes}</span><span className="block text-[18px] font-extrabold tabnum">{e.dia}</span></span>{e.gratis && <span className="absolute top-2 right-2"><Pill cor="ok">Grátis</Pill></span>}</div>
          <div className="p-3"><p className="text-[12px] text-[#FFC107] font-semibold uppercase">{e.wd}, {e.hora}</p><p className="text-[15px] font-semibold leading-snug">{e.titulo}</p><p className="text-[12px] text-[#A8A8A8] mt-0.5">{e.local} · {e.bairro} · {fmt(e.vao + (vou ? 1 : 0))} vão</p></div></button>
          <div className="px-3 pb-3 flex gap-2"><Btn tipo={vou ? 'ok' : 'ouro'} onClick={() => presenca(e.id)} className="flex-1 h-8 text-[13px]"><Icon name={vou ? 'CircleCheck' : 'Star'} size={15} />{vou ? 'Eu vou' : 'Eu vou'}</Btn><Btn tipo="sec" onClick={() => { up((x) => ({ lembretes: lem ? x.lembretes.filter((y) => y !== e.id) : [...x.lembretes, e.id] })); toast(lem ? 'Lembrete removido' : 'Vamos te avisar 1 dia antes'); }} className="h-8 px-3" aria-label="Lembrete"><Icon name={lem ? 'BellRing' : 'Bell'} size={15} className={lem ? 'text-[#FFC107]' : ''} /></Btn></div></div>); })}</div>
    </Pagina>
  );
}
function TelaImoveis({ go, toast }) {
  const [f, setF] = useState('Todos'); const [tipo, setTipo] = useState('Todos'); const [qt, setQt] = useState('Qualquer'); const [ord, setOrd] = useState('Recentes');
  let lista = IMOVEIS.filter((i) => (f === 'Todos' || i.tipo === f) && (tipo === 'Todos' || i.cat === tipo) && (qt === 'Qualquer' || i.quartos >= +qt[0]));
  lista = [...lista].sort((a, b) => (ord === 'Menor preço' ? a.valor - b.valor : ord === 'Maior preço' ? b.valor - a.valor : 0));
  return (
    <Pagina titulo="Imóveis no ABC" sub="Anúncios grátis de moradores e imobiliárias." icon="Building2" go={go} larga acao={<Btn onClick={() => toast('Anunciar imóvel entra na próxima versão')} className="h-9"><Icon name="Plus" size={16} /><span className="hidden sm:inline">Anunciar</span></Btn>}>
      <div className="rounded-lg border border-[#F97316]/50 bg-[#1C0F05] px-3.5 py-2.5 flex gap-2.5 text-[13px] mb-3"><Icon name="ShieldAlert" size={18} className="text-[#F97316] shrink-0 mt-0.5" /><span><b>Nunca pague sinal antes de visitar o imóvel.</b> O Conecta ABC não intermedeia pagamentos.</span></div>
      <div className="space-y-2"><Tabs opcoes={['Todos', 'Aluguel', 'Venda']} valor={f} set={setF} /><Tabs opcoes={['Todos', 'Apartamento', 'Casa', 'Kitnet', 'Sala comercial']} valor={tipo} set={setTipo} /><div className="flex gap-2 flex-wrap"><Tabs opcoes={['Qualquer', '1+ quarto', '2+ quartos', '3+ quartos']} valor={qt} set={setQt} /></div><Tabs opcoes={['Recentes', 'Menor preço', 'Maior preço']} valor={ord} set={setOrd} /></div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-x-3 gap-y-5 mt-4">{lista.map((i) => (<button key={i.id} onClick={() => toast('Pedido de visita enviado ao anunciante')} className="text-left"><div className="relative"><Ph tone={i.tone} icon={i.icon} className="aspect-square rounded-lg w-full" size={44} /><span className="absolute top-2 left-2"><Pill cor={i.tipo === 'Venda' ? 'info' : 'ouro'}>{i.tipo}</Pill></span></div><p className="text-[16px] font-bold mt-2 tabnum">{i.preco}</p><p className="text-[14px]">{i.titulo}</p><p className="text-[12px] text-[#A8A8A8] tabnum">{i.area} · {i.quartos ? i.quartos + ' qto · ' : ''}{i.banheiros} banh · {i.vagas}</p><p className="text-[12px] text-[#A8A8A8]">{i.bairro}{i.cond ? ' · cond. ' + i.cond : ''}</p></button>))}</div>
      {!lista.length && <Vazio icon="Building2" texto="Nenhum imóvel com esses filtros." />}
    </Pagina>
  );
}
function TelaAchados({ s, up, go, toast }) {
  const [f, setF] = useState('Todos'); const [cat, setCat] = useState('Todas');
  const ativos = ACHADOS.filter((o) => !o.resolvido && !s.resolvidos.includes(o.id) && (f === 'Todos' || (f === 'Achei' ? o.tipo === 'Achado' : o.tipo === 'Perdido')) && (cat === 'Todas' || o.cat === cat));
  const felizes = ACHADOS.filter((o) => o.resolvido || s.resolvidos.includes(o.id));
  return (
    <Pagina titulo="Achados e perdidos" sub="Perdeu ou achou algo pela cidade? Avise aqui." icon="KeyRound" go={go} acao={<Btn onClick={() => toast('Publicar "Perdi/Achei" entra na próxima versão')} className="h-9"><Icon name="Plus" size={16} /><span className="hidden sm:inline">Anunciar</span></Btn>}>
      <div className="space-y-2"><Tabs opcoes={['Todos', 'Perdi', 'Achei']} valor={f} set={setF} /><Tabs opcoes={['Todas', ...ACHADOS_CATS]} valor={cat} set={setCat} /></div>
      <div className="mt-2 divide-y divide-[#262626]">{ativos.map((o) => (<div key={o.id} className="flex items-center gap-3 py-3"><Ph tone={o.tone} icon={o.icon} className="w-14 h-14 rounded-lg shrink-0" size={22} /><div className="flex-1 min-w-0"><div className="flex gap-1.5"><Pill cor={o.tipo === 'Achado' ? 'ok' : 'bad'}>{o.tipo === 'Achado' ? 'Achei' : 'Perdi'}</Pill><Pill>{o.cat}</Pill></div><p className="text-[14px] font-semibold mt-1">{o.titulo}</p><p className="text-[12px] text-[#A8A8A8]">{o.local} · {o.bairro} · {o.quando}</p></div>
        <div className="flex flex-col gap-1.5"><Btn tipo="sec" onClick={() => toast(o.tipo === 'Achado' ? 'Mensagem enviada a quem achou' : 'O dono foi avisado')} className="h-8 px-3 text-[13px]">{o.tipo === 'Achado' ? 'É meu' : 'Achei'}</Btn><button onClick={() => { up((x) => ({ resolvidos: [...x.resolvidos, o.id] })); toast('Marcado como resolvido 🎉'); }} className="text-[11px] text-[#A8A8A8] underline">Resolvido</button></div></div>))}</div>
      {!ativos.length && <Vazio icon="Search" texto="Nada nesse filtro." />}
      <b className="block text-[16px] mt-6 mb-2 flex items-center gap-1.5">🎉 Finais felizes</b>
      <div className="divide-y divide-[#262626]">{felizes.map((o) => (<div key={o.id} className="flex items-center gap-3 py-2.5"><span className="w-10 h-10 rounded-full bg-[#16A34A]/20 text-[#22C55E] grid place-items-center"><Icon name="CircleCheck" size={20} /></span><span className="flex-1 min-w-0"><b className="text-[14px] block truncate">{o.titulo}</b><span className="text-[12px] text-[#A8A8A8]">Voltou pro dono · {o.bairro}</span></span></div>))}</div>
    </Pagina>
  );
}
function TelaIndica(ctx) {
  const { s, up, go, toast, pontuar } = ctx;
  const [aba, setAba] = useState('Pedidos'); const [novo, setNovo] = useState(''); const [cat, setCat] = useState('Serviços gerais'); const [abrir, setAbrir] = useState(null);
  const pedidos = [...s.pedidosIndica, ...INDICA];
  const indicar = (pid, emp) => { up((x) => ({ indicados: { ...x.indicados, [pid]: emp } })); pontuar('indicacao', 'Você indicou ' + PARCEIROS.find((p) => p.id === emp).nome); setAbrir(null); };
  const resolveu = (pid) => { up((x) => ({ resolvidos: [...x.resolvidos, pid] })); pontuar('resolveu', 'Indicação resolveu'); };
  const pedir = (e) => { e.preventDefault(); if (novo.trim().length < 8) return; up((x) => ({ pedidosIndica: [{ id: 'pi' + Date.now(), pergunta: novo.trim(), autor: x.nome.split(' ')[0] + ' (você)', meu: true, respostas: 0, top: 'Aguardando indicações', cat }, ...x.pedidosIndica] })); setNovo(''); toast('Pedido publicado. Os vizinhos vão indicar.'); };
  const RANK = [['p5', 23], ['p1', 19], ['p3', 14], ['p6', 9], ['p4', 6]];
  return (
    <Pagina titulo="SAD Indica" sub="Peça uma indicação. Os vizinhos indicam empresas da rede." icon="Sparkles" go={go}>
      <Tabs opcoes={['Pedidos', 'Ranking']} valor={aba} set={setAba} />
      {aba === 'Pedidos' && <>
        <form onSubmit={pedir} className="mt-3 border border-[#262626] rounded-xl p-3 space-y-2"><input id="indica-novo" className={inputCls} value={novo} onChange={(e) => setNovo(e.target.value)} placeholder="Ex: alguém conhece um eletricista no Jardim?" /><div className="flex gap-2"><select id="indica-cat" className={inputCls + ' flex-1'} value={cat} onChange={(e) => setCat(e.target.value)}>{EMP_CATS.map(([c]) => <option key={c}>{c}</option>)}</select><Btn type="submit" disabled={novo.trim().length < 8} className="h-11">Pedir</Btn></div></form>
        <div className="mt-2 divide-y divide-[#262626]">{pedidos.map((k) => { const ind = s.indicados[k.id]; const res = s.resolvidos.includes(k.id); return (
          <div key={k.id} className="py-3.5"><div className="flex items-start gap-2"><p className="flex-1 text-[15px] font-semibold">{k.pergunta}</p>{res && <Pill cor="ok">Resolvido</Pill>}</div><p className="text-[12px] text-[#A8A8A8]">por {k.autor} · {k.respostas + (ind ? 1 : 0)} indicações</p><p className="text-[13px] text-[#FFC107] mt-1.5 flex items-center gap-1"><Icon name="Crown" size={14} />{k.top}</p>
            <div className="flex gap-2 mt-2.5">{k.meu ? (!res && <Btn onClick={() => resolveu(k.id)} className="h-8 px-3 text-[13px]"><Icon name="CircleCheck" size={15} />Essa resolveu</Btn>) : ind ? <span className="text-[13px] text-[#22C55E] flex items-center gap-1"><Icon name="Check" size={15} />Você indicou {PARCEIROS.find((p) => p.id === ind).nome}</span> : <Btn tipo="sec" onClick={() => setAbrir(abrir === k.id ? null : k.id)} className="h-8 px-3 text-[13px]"><Icon name="ThumbsUp" size={15} />Indicar empresa</Btn>}</div>
            {abrir === k.id && <div className="fade mt-2 grid grid-cols-2 gap-2">{PARCEIROS.map((p) => <button key={p.id} onClick={() => indicar(k.id, p.id)} className="h-10 rounded-lg bg-[#121212] border border-[#262626] text-[13px] px-2 flex items-center gap-2 text-left"><Icon name={p.icon} size={16} className="text-[#FFC107]" /><span className="truncate">{p.nome}</span></button>)}<p className="col-span-2 text-[11px] text-[#A8A8A8]">Dono de empresa não pode indicar a própria empresa. Indicar vale +5; se resolver, +15.</p></div>}
          </div>); })}</div>
      </>}
      {aba === 'Ranking' && <div className="mt-3 divide-y divide-[#262626]">{RANK.map(([id, n], i) => { const p = PARCEIROS.find((x) => x.id === id); return (<button key={id} onClick={() => go('parceiro-' + id)} className="w-full flex items-center gap-3 py-3 text-left"><span className="w-6 text-center font-extrabold text-[#FFC107] tabnum">{i + 1}</span><Ph tone={p.tone} icon={p.icon} className="w-11 h-11 rounded-full" size={18} /><span className="flex-1"><b className="text-[14px] block">{p.nome}</b><span className="text-[12px] text-[#A8A8A8]">{p.cat} · {p.bairro}</span></span><span className="text-[13px] tabnum">{n} resolveram</span></button>); })}</div>}
    </Pagina>
  );
}
function TelaUtilidades({ s, go, toast }) {
  const copiar = (n) => { try { navigator.clipboard.writeText(n).then(() => toast('Número copiado: ' + n), () => toast('Ligue para ' + n)); } catch (e) { toast('Ligue para ' + n); } };
  return (
    <Pagina titulo="Utilidades" sub="Telefones, farmácias de plantão e coleta de lixo." voltar="mais" go={go}>
      <b className="block text-[15px] mb-1">Telefones úteis</b>
      <div className="divide-y divide-[#262626]">{UTILIDADES.map(([n, t]) => (<div key={n} className="flex items-center justify-between py-3"><span className="text-[15px]">{n}</span><span className="flex items-center gap-2"><a href={'tel:' + t} className="text-[22px] font-bold text-[#FFC107] tabnum select-all">{t}</a><button onClick={() => copiar(t)} aria-label={'Copiar ' + t} className="p-1.5 text-[#A8A8A8]"><Icon name="Copy" size={16} /></button></span></div>))}</div>
      <b className="block text-[15px] mt-6 mb-1">Farmácias de plantão hoje</b>
      <div className="divide-y divide-[#262626]">{FARMACIAS.map(([n, e, h]) => (<div key={n} className="flex items-center gap-3 py-3"><span className="w-10 h-10 rounded-full bg-[#16A34A]/20 text-[#22C55E] grid place-items-center"><Icon name="Pill" size={19} /></span><span className="flex-1"><b className="text-[14px] block">{n}</b><span className="text-[12px] text-[#A8A8A8]">{e}</span></span><Pill cor="ok">{h}</Pill></div>))}</div>
      <b className="block text-[15px] mt-6 mb-1">Coleta de lixo por bairro</b>
      <div className="divide-y divide-[#262626]">{Object.entries(COLETA).map(([b, d]) => (<div key={b} className={`flex items-center justify-between py-2.5 text-[14px] ${b === s.bairro ? 'text-[#FFC107] font-semibold' : ''}`}><span>{b}{b === s.bairro && ' · seu bairro'}</span><span className={b === s.bairro ? '' : 'text-[#A8A8A8]'}>{d}</span></div>))}</div>
    </Pagina>
  );
}
function TelaMais({ go, s, up, toast }) {
  const mods = [
    ['amigos', 'Amigos', 'Pedidos, sugestões e seus amigos', 'Users'], ['cupons', 'Cupons', 'Descontos que liberam por nível', 'TicketPercent'], ['nivel', 'Meu nível', 'Metas, pontos de hoje e histórico', 'Trophy'],
    ['carteirinha', 'Carteirinha', 'Seu cartão de morador com QR', 'IdCard'], ['convidar', 'Convidar amigos', 'Link, WhatsApp e selo Embaixador', 'Send'], ['empresas', 'Guia de empresas', 'Comércio e serviços por categoria', 'Store'],
    ['voz', 'Voz do Bairro', 'Histórias, elogios e reclamações', 'Megaphone'], ['top', 'Top da semana', 'Os 5 posts mais engajados', 'Flame'], ['sorteios', 'Sorteios', 'Prêmios dos parceiros, grátis', 'Gift'],
    ['premio', 'Melhores do ABC', 'Vote nos melhores da cidade', 'Trophy'], ['placar', 'Placar dos bairros', 'Qual bairro participa mais', 'Flag'], ['pontua', 'Ranking', 'Membros mais ativos da temporada', 'Medal'],
    ['agenda', 'Agenda', 'Eventos com "Eu vou" e lembrete', 'CalendarDays'], ['noticias', 'Notícias', 'O que acontece na cidade', 'Newspaper'], ['mapa', 'Explorar', 'Mapa, check-in e avaliações', 'MapPin'],
    ['mercadao', 'Mercadão', 'Venda, troca e doação', 'ShoppingBag'], ['imoveis', 'Imóveis', 'Aluguel e venda, de graça', 'Building2'], ['vagas', 'Vagas', 'Empregos perto de casa', 'Briefcase'],
    ['achados', 'Achados e perdidos', 'Perdi, achei e finais felizes', 'KeyRound'], ['animais', 'Animais perdidos', 'Ajude pets a voltar pra casa', 'PawPrint'], ['indica', 'SAD Indica', 'Peça e dê indicações', 'Sparkles'],
    ['enquetes', 'Enquetes', 'Opine sobre a cidade', 'Vote'], ['comunidades', 'Comunidades', 'Grupos por interesse', 'Users'], ['problemas', 'Problemas da cidade', 'Buraco, poste, lixo', 'Construction'],
    ['utilidades', 'Utilidades', 'Telefones, plantão e coleta', 'Phone'], ['servicos', 'Serviços', 'Jurídico, veterinário e prefeitura', 'HandHelping'], ['institucional', 'Sobre e regras', 'Termos, privacidade e anuncie', 'Info'],
  ];
  if (s.admin) mods.unshift(['moderacao', 'Moderação', 'Fila de denúncias', 'ShieldCheck']);
  return (
    <Pagina titulo="Mais" go={go}>
      <button onClick={() => go('perfil')} className="w-full flex items-center gap-3 p-3 rounded-xl border border-[#262626] text-left"><Avatar nome={s.nome} size={44} ouro /><span className="flex-1"><b className="text-[15px] block">{s.nome}</b><span className="text-[13px] text-[#A8A8A8]">Ver seu perfil</span></span><Icon name="ChevronRight" size={18} className="text-[#737373]" /></button>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-4">{mods.map(([r, l, d, ic]) => (<button key={r} onClick={() => go(r)} className="flex flex-col items-start gap-1.5 p-3 rounded-xl bg-[#121212] border border-[#262626] hover:bg-[#1A1A1A] text-left"><Icon name={ic} size={22} className="text-[#FFC107]" /><span className="text-[14px] font-semibold leading-tight">{l}</span><span className="text-[12px] text-[#A8A8A8] leading-snug">{d}</span></button>))}</div>
      <div className="mt-5 divide-y divide-[#262626]">
        <Linha icon="ShieldCheck" titulo="Modo administrador" sub={s.admin ? 'Ativo: vídeos no Em alta e moderação liberados' : 'Demonstração: libera vídeos e moderação'} dir={<span className={`w-11 h-6 rounded-full p-0.5 transition-colors ${s.admin ? 'bg-[#FFC107]' : 'bg-[#363636]'}`}><span className={`block w-5 h-5 rounded-full bg-white transition-transform ${s.admin ? 'translate-x-5' : ''}`} /></span>} onClick={() => { up({ admin: !s.admin }); toast(s.admin ? 'Modo administrador desligado' : 'Modo administrador ligado'); }} />
        <Linha icon="RotateCcw" titulo="Reiniciar demonstração" sub="Apaga pontos, posts e salvos desta demonstração" onClick={() => { try { localStorage.removeItem(KEY); } catch (e) {} up(INICIAL); toast('Demonstração reiniciada'); go('inicio'); }} />
        <Linha icon="LogOut" titulo="Sair" perigo onClick={() => { up({ logado: false }); go('entrar'); }} />
      </div>
    </Pagina>
  );
}

/* ====== COLUNA DIREITA (computador) ====== */
function Lateral({ ctx }) {
  const { s, go, checkin, nv, pct, prox, toggleComunidade } = ctx; const fez = s.ultimoCheckin === hoje();
  return (
    <aside className="hidden xl:block w-[320px] shrink-0 pt-8 pl-8 pr-4">
      <div className="sticky top-8 space-y-6">
        <div className="flex items-center gap-3"><Avatar nome={s.nome} size={44} ouro /><button onClick={() => go('perfil')} className="flex-1 text-left min-w-0"><b className="text-[14px] block truncate">{s.user}</b><span className="text-[14px] text-[#A8A8A8]">{s.nome}</span></button><button onClick={() => go('carteirinha')} className="text-[12px] font-semibold text-[#FFC107]">Carteirinha</button></div>
        <div className="rounded-xl border border-[#262626] p-4">
          <div className="flex items-center gap-3"><Medalha size={48} /><div className="flex-1"><b className="text-[14px] block">SAD Pontua · Nível {nv + 1}</b><span className="text-[12px] text-[#A8A8A8] tabnum">{s.xp} / {prox ? prox[1] : s.xp} XP · {s.streak} dias 🔥</span></div></div>
          <div className="h-1.5 rounded-full bg-[#262626] overflow-hidden mt-3"><div className="h-full bg-[#FFC107]" style={{ width: pct + '%' }} /></div>
          <Btn tipo={fez ? 'sec' : 'ouro'} onClick={checkin} className="w-full h-8 mt-3 text-[13px]"><Icon name={fez ? 'CircleCheck' : 'CalendarCheck'} size={15} />{fez ? 'Check-in feito hoje' : 'Check-in diário (+3 XP)'}</Btn>
        </div>
        <div><div className="flex justify-between mb-2"><b className="text-[14px] text-[#A8A8A8]">Próximos eventos</b><button onClick={() => go('agenda')} className="text-[12px] font-semibold">Ver tudo</button></div>
          {EVENTOS.slice(0, 3).map((e) => (<button key={e.id} onClick={() => go('evento-' + e.id)} className="w-full flex items-center gap-3 py-1.5 text-left"><span className="w-10 h-10 rounded-lg bg-[#1A1A1A] text-center leading-none pt-1 shrink-0"><span className="block text-[9px] font-bold uppercase text-[#FFC107]">{e.mes}</span><span className="block text-[16px] font-bold tabnum">{e.dia}</span></span><span className="min-w-0"><b className="text-[13px] block truncate">{e.titulo}</b><span className="text-[12px] text-[#A8A8A8]">{e.hora} · {e.local}</span></span></button>))}</div>
        <div><div className="flex justify-between mb-2"><b className="text-[14px] text-[#A8A8A8]">Comunidades sugeridas</b><button onClick={() => go('comunidades')} className="text-[12px] font-semibold">Ver tudo</button></div>
          {COMUNIDADES.slice(0, 4).map((c) => { const m = s.comunidades.includes(c.id); return (<div key={c.id} className="flex items-center gap-3 py-1.5"><Ph tone={c.tone} icon={c.icon} className="w-10 h-10 rounded-full shrink-0" size={16} /><button onClick={() => go('comunidade-' + c.id)} className="flex-1 min-w-0 text-left"><b className="text-[13px] block truncate">{c.nome}</b><span className="text-[12px] text-[#A8A8A8] tabnum">{fmt(c.membros)} membros</span></button><button onClick={() => toggleComunidade(c.id)} className={`text-[12px] font-semibold ${m ? 'text-[#A8A8A8]' : 'text-[#FFC107]'}`}>{m ? 'Participando' : 'Participar'}</button></div>); })}</div>
        <div><b className="text-[14px] text-[#A8A8A8]">Disputa dos bairros</b><div className="mt-2 space-y-2">{PLACAR.slice(0, 3).map(([b, pts], i) => (<div key={b}><div className="flex justify-between text-[12px]"><span>{i + 1}. {b}</span><span className="tabnum text-[#A8A8A8]">{fmt(pts)}</span></div><div className="h-1 rounded-full bg-[#262626] mt-1 overflow-hidden"><div className={`h-full ${i === 0 ? 'bg-[#FFC107]' : 'bg-white/30'}`} style={{ width: (pts / PLACAR[0][1]) * 100 + '%' }} /></div></div>))}</div></div>
        <p className="text-[11px] text-[#737373] leading-relaxed">Sobre · Ajuda · Termos · Privacidade · Anuncie<br />© 2026 Conecta ABC · Santo André e ABC</p>
      </div>
    </aside>
  );
}

/* ====== ROTAS E SHELL ====== */
const PAI = { evento: 'agenda', produto: 'mercadao', parceiro: 'parceiros', animal: 'animais', noticia: 'noticias', comunidade: 'comunidades' };
const TELAS = { inicio: TelaFeed, explorar: TelaExplorar, busca: TelaBusca, notificacoes: TelaNotificacoes, perfil: TelaPerfil, entrar: TelaEntrar, carteirinha: TelaCarteirinha, pontua: TelaPontua, parceiros: TelaParceiros, parceiro: TelaParceiro, mercadao: TelaMercadao, produto: TelaProduto, animais: TelaAnimais, animal: TelaAnimal, 'cadastrar-animal': TelaCadastrarAnimal, problemas: TelaProblemas, servicos: TelaServicos, agenda: TelaAgenda, evento: TelaEvento, noticias: TelaNoticias, noticia: TelaNoticia, comunidades: TelaComunidades, comunidade: TelaComunidade, vagas: TelaVagas, imoveis: TelaImoveis, mapa: TelaMapa, achados: TelaAchados, enquetes: TelaEnquetes, indica: TelaIndica, utilidades: TelaUtilidades, salvos: TelaSalvos, mais: TelaMais, mural: TelaFeed, agora: TelaEmAlta, 'meu-bairro': TelaFeed, amigos: TelaAmigos, cupons: TelaCupons, voz: TelaVoz, top: TelaTop, sorteios: TelaSorteios, premio: TelaPremio, convidar: TelaConvidar, nivel: TelaNivel, empresas: TelaEmpresas, moderacao: TelaModeracao, institucional: TelaInstitucional, placar: TelaPlacar };
const parse = (r) => { const pre = r.split('-')[0]; return PAI[pre] ? [pre, r.slice(pre.length + 1)] : [TELAS[r] ? r : 'inicio', null]; };
const SIDE = [['inicio', 'Página inicial', 'House'], ['busca', 'Pesquisa', 'Search'], ['explorar', 'Explorar', 'Compass'], ['agora', 'Em alta', 'Clapperboard'], ['amigos', 'Amigos', 'Users'], ['cupons', 'Cupons', 'TicketPercent'], ['parceiros', 'Parceiros', 'Store'], ['mercadao', 'Mercadão', 'ShoppingBag'], ['agenda', 'Agenda', 'CalendarDays'], ['animais', 'Animais', 'PawPrint'], ['notificacoes', 'Notificações', 'Heart'], ['criar', 'Criar', 'SquarePlus'], ['perfil', 'Perfil', null]];
const ativoDe = (base) => ({ parceiro: 'parceiros', produto: 'mercadao', animal: 'animais', 'cadastrar-animal': 'animais', evento: 'agenda', mural: 'inicio', 'meu-bairro': 'inicio', carteirinha: 'perfil', salvos: 'perfil', nivel: 'perfil' }[base] || base);

function App() {
  const [s, setS] = useState(load);
  const [rota, setRota] = useState(() => (location.hash || '#inicio').slice(1) || 'inicio');
  const [toastMsg, setToastMsg] = useState(null); const [story, setStory] = useState(null); const [coment, setComent] = useState(null); const [criar, setCriar] = useState(false); const [q, setQ] = useState(''); const [clipInicial, setClipInicial] = useState(0);
  const timer = useRef(null);
  useEffect(() => save(s), [s]);
  useEffect(() => { const on = () => { setRota((location.hash || '#inicio').slice(1) || 'inicio'); window.scrollTo({ top: 0 }); }; window.addEventListener('hashchange', on); return () => window.removeEventListener('hashchange', on); }, []);
  const go = (r) => { if (r === 'criar') { setCriar(true); return; } if (location.hash !== '#' + r) location.hash = r; else window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const toast = (m) => { setToastMsg(m); clearTimeout(timer.current); timer.current = setTimeout(() => setToastMsg(null), 2400); };
  const up = (patch) => setS((p) => ({ ...p, ...(typeof patch === 'function' ? patch(p) : patch) }));
  const ganharXP = (n, missao, msg, cat) => up((p) => {
    if (missao && p.missoes.includes(missao + ':' + hoje())) { setTimeout(() => toast(msg || 'Feito'), 0); return {}; }
    const antes = nivelDe(p.xp); const xp = p.xp + n; const depois = nivelDe(xp);
    setTimeout(() => toast(depois > antes ? `🎉 Subiu pro nível ${depois + 1}: ${NIVEIS[depois][0]}! +${n} pontos` : `${msg || 'Feito'} · +${n} pontos`), 0);
    return { xp, missoes: missao ? [...p.missoes, missao + ':' + hoje()] : p.missoes, historico: [{ t: Date.now(), n, msg: msg || 'Pontos', cat: cat || missao || 'outro' }, ...p.historico].slice(0, 200) };
  });
  const pontuar = (cat, msg) => { const L = LIMITES[cat]; const feitos = s.historico.filter((h) => h.cat === cat && new Date(h.t).toISOString().slice(0, 10) === hoje()).length; if (feitos >= L.max) { toast(`${msg}. Limite diário de ${L.label.toLowerCase()} atingido: volta a pontuar amanhã`); return; } ganharXP(L.n, null, msg, cat); };
  const nv = nivelDe(s.xp); const prox = NIVEIS[nv + 1];
  const ctx = {
    s, up, go, toast, ganharXP, nv, prox, pct: prox ? Math.round(((s.xp - NIVEIS[nv][1]) / (prox[1] - NIVEIS[nv][1])) * 100) : 100, q, setQ,
    toggleSalvo: (id) => { const tem = s.salvos.includes(id); up((p) => ({ salvos: tem ? p.salvos.filter((x) => x !== id) : [...p.salvos, id] })); toast(tem ? 'Removido dos salvos' : 'Salvo no seu perfil'); },
    toggleComunidade: (id) => { const tem = s.comunidades.includes(id); up((p) => ({ comunidades: tem ? p.comunidades.filter((x) => x !== id) : [...p.comunidades, id] })); toast(tem ? 'Você saiu da comunidade' : 'Bem-vindo à comunidade!'); },
    checkin: () => { if (s.ultimoCheckin === hoje()) { toast('Check-in de hoje já feito. Volte amanhã!'); return; } up((p) => ({ ultimoCheckin: hoje(), streak: p.streak + 1 })); ganharXP(3, 'm-checkin', 'Check-in feito'); },
    votar: (qid, op) => { const ant = s.votos[qid]; if (ant === op) return; up((p) => { const ex = { ...(p.extraVotos[qid] || {}) }; if (ant) ex[ant] = (ex[ant] || 1) - 1; ex[op] = (ex[op] || 0) + 1; return { votos: { ...p.votos, [qid]: op }, extraVotos: { ...p.extraVotos, [qid]: ex } }; }); if (!ant) ganharXP(5, 'm-voto', 'Voto registrado'); },
    curtir: (id) => up((p) => ({ curtidas: p.curtidas.includes(id) ? p.curtidas.filter((x) => x !== id) : [...p.curtidas, id] })),
    apoiar: (id) => up((p) => ({ apoios: p.apoios.includes(id) ? p.apoios.filter((x) => x !== id) : [...p.apoios, id] })),
    presenca: (id) => { const vai = s.presencas.includes(id); up((p) => ({ presencas: vai ? p.presencas.filter((x) => x !== id) : [...p.presencas, id] })); if (!vai) ganharXP(5, 'm-evento', 'Presença confirmada'); else toast('Presença cancelada'); },
    abrirStory: (i) => setStory(i), pontuar, rotaBase: parse(rota)[0],
    resgatarMeta: (m) => { if (s.metas.includes(m.id) || !m.ok(s)) return; up((x) => { const metas = [...x.metas, m.id]; const fund = FUNDADOR.every(([id]) => METAS_UNICAS.find((y) => y.id === id).ok(x)) && !x.selos.includes('Fundador'); if (fund) setTimeout(() => toast('🏅 Você ganhou o selo Fundador!'), 2600); return { metas, selos: fund ? [...x.selos, 'Fundador'] : x.selos }; }); ganharXP(m.n, null, 'Meta: ' + m.titulo, 'meta'); },
    denunciar: (id) => { if (s.denuncias.includes(id)) { toast('Você já denunciou isso'); return; } const total = (BASE_DEN[id] || 0) + 1; up((x) => ({ denuncias: [...x.denuncias, id], ocultos: total >= 3 ? [...x.ocultos, id] : x.ocultos })); toast(total >= 3 ? 'Denúncia enviada. O conteúdo foi ocultado até a moderação decidir' : 'Denúncia enviada pra moderação'); },
    pedirAmizade: (u) => { if (s.enviados.includes(u)) return; up((x) => ({ enviados: [...x.enviados, u] })); toast('Pedido de amizade enviado'); },
    participar: (id) => { up((x) => ({ sorteios: [...x.sorteios, id] })); toast('Inscrição feita. Boa sorte!'); },
    fazerCheckin: (id) => { if (s.checkins.includes(id)) { toast('Você já fez check-in aqui'); return; } up((x) => ({ checkins: [...x.checkins, id] })); pontuar('checkin', 'Check-in em ' + LUGARES.find((l) => l.id === id).nome); },
    avaliar: (id, n) => { const ja = s.avaliacoes[id]; up((x) => ({ avaliacoes: { ...x.avaliacoes, [id]: n } })); if (!ja) pontuar('avaliacao', 'Avaliação enviada'); else toast('Nota atualizada'); },
    seguirEmpresa: (id) => { const seg = s.seguindo.includes(id); up((x) => ({ seguindo: seg ? x.seguindo.filter((y) => y !== id) : [...x.seguindo, id] })); toast(seg ? 'Deixou de seguir' : 'Seguindo ' + PARCEIROS.find((p) => p.id === id).nome); }, abrirCriar: (t) => setCriar(t), clips: [...s.clips, ...CLIPS], clipInicial, abrirClip: (i) => { setClipInicial(i); go('agora'); }, marcarVisto: (id) => up((p) => (p.vistos.includes(id) ? {} : { vistos: [...p.vistos, id] })), abrirComentarios: (p) => setComent(p),
    pets: [...s.pets, ...PETS0], posts: [...POSTS0], produtos: [...s.produtos, ...PRODUTOS0], enquetes: [...s.enquetes, ...ENQUETES0], problemas: [...s.problemas, ...PROBLEMAS0],
  };
  const [base, id] = parse(rota); const Comp = TELAS[base] || TelaFeed; const ativo = ativoDe(base); const mostraLateral = base === 'inicio' || base === 'mural' || base === 'meu-bairro'; const telaCheia = base === 'agora';
  const naoLidas = 3;

  return (
    <div className="min-h-screen bg-black text-[#F5F5F5]">
      {/* Barra lateral (computador/tablet) */}
      <nav className="hidden md:flex fixed inset-y-0 left-0 z-40 w-[72px] xl:w-[244px] flex-col border-r border-[#262626] bg-black px-3 pt-6 pb-5" aria-label="Navegação">
        <button onClick={() => go('inicio')} className="h-14 px-3 mb-4 flex items-center"><ConectaMarca size={30} /><span className="hidden xl:inline ml-3 text-[13px] font-semibold text-[#A8A8A8]">Santo André e ABC</span></button>
        <div className="flex-1 space-y-1">
          {SIDE.map(([r, l, ic]) => { const on = ativo === r; return (
            <button key={r} onClick={() => go(r)} className={`w-full h-12 px-3 rounded-lg flex items-center gap-4 hover:bg-[#1A1A1A] transition-colors ${on ? 'font-bold' : ''}`} title={l}>
              {ic ? <span className="relative"><Icon name={ic} size={26} strokeWidth={on ? 2.8 : 2} fill={on && ['House', 'Heart'].includes(ic) ? '#F5F5F5' : 'none'} />{r === 'notificacoes' && <span className="absolute -top-1 -right-1 w-[18px] h-[18px] rounded-full bg-[#ED4956] text-white text-[10px] font-bold grid place-items-center">{naoLidas}</span>}</span> : <span className={`rounded-full ${on ? 'ring-2 ring-white' : ''}`}><Avatar nome={s.nome} size={26} ouro /></span>}
              <span className="hidden xl:inline text-[15px]">{l}</span>
            </button>); })}
        </div>
        <button onClick={() => go('mais')} className={`w-full h-12 px-3 rounded-lg flex items-center gap-4 hover:bg-[#1A1A1A] ${ativo === 'mais' ? 'font-bold' : ''}`} title="Mais"><Icon name="Menu" size={26} /><span className="hidden xl:inline text-[15px]">Mais</span></button>
      </nav>

      {/* Topo (celular) */}
      <header className={`${telaCheia ? 'hidden' : 'md:hidden'} sticky z-40 bg-black border-b border-[#262626]`} style={{ top: 0, paddingTop: 'env(safe-area-inset-top,0px)' }}>
        <div className="h-[52px] px-3 grid grid-cols-[1fr_auto_1fr] items-center">
          <div className="flex items-center"><button onClick={() => go('criar')} aria-label="Criar"><Icon name="SquarePlus" size={25} /></button></div>
          <button onClick={() => go('inicio')} aria-label="Conecta ABC, início"><Wordmark marca={false} /></button>
          <div className="flex items-center justify-end gap-4">
            <button onClick={() => go('notificacoes')} aria-label="Notificações" className="relative"><Icon name="Heart" size={25} /><span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-[#ED4956]" /></button>
            <button onClick={() => go('mais')} aria-label="Menu"><Icon name="Menu" size={25} /></button>
          </div>
        </div>
      </header>

      <div className="md:pl-[72px] xl:pl-[244px] flex justify-center">
        <main className={`flex-1 min-w-0 ${telaCheia ? '' : 'max-w-[935px]'}`}>{!telaCheia && <div className="hidden md:flex sticky top-0 z-30 h-14 items-center justify-center bg-black/90 backdrop-blur border-b border-[#262626]"><button onClick={() => go('inicio')} aria-label="Conecta ABC, início"><Wordmark /></button></div>}<Comp {...ctx} id={id} /></main>
        {mostraLateral && <Lateral ctx={ctx} />}
      </div>

      {/* Abas (celular) */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-black border-t border-[#262626] flex justify-around" style={{ paddingBottom: 'env(safe-area-inset-bottom,0px)' }} aria-label="Navegação principal">
        {[['inicio', 'House'], ['explorar', 'Search'], ['criar', 'SquarePlus'], ['agora', 'Clapperboard'], ['perfil', null]].map(([r, ic]) => { const on = ativo === r || (r === 'explorar' && ['busca', 'mapa'].includes(base)); return (
          <button key={r} onClick={() => go(r)} className="h-[50px] w-16 grid place-items-center" aria-label={r}>
            {ic ? <Icon name={ic} size={26} strokeWidth={on ? 2.8 : 2} fill={on && ic === 'House' ? '#F5F5F5' : 'none'} /> : <span className={`rounded-full p-[1.5px] ${on ? 'ring-2 ring-white' : ''}`}><Avatar nome={s.nome} size={26} ouro /></span>}
          </button>); })}
      </nav>

      {toastMsg && <div role="status" className="fade fixed left-1/2 -translate-x-1/2 bottom-[76px] md:bottom-8 z-[120] bg-[#F5F5F5] text-black text-[14px] font-semibold px-4 py-2.5 rounded-lg shadow-2xl max-w-[92vw] text-center">{toastMsg}</div>}
      {story !== null && <StoryViewer idx={story} setIdx={setStory} ctx={ctx} />}
      {coment && <Comentarios post={coment} fechar={() => setComent(null)} ctx={ctx} />}
      {criar && <Criar fechar={() => setCriar(false)} ctx={ctx} inicial={criar} />}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
