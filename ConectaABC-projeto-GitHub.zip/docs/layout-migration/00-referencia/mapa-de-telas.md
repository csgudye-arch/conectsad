# Mapa de telas: Conecta ABC

Rotas do protótipo (no protótipo são `#nome`; no seu app use as rotas que fizerem sentido, por exemplo `/agenda`). A coluna **Componente** é o nome da função em `prototipo-codigo-fonte.jsx`, para a IA achar o código de referência.

## Navegação

| Onde | Itens |
|---|---|
| Barra inferior (celular) | Início · Explorar · Criar (+) · Em alta · Perfil |
| Topo (celular) | Criar à esquerda · **CONECTA ABC** no centro · Notificações e Menu à direita |
| Barra lateral (computador) | Página inicial, Pesquisa, Explorar, Em alta, Amigos, Cupons, Parceiros, Mercadão, Agenda, Animais, Notificações, Criar, Perfil, Mais |
| Tela "Mais" | Grade com todos os módulos (título + descrição curta) |

## Telas

| Rota | Tela | Componente | O que tem |
|---|---|---|---|
| `inicio` | Início (feed) | `TelaFeed` | Stories com bolinha de online, painel do dia (saudação, data, clima, Postar algo, Meu bairro), campanha Fundador, destaques que deslizam, caixa de post, abas Cidade/Amigos/Meu bairro, feed misto e blocos no meio da rolagem |
| `meu-bairro` | Início na aba Meu bairro | `TelaFeed` | Mesmo feed filtrado pelo bairro |
| `agora` | Em alta (vídeos) | `TelaEmAlta`, `Clip` | Vídeos verticais com rolagem que encaixa, ações laterais, legenda, botão de destino; só admin publica |
| `explorar` | Explorar | `TelaExplorar` | Grade de fotos de tudo + atalhos por área |
| `busca` | Pesquisa | `TelaBusca` | Busca global com sugestões |
| `notificacoes` | Notificações | `TelaNotificacoes` | Lista com ícone por tipo e ação |
| `perfil` | Perfil | `TelaPerfil` | Avatar com anel, contadores, bio editável, selos, destaques, abas Posts/Salvos/Cupons |
| `amigos` | Amigos | `TelaAmigos` | Sugestões, pedidos (aceitar/recusar), meus amigos |
| `convidar` | Convidar amigos | `TelaConvidar` | Link, WhatsApp, imagem para story, selo Embaixador, ranking |
| `nivel` | Meu nível | `TelaNivel` | Nível de 10, metas únicas, pontos de hoje, histórico |
| `pontua` | SAD Pontua / Ranking | `TelaPontua` | Missões, ranking, bairros, prêmios |
| `placar` | Placar dos bairros | `TelaPlacar`, `PlacarBloco` | Bairros, moradores, posts no mês, compartilhar |
| `carteirinha` | Carteirinha | `TelaCarteirinha` | Frente e verso, QR, cor por nível |
| `parceiros` / `parceiro-{id}` | Parceiros | `TelaParceiros`, `TelaParceiro` | Lista, perfil do parceiro, seguir, cupom, QR do balcão |
| `empresas` | Guia de empresas | `TelaEmpresas`, `QrBalcao` | 18 categorias, seguir |
| `cupons` | Cupons | `TelaCupons` | Nível mínimo, estoque, código único com QR |
| `mercadao` / `produto-{id}` | Mercadão | `TelaMercadao`, `TelaProduto` | Grade, filtros, Baixou %, troca, doação, WhatsApp |
| `imoveis` | Imóveis | `TelaImoveis` | Aviso antifraude, filtros, ordenação |
| `vagas` | Vagas | `TelaVagas` | Busca, regime, candidatar |
| `achados` | Achados e perdidos | `TelaAchados` | Perdi/Achei, categorias, Finais felizes |
| `animais` / `animal-{id}` / `cadastrar-animal` | Animais perdidos | `TelaAnimais`, `TelaAnimal`, `TelaCadastrarAnimal` | Grade, status, cadastro em 3 passos |
| `agenda` / `evento-{id}` | Agenda | `TelaAgenda`, `TelaEvento` | Período, categoria, Eu vou, lembrete |
| `noticias` / `noticia-{id}` | Notícias | `TelaNoticias`, `TelaNoticia` | Lista, filtro, matéria |
| `enquetes` | Enquetes | `TelaEnquetes`, `EnqueteBloco` | Votar, resultado na hora, criar |
| `comunidades` / `comunidade-{id}` | Comunidades | `TelaComunidades`, `TelaComunidade` | Participar, feed do grupo |
| `voz` | Voz do Bairro | `TelaVoz` | História, elogio, reclamação, denúncia; anônimo |
| `top` | Top da semana | `TelaTop` | 5 posts mais engajados |
| `sorteios` | Sorteios | `TelaSorteios` | Participar grátis |
| `premio` | Melhores do ABC | `TelaPremio` | Votação por categoria, fases |
| `mapa` | Explore Santo André | `TelaMapa`, `MapaBloco` | Pinos por tipo, check-in, nota, título de explorador |
| `indica` | SAD Indica | `TelaIndica` | Pedir, indicar empresa, "essa resolveu", ranking |
| `problemas` | Problemas da cidade | `TelaProblemas` | Avisar, apoiar, status |
| `servicos` | Serviços | `TelaServicos` | Jurídico, veterinário, prefeitura |
| `utilidades` | Utilidades | `TelaUtilidades` | Telefones, farmácias de plantão, coleta por bairro |
| `moderacao` | Moderação (admin) | `TelaModeracao` | Fila, restaurar, advertir, remover |
| `institucional` | Sobre e regras | `TelaInstitucional` | Sobre, regras, termos, privacidade (LGPD), anuncie |
| `mais` | Mais | `TelaMais` | Todos os módulos + modo admin |
| `entrar` | Entrar | `TelaEntrar` | Login |

## Janelas (modais e folhas)

| Janela | Componente | Abre de |
|---|---|---|
| Criar | `Criar` | Botão + (post, anúncio, enquete, animal, problema, vídeo só admin) |
| Comentários | `Comentarios` | Ícone de balão em post ou vídeo |
| Story | `StoryViewer` | Bolinhas do topo do início |
| QR do balcão | `QrBalcao` | Página do parceiro |

## Blocos do feed (ordem na aba Cidade)

Os itens do feed se revezam neste ciclo: post → notícia → evento → animal → parceiro → post → produto → notícia → evento → vaga. Entre eles entram os blocos:

| Posição | Bloco | Componente |
|---|---|---|
| depois do 1º item | Em alta no ABC (carrossel de vídeos) | `EmAltaCarrossel` |
| 3º | Explore Santo André (mapa) | `ExploreBloco` |
| 4º | Talvez você conheça | `SugestoesAmigos` |
| 5º | Enquete | `EnqueteBloco` |
| 7º | Ranking dos membros | `RankingBloco` |
| 9º | Top da semana | `TopSemanaBloco` |
| 10º | Placar dos bairros | `PlacarBloco` |
| 12º | Sorteio da semana | `SorteioBloco` |
| 13º | Comunidades pra você | `ComunidadesBloco` |
| 15º | Voz do Bairro | `VozBloco` |
| 17º | Segunda enquete | `EnqueteBloco` |

Antes do feed: `StoriesRow` → `PainelDoDia` → `CampanhaFundador` → `DestaquesRotativos` → caixa "No que você está pensando" → abas.
