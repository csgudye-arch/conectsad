# Regras de negócio: Conecta ABC

Todos os números abaixo são **padrões**. Deixe-os configuráveis (tabela de configurações ou painel admin), não fixos no código.

## Perfis

| Perfil | Pode |
|---|---|
| Morador | Postar, reagir, comentar, anunciar, votar, participar de tudo |
| Empresa | Página própria gerenciada por um morador; posta como empresa, cria cupons e vagas, tem seguidores |
| Moderador | Ver fila de denúncias, ver autor de relatos anônimos, restaurar/advertir/remover |
| Admin | Tudo do moderador + publicar vídeos no Em alta + configurar níveis, metas, cupons, sorteios, bairros |

## Pontos e níveis

- O **livro de pontos** (`points_ledger`) é a única fonte da verdade. Nível, ranking e placar são calculados a partir dele. Nunca guarde "pontos" soltos que possam ser editados direto.
- 10 níveis:

| Nível | Título | A partir de |
|---|---|---|
| 1 | Novato | 0 |
| 2 | Vizinho | 100 |
| 3 | Participante | 250 |
| 4 | Ativo | 500 |
| 5 | Destaque | 800 |
| 6 | Referência | 1.200 |
| 7 | Influente | 1.700 |
| 8 | Líder | 2.300 |
| 9 | Embaixador | 3.000 |
| 10 | Lenda do ABC | 4.000 |

- Subir de nível: notificação + aviso na tela.
- A cor da carteirinha muda por faixa: níveis 1–3 ouro, 4–6 prata, 7–9 "ouro negro", 10 lenda (degradê dourado).

### Metas únicas (pagam uma vez)

| Meta | Pontos |
|---|---|
| Completar o perfil (nome, @, bairro, bio) | +50 |
| Foto de rosto | +50 |
| Escolher capa | +30 |
| Primeiro post | +50 |
| Convidar um amigo (que complete o perfil) | +100 |
| Ter 3 amigos | +60 |
| Criar página de empresa | +100 |
| Criar uma comunidade (exige nível 3) | +100 |
| Seguir 3 empresas | +30 |
| Comentar num post | +20 |
| Reagir a 5 posts | +20 |
| Votar numa enquete | +20 |
| Participar de um sorteio | +20 |
| Instalar o app | +50 |
| Ativar notificações | +30 |

### Ações recorrentes com limite diário

| Ação | Pontos | Limite por dia |
|---|---|---|
| Post | +10 | 3 |
| Comentário | +5 | 10 |
| Check-in num lugar | +10 | 5 |
| Avaliar lugar | +15 | 5 |
| Indicar empresa (SAD Indica) | +5 | 5 |
| Indicação que resolveu | +15 | 5 |
| Amizade nova | +5 | 10 |
| Amigo convidado (perfil completo com foto) | +100 | 5 |
| Check-in diário | +3 | 1 |
| Confirmar presença em evento | +5 | 1 |
| Resgatar cupom | +15 | 1 |
| Votar em enquete | +5 | 1 |
| Avisar problema da cidade | +35 | 1 |

Passou do limite: a ação continua funcionando, mas não pontua até o dia seguinte. Mostre isso ao usuário.

### Selos permanentes

- **Fundador:** completar até a data da campanha (padrão 30/11) os passos: perfil, foto, primeiro post, 3 amigos, 1 convite.
- **Embaixador:** 10 amigos convidados que completaram o perfil.
- **Nível máximo:** acesso ao ranking da temporada e a todos os cupons.

Selos aparecem no perfil e na carteirinha.

### Temporadas

Ranking e placar dos bairros são por temporada (padrão: mensal). Ao encerrar, arquive o ranking e comece outro; selos e nível não zeram.

## Convites

- Link único por usuário (`/c/{usuario}`).
- Só conta quando o convidado completa o perfil com foto.
- Quem convida +100, o convidado +30.

## Cupons

- Criados por empresas: título, tipo (% off, R$ off, frete grátis, brinde, preço especial), regras, validade, estoque (limitado ou ilimitado).
- Mostrar "restam X" e "já pegaram".
- Nível mínimo por cupom (padrão: 10; no protótipo há cupons de 1 a 10 para demonstrar).
- Abaixo do nível: o usuário vê o cupom bloqueado, com cadeado e quanto falta.
- Resgate gera **código único por usuário**, que a empresa valida (QR).

## SAD Indica

- Quem pede escolhe a categoria. Vizinhos indicam empresas cadastradas.
- O dono não pode indicar a própria empresa.
- Quem pediu marca "essa resolveu", e o pedido vira Resolvido. A empresa sobe no ranking.

## Em alta (vídeos)

- **Só administradores publicam.** Todos os vídeos aparecem como da conta oficial `@conectaabc`, com selo "Oficial". Parceiros aparecem só como menção ("com @fulano").
- Para quem não é admin, a opção "Vídeo" no Criar aparece com cadeado.
- **Essa regra tem que valer no servidor** (ver prompt 17), não só na tela.

## Moderação

- Denúncia em post, comentário, anúncio, comunidade, perfil e relato.
- Com **3 denúncias de pessoas diferentes**, o conteúdo fica oculto até o moderador decidir.
- Ações: remover, restaurar, advertir, suspender, banir. Tudo registrado com motivo e data.
- Relato anônimo: o autor fica oculto pros usuários, mas visível pra moderação.
- Proibido: golpe e informação falsa, ódio, expor pessoas, conteúdo adulto ou violento, qualquer coisa envolvendo menores, spam, briga política partidária, venda de itens proibidos.

## Imóveis

Aviso fixo: **nunca pague sinal antes de visitar o imóvel. A plataforma não intermedeia pagamentos.**

## LGPD

Consentimento no cadastro, exportação dos dados do usuário e exclusão da conta pelo próprio usuário.

## Online

Bolinha verde pequena no story e no avatar de quem está online agora (presença em tempo real; no Supabase, Realtime Presence).
