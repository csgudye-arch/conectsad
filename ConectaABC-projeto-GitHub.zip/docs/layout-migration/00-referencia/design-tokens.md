# Design tokens: Conecta ABC

Tema escuro único (preto puro), com o **amarelo SAD** como cor de destaque. Estilo de rede social (Instagram/Facebook) com toques de TikTok na área de vídeos.

## Cores

| Token | Valor | Uso |
|---|---|---|
| `--cor-fundo` | `#000000` | Fundo do app |
| `--cor-superficie` | `#121212` | Cards elevados, folhas (modais), campos |
| `--cor-superficie-2` | `#1A1A1A` | Chips, abas inativas, hover |
| `--cor-linha` | `#262626` | Bordas e divisórias (1px) |
| `--cor-linha-forte` | `#363636` | Bordas de opções, anel de story visto |
| `--cor-texto` | `#F5F5F5` | Texto principal |
| `--cor-texto-2` | `#A8A8A8` | Texto secundário |
| `--cor-texto-3` | `#737373` | Placeholder, dicas |
| `--cor-destaque` | `#FFC107` | Botão principal, nível, links de ação, selos |
| `--cor-destaque-hover` | `#FFCA2C` | Hover do botão principal |
| `--cor-texto-no-destaque` | `#0A0A0A` | Texto sobre amarelo |
| `--cor-curtida` | `#ED4956` | Coração curtido, badge de notificação, ação perigosa |
| `--cor-video` | `#FE2C55` | Curtida e seguir na área Em alta (vídeos) |
| `--cor-online` | `#22C55E` | Bolinha de online |
| `--cor-sucesso` | `#16A34A` | Status ok, "Grátis", "Encontrado" |
| `--cor-info` | `#2563EB` | Notícia, "Venda", informação |
| `--cor-alerta` | `#F97316` | Alerta da Defesa Civil, aviso antifraude |
| `--cor-whatsapp` | `#25D366` | Botões de WhatsApp |

**Anel de story (não visto):** `conic-gradient(from 210deg, #FFC107, #FF8A00, #FFD54F, #FFC107)`.

**Fundos de imagem provisórios** (onde ainda não há foto), em degradê escuro: ouro `#3A2E05→#1A1503`, verde `#0F2A1E→#0B1712`, azul `#0E1D33→#0A1220`, vinho `#33101A→#1A0A0E`, laranja `#3A1D08→#1C0F05`, cinza `#262629→#151517`, roxo `#22143A→#120B1F`. No app real, troque pelas fotos.

## Tipografia

- Fonte: **Inter** (400, 500, 600, 700, 800), com fallback `system-ui, -apple-system, "Segoe UI", sans-serif`
- Números alinhados: `font-variant-numeric: tabular-nums` em contadores, preços e pontos

| Uso | Tamanho / peso |
|---|---|
| Título de página | 22–24px / 700 |
| Nome da marca (CONECTA ABC) | 20px / 800, `letter-spacing: .06em`, "ABC" em amarelo |
| Título de card / seção | 15–16px / 600–700 |
| Texto | 14px / 400 |
| Legenda, meta | 12–13px / 400–600, cor `--cor-texto-2` |
| Rótulo maiúsculo | 11px / 700, `letter-spacing: .12em` |

## Forma e espaço

| Token | Valor |
|---|---|
| Raio de botão, campo, aba | 8px (`rounded-lg`) |
| Raio de card | 12px (`rounded-xl`) |
| Raio de pílula/selo | 6px |
| Avatar, story | círculo |
| Botão padrão | altura 36px; principal em formulário 40–44px |
| Campo de texto | altura 44px, fundo `--cor-superficie`, borda `--cor-linha`, foco com borda amarela |
| Borda | sempre 1px `--cor-linha`; sem sombras pesadas |
| Espaçamento lateral | 12px no celular, 16–24px no computador |
| Largura do feed | 470px; páginas comuns 630px; páginas em grade 935px |

## Layout

- **Celular (< 768px):** topo de 52px com **CONECTA ABC centralizado** (Criar à esquerda; notificações e menu à direita), barra inferior de 50px com 5 ícones (Início, Explorar, Criar, Em alta, Perfil).
- **Tablet (768–1279px):** barra lateral fina de 72px, só ícones.
- **Computador (≥ 1280px):** barra lateral de 244px com ícone e nome; topo fino com CONECTA ABC centralizado; coluna direita de 320px no início (perfil, SAD Pontua, eventos, comunidades, placar).
- Em celular, nada fica colado nas bordas do aparelho: respeite `env(safe-area-inset-*)`.

## Movimento

- Entrada de elementos: fade + subir 6px em 180ms
- Coração do toque duplo: escala 0,2→1,15→1 e some em 700ms
- Destaques: deslizam pro lado a cada 4s (transição 500ms)
- Carteirinha: vira em 600ms (3D)
- Tudo desliga com `prefers-reduced-motion: reduce`

## Tailwind (se o seu app usa)

```js
// tailwind.config: theme.extend
colors: {
  fundo: '#000000', superficie: '#121212', superficie2: '#1A1A1A', linha: '#262626', linhaforte: '#363636',
  texto: '#F5F5F5', texto2: '#A8A8A8', texto3: '#737373',
  destaque: { DEFAULT: '#FFC107', hover: '#FFCA2C', texto: '#0A0A0A' },
  curtida: '#ED4956', video: '#FE2C55', online: '#22C55E', sucesso: '#16A34A', info: '#2563EB', alerta: '#F97316', whatsapp: '#25D366',
},
fontFamily: { sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'] },
```

## CSS puro (se não usa Tailwind)

```css
:root {
  --cor-fundo:#000; --cor-superficie:#121212; --cor-superficie-2:#1A1A1A; --cor-linha:#262626; --cor-linha-forte:#363636;
  --cor-texto:#F5F5F5; --cor-texto-2:#A8A8A8; --cor-texto-3:#737373;
  --cor-destaque:#FFC107; --cor-destaque-hover:#FFCA2C; --cor-texto-no-destaque:#0A0A0A;
  --cor-curtida:#ED4956; --cor-video:#FE2C55; --cor-online:#22C55E; --cor-sucesso:#16A34A; --cor-info:#2563EB; --cor-alerta:#F97316; --cor-whatsapp:#25D366;
  --raio-sm:6px; --raio:8px; --raio-lg:12px;
  --fonte: Inter, system-ui, -apple-system, "Segoe UI", sans-serif;
  color-scheme: dark;
}
body { background: var(--cor-fundo); color: var(--cor-texto); font-family: var(--fonte); }
```
