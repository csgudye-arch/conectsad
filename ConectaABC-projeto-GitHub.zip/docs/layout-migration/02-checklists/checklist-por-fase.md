# Checklist por fase

Marque cada item ao fim do prompt. Só avance quando a fase estiver toda marcada.

Antes de começar: [ ] fiz backup / versão do app.


## Prompt 01: Auditoria do app e mapa da migração

- [ ] Recebi a tabela com todas as telas do protótipo classificadas
- [ ] Recebi a lista do que só existe no meu app
- [ ] O arquivo `MIGRACAO-CONECTA-ABC.md` foi criado
- [ ] Nenhum arquivo do app foi alterado
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 02: Tokens de design e tema escuro

- [ ] App inteiro no fundo preto com destaque amarelo
- [ ] Fonte Inter carregando
- [ ] Nenhuma tela ficou com texto ilegível (preto no preto, branco no amarelo)
- [ ] Nada mudou de lugar
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 03: Layout, topo CONECTA ABC e navegação

- [ ] CONECTA ABC centralizado no topo no celular e no computador
- [ ] Barra inferior com 5 itens no celular
- [ ] Barra lateral no tablet (ícones) e no computador (ícones + nomes)
- [ ] Todas as páginas antigas continuam acessíveis (pelo menu ou pela tela Mais)
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 04: Componentes base

- [ ] Os componentes existem num lugar só e são reaproveitados
- [ ] As telas antigas já usam os botões, campos e abas novos
- [ ] Avatar com anel e com bolinha de online funcionando
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 05: Página inicial (feed)

- [ ] Stories com bolinha verde em quem está online
- [ ] Destaques deslizando sozinhos e com o dedo
- [ ] Abas Cidade / Amigos / Meu bairro filtrando
- [ ] Feed alternando os tipos de conteúdo, com os blocos no meio
- [ ] O que a página inicial antiga mostrava continua aparecendo
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 06: Posts, reações, comentários e denúncia

- [ ] Reações escolhidas ficam salvas e aparecem no resumo
- [ ] Comentários abrem e salvam
- [ ] Denunciar 3 vezes (contas diferentes) oculta o post
- [ ] Curtidas antigas continuam contando
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 07: Em alta: vídeos verticais (só admin publica)

- [ ] Rolagem vertical encaixando vídeo por vídeo
- [ ] Usuário comum não consegue publicar vídeo (nem pela tela, nem chamando a API)
- [ ] Admin publica e o vídeo aparece primeiro
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 08: Perfil, amigos e convites

- [ ] Perfil com contadores, selos, destaques e abas
- [ ] Pedido de amizade: enviar, aceitar, recusar
- [ ] Link de convite copia e abre o WhatsApp
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 09: Gamificação: níveis, metas, ranking e placar

- [ ] Saldo de pontos antigo preservado
- [ ] Limite diário bloqueando pontos extras
- [ ] Meta só paga uma vez
- [ ] Ranking e placar calculados a partir dos pontos
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 10: Carteirinha digital

- [ ] Carteirinha vira e o verso tem o QR
- [ ] A página de verificação abre pelo QR
- [ ] A cor muda quando o nível muda
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 11: Parceiros, empresas e cupons

- [ ] Cupom bloqueado mostra quanto falta
- [ ] Resgate gera código único e respeita estoque
- [ ] Parceiros antigos aparecem no guia novo
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 12: Mercadão, imóveis, vagas, achados e animais

- [ ] Baixar o preço de um anúncio mostra o selo "Baixou"
- [ ] Aviso antifraude fixo em imóveis
- [ ] Item marcado como resolvido vai para Finais felizes
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 13: Agenda, notícias, enquetes, comunidades e Voz do Bairro

- [ ] Filtro "Fim de semana" e lembrete funcionando
- [ ] Um voto por pessoa nas enquetes
- [ ] Relato anônimo não mostra o autor (só a moderação vê)
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 14: Mapa, SAD Indica, sorteios, Melhores do ABC e top da semana

- [ ] Check-in e nota pontuam e respeitam o limite diário
- [ ] Dono não consegue indicar a própria empresa
- [ ] Top da semana atualiza sozinho
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 15: Moderação, notificações e busca

- [ ] Fila de moderação lista o que foi denunciado
- [ ] Restaurar devolve o conteúdo ao feed
- [ ] Notificação chega quando alguém comenta
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 16: Utilidades, institucional, LGPD e PWA

- [ ] App instala no celular com o nome Conecta ABC
- [ ] Exportar dados baixa o arquivo
- [ ] Excluir conta pede confirmação e funciona
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 17: Backend, banco e segurança

- [ ] Plano de migração revisado por mim antes de rodar
- [ ] Nenhum dado antigo perdido
- [ ] Usuário comum não consegue: publicar vídeo, dar pontos a si mesmo, pegar cupom acima do nível
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase


## Prompt 18: Revisão final

- [ ] Todos os fluxos de ponta a ponta passaram
- [ ] Nenhuma tela quebrada no celular nem no computador
- [ ] Relatório final atualizado
- [ ] Atualizei o `MIGRACAO-CONECTA-ABC.md`
- [ ] Fiz backup / versão depois desta fase
