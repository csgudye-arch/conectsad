# Conecta ABC — estado da migração em 06/11/2026

Este documento consolida as etapas anteriores. As notas históricas em MIGRACAO-CONECTA-ABC.md descrevem o estado no momento de cada etapa.

## Dados e infraestrutura

- Aplicação existente preservada: Next.js 16, React 19, Supabase Auth/Postgres/Storage, exportação estática e projetos Capacitor Android/iOS.
- Migrações 202611060001 a 202611060025 aplicadas no Supabase existente. Nenhuma conta, saldo ou publicação real foi excluída. Nenhum usuário, anúncio ou postagem de exemplo foi criado em produção.
- Funções `account-delete` e `public-media` implantadas. Credencial administrativa disponível apenas no ambiente das funções, nunca no frontend.
- `public-media`: verificação JWT legada desativada com autorização específica do proprietário. Retorna apenas bytes de posts anônimos aprovados; não revela caminho de Storage nem autor. Métodos GET/HEAD, suporte Range, sem redirecionamento, sem cache. Testes reais negativos: 400 para ID inválido; 404 para inexistente.
- `account-delete`: verifica bearer com Auth, exige login recente, bloqueia contas operacionais e remove arquivos pela API de Storage antes da conta. Nenhuma conta real foi excluída para testar.
- Frontend publicado em **https://conectaabc.com/** pelo Netlify, deploy `6aee256cc0384f7506b66326`. Pacote: `out-layout-completo-20261106.zip` (178 entradas, sem .env/node_modules/.git). Versão anterior preservada no histórico do Netlify para rollback.

## Recursos implementados

| Área | Funcionamento |
|---|---|
| Início e navegação | Tema preto/amarelo, layout responsivo, menu mobile, voltar, atalhos e links diretos por área. Conteúdo real aprovado. |
| Feed | Texto, foto/vídeo e postagem anônima preservados; aprovação, quatro reações, comentários moderados, salvar, denúncia, compartilhamento externo, ocultar localmente com desfazer. |
| Privacidade anônima | Autor e caminho de mídia omitidos nas consultas públicas. Novos apoios a posts anônimos não creditam +1 ao autor, para evitar identificação pela variação do ranking. Saldos antigos preservados. |
| Stories | Upload, legenda/cidade, aprovação, retirada pelo autor, visualização individual e contagem privada; expiração de visibilidade em 24 horas. |
| Em alta | Coleção de vídeos oficiais e upload restrito à equipe; vídeos de moradores continuam permitidos no feed comum, conforme funcionalidade anterior. |
| Perfil e amizades | Nome/cidade/bio/bairro/capa, publicação opcional, presença opcional, grade identificada, convites/aceite/recusa, sugestões e bloqueio privado. Anônimos excluídos da grade e dos filtros de amizade/bairro. |
| Progresso e carteirinha | Livro de pontos preservado, saldo agregado no servidor, dez níveis configuráveis, histórico paginado, ranking geral/mensal, bairros declarados, resumo real de atividade e emblemas por resultados confirmados. Carteirinha com foto, frente/verso, faixa de nível e QR verificável. |
| Indicações | Link individual existente e validação de cadastro/e-mail/CPF pela equipe preservados; não foi substituída por simples validação visual. |
| Empresas | Guia paginado, categorias/cidade, perfil comercial, contatos fornecidos, seguidores, QR do balcão; proprietário cadastra/edita, envia logo e até seis fotos. Alterações voltam à análise. Pedidos antigos preservados separadamente, sem aprovação automática. |
| Cupons | Cadastro/revisão, nível mínimo, estoque transacional, código único, QR, resgate idempotente e validação exclusiva do responsável. **Clube fechado: resgatar/validar bloqueados no servidor.** |
| Mercadão | Categorias existentes, condição, troca/doação, queda real de preço, gerenciamento próprio e encerramento. |
| Imóveis, vagas e objetos | Novos formulários dedicados, paginação/filtros, moderação, contatos mediante consentimento e login, resolução e avisos contra fraude. |
| Animais, cidade e serviços | Fluxos existentes preservados, com envio autenticado, revisão/acompanhamento e permissões por função. Não foram apagados pedidos antigos. |
| Agenda | Eventos estruturados, período/cidade, lembrete em calendário, interesse e fila da equipe. |
| Enquetes e comunidades | Voto por pessoa, grupos/adesão/posts moderados, configuração de pontuação mínima para criar comunidade. |
| Mapa | Locais existentes, avaliações moderadas e registro privado de visita com limite diário. Visita autodeclarada não dá pontos automaticamente. |
| Indica ABC | Pedidos e recomendações moderados, seleção de solução pelo solicitante e ranking de soluções reais; proprietário não recomenda o próprio negócio. |
| Busca, notificações e denúncias | Pesquisa global paginada por módulos, top semanal, caixa privada, fila de denúncias e ocultação por denunciantes distintos. |
| Utilidades | Cadastro verificado pela equipe com fonte/cidade/validade; nenhum telefone ou horário fictício. Plantões expirados não são publicados. |
| PWA e privacidade | Instalação, aviso de atualização, página offline, exportação dos próprios dados e solicitação/cancelamento/exclusão da conta. Sem cache de respostas Supabase ou dados privados. |
| Campanhas | Somente rascunhos privados de regulamento/período/responsável. Prêmios, sorteios, Fundador e Melhores do ABC **desativados por decisão do proprietário**. Nenhum pagamento ou sorteio real. |

## Verificações executadas

- 216 verificações PostgreSQL em memória: permissões, terceiros, anonimato, aprovação, bloqueios, limites, estoque, idempotência e pontos. Incluem a função real anterior de apoio; corrigida ambiguidade SQL em `ON CONFLICT` que podia impedir apoios.
- 21 testes Vitest.
- 10 testes isolados da função de exclusão e 8 do proxy de mídia.
- TypeScript e build estático (16 rotas) passaram. Lint dos componentes novos/revisados passou; não equivale a lint integral do legado.
- 12 consultas públicas reais ao Supabase passaram. Sem posts de teste em produção.
- Revisão mobile em 390×844: dez áreas sem transbordamento horizontal na navegação inicial; guia de empresas carregado e interação de reação exigiu login corretamente. A passagem inicial por telas ainda em carregamento não comprova fluxo completo.

## Validação adicional antes de divulgação ampla

1. Conferir o visual publicado com o proprietário. Usar o pacote novo identificado acima, sem reenviar ZIPs antigos.
2. Com uma conta de teste autorizada em ambiente de homologação, executar envio → análise → aprovação → leitura por outra conta, cobrindo feed/mídia/stories/classificados/empresa/serviço; conferir ranking e indicação. Os testes isolados não substituem esse percurso autenticado pela interface.
3. Retorno Google, leitura da carteirinha e QR público foram conferidos com a conta real do proprietário. Falta testar upload de foto e confirmação/recuperação de e-mail nesta versão com uma conta de homologação.
4. Não ativar clube ou campanhas sem nova decisão. Regras de pontuação do protótipo não substituem automaticamente as regras existentes.

## Verificação autenticada e publicação

Login Google conferido com conta existente; nome do consentimento exibiu Conecta ABC da SAD. Retorno localhost:3100 caiu no domínio principal por não estar na allowlist; localhost:3000 retornou corretamente. Nenhuma allowlist foi ampliada. Servidor local de preview foi corrigido para resolver `.html` antes de diretórios de dados RSC.

Cidade do proprietário atualizada para Santo André com autorização expressa. Perfil/carteirinha, progresso, envios, amizades, notificações, portal, privacidade e administração carregaram autenticados sem transbordamento mobile. Cinco filas novas carregaram sem erro. Story sem arquivo retornou mensagem em português sem inserir postagem. QR da carteirinha abriu a validação pública com Perfil confirmado, primeiro nome e cidade. Nenhuma publicação de teste foi inserida.

Capturas: netlify-migracao-publicada.png, validacao-publica-carteirinha.png, public-media-deployed.png e banco-etapas19-25.png nesta pasta.

## Limites operacionais

- Stories desaparecem da consulta após 24 horas; o arquivo físico não é apagado automaticamente. Configurar retenção/limpeza por Storage API após definir política, sem SQL DELETE de objetos.
- Uploads novos pelos módulos migrados redimensionam imagens proporcionalmente até 1600 px e removem metadados ao reencodificar. Vídeos não são transcodificados; formatos devem ser testados em iPhone/Android. Limites de 5 MB para fotos de cadastro e até 20 MB para mídia social.
- Alguns módulos antigos/filas usam limites fixos de listagem. Busca/classificados/empresas/histórico têm paginação; não afirmar paginação ilimitada para todo o app.
- Dados abertos de bairros/presença respeitam opção do perfil, mas não são prova de residência ou de localização física.
- O plano gratuito continua; não houve contratação de upgrade. Monitorar armazenamento/egress antes de grande divulgação.

## Comandos

```powershell
pnpm install
pnpm dev
pnpm typecheck
pnpm test
node scripts/test-social-db.mjs
node scripts/test-account-function.mjs
node scripts/test-public-media.mjs
pnpm build
```

O teste SQL usa PGlite instalado isoladamente em `tmp/social-db-test`; seu script não acessa o banco real. A smoke real somente de leitura é `node scripts/smoke-public-rpcs.mjs`; usa apenas URL/chave pública de `.env.local`, sem imprimi-las. Não distribuir `.env.local`, `node_modules`, dumps ou credenciais no pacote estático.

Verificação final da publicação: oito rotas HTTP responderam 200, manifesto servido como application/manifest+json com nome Conecta ABC e dois ícones; sw.js sem cache persistente no servidor. Cabeçalhos para Netlify Drop incluídos em public/_headers. Perfil/progresso e validação da carteirinha conferidos no domínio público com conta autenticada; console sem erros. A tentativa de alternar viewport para 1440 manteve 390 no visualizador, portanto não é registrada como revisão desktop desta versão. App deixado aberto em mobile. Captura final: app-publicado-mobile.png.


## Prévia visual com exemplos — pedido posterior do proprietário

Adicionado modo local opcional `http://localhost:3000/?demonstracao=1`, com cinco stories fictícios e carrossel de destaques: comunidade, vaga, pet, Mercadão e agenda. Conteúdo marcado como exemplo, sem cadastrar registros no Supabase, atribuir pontos, simular contatos ou gerar notificações. A página normal permanece com dados reais. Botão Sair da prévia desativa os exemplos e remove o parâmetro. Nenhuma publicação desta alteração no Netlify nesta etapa.

Componentes: VisualExamples.tsx, Stories.tsx e integração na home. Fotos ilustrativas locais reaproveitadas. Dialog de story com anterior/próximo; carrossel com controles, pausa e respeito a movimento reduzido. Build estático e lint dos componentes passaram. Navegador 390 px: sem transbordamento; abertura/navegação de stories e saída da prévia conferidas; console sem erros. Captura: preview-exemplos-topo-mobile.png.

## Exemplos publicados no app real — autorização posterior

O proprietário pediu explicitamente publicar as demonstrações na página inicial normal do app real. Alteração aplicada e publicada em https://conectaabc.com/, deploy Netlify 6aee285785a71bba4c02a752, pacote out-demo-publico-20261106.zip. Substitui a decisão anterior de limitar os exemplos ao modo local opcional.

Stories/destaques fictícios aparecem por padrão, identificados individualmente como Exemplo e em banner Conteúdo demonstrativo. Ocultar exemplos desativa e mantém demonstracao=0 na URL, inclusive após recarregar; demonstracao=1 e a página inicial sem parâmetro mostram exemplos. Nenhum conteúdo fictício foi inserido no banco, e nenhum contato, ponto ou notificação é gerado pelos exemplos.

Build com TypeScript e lint do componente passaram. Domínio público sem parâmetro conferido: cinco stories demonstrativos, carrossel e banner; largura 390 px sem transbordamento e console sem erros. Capturas: exemplos-publicados-mobile.png e netlify-exemplos-publicados.png.

## Feed inicial intercalado — comparação direta com a referência

A pedido do proprietário, o início agora intercala módulos na rolagem principal, inclusive no celular. Publicado em https://conectaabc.com/, deploy Netlify 6aee2b8e80c91737acd4e08e; pacote out-feed-completo-20261106.zip.

Quatorze blocos: Em alta, mapa, animais, sugestões de pessoas, Mercadão, ranking dos membros, agenda, top semanal, vagas, placar dos bairros, comunidades, enquetes, voz do bairro e serviços. A primeira sequência entra entre os posts; blocos restantes continuam abaixo mesmo quando há poucas publicações. Ranking usa dados públicos reais; bairros usam a temporada e apenas bairros tornados públicos. Mídias de anúncios/animais preservam proporção. As demonstrações autorizadas são identificadas e usadas somente quando não há conteúdo aprovado no respectivo bloco; não são gravadas no banco.

Mapa reutiliza o componente conectado existente, com visual compacto no feed. Scroll do mouse não controla zoom; mapa compacto não captura arraste/toque até ser expandido. Expansão mantém as ferramentas existentes e restaura rolagem ao fechar. Zoom continua pelos controles. Não foram criados pontos fictícios, sorteios, prêmios ou benefícios.

Verificação: TypeScript/build estático passaram, lint dos dois componentes revisados passou e 21 testes Vitest passaram. No navegador a 390 px: 14 blocos presentes, sem transbordamento horizontal e sem erro de console. Teste de roda sobre o mapa moveu a página de scrollY 1777 para 2621; expandir/fechar restaurou overflow do body; Ver ranking abriu Meu progresso e Voltar retornou ao início. Domínio público conferido após a publicação. Banco/usuários/saldos preservados, sem migrações SQL nesta alteração.

Capturas: feed-ranking-inline-publicado.png, feed-mapa-inline-publicado.png, netlify-feed-intercalado-publicado.png.

## Fidelidade ao modelo e anexos — revisão de 06/11

Pedido do proprietário: reproduzir o visual da referência aberta no Claude, especialmente cartão de metas/Fundador, mapa escuro ilustrado, animal em largura inteira e cartões horizontais de pessoas. Referência navegada no iframe e código-fonte do ZIP consultado diretamente; não foi tratado apenas como inclusão de módulos.

Publicado em https://conectaabc.com/, deploy 6aee32be8635da06eaf90dc8. Pacote out-visual-referencia-20261106.zip. Implementados ReferenceHomeParts.tsx e ReferenceRightRail.tsx, integração em HomeOverview/HomeFeedSections, controles compactos em PostSocialActions/ReactionPicker e CSS correspondente. Medidas conferidas na referência e no app: cartão 470 px, título 16 px, padding 16 px, raio 12 px; carrossel 150 px de altura. Mapa SVG escuro com pinos/categorias/tooltip, sem tiles ou captura de rolagem na prévia; botão Abrir mapa mantém acesso ao mapa geográfico existente.

Mapa, animal e sugestões de pessoas agora são consecutivos como no trecho anexado. Pessoas usam cartões de 150 px com avatar de 64 px; primeira borda a 12 px no celular, com rolagem horizontal. Ranking usa número de posição, avatar, nível real, cidade e XP reais. Coluna desktop tem conta/carteirinha, progresso, check-in diário, eventos, grupos e bairros; os dados de exemplo continuam identificados e não viram registros reais.

Controles de posts compactados em ícones, com reações/comentários/compartilhamento/salvar preservados; denúncia e ocultar ficam em Mais opções. Rótulo Em análise preservado para pendentes. Link de animal agora filtra a ocorrência pelo UUID e mantém o contato protegido. Presença e vínculos de amizade não são inventados em perfis reais.

Campanha Fundador permanece DESATIVADA. O cartão é demonstrativo, com checklist ilustrativo explicitamente identificado; não há prazo inventado, emissão de selo ou alteração nas regras de prêmio. Check-ins/estrelas em locais de exemplo não enviam dados nem dão pontos; pessoas fictícias não recebem pedidos. Avaliação real exige relato de 10 a 500 caracteres e segue moderação existente.

Verificações: build estático com TypeScript, lint dos componentes revisados e 21 testes Vitest passaram. Interface: denúncia vazia retornou mensagem em português; abrir reações/comentários, ocultar/desfazer, ação demonstrativa de visita/nota/amizade e link do animal conferidos. Nenhum teste criou post, amizade ou pontuação em produção. Navegador em 1440 px e 390 px sem transbordamento; console sem erros. Sequência DOM confirmada: mapa → animal → pessoas. Ocorrência aberta pelo link com um botão de contato protegido, sem revelar o contato no teste.

Capturas nesta pasta: referencia-metas-publicada.png, referencia-mapa-publicado.png, referencia-pessoas-publicada.png, referencia-desktop-publicada.png e netlify-visual-referencia-publicado.png. Os dados/conteúdos reais podem diferir dos textos e contadores fictícios do protótipo; as campanhas e benefícios não foram ativados para copiar a aparência.
A captura referencia-metas-publicada.png contém a visão desktop completa com o cartão de metas; não é um recorte isolado do cartão.

## Correção da miniatura de stories — 06/11

O proprietário informou que o story publicado pela conta oproibidaosad não mostrava miniatura circular. Consulta pública somente de metadados confirmou uma imagem aprovada com anexo; a causa era a renderização apenas de iniciais e a posição após cinco exemplos.

Stories.tsx agora mostra a mídia em miniatura circular e ordena os stories reais antes dos demonstrativos. URLs assinadas são emitidas em lote, reutilizadas no visualizador, com prazo máximo de cinco minutos limitado pela expiração dos stories; cache separado por sessão e tentativa explícita de renovação. Falhas têm alternativa visual e tentativa novamente no visualizador. Vídeos têm prévia nativa silenciosa com busca inicial de frame; validação desta entrega realizada com a imagem real disponível, sem afirmar teste de todos os formatos de vídeo.

Publicado no domínio principal, deploy Netlify 6aee51864e0ee3d6c7b09459; pacote out-stories-miniaturas-20261106.zip. TypeScript, lint de Stories.tsx e build estático passaram. Navegador local e público: miniatura real carregada (1293×1600), recorte cover, primeira posição após Seu story; visualizador abriu e fechou. Console sem erros. Nenhum story foi criado ou aprovado pelo teste; abrir o existente usa o registro normal/idempotente de visualização. Permissões e moderação preservadas.

Capturas: story-miniatura-publicada.png e netlify-miniaturas-stories.png.

## Preparação para testes com usuários — 06/11

Proprietário confirmou manter exemplos identificados. Revisão publicada em https://conectaabc.com/, deploy final 6aee54cd8bbd651e82aaf329, pacote out-beta-testes-20261106.zip. Substitui o deploy intermediário 6aee547abddc6de11abc6f73.

Incluídos identificação de versão de testes e ajuda no rodapé de todas as rotas. Diálogo orienta acompanhamento de envios/moderação, diferencia exemplos e recursos fechados, prepara e-mail para o contato público já autorizado ou copia relato. O app não envia e-mail automaticamente; diagnóstico inclui somente pathname/data e texto informado, sem query string, hash, tokens ou dados de conta. O participante é orientado a não informar documentos/senhas.

Incluída tela de recuperação para erros de renderização com retry (API desta versão do Next) e retorno ao início. Não foi forçada falha em produção para acionar o boundary. Falhas/rejeições ao carregar perfil agora têm tratamento e limite visual de 10 segundos; conclusão de perfil libera o estado de envio em exceções. Mensagens de autenticação/perfil retiram instruções de banco/migração da interface pública.

Prévia de anúncio sem preço passa a mostrar A combinar, sem herdar R$ 3.500 do exemplo. Ocorrência real sem descrição não herda relato de animal fictício; anúncio real não recebe condição Usado inventada.

Validações: 21 testes Vitest, 216 verificações PostgreSQL isoladas, 10 testes de exclusão e 8 de mídia passaram; 12 RPCs públicos reais e oito rotas HTTP responderam corretamente. TypeScript, lint dos sete arquivos alterados e build estático passaram. Navegador: ajuda abriu, copiou e fechou; formulário de serviço vazio recusado em português; atalhos de criação abriram. Domínio público com ajuda conferido em 390 e 1440 px sem transbordamento e console sem erros. Nenhum e-mail, pedido ou publicação foi enviado pelo teste, nem foram alterados saldos ou usuários. Sem migrações nesta revisão.

Roteiro de aceitação e operação: docs/TESTE-COM-USUARIOS.md. Ainda falta percurso autenticado completo com dois participantes, confirmação/recuperação de e-mail fresco e vídeos nos aparelhos reais. Entrega é para piloto acompanhado; não equivale à homologação de todos os fluxos ou divulgação ampla. Clube/campanhas continuam fechados; retenção física de stories e monitoramento de capacidade continuam pendências operacionais.

Capturas: beta-ajuda-publicada.png e netlify-beta-publicada.png. Aplicação pública deixada aberta no visualizador em formato celular.
