import fs from 'node:fs/promises';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import ts from 'typescript';
const source=(await fs.readFile(new URL('../supabase/functions/account-delete/index.ts',import.meta.url),'utf8')).replace(/^import .*?;\r?\n/,'');
const compiled=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;
let handler,count=0;let calls=[],fresh=true,refuse=false,storageFails=false;
const id='11111111-1111-4111-8111-111111111111';
const client={auth:{getUser:async token=>token==='valid'?{data:{user:{id,last_sign_in_at:new Date(Date.now()-(fresh?0:3600000)).toISOString()}},error:null}:{data:{user:null},error:{message:'invalid'}},admin:{deleteUser:async uid=>{calls.push(['delete',uid]);return {error:null};}}},rpc:async(name,args)=>{calls.push(['prepare',args.target_user]);return refuse?{error:{message:'Conta com responsabilidades operacionais.'},data:null}:{data:{files:[{bucket:'social-stories',path:id+'/story.jpg'}]},error:null};},storage:{from:bucket=>({remove:async paths=>{calls.push(['files',bucket,paths]);return {error:storageFails?{message:'failure'}:null};}})}};
vm.runInNewContext(compiled,{Deno:{serve:fn=>{handler=fn;},env:{get:name=>name==='SUPABASE_URL'?'https://test.invalid':'test-only-key'}},createClient:()=>client,Request,Response,Date,JSON,Set,Map});
function req(body,options={}){return new Request('https://test.invalid/functions/v1/account-delete',{method:'POST',headers:{origin:options.origin||'https://conectaabc.com',authorization:options.auth===false?'':'Bearer '+(options.token||'valid'),'content-type':'application/json'},body:JSON.stringify(body)});}
async function check(request,status,expectedCalls){calls=[];const response=await handler(request);assert.equal(response.status,status);assert.deepEqual(JSON.parse(JSON.stringify(calls)),expectedCalls);count++;return response;}
await check(req({action:'delete'},{origin:'https://attacker.invalid'}),403,[]);
await check(req({action:'delete'},{auth:false}),401,[]);
await check(req({action:'delete'},{token:'invalid'}),401,[]);
fresh=false;await check(req({action:'delete',confirmation:'EXCLUIR MINHA CONTA'}),409,[]);fresh=true;
await check(req({action:'wrong'}),400,[]);
await check(req({action:'delete',confirmation:'sim'}),400,[['prepare',id]]);
await check(req({action:'check',user_id:'victim'}),200,[['prepare',id]]);
refuse=true;await check(req({action:'delete',confirmation:'EXCLUIR MINHA CONTA'}),409,[['prepare',id]]);refuse=false;
storageFails=true;await check(req({action:'delete',confirmation:'EXCLUIR MINHA CONTA'}),503,[['prepare',id],['files','social-stories',[id+'/story.jpg']]]);storageFails=false;
await check(req({action:'delete',confirmation:'EXCLUIR MINHA CONTA',user_id:'victim'}),200,[['prepare',id],['files','social-stories',[id+'/story.jpg']],['delete',id]]);
console.log(`PASS: ${count} verificações da função de exclusão com clientes simulados isolados; nenhum serviço externo foi chamado.`);
