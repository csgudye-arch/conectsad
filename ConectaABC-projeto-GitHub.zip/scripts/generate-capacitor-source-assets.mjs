import sharp from "sharp";
import { mkdir, readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const assetsDir = resolve(root, "assets");
await mkdir(assetsDir, { recursive: true });

const mark = await readFile(resolve(root, "public/conecta-abc-mark.svg"));
const icon = await sharp(mark, { density: 768 }).resize(1024, 1024).png().toBuffer();
await sharp(icon).png().toFile(resolve(assetsDir, "icon-only.png"));
for (const [name, size] of [["conecta-abc-192.png", 192], ["conecta-abc-512.png", 512], ["apple-touch-icon.png", 180]]) {
  await sharp(icon).resize(size, size).png().toFile(resolve(root, "public", name));
}

const splashMark = await sharp(mark, { density: 768 }).resize(720, 720).png().toBuffer();
await sharp({ create: { width: 2732, height: 2732, channels: 4, background: "#101110" } })
  .composite([{ input: splashMark, gravity: "centre" }])
  .png()
  .toFile(resolve(assetsDir, "splash.png"));

const iosAssets = resolve(root, "ios/App/App/Assets.xcassets");
await sharp(icon).png().toFile(resolve(iosAssets, "AppIcon.appiconset/AppIcon-512@2x.png"));
for (const name of ["splash-2732x2732-2.png", "splash-2732x2732-1.png", "splash-2732x2732.png"]) {
  await sharp(resolve(assetsDir, "splash.png")).png().toFile(resolve(iosAssets, `Splash.imageset/${name}`));
}

const androidRes = resolve(root, "android/app/src/main/res");
for (const [density, iconPx, adaptivePx] of [["mdpi", 48, 108], ["hdpi", 72, 162], ["xhdpi", 96, 216], ["xxhdpi", 144, 324], ["xxxhdpi", 192, 432]]) {
  const folder = resolve(androidRes, `mipmap-${density}`);
  await mkdir(folder, { recursive: true });
  const launcher = await sharp(icon).resize(iconPx, iconPx).png().toBuffer();
  await sharp(launcher).png().toFile(resolve(folder, "ic_launcher.png"));
  await sharp(launcher).png().toFile(resolve(folder, "ic_launcher_round.png"));
  const inset = Math.round(adaptivePx * 0.16);
  const foreground = await sharp(mark, { density: 768 })
    .resize(adaptivePx - inset * 2, adaptivePx - inset * 2)
    .extend({ top: inset, bottom: inset, left: inset, right: inset, background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png()
    .toBuffer();
  await sharp(foreground).png().toFile(resolve(folder, "ic_launcher_foreground.png"));
}

const androidSplashDir = resolve(androidRes, "drawable-nodpi");
await mkdir(androidSplashDir, { recursive: true });
await sharp(resolve(assetsDir, "splash.png")).png().toFile(resolve(androidSplashDir, "splash.png"));
