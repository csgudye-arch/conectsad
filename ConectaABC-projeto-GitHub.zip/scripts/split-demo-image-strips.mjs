import sharp from "sharp";
import { mkdir } from "node:fs/promises";
import path from "node:path";

const publicDir = path.resolve("public");
const groups = ["animals", "city", "feed", "market", "partners", "services"];

await mkdir(publicDir, { recursive: true });

for (const group of groups) {
  const source = path.join(publicDir, `demo-${group}-strip.webp`);
  const metadata = await sharp(source).metadata();
  if (!metadata.width || !metadata.height || metadata.width % 5 !== 0) {
    throw new Error(`A faixa de imagens ${group} precisa ter cinco quadros iguais.`);
  }

  const tileWidth = metadata.width / 5;
  const gutter = Math.max(2, Math.round(tileWidth * 0.02));
  for (let index = 0; index < 5; index += 1) {
    const output = path.join(publicDir, `demo-${group}-${index + 1}.webp`);
    await sharp(source)
      .extract({ left: Math.round(index * tileWidth) + gutter, top: 0, width: Math.round(tileWidth) - gutter * 2, height: metadata.height })
      .webp({ quality: 84, effort: 5 })
      .toFile(output);
  }
}

console.log("Imagens demonstrativas divididas em quadros individuais sem deformação.");
