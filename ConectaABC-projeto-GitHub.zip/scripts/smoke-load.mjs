import { setTimeout as delay } from "node:timers/promises";
import { performance } from "node:perf_hooks";

const args = process.argv.slice(2).filter((argument) => argument !== "--");
const rawUrl = args[0];
const concurrency = Number(args[1] ?? 8);
const durationSeconds = Number(args[2] ?? 15);

if (!rawUrl) {
  console.error("Uso: pnpm load:smoke -- <URL-local-ou-preview-Netlify> [concorrência 1-20] [duração 1-30s]");
  process.exit(2);
}

let target;
try {
  target = new URL(rawUrl);
} catch {
  console.error("Informe uma URL válida de ambiente local ou preview.");
  process.exit(2);
}

const localHosts = new Set(["localhost", "127.0.0.1", "::1"]);
const netlifyPreview = target.hostname.endsWith(".netlify.app")
  && (target.hostname.startsWith("deploy-preview-") || target.hostname.slice(0, -".netlify.app".length).includes("--"));

if (!localHosts.has(target.hostname) && !netlifyPreview) {
  console.error("Por segurança, o script só aceita localhost ou preview/branch deploy do Netlify; não use o domínio público.");
  process.exit(2);
}
if (target.protocol !== "https:" && !localHosts.has(target.hostname)) {
  console.error("Previews externos precisam usar HTTPS.");
  process.exit(2);
}
if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 20) {
  console.error("A concorrência deve ficar entre 1 e 20.");
  process.exit(2);
}
if (!Number.isInteger(durationSeconds) || durationSeconds < 1 || durationSeconds > 30) {
  console.error("A duração deve ficar entre 1 e 30 segundos.");
  process.exit(2);
}

const paths = ["/", "/manifest.webmanifest"];
const endAt = performance.now() + durationSeconds * 1000;
const samples = [];
const statuses = new Map();
let failures = 0;

async function worker(workerId) {
  let requestIndex = workerId;
  while (performance.now() < endAt) {
    const url = new URL(paths[requestIndex % paths.length], target);
    const startedAt = performance.now();
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
      const elapsed = performance.now() - startedAt;
      samples.push(elapsed);
      statuses.set(response.status, (statuses.get(response.status) ?? 0) + 1);
      if (!response.ok) failures += 1;
      await response.arrayBuffer();
    } catch {
      samples.push(performance.now() - startedAt);
      failures += 1;
    }
    requestIndex += concurrency;
    await delay(40);
  }
}

console.log(`Teste de leitura: ${target.origin} · ${concurrency} conexões · ${durationSeconds}s`);
console.log("Alvos: página inicial e manifest estático. Nenhum envio ao banco ou armazenamento.");
await Promise.all(Array.from({ length: concurrency }, (_, index) => worker(index)));

const sorted = [...samples].sort((a, b) => a - b);
const percentile = (p) => sorted.length ? Math.round(sorted[Math.min(sorted.length - 1, Math.ceil(sorted.length * p) - 1)]) : 0;
console.log(`Requisições: ${samples.length} · falhas: ${failures} · p50: ${percentile(0.5)}ms · p95: ${percentile(0.95)}ms`);
console.log(`Status HTTP: ${[...statuses.entries()].sort(([a], [b]) => a - b).map(([status, count]) => `${status}: ${count}`).join(", ") || "nenhum"}`);
console.log("Este resultado mede apenas a entrega estática; não representa capacidade simultânea do Supabase.");
if (failures) process.exitCode = 1;
