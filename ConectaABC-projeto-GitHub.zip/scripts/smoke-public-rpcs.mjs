import fs from 'node:fs/promises';
import {createClient} from '@supabase/supabase-js';
const content=await fs.readFile(new URL('../.env.local',import.meta.url),'utf8');
const read=name=>content.split(/\r?\n/).find(line=>line.startsWith(name+'='))?.slice(name.length+1).trim().replace(/^['"]|['"]$/g,'');
const url=read('NEXT_PUBLIC_SUPABASE_URL'),key=read('NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY');
if(!url||!key)throw Error('Configuração pública indisponível.');
const client=createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
const queries=[['social_get_levels',{}],['social_list_stories',{story_city:null}],['social_list_businesses',{target_business:null,page_number:0}],['social_list_events',{target_event:null}],['social_list_recommendations',{}],['social_list_utilities',{}],['social_list_coupons',{}],['social_top_week',{}],...['imoveis','vagas','achados'].map(kind=>['social_list_classifieds',{listing_kind:kind,page_number:0,mine_only:false}]),['social_search_public',{search_term:'comunidade',search_city:null,page_number:0}]];
let failed=false;for(const [name,args] of queries){const result=await client.rpc(name,args);console.log(name,result.error?'ERRO '+result.error.code:'OK');if(result.error)failed=true;}
if(failed)process.exitCode=1;
