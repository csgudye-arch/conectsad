import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { PGlite } from '../tmp/social-db-test/node_modules/@electric-sql/pglite/dist/index.js';
import { pgcrypto } from '../tmp/social-db-test/node_modules/@electric-sql/pglite/dist/contrib/pgcrypto.js';

// Local stand-ins for Supabase infrastructure. App tables, triggers, grants,
// policies and RPCs come exclusively from the migrations below.
const infrastructure = `
  create role anon;
  create role authenticated;
  create role service_role bypassrls;
  create schema auth;
  create table auth.users (
    id uuid primary key, raw_user_meta_data jsonb, email_confirmed_at timestamptz
  );
  create function auth.uid() returns uuid language sql stable as $$
    select nullif(current_setting('test.uid', true), '')::uuid
  $$;
  grant usage on schema auth to anon, authenticated;

  create schema storage;
  create table storage.buckets (
    id text primary key, name text, public boolean, file_size_limit bigint, allowed_mime_types text[]
  );
  create table storage.objects (
    bucket_id text references storage.buckets(id), name text, metadata jsonb,
    primary key (bucket_id, name)
  );
  create function storage.foldername(path text) returns text[] language sql immutable as $$
    select (string_to_array(path, '/'))[1:cardinality(string_to_array(path, '/'))-1]
  $$;
  alter table storage.objects enable row level security;
  grant usage on schema storage to anon, authenticated;
  grant select on storage.objects to anon, authenticated;
  grant insert, update, delete on storage.objects to authenticated;

  create schema extensions;
  create extension pgcrypto with schema extensions;
  create schema vault;
  create table vault.secrets (id uuid primary key default gen_random_uuid(), name text unique, secret text);
  create view vault.decrypted_secrets as select name, secret as decrypted_secret from vault.secrets;
  create function vault.create_secret(secret text, name text, description text) returns uuid language sql as $$
    insert into vault.secrets(secret, name) values ($1, $2) returning id
  $$;
`;

const db = new PGlite({ extensions: { pgcrypto } });
const member = '00000000-0000-4000-8000-000000000011';
const moderator = '00000000-0000-4000-8000-000000000012';
const city = 'Santo André';

async function asUser(id) {
  await db.exec(`reset role; set role ${id ? 'authenticated' : 'anon'}`);
  await db.query("select set_config('test.uid', $1, false)", [id ?? '']);
}

async function rows(sql, params = []) {
  return (await db.query(sql, params)).rows;
}

async function value(sql, params = []) {
  const [row] = await rows(sql, params);
  return row && Object.values(row)[0];
}

async function upload(bucket, name, mime) {
  await db.query('insert into storage.objects(bucket_id, name, metadata) values ($1, $2, $3)',
    [bucket, name, JSON.stringify({ mimetype: mime })]);
}

async function canReadMedia(bucket, name) {
  return value('select exists(select 1 from storage.objects where bucket_id = $1 and name = $2)', [bucket, name]);
}

try {
  await db.exec(infrastructure);
  const directory = new URL('../supabase/migrations/', import.meta.url);
  const files = (await readdir(directory)).filter(file => file.endsWith('.sql')).sort();
  for (const file of files) {
    try {
      await db.exec(await readFile(new URL(file, directory), 'utf8'));
    } catch (error) {
      throw new Error(`Falha ao aplicar ${file}: ${error.message}`, { cause: error });
    }
  }
  console.log(`OK: ${files.length} migrações aplicadas ao banco em memória.`);

  for (const [id, name] of [[member, 'Moradora Teste'], [moderator, 'Equipe Teste']]) {
    await db.query('insert into auth.users(id, raw_user_meta_data) values ($1, $2)',
      [id, JSON.stringify({ display_name: name, city })]);
  }
  await db.query('insert into public.community_moderators(user_id) values ($1)', [moderator]);

  await asUser(null);
  assert.deepEqual(await rows('select * from public.verify_member_card($1)', [member]), [
    { first_name: 'Moradora', city, email_confirmed: false },
  ]);
  await db.exec('reset role');
  await db.query('update auth.users set email_confirmed_at = now() where id = $1', [member]);
  await asUser(null);
  assert.deepEqual(await rows('select * from public.verify_member_card($1)', [member]), [
    { first_name: 'Moradora', city, email_confirmed: true },
  ]);
  console.log('OK: criação de perfil por trigger e confirmação refletida no QR público.');

  await asUser(member);
  const photo = `${member}/foto.jpg`;
  const video = `${member}/video.mp4`;
  await upload('feed-media', photo, 'image/jpeg');
  await upload('feed-media', video, 'video/mp4');
  await assert.rejects(upload('feed-media', `${moderator}/forjada.jpg`, 'image/jpeg'), { code: '42501' });
  for (const [path, kind, anonymous] of [[photo, 'image', false], [video, 'video', true]]) {
    await db.query(`insert into public.community_posts(author_id, category, city, body, is_anonymous, media_path, media_kind)
      values ($1, 'Dica ou informação', $2, 'Publicação de homologação em memória.', $3, $4, $5)`,
    [member, city, anonymous, path, kind]);
  }
  const pending = await rows('select * from public.list_public_community_posts()');
  assert.equal(pending.length, 2);
  assert.ok(pending.every(post => post.status === 'pending'));
  const identified = pending.find(post => !post.is_anonymous).id;
  const feedIds = pending.map(post => post.id);
  const avatar = `${member}/carteirinha.jpg`;
  const feedAuthors = () => rows('select * from public.social_feed_authors($1::uuid[])', [feedIds]);
  await upload('member-avatars', avatar, 'image/jpeg');
  await db.query('update public.profiles set avatar_path = $1 where id = $2', [avatar, member]);
  assert.deepEqual(await feedAuthors(), [{ post_id: identified, first_name: 'Moradora', avatar_path: null }]);
  await assert.rejects(rows('select * from public.list_pending_community_posts()'), { code: '42501' });
  await assert.rejects(rows("select public.moderate_community_post($1, 'approved')", [pending[0].id]), { code: '42501' });
  await asUser(null);
  assert.deepEqual(await feedAuthors(), []);
  assert.deepEqual(await rows('select * from public.list_public_community_posts()'), []);
  assert.equal(await canReadMedia('feed-media', photo), false);
  assert.equal(await value('select public.social_public_post($1)', [pending[0].id]), null);

  await asUser(moderator);
  const queue = await rows('select * from public.list_pending_community_posts()');
  assert.deepEqual(new Set(queue.map(post => post.id)), new Set(pending.map(post => post.id)));
  assert.equal(await canReadMedia('feed-media', photo), true);
  assert.equal(await canReadMedia('feed-media', video), true);
  for (const post of queue) await rows("select public.moderate_community_post($1, 'approved')", [post.id]);
  assert.deepEqual(await rows('select * from public.list_pending_community_posts()'), []);

  await asUser(null);
  const approved = await rows('select * from public.list_public_community_posts()');
  assert.equal(approved.length, 2);
  const anonymous = approved.find(post => post.is_anonymous);
  assert.equal(anonymous.author_id, null);
  assert.equal(anonymous.media_path, null);
  assert.equal(anonymous.media_kind, 'video');
  const shared = await value('select public.social_public_post($1)', [anonymous.id]);
  assert.equal(shared.author_id, null);
  assert.equal(shared.media_path, null);
  assert.equal(await canReadMedia('feed-media', video), false);
  assert.equal(await canReadMedia('feed-media', photo), true);
  console.log('OK: envio, fila, aprovação e link público do Feed com isolamento do anexo anônimo.');

  assert.deepEqual(await feedAuthors(), [{ post_id: identified, first_name: 'Moradora', avatar_path: null }]);
  assert.equal(await canReadMedia('member-avatars', avatar), false);
  await asUser(member);
  await db.query('update public.profiles set avatar_public = true where id = $1', [member]);
  await asUser(null);
  assert.deepEqual(await feedAuthors(), [{ post_id: identified, first_name: 'Moradora', avatar_path: avatar }]);
  assert.equal(await canReadMedia('member-avatars', avatar), true);
  await asUser(member);
  await db.query('update public.profiles set avatar_public = false where id = $1', [member]);
  await asUser(null);
  assert.deepEqual(await feedAuthors(), [{ post_id: identified, first_name: 'Moradora', avatar_path: null }]);
  assert.equal(await canReadMedia('member-avatars', avatar), false);
  console.log('OK: nome do autor identificado, foto por consentimento e ausência de identidade em posts anônimos.');

  await asUser(member);
  await upload('social-stories', video, 'video/mp4');
  const story = await value("select public.social_create_story('Story local', $1, $2, 'video')", [city, video]);
  await asUser(moderator);
  assert.deepEqual(await value('select public.social_list_stories()'), []);
  assert.equal((await value('select public.social_story_queue()'))[0].id, story);
  await rows("select public.social_review_story($1, 'approved', 'Revisão local')", [story]);
  assert.equal((await value('select public.social_list_stories()'))[0].id, story);
  assert.equal(await canReadMedia('social-stories', video), true);
  await rows('select public.social_see_story($1)', [story]);
  await rows('select public.social_see_story($1)', [story]);
  await asUser(member);
  assert.equal((await value('select public.social_list_stories()'))[0].views, 1);
  await db.exec('reset role');
  await db.query("update public.social_stories set expires_at = now() - interval '1 second' where id = $1", [story]);
  await asUser(null);
  assert.deepEqual(await value('select public.social_list_stories()'), []);
  assert.equal(await canReadMedia('social-stories', video), false);
  console.log('OK: story aprovado, mídia liberada, visualização única e expiração.');

  await asUser(member);
  await db.query(`insert into public.service_requests(author_id, service_type, city, contact, description)
    values ($1, 'Orientação jurídica', $2, 'teste@example.invalid', 'Pedido privado de homologação em memória.')`, [member, city]);
  const submissions = await rows('select * from public.social_my_submissions()');
  const request = submissions.find(item => item.submission_type === 'servico');
  assert.equal(request.status, 'received');
  assert.equal(submissions.find(item => item.submission_id === story).status, 'expired');
  assert.equal('contact' in request, false);
  await asUser(moderator);
  assert.deepEqual(await rows('select * from public.service_requests'), []);
  assert.deepEqual(await rows('select * from public.social_my_submissions()'), []);
  const serviceQueue = await rows('select * from public.list_service_requests_for_moderation()');
  assert.equal(serviceQueue[0].request_id, request.submission_id);
  await rows("select public.moderate_service_request($1, 'completed')", [request.submission_id]);
  await asUser(member);
  assert.equal((await rows('select * from public.social_my_submissions()')).find(item => item.submission_id === request.submission_id).status, 'completed');
  await asUser(null);
  await assert.rejects(rows('select * from public.service_requests'), { code: '42501' });
  console.log('OK: pedido privado, acompanhamento em Meus envios e conclusão pela equipe.');

  await asUser(member);
  const contact = 'teste@example.invalid';
  const listingSql = `insert into public.marketplace_listings(owner_id, title, category, city, description, contact, contact_consent_at)
    values ($1, 'Bicicleta de teste', 'Outros', $2, 'Descrição do anúncio de homologação.', $3, $4) returning id`;
  await assert.rejects(rows(listingSql, [member, city, contact, null]), { code: '42501' });
  const listing = await value(listingSql, [member, city, contact, new Date().toISOString()]);
  const animal = await value(`insert into public.animal_reports(owner_id, report_type, species, city, description, contact, contact_consent_at)
    values ($1, 'perdido', 'Cão', $2, 'Descrição do aviso de homologação.', $3, now()) returning id`, [member, city, contact]);
  const reportPhoto = `${member}/relato.jpg`;
  await upload('submission-media', reportPhoto, 'image/jpeg');
  const report = await value(`insert into public.city_reports(author_id, category, city, description, media_path)
    values ($1, 'Outro', $2, 'Descrição do relato de homologação.', $3) returning id`, [member, city, reportPhoto]);
  await assert.rejects(rows('select * from public.list_city_reports_for_moderation()'), { code: '42501' });
  assert.equal(await value('select public.get_listing_contact($1)', [listing]), null);
  assert.equal(await value('select public.get_animal_contact($1)', [animal]), null);
  assert.equal(await value('select count(*) from public.points_ledger'), 0);
  await asUser(null);
  assert.deepEqual(await rows('select id from public.marketplace_listings'), []);
  assert.deepEqual(await rows('select id from public.animal_reports'), []);
  assert.deepEqual(await rows('select id from public.city_reports'), []);
  assert.equal(await canReadMedia('submission-media', reportPhoto), false);
  await assert.rejects(rows('select * from public.list_city_reports_for_moderation()'), { code: '42501' });

  await asUser(moderator);
  assert.equal((await rows('select * from public.list_pending_marketplace_listings()'))[0].id, listing);
  assert.equal((await rows('select * from public.list_pending_animal_reports()'))[0].id, animal);
  const [cityReport] = await rows('select * from public.list_city_reports_for_moderation()');
  assert.equal(cityReport.id, report);
  assert.equal(cityReport.media_path, reportPhoto);
  assert.equal(await canReadMedia('submission-media', reportPhoto), true);
  await rows("select public.moderate_marketplace_listing($1, 'active')", [listing]);
  await rows("select public.moderate_animal_report($1, 'active')", [animal]);
  await assert.rejects(rows("select public.moderate_city_report($1, 'resolved')", [report]), { code: 'P0002' });
  for (const status of ['review', 'in_progress', 'resolved']) {
    await rows('select public.moderate_city_report($1, $2)', [report, status]);
  }
  assert.equal(await value('select public.get_listing_contact($1)', [listing]), contact);
  assert.equal(await value('select public.get_animal_contact($1)', [animal]), contact);
  await asUser(null);
  assert.equal(await value('select status from public.marketplace_listings where id = $1', [listing]), 'active');
  assert.equal(await value('select status from public.animal_reports where id = $1', [animal]), 'active');
  assert.equal(await value('select status from public.city_reports where id = $1', [report]), 'resolved');
  await assert.rejects(rows('select contact from public.marketplace_listings'), { code: '42501' });
  await assert.rejects(rows('select contact from public.animal_reports'), { code: '42501' });
  await assert.rejects(rows('select public.get_listing_contact($1)', [listing]), { code: '42501' });
  await assert.rejects(rows('select public.get_animal_contact($1)', [animal]), { code: '42501' });
  console.log('OK: Mercadão e animais com consentimento e contato protegido; relato segue as etapas da equipe.');

  await asUser(member);
  const house = await value(`select public.social_create_classified(
    'imoveis', 'Casa de homologação', 'Descrição do imóvel de teste em memória.', $1, 'Centro', 350000,
    '{"operation":"Venda","type":"Casa","area":120,"bedrooms":3,"bathrooms":2,"parking":1,"condo":0}',
    $2, null, true
  )`, [city, contact]);
  assert.equal((await value("select public.social_list_classifieds('imoveis', 0, true)"))[0].status, 'pending');
  assert.deepEqual(await value("select public.social_list_classifieds('imoveis', 0, false)"), []);
  await assert.rejects(rows('select public.social_classified_queue()'), { code: '42501' });
  await assert.rejects(rows("select public.social_review_classified($1, 'approved', 'Decisão de teste')", [house]), { code: '42501' });
  await asUser(moderator);
  const [pendingHouse] = await value('select public.social_classified_queue()');
  assert.equal(pendingHouse.id, house);
  assert.equal(pendingHouse.details.operation, 'Venda');
  assert.equal('contact' in pendingHouse, false);
  await rows("select public.social_review_classified($1, 'approved', 'Revisão do imóvel de teste')", [house]);
  assert.deepEqual(await value('select public.social_classified_queue()'), []);
  await asUser(null);
  const [publishedHouse] = await value("select public.social_list_classifieds('imoveis', 0, false)");
  assert.equal(publishedHouse.id, house);
  assert.equal(publishedHouse.status, 'approved');
  assert.equal('contact' in publishedHouse, false);
  console.log('OK: casa à venda passa de Meus envios para a fila da equipe e aparece em Imóveis após aprovação.');

  await asUser(member);
  const createPoll = (question) => value("select public.social_create_poll($1, $2, array['Sim','Não'], now()+interval '2 days')", [question, city]);
  const olderPoll = await createPoll('Você participaria de uma feira?');
  const newerPoll = await createPoll('Você conhece os parques do ABC?');
  await createPoll('Uma pergunta ainda em moderação?');
  await asUser(moderator);
  for (const id of [olderPoll, newerPoll]) {
    await rows("select public.social_review_hub('poll', $1, 'approved', 'Aprovação em homologação')", [id]);
  }
  await db.exec('reset role');
  await db.query("update public.social_polls set created_at = now()-interval '1 minute' where id = $1", [olderPoll]);
  await db.query(`insert into public.social_polls(author_id, question, city, closes_at, status)
    values ($1, 'Enquete que já encerrou', $2, now()-interval '1 minute', 'approved')`, [member, city]);

  const nextPoll = () => value('select public.social_next_home_poll()');
  await asUser(null);
  assert.equal((await nextPoll()).id, newerPoll);
  await asUser(member);
  for (const id of [newerPoll, olderPoll]) {
    const poll = await nextPoll();
    assert.equal(poll.id, id);
    assert.deepEqual(poll.options.map(option => option.label), ['Sim', 'Não']);
    await rows('select public.social_vote_poll($1, $2)', [id, poll.options[0].id]);
  }
  assert.equal(await nextPoll(), null);
  await asUser(moderator);
  assert.equal((await nextPoll()).id, newerPoll);
  console.log('OK: a página inicial avança após cada voto e a fila é independente por conta.');

  await asUser(member);
  assert.equal(await value('select count(*) from public.points_ledger'), 0);
  assert.equal(await value('select public.claim_daily_checkin()'), 5);
  assert.equal(await value('select public.claim_daily_checkin()'), 0);
  await asUser(moderator);
  const firstReaction = (await rows('select * from public.toggle_community_post_reaction($1)', [anonymous.id]))[0];
  assert.equal(firstReaction.points_awarded, 3);
  assert.equal(firstReaction.author_points_awarded, 0);
  await rows('select * from public.toggle_community_post_reaction($1)', [anonymous.id]);
  const repeatedReaction = (await rows('select * from public.toggle_community_post_reaction($1)', [anonymous.id]))[0];
  assert.equal(repeatedReaction.points_awarded, 0);
  await asUser(null);
  const ranking = await rows('select * from public.get_public_leaderboard()');
  assert.deepEqual(ranking.map(item => [item.first_name, item.points]), [['Moradora', 5], ['Equipe', 3]]);
  assert.deepEqual(Object.keys(ranking[0]).sort(), ['city', 'first_name', 'points', 'rank_position']);
  console.log('OK: check-in e reação sem XP duplicado, com total refletido no ranking público.');

  const invited = '00000000-0000-4000-8000-000000000013';
  const duplicate = '00000000-0000-4000-8000-000000000014';
  const testCpf = '12345678909'; // Synthetic checksum fixture for the in-memory database.
  await asUser(member);
  const referralCode = await value('select referral_code from public.profiles where id = $1', [member]);
  await db.exec('reset role');
  for (const id of [invited, duplicate]) {
    await db.query('insert into auth.users(id, raw_user_meta_data) values ($1, $2)',
      [id, JSON.stringify({ display_name: 'Convite Teste', city, referral_code: referralCode })]);
  }
  await asUser(member);
  await assert.rejects(rows('select public.verify_referral_cpf($1, $2)', [invited, testCpf]), { code: '42501' });
  await asUser(moderator);
  assert.deepEqual(await rows('select * from public.list_referrals_pending_cpf()'), []);
  assert.equal(await value('select public.verify_referral_cpf($1, $2)', [invited, testCpf]), false);
  await db.exec('reset role');
  await db.query('update auth.users set email_confirmed_at = now() where id in ($1, $2)', [invited, duplicate]);
  await asUser(member);
  assert.equal(await value("select count(*) from public.points_ledger where event_type = 'verified_referral'"), 0);
  await asUser(moderator);
  assert.equal(await value('select public.verify_referral_cpf($1, $2)', [invited, testCpf]), true);
  assert.equal(await value('select public.verify_referral_cpf($1, $2)', [invited, testCpf]), false);
  await assert.rejects(rows('select public.verify_referral_cpf($1, $2)', [duplicate, testCpf]), { code: '23505' });
  await asUser(member);
  assert.deepEqual(await rows("select points, evidence_id from public.points_ledger where event_type = 'verified_referral'"), [
    { points: 10, evidence_id: invited },
  ]);
  console.log('OK: indicação só pontua após confirmação e revisão, com CPF único.');
} catch (error) {
  console.error(error.message);
  if (error.query) console.error(error.query);
  process.exitCode = 1;
} finally {
  await db.close();
}
