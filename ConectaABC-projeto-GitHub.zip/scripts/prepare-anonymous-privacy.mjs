import fs from 'node:fs/promises';
const root=new URL('../',import.meta.url);
const read=p=>fs.readFile(new URL(p,root),'utf8');
const original=await read('supabase/migrations/202611030013_feed_media_anonymous.sql');
const list=original.slice(original.indexOf('create or replace function public.list_public_community_posts()'),original.indexOf('drop function if exists public.list_pending_community_posts()'))
 .replace('p.is_anonymous, p.media_path, p.media_kind','p.is_anonymous, case when p.is_anonymous and p.status=\'approved\' then null else p.media_path end, p.media_kind');
const rewards=(await read('supabase/migrations/202611030018_feed_like_received_points.sql'));
let reward=rewards.slice(rewards.indexOf('create function public.toggle_community_post_reaction'),rewards.indexOf('revoke all on function public.toggle_community_post_reaction'))
 .replace('on conflict (post_id, supporter_id) do nothing','on conflict on constraint feed_reaction_point_awards_post_id_supporter_id_key do nothing').replace('create function','create or replace function').replace('  post_author_id uuid;','  post_author_id uuid;\n  anonymous_post boolean;')
 .replace('select p.author_id into post_author_id','select p.author_id,p.is_anonymous into post_author_id,anonymous_post')
 .replace('        insert into public.points_ledger (user_id, event_type, points, evidence_id)\n        values (post_author_id', '        if not anonymous_post then\n        insert into public.points_ledger (user_id, event_type, points, evidence_id)\n        values (post_author_id')
 .replace('if author_ledger_rows = 1 then granted_author_points := 1; end if;','if author_ledger_rows = 1 then granted_author_points := 1; end if;\n        end if;');
const deep=(await read('supabase/migrations/202611060017_feed_filters_and_deep_links.sql'));
const single=deep.slice(deep.indexOf('create function public.social_public_post'),deep.indexOf('create function public.social_get_classified'))
 .replace('create function','create or replace function').replace("'media_path',p.media_path","'media_path',case when p.is_anonymous then null else p.media_path end");
const helper=(await read('supabase/migrations/202611030014_feed_media_access_helper.sql')).replace(/^begin;|^commit;/gm,'').replace("p.status = 'approved' or p.author_id", "(p.status = 'approved' and not p.is_anonymous) or p.author_id");
await fs.writeFile(new URL('supabase/migrations/202611060025_anonymous_media_privacy.sql',root),`-- Preserve saldos antigos. Novos apoios anônimos não revelam autor por variação no ranking.\nbegin;\n${list}\n${single}\n${helper}\n${reward}\ncommit;\n`);


