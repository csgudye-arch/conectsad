import { PGlite } from '../tmp/social-db-test/node_modules/@electric-sql/pglite/dist/index.js';
import { readFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const db = new PGlite();
const ids = { a:'00000000-0000-4000-8000-000000000001', b:'00000000-0000-4000-8000-000000000002', c:'00000000-0000-4000-8000-000000000003', mod:'00000000-0000-4000-8000-000000000004', post:'00000000-0000-4000-8000-000000000005', hidden:'00000000-0000-4000-8000-000000000006' };
let count=0;
async function actor(id, role='authenticated') { await db.exec(`reset role; set role ${role}; select set_config('test.uid','${id || ''}',false);`); }
async function query(sql, args=[]) { return (await db.query(sql,args)).rows; }
async function deny(sql,args,code) { try { await db.query(sql,args); assert.fail('Operação deveria ser negada'); } catch (err) { assert.equal(err.code,code,sql+" -> "+err.message); } count++; }
function check(actual,expected) { assert.deepEqual(actual,expected); count++; }
try {
await db.exec(`create role anon; create role authenticated; create schema auth;
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('test.uid',true),'')::uuid $$;
grant usage on schema auth to anon,authenticated; grant execute on function auth.uid() to anon,authenticated;
create table auth.users(id uuid primary key);
create table public.profiles(id uuid primary key references auth.users(id),display_name text,city text);
create table public.community_posts(id uuid primary key,author_id uuid references public.profiles(id),body text,title text,city text,status text);
create table public.community_moderators(user_id uuid primary key references auth.users(id));
insert into auth.users values ('${ids.a}'),('${ids.b}'),('${ids.c}'),('${ids.mod}');
insert into public.profiles values ('${ids.a}','Ana Privado','Santo André'),('${ids.b}','Bruno Privado','Mauá'),('${ids.c}','Carla Privado','Diadema'),('${ids.mod}','Moderador Privado','Santo André');
insert into public.community_moderators values ('${ids.mod}');
insert into public.community_posts values ('${ids.post}','${ids.a}','Conteúdo aprovado','Título','Santo André','approved'),('${ids.hidden}','${ids.a}','Conteúdo pendente','Título privado','Santo André','pending');`);
await db.exec(await readFile(new URL('../supabase/migrations/202611060001_social_interactions.sql',import.meta.url),'utf8'));
await actor(null,'anon');
await deny('select public.social_add_comment($1,$2)',[ids.post,'Teste local'],'42501');
check(await query('select * from public.social_list_comments($1)',[ids.post]),[]);
await actor(ids.b);
await deny('insert into public.social_notifications(user_id,kind,message) values($1,$2,$3)',[ids.a,'comment','forjada'],'42501');
await deny('select public.social_set_bookmark($1,true)',[ids.hidden],'P0002');
const comment=(await query('select public.social_add_comment($1,$2) as id',[ids.post,'Comentário local para testar moderação.']))[0].id;
check((await query('select * from public.social_list_comments($1)',[ids.post]))[0].status,'pending');
await actor(ids.c);check(await query('select * from public.social_list_comments($1)',[ids.post]),[]);
await deny('select public.social_review_comment($1,$2,$3)',[comment,'approved','Revisado localmente'],'42501');
await actor(ids.mod);await query('select public.social_review_comment($1,$2,$3)',[comment,'approved','Conteúdo adequado.']);
await query('select public.social_review_comment($1,$2,$3)',[comment,'approved','Repetição segura.']);
await actor(null,'anon');const comments=await query('select * from public.social_list_comments($1)',[ids.post]);check(comments.length,1);check(comments[0].first_name,'Bruno');check('author_id' in comments[0],false);
await actor(ids.a);let notices=await query('select * from public.social_my_notifications()');check(notices.length,1);const notice=notices[0].id;
await actor(ids.c);check(await query('select * from public.social_my_notifications()'),[]);await query('select public.social_read_notification($1)',[notice]);
await actor(ids.a);check((await query('select * from public.social_my_notifications()'))[0].read_at,null);
await query('select public.social_read_notification($1)',[notice]);check(Boolean((await query('select * from public.social_my_notifications()'))[0].read_at),true);
await actor(ids.b);await query('select public.social_set_bookmark($1,true)',[ids.post]);await query('select public.social_set_bookmark($1,true)',[ids.post]);check((await query('select * from public.social_saved_posts()')).length,1);
await actor(ids.c);check(await query('select * from public.social_saved_posts()'),[]);await deny('select * from public.social_bookmarks',[],'42501');
await actor(ids.b);await query('select public.social_request_friend($1)',[ids.a]);await query('select public.social_request_friend($1)',[ids.a]);let friends=await query('select * from public.social_my_friends()');check(friends.length,1);const friendship=friends[0].request_id;
await deny('select public.social_respond_friend($1,true)',[friendship],'42501');await deny('select public.social_request_friend($1)',[ids.b],'22023');
await actor(ids.c);check(await query('select * from public.social_my_friends()'),[]);await deny('select public.social_respond_friend($1,true)',[friendship],'42501');
await actor(ids.a);await query('select public.social_respond_friend($1,true)',[friendship]);check((await query('select * from public.social_my_friends()'))[0].status,'accepted');
await actor(ids.b);check((await query('select * from public.social_my_notifications()')).filter(n=>n.kind==='friend_accepted').length,1);
const members=await query('select * from public.social_search_members($1)',['Ana']);check(members[0].first_name,'Ana');check(Object.keys(members[0]).sort(),['city','first_name','member_id']);
for(let i=0;i<4;i++) await query('select public.social_add_comment($1,$2)',[ids.post,`Comentário de teste ${i}`]);
await deny('select public.social_add_comment($1,$2)',[ids.post,'Limite excedido'],'P0001');
await db.exec(`reset role; update public.community_posts set status='hidden' where id='${ids.post}';`);
await actor(ids.b);check(await query('select * from public.social_saved_posts()'),[]);check(await query('select * from public.social_list_comments($1)',[ids.post]),[]);
await query('select public.social_set_bookmark($1,false)',[ids.post]);
await db.exec(`reset role; create table public.points_ledger(user_id uuid references public.profiles(id),points integer); insert into public.points_ledger values ('${ids.a}',1500);`);
await db.exec(await readFile(new URL('../supabase/migrations/202611060002_polls_and_groups.sql',import.meta.url),'utf8'));
await actor(null,'anon');
await deny('select public.social_create_poll($1,$2,$3,now()+interval \'2 days\')',['Pergunta válida de teste','Santo André',['Sim','Não']],'42501');
await actor(ids.a);
await deny('select public.social_create_poll($1,$2,$3,now()+interval \'2 days\')',['Pergunta válida de teste','Santo André',['Sim',' sim ']],'22023');
const poll=(await query('select public.social_create_poll($1,$2,$3,now()+interval \'2 days\') id',['Qual iniciativa local você prefere?','Santo André',['Cultura','Esporte']]))[0].id;
await actor(ids.b);check((await query('select public.social_list_polls() data'))[0].data,[]);
await deny('select public.social_review_hub($1,$2,$3,$4)',['poll',poll,'approved','Aprovação indevida'],'42501');
await actor(ids.mod);await query('select public.social_review_hub($1,$2,$3,$4)',['poll',poll,'approved','Conteúdo adequado']);
await actor(ids.b);let pollRow=(await query('select public.social_list_polls() data'))[0].data[0];
await query('select public.social_vote_poll($1,$2)',[poll,pollRow.options[0].id]);await query('select public.social_vote_poll($1,$2)',[poll,pollRow.options[1].id]);
pollRow=(await query('select public.social_list_polls() data'))[0].data[0];check(pollRow.my_vote,pollRow.options[0].id);check(pollRow.options.reduce((n,o)=>n+o.votes,0),1);
await deny('select * from public.social_poll_votes',[],'42501');
await actor(ids.c);await deny('select public.social_vote_poll($1,$2)',[poll,ids.hidden],'22023');
await db.exec(`reset role;update public.social_polls set closes_at=now()-interval '1 minute' where id='${poll}';`);
await actor(ids.c);await deny('select public.social_vote_poll($1,$2)',[poll,pollRow.options[0].id],'P0002');
await deny('select public.social_create_group($1,$2,$3,$4)',['Grupo de teste','Descrição suficientemente longa para teste.','Bairro','Santo André'],'P0001');
await actor(ids.a);const group=(await query('select public.social_create_group($1,$2,$3,$4) id',['Grupo de teste','Descrição suficientemente longa para teste.','Bairro','Santo André']))[0].id;
await actor(ids.b);check((await query('select public.social_list_groups() data'))[0].data.groups,[]);await deny('select public.social_join_group($1,true)',[group],'P0002');
await actor(ids.mod);await query('select public.social_review_hub($1,$2,$3,$4)',['group',group,'approved','Comunidade adequada']);
await actor(ids.b);await deny('select public.social_add_group_post($1,$2)',[group,'Post de membro não participante.'],'42501');
await query('select public.social_join_group($1,true)',[group]);await query('select public.social_join_group($1,true)',[group]);check((await query('select public.social_list_groups() data'))[0].data.groups[0].members,2);
const groupPost=(await query('select public.social_add_group_post($1,$2) id',[group,'Post da comunidade para testar revisão.']))[0].id;
await actor(ids.c);check(await query('select * from public.social_group_feed($1)',[group]),[]);
await actor(ids.mod);await query('select public.social_review_hub($1,$2,$3,$4)',['group_post',groupPost,'approved','Publicação adequada']);
await actor(null,'anon');check((await query('select * from public.social_group_feed($1)',[group])).length,1);
for(const person of [ids.a,ids.b,ids.c]){await actor(person);await query('select public.social_report_hub($1,$2,$3)',['group_post',groupPost,'Denúncia de teste local']);}
await actor(null,'anon');check(await query('select * from public.social_group_feed($1)',[group]),[]);
await actor(ids.mod);check((await query('select * from public.social_hub_queue()')).some(row=>row.id===groupPost&&row.status==='hidden'&&row.body.includes('Denúncia de teste local')),true);
await query('select public.social_review_hub($1,$2,$3,$4)',['group_post',groupPost,'approved','Revisão concluída']);
await actor(ids.a);await query('select public.social_report_hub($1,$2,$3)',['group_post',groupPost,'Repetir denúncia encerrada']);
await actor(null,'anon');check((await query('select * from public.social_group_feed($1)',[group])).length,1);
await actor(ids.b);await query('select public.social_join_group($1,false)',[group]);await deny('select public.social_add_group_post($1,$2)',[group,'Post após sair da comunidade.'],'42501');


await db.exec('reset role;');
await db.exec(await readFile(new URL('../supabase/migrations/202611060003_community_events.sql',import.meta.url),'utf8'));
await actor(null,'anon');
await deny("select public.social_create_event($1,$2,$3,$4,now()+interval '2 days',now()+interval '2 days 2 hours')",['Evento local','Descrição de evento para verificação local.','Santo André','Parque de teste'],'42501');
await actor(ids.a);
await deny("select public.social_create_event($1,$2,$3,$4,now()-interval '2 days',now()+interval '2 days')",['Evento local','Descrição de evento para verificação local.','Santo André','Parque de teste'],'22023');
const event=(await query("select public.social_create_event($1,$2,$3,$4,now()+interval '2 days',now()+interval '2 days 2 hours') id",['Evento local','Descrição de evento para verificação local.','Santo André','Parque de teste']))[0].id;
await actor(ids.b);check((await query('select public.social_list_events($1) data',[event]))[0].data,[]);
await deny('select public.social_attend_event($1,true)',[event],'P0002');
await deny('select * from public.social_event_queue()',[],'42501');
await deny('select public.social_review_event($1,$2,$3)',[event,'approved','Aprovação indevida'],'42501');
await deny('select public.social_review_event($1,$2,$3)',[event,'cancelled','Cancelamento indevido'],'42501');
await actor(ids.mod);await query('select public.social_review_event($1,$2,$3)',[event,'approved','Conteúdo adequado']);
await actor(ids.b);await query('select public.social_attend_event($1,true)',[event]);await query('select public.social_attend_event($1,true)',[event]);
let eventRow=(await query('select public.social_list_events($1) data',[event]))[0].data[0];check(eventRow.attendees,1);check(eventRow.attending,true);check('owner_id' in eventRow,false);
await deny('select * from public.social_event_attendance',[],'42501');
await actor(ids.c);eventRow=(await query('select public.social_list_events($1) data',[event]))[0].data[0];check(eventRow.attending,false);
await actor(ids.a);await query('select public.social_review_event($1,$2,$3)',[event,'cancelled','Organização cancelou o encontro']);
await actor(ids.c);await deny('select public.social_attend_event($1,true)',[event],'P0002');
await actor(ids.mod);await deny('select public.social_review_event($1,$2,$3)',[event,'approved','Tentativa de reabertura'],'P0001');
await actor(ids.b);await query('select public.social_attend_event($1,false)',[event]);check((await query('select public.social_list_events($1) data',[event]))[0].data[0].attendees,0);
await actor(ids.a);const draft=(await query("select public.social_create_event($1,$2,$3,$4,now()+interval '2 days',now()+interval '2 days 2 hours') id",['Outro evento','Descrição de evento para verificação local.','Santo André','Parque de teste']))[0].id;
await query('select public.social_review_event($1,$2,$3)',[draft,'cancelled','Retirando rascunho']);
await actor(null,'anon');check((await query('select public.social_list_events($1) data',[draft]))[0].data,[]);


await db.exec(`reset role;
create schema storage; grant usage on schema storage to anon,authenticated;
create table storage.objects(bucket_id text,name text,metadata jsonb); alter table storage.objects enable row level security;
create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
create function storage.foldername(text) returns text[] language sql as $$select string_to_array($1,'/')$$;
alter table public.profiles add column avatar_public boolean default false,add column avatar_path text;
alter table public.community_posts add column created_at timestamptz default now(),add column is_anonymous boolean default false,add column is_official boolean default false,add column media_path text,add column media_kind text;
alter table public.points_ledger add column created_at timestamptz default now();
create function public.create_official_post(text,text,text,text,text,boolean) returns uuid language plpgsql as $$declare result uuid:=gen_random_uuid();begin insert into public.community_posts(id,author_id,title,city,body,status,is_official) values(result,auth.uid(),$1,$3,$4,'approved',true);return result;end;$$;
`);
await db.exec(await readFile(new URL('../supabase/migrations/202611060004_profiles_levels_official.sql',import.meta.url),'utf8'));
await actor(null,'anon');check((await query('select * from public.social_get_levels()')).length,10);
await deny('select public.social_my_details()',[],'42501');
await actor(ids.a);
await query('select public.social_save_details($1,$2,$3,$4,$5,$6)',['ana_local','Minha bio','Centro',null,false,false]);
await actor(null,'anon');check((await query('select public.social_public_profile($1) data',['ana_local']))[0].data,null);
await actor(ids.a);await query('select public.social_save_details($1,$2,$3,$4,$5,$6)',['ana_local','Minha bio','Centro',null,true,true]);
await query('select public.social_touch_presence()');
await actor(null,'anon');let publicMember=(await query('select public.social_public_profile($1) data',['ana_local']))[0].data;check(publicMember.first_name,'Ana');check(publicMember.recently_active,true);check('display_name' in publicMember,false);
await actor(ids.b);await deny('select public.social_save_details($1,$2,$3,$4,$5,$6)',['ana_local','','',null,true,false],'22023');
await deny('select public.social_save_details($1,$2,$3,$4,$5,$6)',['bruno_local','','',ids.a+'/cover.jpg',true,false],'22023');
check((await query('select public.social_my_progress() data'))[0].data.points,0);
await deny('select public.social_set_levels($1)',['[]'],'42501');
await deny('select public.social_publish_official($1,$2,$3,$4,$5,$6,$7,$8)',['Título oficial','Informação pública','Santo André','Texto para comunicado oficial de teste local.','Fonte oficial',false,null,null],'42501');
await actor(ids.mod);await deny('select public.social_publish_official($1,$2,$3,$4,$5,$6,$7,$8)',['Título oficial','Informação pública','Santo André','Texto para comunicado oficial de teste local.','Fonte oficial',false,ids.a+'/video.mp4','video'],'22023');
await db.exec(`reset role;update public.community_posts set is_anonymous=true where id='${ids.post}';`);
await actor(null,'anon');check((await query('select public.social_member_posts($1,0) data',['ana_local']))[0].data,[]);
await actor(ids.a);check((await query('select public.social_my_progress() data'))[0].data.points,1500);


await db.exec('reset role');
await db.exec(await readFile(new URL('../supabase/migrations/202611060005_business_directory.sql',import.meta.url),'utf8'));
const businessArgs=[null,'Negócio de teste','Tecnologia','Santo André','Descrição comercial somente para teste em memória.','Endereço comercial','Segunda a sexta','5511999999999','negocio_teste',true];
await actor(null,'anon');await deny('select public.social_save_business($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',businessArgs,'42501');
await actor(ids.a);await deny('select public.social_save_business($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[...businessArgs.slice(0,9),false],'22023');
const business=(await query('select public.social_save_business($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) id',businessArgs))[0].id;
await actor(null,'anon');check((await query('select public.social_list_businesses($1,0) data',[business]))[0].data,[]);
await actor(ids.b);await deny('select public.social_save_business($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[business,...businessArgs.slice(1)],'42501');await deny('select public.social_business_queue()',[],'42501');await deny('select public.social_review_business($1,$2,$3)',[business,'approved','Aprovação indevida'],'42501');await deny('select public.social_follow_business($1,true)',[business],'P0002');
await actor(ids.mod);await query('select public.social_review_business($1,$2,$3)',[business,'approved','Cadastro conferido']);
await actor(ids.a);await deny('select public.social_follow_business($1,true)',[business],'P0002');
await actor(ids.b);await query('select public.social_follow_business($1,true)',[business]);await query('select public.social_follow_business($1,true)',[business]);let biz=(await query('select public.social_list_businesses($1,0) data',[business]))[0].data[0];check(biz.followers,1);check(biz.following,true);check('owner_id' in biz,false);await deny('select * from public.social_business_followers',[],'42501');
await actor(ids.c);check((await query('select public.social_my_businesses() data'))[0].data,[]);
await actor(ids.a);await query('select public.social_save_business($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[business,...businessArgs.slice(1)]);
await actor(null,'anon');check((await query('select public.social_list_businesses($1,0) data',[business]))[0].data,[]);
await actor(ids.b);await query('select public.social_follow_business($1,false)',[business]);

await actor(ids.mod);await deny('select public.social_set_levels($1)',[null],'22023');check((await query('select * from public.social_get_levels()')).length,10);

await db.exec(`reset role;insert into storage.objects values ('social-stories','${ids.a}/story.jpg','{"mimetype":"image/jpeg"}'),('social-stories','${ids.a}/wrong.mp4','{"mimetype":"video/mp4"}');`);
await db.exec(await readFile(new URL('../supabase/migrations/202611060007_stories.sql',import.meta.url),'utf8'));
await actor(null,'anon');await deny('select public.social_create_story($1,$2,$3,$4)',['Story local','Santo André',ids.a+'/story.jpg','image'],'42501');
await actor(ids.b);await deny('select public.social_create_story($1,$2,$3,$4)',['Story local','Santo André',ids.a+'/story.jpg','image'],'22023');
await actor(ids.a);await deny('select public.social_create_story($1,$2,$3,$4)',['Story local','Santo André',ids.a+'/wrong.mp4','image'],'22023');
const story=(await query('select public.social_create_story($1,$2,$3,$4) id',['Story local','Santo André',ids.a+'/story.jpg','image']))[0].id;
await actor(ids.b);check((await query('select public.social_list_stories(null) data'))[0].data,[]);check((await query('select public.social_story_media_readable($1) readable',[ids.a+'/story.jpg']))[0].readable,false);await deny('select public.social_review_story($1,$2,$3)',[story,'approved','Indevido'],'42501');
await actor(ids.mod);await query('select public.social_review_story($1,$2,$3)',[story,'approved','Conteúdo adequado']);
await actor(ids.b);await query('select public.social_see_story($1)',[story]);await query('select public.social_see_story($1)',[story]);let sr=(await query('select public.social_list_stories(null) data'))[0].data[0];check(sr.views,null);check(sr.seen,true);await deny('select * from public.social_story_views',[],'42501');
await actor(ids.a);check((await query('select public.social_list_stories(null) data'))[0].data[0].views,1);
await db.exec(`reset role;update public.social_stories set expires_at=now()-interval '1 second' where id='${story}';`);
await actor(null,'anon');check((await query('select public.social_list_stories(null) data'))[0].data,[]);check((await query('select public.social_story_media_readable($1) readable',[ids.a+'/story.jpg']))[0].readable,false);
await actor(ids.b);await deny('select public.social_see_story($1)',[story],'P0002');
await db.exec(`reset role;create table public.marketplace_listings(id uuid primary key default gen_random_uuid(),owner_id uuid references public.profiles(id),title text,price numeric(10,2),status text default 'active',created_at timestamptz default now());insert into public.marketplace_listings(id,owner_id,title,price) values ('${ids.post}','${ids.a}','Anúncio local',100);`);
await db.exec(await readFile(new URL('../supabase/migrations/202611060008_marketplace_improvements.sql',import.meta.url),'utf8'));
await actor(ids.b);await deny('select public.social_change_listing_price($1,$2)',[ids.post,50],'42501');await deny('select public.social_close_listing($1,$2)',[ids.post,'sold'],'42501');
await actor(ids.a);await deny('select public.social_change_listing_price($1,$2)',[ids.post,-5],'22023');await query('select public.social_change_listing_price($1,$2)',[ids.post,80]);let ls=(await query('select public.social_my_listings() data'))[0].data[0];check(Number(ls.previous_price),100);check(Number(ls.price),80);
await query('select public.social_change_listing_price($1,$2)',[ids.post,80]);check(Number((await query('select public.social_my_listings() data'))[0].data[0].previous_price),100);
await query('select public.social_close_listing($1,$2)',[ids.post,'sold']);await deny('select public.social_change_listing_price($1,$2)',[ids.post,70],'42501');
await db.exec(`reset role;create table public.community_places(id uuid primary key,author_id uuid references public.profiles(id),title text,city text,status text);insert into public.community_places values ('${ids.post}','${ids.a}','Praça local','Santo André','approved'),('${ids.hidden}','${ids.a}','Local pendente','Santo André','pending');`);
await db.exec(await readFile(new URL('../supabase/migrations/202611060009_place_participation.sql',import.meta.url),'utf8'));
await actor(null,'anon');await deny('select public.social_checkin_place($1)',[ids.post],'42501');
await actor(ids.b);await deny('select public.social_checkin_place($1)',[ids.hidden],'P0002');await query('select public.social_checkin_place($1)',[ids.post]);await query('select public.social_checkin_place($1)',[ids.post]);let activity=(await query('select public.social_place_activity($1) data',[ids.post]))[0].data;check(activity.places_visited,1);check(activity.visited_today,true);await deny('select * from public.social_place_visits',[],'42501');
await query('select public.social_rate_place($1,$2,$3)',[ids.post,4,'Avaliação em memória para teste.']);activity=(await query('select public.social_place_activity($1) data',[ids.post]))[0].data;const review=activity.reviews[0].id;check(activity.average_rating,null);check(activity.reviews[0].status,'pending');
await actor(ids.c);check((await query('select public.social_place_activity($1) data',[ids.post]))[0].data.reviews,[]);await deny('select public.social_review_place_rating($1,$2,$3)',[review,'approved','Indevido'],'42501');await deny('select public.social_rate_place($1,$2,$3)',[ids.post,6,'Avaliação em memória para teste.'],'22023');
await actor(ids.mod);await query('select public.social_review_place_rating($1,$2,$3)',[review,'approved','Avaliação adequada']);await actor(null,'anon');activity=(await query('select public.social_place_activity($1) data',[ids.post]))[0].data;check(Number(activity.average_rating),4);check(activity.places_visited,0);check('user_id' in activity.reviews[0],false);


await db.exec('reset role;');await db.exec(await readFile(new URL('../supabase/migrations/202611060010_extended_classifieds.sql',import.meta.url),'utf8'));
const clsArgs=['achados','Chaves encontradas','Chaves encontradas em local público para teste local.','Santo André','Centro',null,{report_type:'Achei',category:'Chave',occurred_on:'2026-01-01'},'11999999999',null,true];
await actor(null,'anon');await deny('select public.social_create_classified($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',clsArgs,'42501');
await actor(ids.a);await deny('select public.social_create_classified($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[...clsArgs.slice(0,9),false],'22023');
await deny('select public.social_create_classified($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',['imoveis','Apartamento local','Descrição de imóvel para teste em memória.','Santo André','Centro',2000,{operation:'Aluguel',type:'Apartamento',area:'inválida',bedrooms:2,bathrooms:1,parking:1,condo:0},'11999999999',null,true],'22023');
const classified=(await query('select public.social_create_classified($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) id',clsArgs))[0].id;
await actor(ids.b);check((await query('select public.social_list_classifieds($1,0,false) data',['achados']))[0].data,[]);await deny('select public.social_resolve_classified($1)',[classified],'42501');await deny('select public.social_review_classified($1,$2,$3)',[classified,'approved','Indevido'],'42501');
await actor(ids.mod);await query('select public.social_review_classified($1,$2,$3)',[classified,'approved','Aviso adequado']);
await actor(null,'anon');let cl=(await query('select public.social_list_classifieds($1,0,false) data',['achados']))[0].data[0];check('contact' in cl,false);check('owner_id' in cl,false);await deny('select public.social_classified_contact($1)',[classified],'42501');
await actor(ids.b);check((await query('select public.social_classified_contact($1) contact',[classified]))[0].contact,'11999999999');await deny('select public.social_resolve_classified($1)',[classified],'42501');
for(const person of [ids.a,ids.b,ids.c]){await actor(person);await query('select public.social_report_classified($1,$2)',[classified,'Denúncia em memória']);}
await actor(null,'anon');check((await query('select public.social_list_classifieds($1,0,false) data',['achados']))[0].data,[]);
await actor(ids.mod);await query('select public.social_review_classified($1,$2,$3)',[classified,'approved','Revisto pela equipe']);
await actor(ids.a);await query('select public.social_resolve_classified($1)',[classified]);await actor(null,'anon');check((await query('select public.social_list_classifieds($1,0,false) data',['achados']))[0].data[0].status,'resolved');


await db.exec(`reset role;alter table public.community_posts add column category text default 'Conversa',add column sensitive boolean default false;alter table public.marketplace_listings add column description text default 'Descrição pública',add column category text default 'Casa',add column city text default 'Santo André';create table public.animal_reports(id uuid primary key,animal_name text,report_type text,description text,species text,city text,status text,created_at timestamptz);create table public.community_post_reactions(post_id uuid references public.community_posts(id),user_id uuid references public.profiles(id),created_at timestamptz default now());`);
await db.exec(await readFile(new URL('../supabase/migrations/202611060011_public_search.sql',import.meta.url),'utf8'));
await actor(null,'anon');await deny('select public.social_search_public($1,null,0)',['a'],'22023');
check((await query('select public.social_search_public($1,null,0) data',['Conteúdo pendente']))[0].data,[]);
check((await query('select public.social_top_week() data'))[0].data.every(r=>r.id!==ids.hidden),true);
await db.exec('reset role;');await db.exec(await readFile(new URL('../supabase/migrations/202611060012_recommendations.sql',import.meta.url),'utf8'));
await actor(ids.a);const req=(await query('select public.social_ask_recommendation($1,$2,$3) id',['Tecnologia','Santo André','Preciso de uma recomendação de serviço local.']))[0].id;
await actor(ids.b);check((await query('select public.social_list_recommendations() data'))[0].data,[]);
await actor(ids.mod);await query('select public.social_review_recommendation($1,$2,$3,$4)',['request',req,'approved','Pedido adequado']);await query('select public.social_review_business($1,$2,$3)',[business,'approved','Cadastro conferido']);
await actor(ids.a);await deny('select public.social_recommend_business($1,$2,$3)',[req,business,'Recomendo meu próprio negócio.'],'P0002');
await actor(ids.b);await query('select public.social_recommend_business($1,$2,$3)',[req,business,'Conheço esse negócio e recomendo.']);await query('select public.social_recommend_business($1,$2,$3)',[req,business,'Conheço esse negócio e recomendo.']);let requestRow=(await query('select public.social_list_recommendations() data'))[0].data[0];check(requestRow.answers.length,1);const ans=requestRow.answers[0].id;
await actor(ids.c);check((await query('select public.social_list_recommendations() data'))[0].data[0].answers,[]);await deny('select public.social_review_recommendation($1,$2,$3,$4)',['answer',ans,'approved','Indevido'],'42501');
await actor(ids.mod);await query('select public.social_review_recommendation($1,$2,$3,$4)',['answer',ans,'approved','Indicação adequada']);
await actor(ids.c);await deny('select public.social_accept_recommendation($1)',[ans],'42501');
await actor(ids.a);await query('select public.social_accept_recommendation($1)',[ans]);check((await query('select public.social_recommendation_ranking() data'))[0].data[0].solutions,1);
await db.exec('reset role;');await db.exec(await readFile(new URL('../supabase/migrations/202611060013_utilities.sql',import.meta.url),'utf8'));
await actor(ids.b);await deny('select public.social_save_utility($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[null,'coleta','Informação local','Santo André','Centro','Descrição verificada de teste.','','https://example.com/fonte',null,true],'42501');
await actor(ids.mod);await deny('select public.social_save_utility($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[null,'plantao','Plantão local','Santo André','Centro','Descrição verificada de teste.','','https://example.com/fonte',null,true],'22023');
await query('select public.social_save_utility($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[null,'coleta','Informação local','Santo André','Centro','Descrição verificada de teste.','','https://example.com/fonte',null,true]);
await actor(null,'anon');check((await query('select public.social_list_utilities() data'))[0].data.length,1);


await db.exec('reset role;');await db.exec(await readFile(new URL('../supabase/migrations/202611060014_coupons.sql',import.meta.url),'utf8'));
await actor(ids.a);const coupon=(await query("select public.social_create_coupon($1,$2,$3,1,1,now()+interval '2 days') id",[business,'Benefício de teste','Regras somente para teste em memória.']))[0].id;
await actor(ids.mod);await query('select public.social_review_coupon($1,$2,$3)',[coupon,'approved','Regras verificadas']);
await actor(ids.b);await deny('select public.social_claim_coupon($1)',[coupon],'P0001');
await db.exec('reset role;update public.social_coupon_settings set enabled=true;');
await actor(ids.a);await deny('select public.social_claim_coupon($1)',[coupon],'P0002');
await actor(ids.b);const claim=(await query('select public.social_claim_coupon($1) id',[coupon]))[0].id;check((await query('select public.social_claim_coupon($1) id',[coupon]))[0].id,claim);
await actor(ids.c);await deny('select public.social_claim_coupon($1)',[coupon],'P0001');await deny('select public.social_validate_coupon($1)',[claim],'42501');
await actor(ids.a);check((await query('select public.social_validate_coupon($1) data',[claim]))[0].data.already_used,false);check((await query('select public.social_validate_coupon($1) data',[claim]))[0].data.already_used,true);
await actor(ids.b);check((await query('select public.social_my_coupons() data'))[0].data.length,1);
await actor(ids.c);check((await query('select public.social_my_coupons() data'))[0].data,[]);await deny('select * from public.social_coupon_claims',[],'42501');
await db.exec(`reset role;create role service_role;grant usage on schema auth to service_role;alter table public.profiles add column referral_code text default 'TESTCODE',add column created_at timestamptz default now();create table public.city_reports(id uuid primary key,author_id uuid references public.profiles(id));create table public.service_requests(id uuid primary key,author_id uuid references public.profiles(id));alter table public.animal_reports add column owner_id uuid references public.profiles(id);create table public.city_report_moderators(user_id uuid);create table public.service_providers(user_id uuid);create table public.referral_verifiers(user_id uuid);alter table public.profiles drop constraint profiles_id_fkey;alter table public.profiles add constraint profiles_id_fkey foreign key(id) references auth.users(id) on delete cascade;`);
await db.exec(await readFile(new URL('../supabase/migrations/202611060015_account_privacy.sql',import.meta.url),'utf8'));
await actor(null,'anon');await deny('select public.social_export_my_data()',[],'42501');
await actor(ids.a);const exported=(await query('select public.social_export_my_data() data'))[0].data;check(exported.profile.display_name,'Ana Privado');check(exported.community_posts.every(p=>p.author_id===ids.a),true);check(exported.social_coupon_claims,[]);await deny('select public.social_prepare_account_delete($1)',[ids.b],'42501');await deny('select public.social_request_account_deletion($1)',['sim'],'22023');
const deletionRequest=(await query('select public.social_request_account_deletion($1) id',['EXCLUIR MINHA CONTA']))[0].id;check((await query('select public.social_request_account_deletion($1) id',['EXCLUIR MINHA CONTA']))[0].id,deletionRequest);
await actor(ids.b);check((await query('select public.social_my_account_requests() data'))[0].data,[]);await query('select public.social_cancel_account_deletion($1)',[deletionRequest]);
await actor(ids.a);check((await query('select public.social_my_account_requests() data'))[0].data[0].status,'requested');await query('select public.social_cancel_account_deletion($1)',[deletionRequest]);check((await query('select public.social_my_account_requests() data'))[0].data[0].status,'cancelled');
await actor(ids.mod,'service_role');await deny('select public.social_prepare_account_delete($1)',[ids.mod],'P0001');
await db.exec('reset role;');await db.exec(await readFile(new URL('../supabase/migrations/202611060016_campaign_drafts.sql',import.meta.url),'utf8'));
await actor(ids.b);await deny('select public.social_campaign_drafts_list()',[],'42501');
await actor(ids.mod);await query('select public.social_save_campaign_draft($1,$2,$3,$4,$5,$6,$7)',[null,'sorteio','Campanha em preparação','Rascunho de regras apenas para teste em memória.','Equipe responsável',null,null]);check((await query('select public.social_campaign_drafts_list() data'))[0].data.length,1);


await db.exec('reset role;alter table public.community_posts add column source text;');await db.exec(await readFile(new URL('../supabase/migrations/202611060017_feed_filters_and_deep_links.sql',import.meta.url),'utf8'));
await actor(null,'anon');check((await query('select public.social_public_post($1) data',[ids.hidden]))[0].data,null);check((await query('select public.social_public_post($1) data',[ids.post]))[0].data,null);
await db.exec(`reset role;update public.community_posts set status='approved' where id='${ids.post}';`);
await actor(null,'anon');check((await query('select public.social_public_post($1) data',[ids.post]))[0].data.author_id,null);
await actor(ids.b);check((await query('select public.social_feed_scope($1) ids',['amigos']))[0].ids,[]);
await db.exec(await readFile(new URL('../supabase/migrations/202611060018_reported_content.sql',import.meta.url),'utf8').then(t=>'reset role;'+t));
await actor(ids.b);await deny('select public.social_review_reported_content($1,$2,$3,$4)',['profile',ids.a,'approved','Indevido'],'42501');
for(const person of [ids.b,ids.c,ids.mod]){await actor(person);await query('select public.social_report_content($1,$2,$3)',['profile',ids.a,'Denúncia de perfil em memória']);}
await actor(null,'anon');check((await query('select public.social_public_profile($1) data',['ana_local']))[0].data,null);
await actor(ids.a);await query('select public.social_save_details($1,$2,$3,$4,$5,$6)',['ana_local','Bio editada','Centro',null,true,true]);
await actor(null,'anon');check((await query('select public.social_public_profile($1) data',['ana_local']))[0].data,null);
await actor(ids.mod);check((await query('select public.social_content_report_queue() data'))[0].data.length,1);await query('select public.social_review_reported_content($1,$2,$3,$4)',['profile',ids.a,'approved','Revisão concluída']);
await actor(null,'anon');check((await query('select public.social_public_profile($1) data',['ana_local']))[0].data.first_name,'Ana');
await actor(ids.a);await query('select public.social_save_details($1,$2,$3,$4,$5,$6)',['ana_local','Bio editada','Centro',null,false,true]);
await actor(ids.mod);await query('select public.social_review_reported_content($1,$2,$3,$4)',['profile',ids.a,'approved','Conferindo privacidade']);
await actor(null,'anon');check((await query('select public.social_public_profile($1) data',['ana_local']))[0].data,null);


await db.exec(`reset role;alter table public.city_reports add column category text default 'Relato',add column city text,add column status text default 'pending',add column description text,add column created_at timestamptz default now();alter table public.service_requests add column service_type text default 'Pedido',add column city text,add column status text default 'received',add column description text,add column created_at timestamptz default now();alter table public.community_places add column description text,add column created_at timestamptz default now();`);
await db.exec(await readFile(new URL('../supabase/migrations/202611060019_all_submissions.sql',import.meta.url),'utf8'));
await actor(null,'anon');await deny('select * from public.social_my_submissions(0)',[],'42501');
await actor(ids.a);let ownSubmissions=await query('select * from public.social_my_submissions(0)');check(ownSubmissions.some(s=>s.submission_id===business&&s.submission_type==='empresa'),true);check(ownSubmissions.some(s=>s.submission_id===classified&&s.submission_type==='achados'),true);
await actor(ids.c);check(await query('select * from public.social_my_submissions(0)'),[]);
await db.exec(`reset role;create table public.referral_attributions(referred_user_id uuid,referrer_user_id uuid,email_confirmed_at timestamptz,cpf_verified_at timestamptz,points_awarded_at timestamptz);`);
await db.exec(await readFile(new URL('../supabase/migrations/202611060020_activity_and_badges.sql',import.meta.url),'utf8'));
await actor(ids.a);check((await query('select public.social_my_activity_summary() data'))[0].data.posts,2);
await actor(null,'anon');check((await query('select public.social_member_badges($1) data',[ids.a]))[0].data,[]);await deny('select public.social_my_activity_summary()',[],'42501');

await db.exec('reset role;');
await db.exec(await readFile(new URL('../supabase/migrations/202611060021_business_photos.sql',import.meta.url),'utf8'));
await actor(ids.b);await deny('select public.social_set_business_photos($1,null,$2)',[business,[]],'42501');
await actor(ids.a);await deny('select public.social_set_business_photos($1,$2,$3)',[business,ids.b+'/photo.jpg',[]],'22023');
await db.exec(`reset role;insert into storage.objects values ('submission-media','${ids.a}/logo.webp','{"mimetype":"image/webp","size":100}');alter table public.profiles add column updated_at timestamptz default now();`);
await actor(ids.a);await query('select public.social_set_business_photos($1,$2,$3)',[business,ids.a+'/logo.webp',[]]);
await actor(null,'anon');check((await query('select public.social_list_businesses($1) data',[business]))[0].data,[]);check((await query('select public.social_business_media_readable($1) yes',[ids.a+'/logo.webp']))[0].yes,false);
await actor(ids.mod);await query('select public.social_review_business($1,$2,$3)',[business,'approved','Fotos verificadas']);
await actor(null,'anon');check((await query('select public.social_business_media_readable($1) yes',[ids.a+'/logo.webp']))[0].yes,true);
await db.exec('reset role;');await db.exec(await readFile(new URL('../supabase/migrations/202611060022_profile_editing.sql',import.meta.url),'utf8'));
await actor(ids.a);await deny('select public.social_save_full_profile($1,$2,$3,$4,$5,$6,$7,$8)',['Ana','Cidade inválida','ana_local','','',null,true,false],'22023');
await query('select public.social_save_full_profile($1,$2,$3,$4,$5,$6,$7,$8)',['Ana Atualizada','Santo André','ana_local','Bio','Centro',null,true,false]);
await actor(null,'anon');check((await query('select public.social_public_profile($1) data',['ana_local']))[0].data.first_name,'Ana');
await db.exec('reset role;alter table public.points_ledger add column event_type text,add column evidence_id uuid;alter table public.community_post_reactions add constraint community_post_reactions_pkey primary key(post_id,user_id);');
await db.exec(await readFile(new URL('../supabase/migrations/202611030018_feed_like_received_points.sql',import.meta.url),'utf8'));
await db.exec(await readFile(new URL('../supabase/migrations/202611060023_feed_reactions.sql',import.meta.url),'utf8'));
await db.exec(await readFile(new URL('../supabase/migrations/202611060024_member_connections.sql',import.meta.url),'utf8'));
await db.exec('reset role;update public.community_posts set is_anonymous=false;');await actor(ids.b);await query('select public.social_block_member($1,true)',[ids.a]);check((await query('select public.social_my_blocks() data'))[0].data.length,1);await deny('select public.social_request_friend($1)',[ids.a],'42501');
await actor(ids.b);await deny('select public.social_add_comment($1,$2)',[ids.post,'Interação bloqueada'],'42501');
await actor(ids.c);check((await query('select public.social_my_blocks() data'))[0].data,[]);await deny('select public.social_block_friend($1)',[friendship],'42501');
await db.exec(await readFile(new URL('../supabase/migrations/202611060025_anonymous_media_privacy.sql',import.meta.url),'utf8').then(t=>'reset role;'+t));
await db.exec(`reset role;update public.community_posts set is_anonymous=true,media_path='${ids.a}/anonymous.jpg',media_kind='image' where id='${ids.post}';`);
await actor(null,'anon');const anonymousPost=(await query('select public.social_public_post($1) data',[ids.post]))[0].data;check(anonymousPost.author_id,null);check(anonymousPost.media_path,null);check(Boolean((await query('select public.can_access_feed_media($1) yes',[ids.a+'/anonymous.jpg']))[0].yes),false);
await actor(ids.b);check((await query('select * from public.social_set_reaction($1,$2)',[ids.post,'love']))[0].points_awarded,3);check((await query('select * from public.social_set_reaction($1,$2)',[ids.post,'fire']))[0].points_awarded,0);
check((await query('select public.social_reaction_details($1) data',[ids.post]))[0].data.counts,{fire:1});
await query('select * from public.toggle_community_post_reaction($1)',[ids.post]);check((await query('select * from public.social_set_reaction($1,$2)',[ids.post,'like']))[0].points_awarded,0);
await db.exec('reset role;');check((await query("select count(*)::int n from public.points_ledger where event_type='feed_like_received'"))[0].n,0);
await db.exec(`update public.community_posts set is_anonymous=false where id='${ids.post}';`);
await actor(ids.c);check((await query('select * from public.social_set_reaction($1,$2)',[ids.post,'fun']))[0].points_awarded,3);
await db.exec('reset role;');check((await query("select count(*)::int n from public.points_ledger where event_type='feed_like_received'"))[0].n,1);
console.log(`PASS: ${count} verificações de permissões, privacidade, moderação, idempotência e limite. Banco somente em memória; nenhum dado de produção alterado.`);
} catch(err) { console.error(err.message,err.code);process.exitCode=1; } finally { await db.close(); }




