package br.com.sad.conectaabc;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
