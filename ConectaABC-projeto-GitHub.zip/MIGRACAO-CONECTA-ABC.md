# Migração Conecta ABC — acompanhamento

> Estado consolidado: [docs/layout-migration/ESTADO-ATUAL.md](docs/layout-migration/ESTADO-ATUAL.md). As notas abaixo são históricas; várias pendências antigas já foram resolvidas nas etapas 007–025.

Data: 06/11/2026. Referência completa preservada em `docs/layout-migration/`.
Backup anterior: `tmp/backups/before-layout-20261106.zip` (código, recursos públicos e migrações; não é backup do banco remoto).

## Decisão sobre dados

O proprietário confirmou remover **somente dados fictícios e exemplos**. Nenhuma conta, publicação ou tabela real foi apagada. Não inferir que um texto curto no banco é fictício: a limpeza de registros reais depende de identificar os registros de teste com o proprietário.
O JSX e o SQL do pacote são referências, não substitutos da aplicação nem migrações prontas para produção. Não executar o modelo SQL do pacote sobre o banco existente.

## Estrutura preservada

Next.js 16.4.2, React 19, TypeScript, CSS/Tailwind, exportação estática para Netlify; Supabase Auth, RPCs, RLS e Storage. Capacitor Android/iOS permanece no projeto. Não houve alteração nas credenciais nem nos provedores de autenticação. Nas etapas 2 a 4, o banco recebeu extensões aditivas descritas abaixo.
Rotas preservadas: `/`, `/login`, `/login/complete-profile`, `/login/recovery`, `/verificar`, `/equipe/painel`, `/equipe/validar-indicacoes`, `/termos`, `/privacidade` e manifest.
Módulos já conectados: feed com aprovação, curtidas/denúncias, marketplace/vagas, animais, serviços, relatos da cidade, parceiros, mapa, histórico de pontos, indicações, ranking, carteirinha e moderação por função.

## Entrega desta etapa

- Nova estrutura social em `SocialShell.tsx`: topo centralizado, lateral de ícones no tablet, lateral com nomes no desktop, cinco destinos inferiores no celular.
- Tema preto/amarelo separado em `social-theme.css`; os componentes de envio e autorização existentes foram reaproveitados.
- Início com posts aprovados, filtro de cidade, atalhos, formulário de criação acessível pelo botão +.
- Menu Mais com acesso aos módulos existentes, inclusive serviços, meus envios, portal e mapa.
- Notícias, agenda derivada dos eventos publicados, consulta nas publicações carregadas e coleção de vídeos oficiais.
- Ranking lateral com RPC existente, sem contadores artificiais.
- Remoção dos catálogos de exemplo, pessoa/carteirinha fictícia, selos demonstrativos e caminho de publicação local fictícia.
- Mensagem em português quando falta assunto na postagem; configurações de erro Zod em português.
- Filtros públicos rejeitam explicitamente itens demonstrativos e itens não aprovados.

**Não é a migração completa dos 18 prompts.** Esta é a base visual funcional para testes. A versão pública anterior ainda não foi substituída nesta etapa.

## Mapeamento de todas as áreas

| Referência | Situação encontrada | Trabalho atual / próximo |
|---|---|---|
| Início/feed | Parecido | Novo visual e dados aprovados; stories/presença e blocos mistos ainda pendentes |
| Meu bairro | Não existe filtro estruturado | Criar cadastro/validação de bairro antes do filtro |
| Em alta | Feed tem vídeo, publicação oficial não tem upload | Leitura filtrada pronta; upload oficial e experiência vertical completa pendentes |
| Explorar | Mapa existente | Novo acesso às publicações/áreas; grade multimódulo pendente |
| Pesquisa | Busca no Mercadão | Consulta textual nas publicações carregadas; busca global paginada pendente |
| Notificações | Implementado na etapa 2 | Caixa privada e eventos de comentários, amizade e revisão do feed |
| Perfil | Existe | Visual adaptado, dados reais; bio, capa, salvos e grade pessoal pendentes |
| Amigos | Implementado na etapa 2 | Pedidos, aceite/recusa/cancelamento privados; bloqueio dedicado ainda pendente |
| Convidar | Existe | Link e validação da equipe preservados; não usar validação só por foto |
| Meu nível | Existe com 4 faixas | Preservado; 10 faixas exigem configuração central compartilhada com regras |
| Meu progresso/ranking | Existe | Preservado com livro de pontos; não importar valores de recompensa do protótipo |
| Placar dos bairros | Não existe | Agregação por bairro validado e temporada |
| Carteirinha | Existe com foto e QR real | Preservada; frente/verso e faixa de cores pendentes |
| Parceiros/perfil do parceiro | Existe parcialmente | Reaproveitado; seguir e QR do balcão pendentes |
| Guia de empresas | Parceiros | Reaproveitado; novas categorias e seguimento pendentes |
| Cupons | Clube fechado por decisão anterior | Estoque, resgate atômico e validação por parceiro antes da abertura |
| Mercadão/produto | Existe | Reaproveitado; queda de preço, troca e doação estruturadas pendentes |
| Imóveis | Não existe dedicado | Modelo, filtros, moderação e aviso antifraude |
| Vagas | Dentro do Mercadão | Preservado; regime e candidatura estruturados pendentes |
| Achados e perdidos | Não existe para objetos | Criar publicação e resolução com moderação |
| Animais/detalhes/cadastro | Existe | Reaproveitado; wizard de três passos e fluxo de reencontro pendentes |
| Agenda/evento | Implementado na etapa 4 | Datas, local, presença privada, revisão, cancelamento, link e arquivo de calendário; sem lembrete automático do servidor |
| Notícias/matéria | Feed oficial | Tela por cidade pronta e controles existentes preservados |
| Enquetes | Implementado na etapa 3 | Criação, revisão, voto único, filtros e denúncias |
| Comunidades/detalhe | Implementado na etapa 3 | Criação por pontuação confirmada, participação, posts e moderação |
| Voz do Bairro | Feed anônimo e relatos existentes | Reaproveitar anonimato protegido; categorias dedicadas pendentes |
| Top da semana | Curtidas existentes | Ranking com janela de tempo no servidor |
| Sorteios | Não existe | Regras, elegibilidade e operação ainda não implementadas |
| Melhores do ABC | Não existe | Categorias, fases e voto único no servidor |
| Mapa | Existe e conectado | Preservado; check-in, avaliações e títulos pendentes |
| SAD Indica | Não existe | Pedidos, respostas de empresas e resolução |
| Problemas da cidade | Existe | Reaproveitado com status e moderação |
| Serviços | Existe | Cadastro, pedido e análise preservados |
| Utilidades | Não existe | Fontes verificadas de telefones, plantão e coleta |
| Moderação | Existe por funções | Preservada; ampliar entidades conforme cada módulo entrar |
| Institucional | Termos/privacidade existentes | Preservados; exportação/exclusão de conta precisam de fluxo auditado |
| Mais | Não existia | Criado, mantendo todos os módulos antigos acessíveis |
| Entrar | Existe e Google configurado | Preservado |
| Criar | Formulários separados | Seletor criado com publicação, anúncio/vaga, animal e relato |
| Comentários | Implementado na etapa 2 | Persistência, privacidade, limites e moderação |
| Story | Não existe | Expiração, upload, visualizações e privacidade |
| QR do balcão | Não existe | Validação vinculada à empresa e ao resgate |

Somente no app: painel externo de validação de indicações, consulta pública de carteirinha, permissão por área, serviços sociais e meus envios. Tudo preservado.

## Regras que não podem ser copiadas diretamente

O protótipo concede +100 por convite e pontos por envios, enquanto o app atual exige validação e tem controles contra abuso. A migração visual não altera essas regras. QR ilustrativo do protótipo não substitui o QR verificável. Não importar o botão de modo administrador do protótipo: acesso continua dependendo do servidor. Não simular clima, pessoas online, comentários, estoques, amizades ou eventos.

## Próximas etapas técnicas

1. Validar esta base visual com os fluxos autenticados existentes em ambiente de homologação.
2. Extrair componentes/dados de `page.tsx`; criar banco de homologação para novas migrações e testes de RLS.
3. Implementar comentários, salvos, amizades, perfil e notificações, com testes de proprietário/moderador/anônimo.
4. Adicionar configuração de níveis/temporadas e metas sem alterar as regras antifraude de indicações.
5. Implementar cupons transacionais, empresas, grupos, enquetes e agenda estruturada.
6. Implementar classificados novos, utilidades e engajamento. Sorteios/prêmios só com regras operacionais definidas.
7. Testar autenticação, confirmação de e-mail, uploads, moderação, permissões, links externos, desempenho, PWA e Capacitor; publicar após resolver os bloqueios encontrados.

## Verificações desta etapa

- 17 testes unitários passam (validação, autenticação e filtros públicos).
- Build estático passa (13 páginas geradas).
- Navegador: posts reais carregados, sem erro de console na abertura; menu de criação abre; campo vazio foi identificado e corrigido.
- Ainda não foi feito teste ponta a ponta autenticado de cadastro, upload, aprovação e pontuação nesta versão. Nenhum teste criou conteúdo no banco de produção.

Prévia local: `http://localhost:3100` (servidor iniciado com 
ode tmp/serve-layout.cjs`, servindo `out/`). Recompilar com `pnpm build` e atualizar o navegador depois de mudar o código. A prévia usa a configuração Supabase existente; envios válidos vão ao banco configurado.

Revisão visual concluída: celular 390×844 e desktop 1440×900, sem transbordamento horizontal na página inicial. Foram abertos 12 módulos pelo menu Mais. Campo de assunto vazio confirmado com a mensagem “Escolha o tipo de publicação.”. Capturas em `docs/layout-migration/preview-mobile.png` e `preview-desktop.png`.

## Etapa 2 — interações sociais (06/11/2026)

Implementadas: comentários com revisão da equipe, lista privada de salvos, busca de membros por primeiro nome, convite/aceite/recusa/cancelamento de amizade e notificações privadas. Os comentários não pontuam automaticamente. As regras anteriores de pontos/indicações permanecem.

**Banco remoto:** `202611060001_social_interactions.sql` executada no Supabase Conecta ABC (`rqpnyxphbhipkqrnrnxd`), com resultado `Success. No rows returned`. Foram acrescentadas cinco tabelas com RLS e acesso direto revogado, RPCs restritas e um gatilho para avisar o autor quando seu post for aprovado/rejeitado. Nenhum registro antigo foi apagado. Esta migração é de execução única; não repetir sobre tabelas já criadas.

**Interface:** ações Comentários e Salvar nos posts aprovados; Amigos/Salvos no menu e Mais; notificações no sino; painel de comentários em `/equipe/comentarios`, ligado ao painel externo e à Administração. A prévia em localhost consulta as novas funções reais. O site público ainda não recebeu esta atualização visual.

**Permissões e limites:** somente o destinatário aceita/recusa convite; salvos/notificações só são retornados ao titular; comentários pendentes/rejeitados só aparecem ao próprio autor (ou na fila autorizada); não há consulta de e-mails/CPF/telefone nas amizades; cada par tem no máximo uma amizade; 20 convites/24h; 5 comentários/minuto e 30/24h. Pedidos encerrados não podem ser reenviados nesta versão, evitando insistência automática. Consultas têm limites de 100 comentários/notificações e 200 salvos/amizades; paginação futura ainda necessária.

**Verificação:** 29 asserções PostgreSQL em memória passaram em `scripts/test-social-db.mjs` (negativas de acesso, isolamento por usuário, idempotência, ocultação de conteúdo e limites), além dos 17 testes existentes. A fixture usa as colunas de dependência da migração, não é uma cópia integral do banco remoto. Leitura anônima de comentários conferida na prévia contra o Supabase real, sem erro de console. Testes autenticados ponta a ponta de criação/aceite/aprovação na interface ainda dependem de uma sessão de teste autenticada. Não foi criada conta fictícia nem publicação fictícia na produção.

Para repetir o teste SQL isolado:

```powershell
pnpm --dir tmp/social-db-test --ignore-workspace add @electric-sql/pglite@0.5.15 --store-dir .pnpm-store
node scripts/test-social-db.mjs
```

**Ainda pendentes do pacote:** stories/presença, enquetes, grupos, cupons e estoque, guia avançado de empresas, agenda estruturada, novos classificados, 10 níveis configuráveis/temporadas, check-in e avaliações no mapa, utilidades verificadas e recursos de sorteio/premiação. O arquivo de referência não foi executado para simular esses recursos.

## Etapa 3 — enquetes e comunidades (06/11/2026)

Migração `202611060002_polls_and_groups.sql` aplicada no Supabase Conecta ABC com resultado `Success. No rows returned`. A primeira tentativa reenviou SQL anterior acumulado no editor e falhou em tabela já existente; substituído o conteúdo completo, somente a nova migração foi executada com sucesso. Nenhuma tabela foi apagada.

- Enquetes: 2 a 6 opções distintas, prazo de 30 minutos a 30 dias, máximo de três criações por 24 horas; voto único e imutável por conta, apuração agregada, sem divulgar quem votou.
- Comunidades: participar é livre; criar exige 1.500 pontos confirmados ou função de moderador, no máximo uma criação por sete dias. O limite está em social_hub_settings; não altera níveis ou pontos anteriores. Publicações exigem participação e revisão, até dez por 24 horas.
- Denúncias: três contas distintas ocultam conteúdo para revisão; a equipe registra motivo e decisão. Denúncias já analisadas não são contadas novamente.
- Painel `/equipe/comunidades` e botão na Administração. Filas e RPCs exigem moderação no servidor.
- Navegador: consultas públicas das duas áreas funcionaram sem erro; login exigido para criar. Nenhum grupo/enquete fictício foi inserido na produção.

## Etapa 4 — agenda estruturada (06/11/2026)

Migração `202611060003_community_events.sql` aplicada no mesmo Supabase com resultado `Success. No rows returned`. Três tabelas com RLS e acesso direto revogado; funções públicas retornam somente campos necessários, sem identidade dos participantes. A revisão mantém auditoria.

- Criar evento com título, descrição, cidade, local público, início e término; três envios por 24 horas e revisão antes de publicar.
- Confirmar/remover presença de forma idempotente. Não é reserva de ingresso e não concede pontos.
- Responsável pode cancelar; terceiros não podem. Cancelamento de um rascunho não publica seus dados. Eventos cancelados não reabrem.
- Link externo próprio; consulta pelo ID funciona independentemente das 200 entradas da listagem. Arquivo ICS seguro para importar no calendário do aparelho. Lembretes dependem da configuração desse calendário; não há agendador de e-mails/push. Arquivo baixado não recebe cancelamentos automaticamente.
- Publicações antigas de eventos continuam visíveis abaixo da agenda, sem inferir datas ou migrar textos para registros inventados.
- Painel `/equipe/agenda` e acesso pela Administração para análise.

## Estado consolidado para testes

- 65 verificações PostgreSQL em memória e 21 testes Vitest passaram; TypeScript e build estático passaram (16 páginas).
- Prévia: enquetes, comunidades e agenda consultadas contra o banco real; agenda conferida em 390×844 sem transbordamento horizontal, sem erros de console e com exigência de login para divulgar. Captura em `docs/layout-migration/preview-agenda-mobile.png`.
- Não foram apagados usuários ou registros reais; não foram inseridos exemplos em produção.
- Banco remoto atualizado; frontend novo permanece na prévia local. A versão pública anterior NÃO foi substituída.
- Faltam testes autenticados ponta a ponta de envio, votação, aceite e moderação na interface. Os testes isolados de regras não substituem esses testes.
- Limites atuais de listagem: 100 enquetes/grupos/posts/filas, 200 eventos. Paginação completa ainda pendente.
- Próximos módulos do ZIP: stories/presença, perfil com bio/capa, upload oficial de vídeos, cupons/estoque/QR do parceiro, novos classificados, níveis/temporadas configuráveis, avaliações/check-ins, utilidades e campanhas. Clube de benefícios continua fechado. A migração integral ainda não está concluída.

Verificação final: lint dos componentes novos, páginas novas e utilitários da agenda passou sem erros. Agenda também conferida em desktop 1440×900 sem transbordamento; link de evento inexistente retorna mensagem apropriada e permite voltar à agenda completa. Pacote de prévia atualizado: `out-layout-social-20261106.zip`.

## Etapa 5 — perfil, níveis e mídia oficial (em construção)

Arquivos implementados: `CommunityProfile.tsx`, `OfficialMediaPublisher.tsx`, `LevelFeatures.tsx`, hooks de recursos e upload; integrados ao perfil, carteirinha, progresso e administração. Perfil público por `/?area=membro&usuario=nome`; bio, bairro, capa, publicação opcional do perfil e atividade recente opcional. Fotos respeitam a opção pública anterior. Publicações anônimas não aparecem na grade pessoal.

Carteirinha tem frente/verso, QR verificável e cores por faixa. Dez níveis preservam as quatro faixas anteriores; saldo calculado no servidor sobre todo o livro de pontos. Ranking mensal consulta o histórico sem zerar saldo. Publicação oficial aceita imagem/vídeo com autorização conferida no servidor. O envio de vídeo por moradores continua no feed comum, conforme autorização anterior; Em alta permanece para conteúdo oficial.

**Migração `202611060004_profiles_levels_official.sql` NÃO aplicada no banco remoto.** Foi validada em PostgreSQL isolado; 79 verificações passam. TypeScript e lint dos novos componentes passaram. O frontend dessa etapa exige a migração antes de ser publicado. Nenhum dado fictício ou real foi inserido/apagado em produção nessa etapa.

**Pendências atuais:** aplicar 004 e validar com sessão autenticada; terminar guia de empresas/cupons e os demais módulos do inventário. A tabela de solicitações de exclusão está preparada, mas seu fluxo ainda não foi implementado. Não anunciar a migração completa como concluída.

## Acabamento da referência visual — início

Página inicial ajustada após conferência do artefato original: coluna central de 470px no tablet, atalhos circulares com anel amarelo, data, ações principais, cartão de progresso e descoberta entre posts. Destaques da agenda e grupos usam somente registros aprovados reais. Os atalhos circulares são navegação de módulos; stories ainda não foram implementados. Campanha Fundador e clima ilustrativo do protótipo não foram inventados na interface.

HomeOverview.tsx adicionado. TypeScript, lint do componente, 21 testes e build passaram. Conferido no navegador em localhost:3100, com leitura real de três posts, nenhum evento estruturado e sem conteúdo de exemplo. Captura: docs/layout-migration/preview-home-reference.png. Alteração somente local; publicação e migração 004 ainda pendentes.

## Etapa 6 — guia e portal de empresas

Implementado BusinessDirectory.tsx com 18 categorias, filtros por cidade/categoria, busca na página, paginação de 24 registros, perfil comercial, WhatsApp e Instagram opcionais, seguidores e QR do balcão com link externo real. O portal permite cadastrar até três negócios por conta e editar somente os próprios; alterações voltam à análise. Fila de empresas ligada à Administração e ao painel externo. Os pedidos antigos de parceiros em service_requests permanecem acessíveis em “Solicitações anteriores e contato com a equipe”. Nenhum cadastro antigo foi convertido automaticamente em empresa aprovada.

Migrações 004 (perfil/níveis/mídia oficial), 005 (empresas) e 006 (validação de configuração dos níveis) aplicadas no Supabase existente com resultado “Success. No rows returned”. A 006 rejeita configuração nula/incompleta antes de substituir as faixas. Capturas das aplicações em docs/layout-migration/banco-etapa5.png e banco-etapa6.png. Nenhum dado real foi excluído e nenhum exemplo foi inserido na produção.

95 verificações de PostgreSQL isolado passaram, além de 21 testes Vitest. Build e lint do componente passaram. Navegador: guia consultado contra banco real, 18 categorias e estado vazio correto; portal oferece autenticação para cadastrar. Fluxos autenticados de envio/aprovação/seguimento ainda precisam de teste na interface. Testes de regra isolados cobrem proprietário, anônimo, terceiros, moderação, consentimento e seguimento idempotente.

Clube e cupons continuam fechados por decisão anterior. Estoque transacional, resgate e validação de cupons ainda não foram implementados; o atalho apresenta o estado de fechamento e acesso ao guia, sem pagamento ou benefício simulado. Frontend atualizado somente na prévia local; não houve publicação no Netlify nesta etapa.


## Publicação consolidada das etapas 007–025
Atualização publicada no Netlify: 6aee256cc0384f7506b66326, domínio https://conectaabc.com/. Recursos, decisões, limitações e verificações em docs/layout-migration/ESTADO-ATUAL.md. Banco e saldos reais preservados; campanhas e clube desativados.
